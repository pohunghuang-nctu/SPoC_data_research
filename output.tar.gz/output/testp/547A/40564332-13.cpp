
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long m, x1, x2, y1, y2, h1, h2, a1, a2; // create long long integers m, x1, x2, y1, y2, h1, h2, a1, and a2
  cin >> m; // read m
  cin >> h1 >> a1; // read h1 and a1
  cin >> x1 >> y1; // read x1 and y1
  cin >> h2 >> a2; // read h2 and a2
  cin >> x2 >> y2; // read x2 and y2
  vector<int> ans1; // create integer vector ans1
  vector<int> ans2; // create integer vector ans2
  long long total = 0; // create long long integer total = 0
  while (total < 2 * m) { // while total is less than 2 * m
    if (h1 == a1) { ans1.push_back(total); } // if h1 is equal to a1, append total to ans1
    if (h2 == a2) { ans2.push_back(total); } // if h2 is equal to a2, append total to ans2
    total++; // increment total
    h1 = (h1 * x1 + y1) % m; // set h1 to the result of (h1 * x1 + y1) % m
    h2 = (h2 * x2 + y2) % m; // set h2 to the result of (h2 * x2 + y2) % m;
  } 
  if (ans1.empty() || ans2.empty()) { // if ans1.empty() is truthy or ans2.empty() is truthy
    cout << "-1" << endl; // print "-1"
    return 0; 
  } 
  long long t1 = ans1[0], t2 = ans2[0]; // create long long integers t1 = ans1[0] and t2 = ans2[0]
  long long s1 = ans1[1] - ans1[0]; // create long long integer s1 = ans1[1] - ans1[0]
  long long s2 = ans2[1] - ans2[0]; // create long long integer s2 = ans2[1] - ans2[0]
  for (int i = 0; i <= 5e6; i++) { // for i = 0 to 5e6
    if (t1 == t2) { // if t1 is equal to t2
      cout << t1 << endl; // print t1
      return 0; 
    } 
    if (t1 < t2) { // if t1 is less than t2
      t1 += s1; // set t1 to t1 + s1
    } else { // else
      t2 += s2; // set t2 to t2 + s2
    } 
  } 
  cout << "-1" << endl; // print "-1"
  return 0; 
} 