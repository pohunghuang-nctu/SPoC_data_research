
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long vis1[1000005]; // vis1 = array of long integers of length 1000005
long long vis2[1000005]; // vis2 = array of long integers of length 1000005
int main() { 
  long long m; // let m be a long integer
  long long h1, a1; // let h1, a1 be long integers
  long long x1, y1; // let x1, y1 be long integers
  long long h2, a2; // let h2, a2 be long integers
  long long x2, y2; // let x2, y2 be long integers
  cin >> m >> h1 >> a1 >> x1 >> y1 >> h2 >> a2 >> x2 >> y2; // read m, h1, a1, x1, y1, h2, a2, x2, y2
  memset(vis1, 0, sizeof(vis1)); // memset of vis1, 0, size of vis1
  memset(vis2, 0, sizeof(vis2)); // memset of vis2, 0, size of vis2
  long long t1 = -1, t2 = -1; // let t1, t2 be long integers with t1 = -1, t2 = -1
  long long c1 = -1, c2 = -1; // let c1, c2 be long integers with c1 = -1, c2 = -1
  long long q1 = -1, q2 = -1; // let q1, q2 be long integers with q1 = -1, q2 = -1
  long long f1 = -1, f2 = -1; // let f1, f2 be long integers with f1 = -1, f2 = -1
  bool flag = true; // set boolean value flag to true
  bool fuck = false; // set boolean value fuck to false
  for (long long i = 1; i <= 2 * m; i++) { // for long integer i = 1 to 2 * m inclusive
    h1 *= x1; // the value of h1 = h1 * x1
    h1 %= m; // the value of h1 = h1 modulo m
    h1 += y1; // the value of h1 = h1 + y1
    h1 %= m; // the value of h1 = h1 modulo m
    h2 *= x2; // the value of h2 = h2 * x2
    h2 %= m; // the value of h2 = h2 modulo m
    h2 += y2; // the value of h2 = h2 + y2
    h2 %= m; // the value of h2 = h2 modulo m
    if (h1 == a1 && a2 == h2) { // if h1 is equal to a1 and a2 is equal to h2
      fuck = true; // set fuck to true
      cout << i << endl; // print i and newline
      break; // stop
    } 
    if (vis1[a1] == 0 && h1 == a1) { f1 = i; } // if vis1[a1] is equal to 0 and h1 is equal to a1, f1 is equal to i
    if (vis2[a2] == 0 && h2 == a2) { f2 = i; } // if vis2[a2] is equal to 0 and h2 is equal to a2, f2 is equal to i
    if (h1 == a1 && t1 == -1) { c1 = i; } // if h1 is equal to a1 and t1 is equal to -1, c1 is equal to i
    if (h2 == a2 && t2 == -1) { c2 = i; } // if h2 is equal to a2 and t2 is equal to -1, c2 is equal to i
    if (vis1[h1] != 0 && q1 == -1) { // if vis1[h1] is not equal to 0 and q1 is equal to -1
      q1 = vis1[h1]; // the value of q1 is equal to vis1[h1]
      t1 = i - q1; // the value of t1 is equal to i - q1
      if (c1 < q1) { // if c1 is less than q1
        flag = false; // set flag to false
        break; // stop
      } else { // else do the following
        c1 = c1 - q1; // decrement c1 by q1
      } 
    } 
    if (vis2[h2] != 0 && q2 == -1) { // if vis2[h2] is not equal to 0 and q2 is equal to -1
      q2 = vis2[h2]; // the value of q2 is equal to vis2[h2]
      t2 = i - q2; // the value of t2 is equal to i - q2
      if (c2 < q2) { // if c2 is less than q2
        flag = false; // set flag to false
        break; // stop
      } else { // else do the following
        c2 = c2 - q2; // decrement c2 by q2
      } 
    } 
    if (t1 != -1 && t2 != -1) { break; } // if t1 is not equal to -1 and t2 is not equal to -1, stop
    if (vis1[h1] == 0) vis1[h1] = i; // if vis1[h1] is equal to 0, vis1[h1] is equal to i
    if (vis2[h2] == 0) vis2[h2] = i; // if vis2[h2] is equal to 0, vis2[h2] is equal to i
  } 
  if (fuck) { // if fuck is true
  } else if (!flag) { // else if not flag
    if (f1 != f2 || f1 == -1 || f2 == -1) // if f1 is not equal to f2 or f1 is equal to -1 or f2 is equal to -1
      cout << "-1\n"; // print -1 and newline
    else // else do the following
      cout << f1 + 1 << "\n"; // print f1 + 1 and newline
  } else { // else do the following
    if (f1 == f2 && f1 != -1 && f2 != -2) { // if f1 is equal to f2 and f1 is not equal to -1 and f2 is not equal to -2
      cout << f1 << "\n"; // print f1 and newline
    } else if (t1 == t2 && ((c1 == c2 && f1 != f2) || c1 != c2)) { // else if t1 is equal to t2 and (c1 is equal to c2 and f1 is not equal to f2) or c1 is not equal to c2
      cout << "-1\n"; // print -1 and newline
    } 
    else { // else do the following
      long long x = 0; // let x be a long integer with x = 0
      while ((x * t1 + c1 + q1 - c2 - q2) % t2 != 0) { // while x * t1 + c1 + q1 - c2 - q2 modulo t2 is not equal to 0
        x++; // increment x by 1
        if (x > 1000000) { break; } // if x is greater than 1000000, stop
      } 
      if (x > 1000000) { // if x is greater than 1000000
        cout << "-1" << endl; // print -1 and newline
      } else // else do the following
        cout << x * t1 + c1 + q1 << "\n"; // print x * t1 + c1 + q1 and newline
    } 
  } 
  return 0; 
} 