
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long m, h[2], a[2], x[2], y[2]; // n = long long and h, a, x, y = long long array of size 2 each
long long vis[1000001][2]; // vis = two dimensional long long array of sizes 1000001 and 2
vector<long long> b[2]; // b = long long vector array of size 2
long long ans[2][2]; // ans = two dimensional long long array of sizes 2 and 2
long long val[1000001][2]; // val = two dimensional long long array of sizes 1000001 and 2
long long pass(long long i) { // in function pass taking a long long i and returning a long long
  vis[h[i]][i] = 1; // set vis[h[i]][i] to 1
  val[h[i]][i] = 1; // set val[h[i]][i] to 1
  long long va = 2; // va = long long with va = 2
  b[i].push_back(h[i]); // append h[i] to b[i]
  while (vis[h[i]][i] == 1) { // loop while vis[h[i]][i] is 1
    h[i] = (x[i] * h[i] + y[i]) % m; // set h[i] to (x[i] * h[i] + y[i]) mod m
    b[i].push_back(h[i]); // append h[i] to b[i]
    if (vis[h[i]][i] == 0) { // if vis[h[i]][i] is 0
      vis[h[i]][i]++; // increment vis[h[i]][i]
      val[h[i]][i] = va; // set val[h[i]][i] to va
      va++; // increment va
    } else { // else
      ans[i][0] = val[h[i]][i] - 1; // set ans[i][0] to val[h[i]][i] - 1
      ans[i][1] = va - val[h[i]][i]; // set ans[i][1] to va - val[h[i]][i]
      return 0; 
    } 
  } 
} 
int main() { 
  cin >> m >> h[0] >> a[0] >> x[0] >> y[0] >> h[1] >> a[1] >> x[1] >> y[1]; // read m then h[0] then a[0] then x[0] then y[0] then h[1] then a[1] then x[1] then y[1]
  pass(0); // call pass of 0
  pass(1); // call pass of 1
  if (vis[a[0]][0] == 0 || vis[a[1]][1] == 0) { // if vis[a[0]][0] or vis[a[1]][1] is 0
    cout << -1 << endl; // print -1
    return 0; 
  } 
  long long va1 = val[a[0]][0], va2 = val[a[1]][1]; // va1, va2 = long long with va1 = val[a[0]][0] and va2 = val[a[1]][1]
  long long cy1 = ans[0][1], cy2 = ans[1][1]; // cy1, cy2 = long long with cy1 = ans[0][1] and cy2 = ans[1][1]
  if (val[a[0]][0] == val[a[1]][1]) { // if val[a[0]][0] is val[a[1]][1]
    cout << val[a[0]][0] - 1 << endl; // print val[a[0]][0] - 1
    return 0; 
  } 
  if (val[a[0]][0] <= ans[0][0] && val[a[1]][1] <= ans[1][0]) { // if val[a[0]][0] is less or equal to ans[0][0] and val[a[1]][1] is less or equal to ans[1][0]
    cout << -1 << endl; // print -1
    return 0; 
  } else if (val[a[0]][0] <= ans[0][0] || val[a[1]][1] <= ans[1][0]) { // else if val[a[0]][0] is less or equal to ans[0][0] or val[a[1]][1] is less or equal to ans[1][0]
    long long mo = abs(val[a[1]][1] - val[a[0]][0]); // mo = long long with mo = absolute of val[a[1]][1] - val[a[0]][0]
    if (val[a[0]][0] > val[a[1]][1] && val[a[0]][0] <= ans[0][0]) { // if val[a[0]][0] is greater than val[a[1]][1] and val[a[0]][0] is less or equal to ans[0][0]
      if (mo % ans[1][1] == 0) // if mo is a multiple of ans[1][1]
        cout << val[a[0]][0] - 1 << endl; // print val[a[0]][0] - 1
      else // else
        cout << -1 << endl; // print -1
    } else if (val[a[0]][0] < val[a[1]][1] && val[a[1]][1] <= ans[1][0]) { // else if val[a[0]][0] is less than val[a[1]][1] and val[a[1]][1] is less or equal to ans[1][0]
      if (mo % ans[0][1] == 0) // if mo is a multiple of ans[0][1]
        cout << val[a[1]][1] - 1 << endl; // print val[a[1]][1] - 1
      else // else
        cout << -1 << endl; // print -1
    } else { // else
      cout << -1 << endl; // print -1
    } 
    return 0; 
  } 
  if (abs(va1 - va2) % __gcd(cy1, cy2) != 0) { // if absolute of va1 - va2 mod __gcd of cy1 and cy2 is not 0
    cout << -1 << endl; // print -1
    return 0; 
  } 
  for (long long i = 0; i < 1000001; i++) { // for i = 0 to 1000001
    long long va = va1 - va2 + i * cy1; // va = long long with va = va1 - va2 + i * cy1
    if (va % cy2 == 0 && va >= 0) { // if va is a multiple of cy2 and va is greater or equal to 0
      cout << va1 + i * cy1 - 1 << endl; // print va1 + i * cy1 - 1
      return 0; 
    } 
  } 
  return 0; 
} 