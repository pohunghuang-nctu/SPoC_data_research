
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int m, h, h2, a, a2, x, x2, y, y2; // create integers m, h, h2, a, a2, x, x2, y, y2
int get(int s, int e) { // declare get with integers s, e as arguments, returning integer
  for (int i = 0; i < m; ++i) { // for i = 0 to m exclusive
    s = (1ll * s * x + y) % m; // set s to (1ll * s * x + y ) % m
    if (s == e) return i + 1; // if s is e, return i + 1
  } 
  return -1; // return -1 from function
} 
int get2(int s, int e) { // declare get2 with integers s, e as arguments, returning integer
  for (int i = 0; i < m; ++i) { // for i = 0 to m exclusive
    s = (1ll * s * x2 + y2) % m; // set s to (1ll * s * x2 + y2 ) % m
    if (s == e) return i + 1; // if s is e, return i + 1 from function
  } 
  return -1; // return -1 from function
} 
int main() { 
  cin >> m >> h >> a >> x >> y >> h2 >> a2 >> x2 >> y2; // read m read h read a read x read y read h2 read a2 read x2 read y2
  int t = get(h, a), t2 = get2(h2, a2); // create integers t, t2 with t = result of run get with h, a as arguments, t2 = result of run get2 with h2, a2 as arguments
  if (t == -1 || t2 == -1) return cout << "-1\n", 0; // if t is -1 or t2 is -1, return print "-1\n", 0 from function
  if (t == t2) return cout << t << '\n', 0; // if t is t2, return print t print '\n', 0 from function
  int l = get(a, a), l2 = get2(a2, a2); // create integers l, l2 with l = result of run get with a, a as arguments, l2 = result of run get2 with a2, a2, as arguments
  if (~l && t2 - t >= 0 && !((t2 - t) % l)) return cout << t2 << '\n', 0; // if bitwise not l and t - t2 is greater than or equal to 0 and not ( (t-t2)%l2), return print t print '\n', 0 from function
  if (~l2 && t - t2 >= 0 && !((t - t2) % l2)) return cout << t << '\n', 0; // if bitwise not l2 and t - t2 is greater than or equal to 0 and not ( (t-t2) % l2 ), return print t print '\n', 0 from function
  if (l == -1 || l2 == -1) return cout << "-1\n", 0; // if l is -1 or l2 is -1, return print "-1\n", 0
  int val = t2 - t; // create integer val with val = t2 - t
  for (int i = 1, lim = m << 1; i <= lim; ++i) // for i =1, lim = m bitshift left 1 to i is less than or equal to lim, incrementing i
    if (val + 1ll * i * l2 >= 0 && !((val + 1ll * i * l2) % l)) return cout << 1ll * i * l2 + t2 << '\n', 0; // if (val + 1ll * i * l2 is greater than or equal to 0 and not ((val + 1ll * i * l2) % l)) return print 1ll * i * l2 + t2 print '\n', 0 from function
  cout << "-1\n"; // print "-1\n"
  return 0; 
} 