
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long x, y; // create long longs x, y
long long exgcd(long long a, long long b) { // declare exgcd with long longs a, b as arguments returning long long
  if (b == 0) { // if b is 0
    x = 1; // set x to 1
    y = 0; // set y to 0
    return a; // return a from function
  } 
  long long d = exgcd(b, a % b); // crate long long d with d = result of run exgcd with b, a % b as arguments
  long long t = x; // create long long t with t = x
  x = y; // set x to y
  y = t - a / b * y; // set y to t - a / b * y
  return d; // return d from function
} 
int main() { 
  long long m, h1, a1, x1, y1, h2, a2, x2, y2; // create long longs m, h1, a1, x1, y1, h2, a2, x2, y2
  long long p1, p2, q1, q2; // create long longs p1, p2, q1, q2
  while (cin >> m >> h1 >> a1 >> x1 >> y1 >> h2 >> a2 >> x2 >> y2) { // while read m read h1 read a1 read x1 read y1 read h2 read a2 read x2 read y2 is true
    p1 = p2 = q1 = q2 = 0; // set p1 to p2 to q1 to q2 to 0
    for (long long i = 1; i <= 2 * m; i++) { // for i = 1 to 2 * m inclusive
      h1 = (h1 * x1 + y1) % m; // set h1 to (h1 * x1 + y1) % m
      if (h1 == a1) { // if h1 is a1
        if (p1 == 0) // if p1 is 0
          p1 = i; // set p1 to i
        else if (q1 == 0) { // else if q1 is 0
          q1 = i - p1; // set q1 to i - p1
          break; // break loop
        } 
      } 
    } 
    for (long long i = 1; i <= 2 * m; i++) { // for i = 1 to 2 * m inclusive
      h2 = (h2 * x2 + y2) % m; // set h2 to (h2 * x2 + y2) % m
      if (h2 == a2) { // if h2 is a2
        if (p2 == 0) // if p2 is 0
          p2 = i; // set p2 to i
        else if (q2 == 0) { // else if q2 is 0
          q2 = i - p2; // set q2 to i - p2
          break; // break loop
        } 
      } 
    } 
    long long d = exgcd(q1, -q2); // create long long d with d = result of run exgcd with q1, -q2 as arguments
    long long c = p2 - p1; // create long long c with c = p2 - p1
    if (d == 0) { // if d is 0
      puts("-1"); // print "-1"
      continue; // break current loop iteration
    } 
    if (c % d) { // if c % d
      puts("-1"); // print "-1"
      continue; // break current loop iteration
    } 
    if (p1 == 0 || p2 == 0) { // if p1 is 0 or p2 is 0
      puts("-1"); // print "-1"
      continue; // break current loop iteration
    } 
    if (q2 == 0 && q1 == 0 && p1 != p2) { // if q2 is 0 and q1 is 0 and p1 is not p2
      puts("-1"); // print "-1"
      continue; // break current loop iteration
    } 
    if ((q2 == 0 && p2 - p1 < 0) || (q1 == 0 && p1 - p2 < 0)) { // if ( q2 is 0 and p2 - p1 is less than 0 ) or ( q2 is 0 and p1 - p2 is less than 0 )
      puts("-1"); // print "-1"
      continue; // break current loop iteration
    } 
    long long k = c / d; // create long long k with k = c / d
    x *= k; // set x to x * k
    y *= k; // set y to y * k
    if (d < 0) d = -d; // if d is less than 0, set d to -d
    if (x < 0 || y < 0) { // if x is less than 0 or y is less than 0
      while (1) { // while 1 is true
        x += q2 / d; // increment x by q2 / d
        y += q1 / d; // increment y by q1 / d
        if (x >= 0 && y >= 0) break; // if x is greater than or equal to 0 and y is greater than or equal to 0, break loop
      } 
    } 
    if (x > 0 && y > 0) { // if x is greater than 0 and y is greater than 0
      while (1) { // while 1 is true
        x -= q2 / d; // decrement x by q2 / d
        y -= q1 / d; // decrement y by q1 / d
        if (x < 0 || y < 0) break; // if x is less than 0 or y is less than 0, break loop
      } 
      x += q2 / d; // increment x by q2 / d
      y += q1 / d; // increment y by q1 / d
    } 
    long long ans = x * q1 + p1; // create long long ans with ans = x * q1 + p1
    cout << ans << endl; // print ans print newline
  } 
  return 0; 
} 