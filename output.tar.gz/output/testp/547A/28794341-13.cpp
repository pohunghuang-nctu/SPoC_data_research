
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long x, y; // create long long integers x and y
long long exgcd(long long a, long long b) { // declare exgcd taking in long long integers a and returning long longand b
  if (b == 0) { // if b is equal to 0
    x = 1; // set x to 1
    y = 0; // set y to 0
    return a; // return a
  } 
  long long d = exgcd(b, a % b); // create long long d = exgcd(b, a % b)
  long long t = x; // create long long t = x
  x = y; // set x to y
  y = t - a / b * y; // set y to the result of t - a / b * y
  return d; // return d
} 
int main() { 
  long long m, h1, a1, x1, y1, h2, a2, x2, y2; // create long long integers m, h1, al, x1, y1, h2, a2, x2, y2
  long long p1, p2, q1, q2; // create long long integers p1, p2, q1, q2
  while (cin >> m >> h1 >> a1 >> x1 >> y1 >> h2 >> a2 >> x2 >> y2) { // while cin >> m >> h1 >> a1 >> x1 >> y1 >> h2 >> a2 >> x2 >> y2 is truthy
    p1 = p2 = q1 = q2 = 0; // set p1, p2, q1, and q1 to 0
    for (long long i = 1; i <= 2 * m; i++) { // for i = 1 to 2 * m
      h1 = (h1 * x1 + y1) % m; // set h1 to (h1 * x1 + y1) % m
      if (h1 == a1) { // if h1 is equal to a1
        if (p1 == 0) // if p1 is equal to 0
          p1 = i; // set p1 to i
        else if (q1 == 0) { // else if q1 is equal to 0
          q1 = i - p1; // set q1 to the result of i - p1
          break; // break loop
        } 
      } 
    } 
    for (long long i = 1; i <= 2 * m; i++) { // for i = 1 to 2 * m
      h2 = (h2 * x2 + y2) % m; // set h2 to the result of (h2 * x2 + y2) % m
      if (h2 == a2) { // if h2 is equal to a2
        if (p2 == 0) // if p2 is equal to 0
          p2 = i; // set p2 to i
        else if (q2 == 0) { // else if q2 is equal to 0
          q2 = i - p2; // set q2 to the result of i - p2
          break; // break loop
        } 
      } 
    } 
    long long d = exgcd(q1, -q2); // create long long d = exgcd(q1, -q2)
    long long c = p2 - p1; // create long long c = p2 - p1
    if (d == 0) { // if d is equal to 0
      puts("-1"); // print "-1"
      continue; // continue to next loop iteration
    } 
    if (c % d) { // if c modulo d is truthy
      puts("-1"); // print "-1"
      continue; // continue to next loop iteration
    } 
    if (d < 0) d = -d; // if d is less than 0, set d to -d
    if (p1 == 0 || p2 == 0) { // if p1 is equal to 0 or p2 is equal to 0
      puts("-1"); // print "-1"
      continue; // continue to next loop iteration
    } 
    if (q2 == 0 && q1 == 0 && p1 != p2) { // if q2 is equal to 0 and q1 is equal to 0 and p1 is not equal to p2
      puts("-1"); // print "-1"
      continue; // continue to next loop iteration
    } 
    if ((q2 == 0 && p2 - p1 < 0) || (q1 == 0 && p1 - p2 < 0)) { // if q2 is equal to 0 and p2 - p1 is less than 0 or q1 is equal to 0 and p1 - p2 is less than 0
      puts("-1"); // print "-1"
      continue; // continue to next loop iteration
    } 
    long long k = c / d; // create long long k = c / d
    if (exgcd(q1, -q2) < 0) x = -x, y = -y; // if the return value of exgcd(q1, -q2) is less than 0, set x to -x and set y to -y
    x *= k; // set x to the result of x * k
    y *= k; // set y to the result of y * k
    if (x < 0 || y < 0) { // if x is less than 0 or y is less than 0
      while (1) { // while 1 is truthy
        x += q2 / d; // set x to the result of x + q2 / d
        y += q1 / d; // set y to the result of y + q1 / d
        if (x >= 0 && y >= 0) break; // if x is greater than or equal to 0 and y is greater than or equal to 0, break loop
      } 
    } 
    if (x > 0 && y > 0) { // if x is greater than 0 and y is greater then 0
      while (1) { // while 1 is truthy
        x -= q2 / d; // set x to the result of x - q2 / d
        y -= q1 / d; // set y to the result of y - q1 / d
        if (x < 0 || y < 0) break; // if x is less than 0 or y is less than 0, break loop
      } 
      x += q2 / d; // set x to the result of x + q2 / d
      y += q1 / d; // set y to the result of y + q1 / d
    } 
    long long ans = x * q1 + p1; // create long long ans = x * q1 + p1
    cout << ans << endl; // print ans
  } 
  return 0; 
} 