
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long x, y; // x, y = long long integers
long long exgcd(long long a, long long b) { // declare exgcd that takes two arguments, long long integers a and b
  if (b == 0) { // if b is 0
    x = 1; // set x to 1
    y = 0; // set y to 0
    return a; // return a
  } 
  long long d = exgcd(b, a % b); // d = long long integer set to exgcd of b and a modulo b
  long long t = x; // t = long long integer set to x
  x = y; // set x to y
  y = t - a / b * y; // set y to t - a / b * y
  return d; // return d
} 
int main() { 
  long long m, h1, a1, x1, y1, h2, a2, x2, y2; // m, h1, a1, x1, y1, h2, a2, x2, y2 = long long integers
  long long p1, p2, q1, q2; // p1, p2, q1, q2 = long long integers
  while (cin >> m >> h1 >> a1 >> x1 >> y1 >> h2 >> a2 >> x2 >> y2) { // while reading m, h1, a1, x1, y1, h2, a2, x2, and y2
    p1 = p2 = q1 = q2 = 0; // set p1, p2, q1, q2 to 0
    for (long long i = 1; i <= 2 * m; i++) { // for i = 1 to 2 * m inclusive
      h1 = (h1 * x1 + y1) % m; // set h1 to h1 * x1 + y1 modulo m
      if (h1 == a1) { // if h1 is a1
        if (p1 == 0) // if p1 is 0
          p1 = i; // set p1 to i
        else if (q1 == 0) { // else if q1 is 0
          q1 = i - p1; // set q1 to i - p1
          break; // break
        } 
      } 
    } 
    for (long long i = 1; i <= 2 * m; i++) { // for i =1 to 2 * m inclusive
      h2 = (h2 * x2 + y2) % m; // set h2 to h2 * x2 + y2 modulo m
      if (h2 == a2) { // if h2 is a2
        if (p2 == 0) // if p2 is 0
          p2 = i; // set p2 to i
        else if (q2 == 0) { // else if q2 is 0
          q2 = i - p2; // set q2 to i - p2
          break; // break
        } 
      } 
    } 
    long long d = exgcd(q1, -q2); // d = long long integer set to exgcd of q1 and -q2
    long long c = p2 - p1; // c = long long integer set to p2 - p1
    if (d == 0) { // if d is 0
      puts("-1"); // puts "-1"
      continue; // continue
    } 
    if (c % d) { // if c modulo d
      puts("-1"); // puts "-1"
      continue; // continue
    } 
    if (p1 == 0 || p2 == 0) { // if p1 is 0 or p2 is 0
      puts("-1"); // puts "-1"
      continue; // continue
    } 
    if (q2 == 0 && q1 == 0 && p1 != p2) { // if q2 is 0 and q1 is 0 and p1 != p2
      puts("-1"); // puts "-1"
      continue; // continue
    } 
    if ((q2 == 0 && p2 - p1 < 0) || (q1 == 0 && p1 - p2 < 0)) { // if q2 is 0 and p2 - p1 < 0 or q1 is 0 and p1 - p2 < 0
      puts("-1"); // puts "-1"
      continue; // continue
    } 
    long long k = c / d; // k = long long integer set to c / d
    x *= k; // multiply x by k
    y *= k; // multiply y by k
    if (d < 0) d = -d; // if d < 0, set d to -d
    if (x < 0 || y < 0) { // if x < 0 or y < 0
      while (1) { // while 1 exists
        x += q2 / d; // add q2 / d to x
        y += q1 / d; // add q1 / d to y
        if (x >= 0 && y >= 0) break; // if x >= 0 and y >= 0, break
      } 
    } 
    if (x > 0 && y > 0) { // if x > 0 and y > 0
      while (1) { // while 1 exists
        x -= q2 / d; // subtract q2 / d from x
        y -= q1 / d; // subtract q1 / d from y
        if (x < 0 || y < 0) { // if x < 0 or y < 0
          x += q2 / d; // add q2 / d to x
          y += q1 / d; // add q1 / d to y
          break; // break
        } 
      } 
    } 
    long long ans = x * q1 + p1; // ans = long long integer set to x * q1 + p1
    cout << ans << endl; // print ans
  } 
  return 0; 
} 