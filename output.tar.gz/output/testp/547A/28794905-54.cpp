
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long x, y; // declare long long variables x and y
long long exgcd(long long a, long long b) { // exgcd is a long long function with long long arguments a and b
  if (b == 0) { // if b = 0
    x = 1; // assign 1 to x
    y = 0; // assign 0 to y
    return a; // return a
  } 
  long long d = exgcd(b, a % b); // declare long long d = exgcd(b, a % b)
  long long t = x; // declare long long variable t = x
  x = y; // change x to y
  y = t - a / b * y; // set y to t - a / b * y
  return d; // return d
} 
int main() { 
  long long m, h1, a1, x1, y1, h2, a2, x2, y2; // create long longs m, h1, a1, x1, y1, h2, a2, x2 and y2
  long long p1, p2, q1, q2; // declare long longs p1, p2, q1 and q2
  while (cin >> m >> h1 >> a1 >> x1 >> y1 >> h2 >> a2 >> x2 >> y2) { // loop, reading m, h1, a1, x1, y1, h2, a2, x2 and y2 from the input
    p1 = p2 = q1 = q2 = 0; // change p1, p2, q1 and q2 to 0
    for (long long i = 1; i <= 2 * m; i++) { // change i from 1 to 2 * m inclusive in a loop
      h1 = (h1 * x1 + y1) % m; // set h1 to (h1 * x1 + y1) % m
      if (h1 == a1) { // if h1 is equal to a1
        if (p1 == 0) // if p1 = 0
          p1 = i; // assign i to p1
        else if (q1 == 0) { // else if q1 is equal to 0
          q1 = i - p1; // assign i - p1 to q1
          break; // break the loop
        } 
      } 
    } 
    for (long long i = 1; i <= 2 * m; i++) { // for i = 1 to 2 * m inclusive
      h2 = (h2 * x2 + y2) % m; // set h2 to (h2 * x2 + y2) % m
      if (h2 == a2) { // if h2 = a2
        if (p2 == 0) // if p2 = 0
          p2 = i; // set p2 to i
        else if (q2 == 0) { // else if q2 = 0
          q2 = i - p2; // assign i - p2 to q2
          break; // stop the loop
        } 
      } 
    } 
    long long d = exgcd(q1, -q2); // declare long long d = exgcd(q1, -q2)
    long long c = p2 - p1; // create long long c = p2 - p1
    if (d == 0) { // if d = 0
      puts("-1"); // print "-1" to stdout
      continue; // go to the start of the loop
    } 
    if (c % d) { // if c % d != 0
      puts("-1"); // print "-1" to stdout
      continue; // skip the rest of the loop
    } 
    if (p1 == 0 || p2 == 0) { // if p1 = 0 or p2 is equal to 0
      puts("-1"); // print "-1" to stdout
      continue; // skip the rest of the loop
    } 
    if (q2 == 0 && q1 == 0 && p1 != p2) { // if q2 = 0 and q1 = 0 and p1 != p2
      puts("-1"); // print "-1" to stdout
      continue; // skip the rest of the loop
    } 
    if ((q2 == 0 && p2 - p1 < 0) || (q1 == 0 && p1 - p2 < 0)) { // if (q2 = 0 and p2 - p1 < 0) is true or (q1 = 0 and p1 - p2 < 0) is true
      puts("-1"); // print "-1" to standard output
      continue; // skip the rest of the loop
    } 
    long long k = c / d; // declare long long variable k = c / d
    x *= k; // multiply x by k
    y *= k; // multiply y by k
    if (d < 0) d = -d; // if d is less than 0, invert the sign of d
    if (x < 0 || y < 0) { // if x < 0 or y < 0
      while (1) { // start infinite loop
        x += q2 / d; // add q2 / d to x
        y += q1 / d; // add q1 / d to y
        if (x >= 0 && y >= 0) break; // if x >= 0 and y >= 0, stop the loop
      } 
    } 
    if (x > 0 && y > 0) { // if x > 0 and y > 0
      while (1) { // start infinite loop
        x -= q2 / d; // subtract q2 / d from x
        y -= q1 / d; // decrease y by q1 / d
        if (x < 0 || y < 0) { // if x < 0 or y < 0
          x += q2 / d; // add q2 / d to x
          y += q1 / d; // add q1 / d to y
          break; // break
        } 
      } 
    } 
    long long ans = x * q1 + p1; // create long long ans = x * q1 + p1
    cout << ans << endl; // print ans
  } 
  return 0; 
} 