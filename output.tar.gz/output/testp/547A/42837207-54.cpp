
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long m, h1, a1, x1, h2, a2, x2, y2, y, p1, p2, t1, t2; // create long long variables m, h1, a1, x1, h2, a2, x2, y2, y, p1, p2, t1 and t2
int main() { 
  cin >> m >> h1 >> a1 >> x1 >> y >> h2 >> a2 >> x2 >> y2; // read input to m, h1, a1, x1, y, h2, a2, x2 and y2
  for (int i = 1; i <= 1e7; i++) { // for i from 1 to 1e7 inclusive
    long long ans1 = (((h1 * x1 * 1LL) + y) % m); // declare long long ans1 = (((h1 * x1 * 1LL) + y) % m)
    long long ans2 = (((h2 * x2 * 1LL) + y2) % m); // declare long long ans2 = (((h2 * x2 * 1LL) + y2) % m)
    h1 = ans1, h2 = ans2; // change h1 to ans1 and h2 to ans2
    if (a1 == ans1) { // if a1 is equal to ans1
      if (!p1) // if p1 = 0
        p1 = i; // assign i to p1
      else if (!t1) // else if t1 = 0
        t1 = i - p1; // change t1 to i - p1
    } 
    if (a2 == ans2) { // if a2 is equal to ans2
      if (!p2) // if p2 is false
        p2 = i; // change p2 to i
      else if (!t2) // else if t2 = 0
        t2 = i - p2; // change t2 to i - p2
    } 
  } 
  if (!p1 || !p2) return !(cout << -1 << endl); // if p1 is false or p2 is false, return !(cout<< -1 << endl)
  for (int i = 1; i <= 1e7; i++) { // for i from 1 to 1e7 inclusive
    if (p1 == p2) return !(cout << p1 << endl); // if p1 is equal to p2, return !(cout << p1 << endl)
    if (p1 < p2) // if p1 is less than p2
      p1 += t1; // increase p1 by t1
    else // else
      p2 += t2; // add t2 to p2
  } 
  cout << -1 << endl; // print -1
  return 0; 
} 