
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x; // let x be integer
  cin >> x; // read x
  if (x == 1) // if x == 1
    puts("-1"); // call puts of "-1"
  else // else
    cout << x << " " << x << endl; // print x, " ", x
  return 0; 
} 