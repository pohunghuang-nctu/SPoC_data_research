
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x; // x=int
  cin >> x; // read x
  if (x == 1) // if x is 1
    puts("-1"); // print -1
  else // else
    cout << x << " " << x << endl; // print x, space, x
  return 0; 
} 