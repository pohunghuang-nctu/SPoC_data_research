
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int t; // create integer variable t
  cin >> t; // read variable t from the input
  if (t == 1) // if t = 1
    cout << "-1" << endl; // print "-1" to the standard output
  else // else
    cout << t << " " << t << endl; // print t, " " and t
  return 0; 
} 