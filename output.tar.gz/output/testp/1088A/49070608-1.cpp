
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x; // declare integer x
  cin >> x; // read x
  if (x == 1) { // if x is 1
    cout << "-1" << endl; // print "-1" and newline
    return 0; 
  } 
  cout << x << " " << x << endl; // print x, " ", x, newline
  return 0; 
} 