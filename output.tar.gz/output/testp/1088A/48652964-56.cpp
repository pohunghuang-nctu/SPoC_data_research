
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long int x; // let x be long long int
int main() { 
  cin >> x; // read x
  if (x <= 1) { // if x <= 1
    cout << "-1\n"; // print -1 with newline
  } else { // else
    cout << x << ' ' << x << '\n'; // print x + ' ' + x with newline
  } 
} 