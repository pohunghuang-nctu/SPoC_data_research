
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // let n be an integer
  cin >> n; // input n
  if (1 == n) { // if 1 equals n
    cout << -1 << endl; // print -1
  } else { // else
    cout << n << " " << n << endl; // print n, " ", n
  } 
  return 0; 
} 