
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x; // x=int
  cin >> x; // read x
  int a = x; // a=x
  int b = a; // b=a
  if (a * b <= x || a / b >= x) { // if a*b <= x or a/b >= x
    cout << -1 << endl; // print -1
  } else { // else
    cout << a << ' ' << b << endl; // print a, space, b
  } 
} 