
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // let n be a integer
  cin >> n; // read n
  if (n == 1) { // if n equals 1
    cout << -1 << endl; // print -1 and newline
  } else { // else
    cout << n << " " << n << endl; // print n space n and newline
  } 
  return 0; 
} 