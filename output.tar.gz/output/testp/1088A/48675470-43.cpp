
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int n; // n = int
int main() { 
  cin >> n; // read n
  if (n == 1) // if n = 1
    cout << -1 << endl; // print -1
  else // else
    cout << n << " " << n << endl; // print n and space and n
  return 0; 
} 