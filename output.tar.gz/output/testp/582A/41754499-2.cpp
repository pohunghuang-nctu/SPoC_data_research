
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

map<int, int> m; // m = map from int to int
int s[300000], a[505]; // s = array of integers of length 300000 , a = array of integers of length 505
bool cmp(int a, int b) { // let cmp be a function that accepts integers a, b and returns a boolean value
  return a > b; // return a is greater than b
} 
int gcd(int a, int b) { // let gcd be a function that accepts integers a, b and returns a integer value
  return b ? gcd(b, a % b) : a; // return gcd of b, a modulo b if b else return a
} 
int main() { 
  int n, t, k; // let n, t, k be integers
  while (cin >> n) { // while read n
    for (int i = 0; i < n * n; i++) { // for i = 0 to n * n exclusive
      cin >> s[i]; // read s[i]
      m[s[i]]++; // increment m[s[i]] by 1
    } 
    sort(s, s + n * n, cmp); // sort the values s, s + n * n, cmp
    t = 0, k = 0; // t is equal to 0, k is equal to 0
    for (int i = 0; i < n * n; i++) { // for i = 0 to n * n exclusive
      if (m[s[i]] == 0) continue; // if m[s[i]] is equal to 0 , proceed to next
      m[s[i]]--; // decrement m[s[i]] by 1
      for (int j = 0; j < t; j++) { // for j = 0 to t exclusive
        k = gcd(s[i], a[j]); // k is equal to gcd of s[i] and a[j]
        m[k] -= 2; // decrement m[k] by 2
      } 
      a[t++] = s[i]; // a[t++] is equal to s[i]
    } 
    cout << a[0]; // print a[0]
    for (int i = 1; i < t; i++) { cout << " " << a[i]; } // for i = 1 to t exclusive , print space and a[i]
    cout << endl; // print newline
  } 
  return 0; 
} 