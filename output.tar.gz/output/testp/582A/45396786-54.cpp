
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int a[250005]; // a is a new array of integers with 250005 elements
int b[505]; // declare new array of integers b with size 505
map<int, int> f; // f = map from integers to integers
int main() { 
  int n; // declare new integer called n
  cin >> n; // read n from the input
  for (int i = 1; i <= n * n; i++) cin >> a[i]; // read n * n elements from the input into a, starting from the index 1
  sort(a + 1, a + 1 + n * n, greater<int>()); // sort a
  for (int i = 1; i <= n * n; i++) { f[a[i]]++; } // for i = 1 to n * n inclusive increment f[a[i]]
  b[1] = a[1]; // set b[1] to a[1]
  map<int, int>::iterator itr; // create new int to int map iterator itr
  f[b[1]]--; // decrease f[b[1]]
  int idx = 1; // create new integer idx = 1
  for (int i = 2; i <= n * n; i++) { // start for loop from i = 2 to n squared inclusive
    if (f[a[i]] > 0) { // if f[a[i]] is greater than 0
      idx++; // increment idx by one
      b[idx] = a[i]; // change the value of b[idx] to a[i]
      f[a[i]]--; // decrement f[a[i]]
      for (int j = 1; j < idx; j++) { f[__gcd(b[idx], b[j])] -= 2; } // in a for loop, change j from 1 to idx exclusive, decreasing f[__gcd(b[idx], b[j])] by 2 on each iteration
    } 
    if (idx == n) break; // if idx is equal to n, break the loop
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    if (i == 1) // if i = 1
      cout << b[i]; // print b[i] to the standard output
    else // else
      cout << ' ' << b[i]; // print ' ' and b[i]
  } 
  cout << endl; // print new line
  return 0; 
} 