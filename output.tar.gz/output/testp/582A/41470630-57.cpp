
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int a[250010]; // let a be an int array of length 250010
int gcd(int x, int y) { // In function gcd which takes ints x and y and returns an int
  return x == 0 ? y : gcd(y % x, x); // if x is 0 return y, else return gcd of y mod x and x
} 
int main() { 
  int n; // let n be an int
  cin >> n; // read n
  for (int i = 0; i < n * n; i++) cin >> a[i]; // for i = 0 to n*n exclusive, read a[i]
  sort(a, a + n * n, greater<int>()); // call sort on a, a+n*n, greater<int>()
  map<int, int> ma; // let ma be a map from int to int
  for (int i = 0; i < n * n; i++) { // for i to n*n exclusive
    int tmp = i; // let tmp be an int with value i
    int x = a[i]; // let x be an int with value a[i]
    while (a[i + 1] == a[i] && i + 1 < n * n) i++; // while a[i+1] is a[I] and i+1 ia less than n*n, increment i
    ma[x] = i - tmp + 1; // set ma[x] to i-tmp+1
  } 
  vector<int> ans; // let ans be a vector of ints
  map<int, int>::iterator it = ma.end(); // let it be an iterator with value ma.end()
  it--; // decrement it
  int x = it->first; // let x be an int with value it->first
  ans.push_back(x); // append x to ans
  ma[x]--; // decrement ma[x]
  if (ma[x] == 0) ma.erase(x); // if ma[x] is 0, erase x from ma
  while (!ma.empty()) { // while ma is not empty
    it = ma.end(); // set it to ma.end()
    it--; // decrement it
    x = it->first; // set x to it->first
    ma[x]--; // decrement ma[x]
    if (ma[x] == 0) ma.erase(x); // if ma[x] is 0, erase x from ma
    ans.push_back(x); // append x to ans
    int len = ans.size(); // let len be an int with value ans.size()
    int g; // let g be an int
    for (int i = 0; i < len - 1; i++) { // for i=0 to len-1 exclusive
      g = gcd(x, ans[i]); // set g to gcd(x, ans[i])
      ma[g] -= 2; // subtract 2 from ma[g]
      if (ma[g] == 0) ma.erase(g); // if ma[g] is 0 erase g from ma
    } 
  } 
  int len = ans.size(); // let len be an int with value ans.size()
  for (int i = 0; i < len - 1; i++) cout << ans[i] << ' '; // for I=0 to len-1 exclusive, print ans[I] and a space
  cout << ans[len - 1] << endl; // print ans[len-1]
  return 0; 
} 