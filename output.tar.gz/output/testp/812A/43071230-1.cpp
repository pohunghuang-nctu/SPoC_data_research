
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int INF = 1 << 29; // create constant integer INF with INF = 1 bitshift left 29
int l[4], s[4], r[4], p[4]; // create integer arrays l, s, r, p, with l size 4, s size 4, r size 4, p size 4
int main() { 
  for (int i = 0; i < 4; i++) cin >> l[i] >> s[i] >> r[i] >> p[i]; // for i = 0 to 4 exclusive, read l[i] read s[i] read r[i] read p[i]
  for (int i = 0; i < 4; i++) { // for i = 0 to 4 exclusive
    if (p[i]) { // if p[i] is true
      if (l[(i + 1) % 4] || r[(i + 3) % 4] || s[(i + 2) % 4]) { // if l[(i+1)%4] or r[(i+3)%4] or s[(i+2)%4]
        cout << "YES\n"; // print "YES\n"
        return 0; 
      } 
      if (l[i] || r[i] || s[i]) { // if l[i] or r[i] or s[i]
        cout << "YES\n"; // print "YES\n"
        return 0; 
      } 
    } 
  } 
  cout << "NO\n"; // print "NO\n"
  return 0; 
} 