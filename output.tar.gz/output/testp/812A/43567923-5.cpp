
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int q = 0; // q = integer with q = 0
  int l[5], r[5], s[5], p[5]; // l, r, s, p = integer array of size 5
  for (int i = 1; i <= 4; i++) { cin >> l[i] >> s[i] >> r[i] >> p[i]; } // for i = 1 to 4, read l, r, s, p
  if (p[1] == 1) { // if p[1] is 1
    if (l[1] == 1 || s[1] == 1 || r[1] == 1 || l[2] == 1 || s[3] == 1 || r[4] == 1) q = 1; // if l[1] is 1 or s[1] is 1 or r[1] is 1 or l[2] is 1 or s[3] is 1 or r[4] is 1, q = 1
  } 
  if (p[2] == 1) { // if p[2] is 1
    if (l[2] == 1 || s[2] == 1 || r[2] == 1 || l[3] == 1 || s[4] == 1 || r[1] == 1) q = 1; // if l[2] is 1 or s[2] is 1 or r[2] is 1 or l[3] is 1 or s[4] is 1 or r[1] is 1, q = 1
  } 
  if (p[3] == 1) { // if p[3] is 1
    if (l[3] == 1 || s[3] == 1 || r[3] == 1 || l[4] == 1 || s[1] == 1 || r[2] == 1) q = 1; // if l[3] is 1 or s[3] is 1 or r[3] is 1 or l[4] is 1 or s[1] is 1 or r[2] is 1, q = 1
  } 
  if (p[4] == 1) { // if p[4] is 1
    if (l[4] == 1 || s[4] == 1 || r[4] == 1 || l[1] == 1 || s[2] == 1 || r[3] == 1) q = 1; // if l[4] is 1 or s[4] is 1 or r[4] is 1 or l[1] is 1 or s[2] is 1 or r[3] is 1, q = 1
  } 
  if (q == 1) // if q is 1
    cout << "YES" << endl; // print YES
  else // else
    cout << "NO" << endl; // print NO
  return 0; 
} 