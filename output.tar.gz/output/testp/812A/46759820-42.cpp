
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int l1, s1, r1, p1, l2, s2, r2, p2, l3, s3, r3, p3, l4, s4, r4, p4; // let l1, s1, r1, p1, l2, s2, r2, p2, l3, s3, r3, p3, l4, s4, r4, p4 be integers
  cin >> l1 >> s1 >> r1 >> p1; // read l1, s1, r1, and p1
  cin >> l2 >> s2 >> r2 >> p2; // read l2, s2, r2, and p2
  cin >> l3 >> s3 >> r3 >> p3; // read l3, s3, r3, and p3
  cin >> l4 >> s4 >> r4 >> p4; // read l1, s4, r4, and p4
  if ((l1 || s1 || r1) && p1) { // if (l1 or s1 or r1) and p1
    cout << "YES\n"; // print YES
    return 0; 
  } 
  if ((l2 || s2 || r2) && p2) { // if (l2 or s2 or r2) and p2
    cout << "YES\n"; // print YES
    return 0; 
  } 
  if ((l3 || s3 || r3) && p3) { // if (l3 or s3 or r3) and p3
    cout << "YES\n"; // print YES
    return 0; 
  } 
  if ((l4 || s4 || r4) && p4) { // if (l4 or s4 or r4) and p4
    cout << "YES\n"; // print YES
    return 0; 
  } 
  if (l1 && p4) { // if l1 and p4
    cout << "YES\n"; // print YES
    return 0; 
  } 
  if (s1 && p3) { // if s1 and p3
    cout << "YES\n"; // print YES
    return 0; 
  } 
  if (r1 && p2) { // if r1 and p2
    cout << "YES\n"; // print YES
    return 0; 
  } 
  if (l4 && p3) { // if l4 and p3
    cout << "YES\n"; // print YES
    return 0; 
  } 
  if (s4 && p2) { // if s4 and p2
    cout << "YES\n"; // print YES
    return 0; 
  } 
  if (r4 && p1) { // if r4 and p1
    cout << "YES\n"; // print YES
    return 0; 
  } 
  if (l3 && p2) { // if l3 and p2
    cout << "YES\n"; // print YES
    return 0; 
  } 
  if (s3 && p1) { // if s3 and p1
    cout << "YES\n"; // print YES
    return 0; 
  } 
  if (r3 && p4) { // if r3 and p4
    cout << "YES\n"; // print YES
    return 0; 
  } 
  if (l2 && p1) { // if l2 and p1
    cout << "YES\n"; // print YES
    return 0; 
  } 
  if (s2 && p4) { // if s2 and p4
    cout << "YES\n"; // print YES
    return 0; 
  } 
  if (r2 && p3) { // if r2 and p3
    cout << "YES\n"; // print YES
    return 0; 
  } 
  cout << "NO\n"; // print NO
} 