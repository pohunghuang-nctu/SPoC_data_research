
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 2e5 + 7; // set const int N to 2e5 + 7
const long double pi = 3.14159265359; // set const long double pi to 3.14159265359
const long long INF = 1e9; // set const long long INF to 1e9
const long double eps = 1e-9; // set const long double eps to 1e-9
int n, s[N], r[N], p[N], l[N]; // integers = n,s[N],r[N],p[N],l[N]
int main() { 
  n = 4; // set n to 4
  for (int i = 1; i <= n; i++) { // for i = 1 to less than or equal to n do the following
    cin >> l[i] >> s[i] >> r[i] >> p[i]; // read l[i],s[i],r[i],p[i]
    if (p[i]) { // if p[i] is true
      if (l[i] || s[i] || r[i]) { // if l[i] or s[i] or r[i] is true
        cout << "YES\n"; // output YES
        return 0; 
      } 
    } 
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to less than or equal to n do the following
    if (i == 1) { // if i is 1 then do
      if (l[i] == 1) { // if l[i] is 1 then do
        if (p[4]) { // if p[4] is true
          cout << "YES\n"; // output YES\n
          return 0; 
        } 
      } 
      if (s[i] == 1) { // if s[i] is 1 then do
        if (p[3]) { // if p[3] is true
          cout << "YES\n"; // output YES\n
          return 0; 
        } 
      } 
      if (r[i] == 1) { // if r[i] is 1 then do
        if (p[2]) { // if p[2] is true
          cout << "YES\n"; // output YES\n
          return 0; 
        } 
      } 
    } else if (i == 2) { // else
      if (l[i] == 1) { // if l[i] is 1 then do
        if (p[1]) { // if p[1] is true
          cout << "YES\n"; // output YES\n
          return 0; 
        } 
      } 
      if (s[i] == 1) { // if s[i] is 1 then do
        if (p[4]) { // if p[4] is true
          cout << "YES\n"; // output YES\n
          return 0; 
        } 
      } 
      if (r[i] == 1) { // if r[i] is 1 then do
        if (p[3]) { // if p[3] is true
          cout << "YES\n"; // output YES\n
          return 0; 
        } 
      } 
    } else if (i == 3) { // else
      if (l[i] == 1) { // if l[i] is 1 then do
        if (p[2]) { // if p[2] is true
          cout << "YES\n"; // output YES\n
          return 0; 
        } 
      } 
      if (s[i] == 1) { // if s[i] is 1 then do
        if (p[1]) { // if p[1] is true
          cout << "YES\n"; // output YES\n
          return 0; 
        } 
      } 
      if (r[i] == 1) { // if r[i] is 1 then do
        if (p[4]) { // if p[4] is true
          cout << "YES\n"; // output YES\n
          return 0; 
        } 
      } 
    } else { // else
      if (l[i] == 1) { // if l[i] is 1 then do
        if (p[3]) { // if p[3] is true
          cout << "YES\n"; // output YES\n
          return 0; 
        } 
      } 
      if (s[i] == 1) { // if s[i] is 1 then do
        if (p[2]) { // if p[2] is true
          cout << "YES\n"; // output YES\n
          return 0; 
        } 
      } 
      if (r[i] == 1) { // if r[i] is 1 then do
        if (p[1]) { // if p[1] is true
          cout << "YES\n"; // output YES\n
          return 0; 
        } 
      } 
    } 
  } 
  cout << "NO\n"; // output NO
  return 0; 
} 