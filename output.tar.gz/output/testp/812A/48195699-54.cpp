
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int arr[4][4]; // declare 2d integer array arr with size 4 by 4
  for (int i = 0; i < 4; i++) { // for i = 0 to 4 exclusive incrementing i
    for (int j = 0; j < 4; j++) { cin >> arr[i][j]; } // for j from 0 to 4 exclusive read arr[i][j]
  } 
  int f = 0; // create int f = 0
  for (int i = 0; i < 4; i++) { // for integer i = 0 to 4 exclusive
    if (arr[i][3] == 1) { // if arr[i][3] is 1
      if (arr[i][0] == 1 || arr[i][1] == 1 || arr[i][2] == 1) f = 1; // if arr[i][0], arr[i][1] or arr[i][2] is 1, set f to 1
      if (arr[(i + 1) % 4][0] == 1) f = 1; // if arr[(i + 1) % 4][0] = 1, set f to 1
      if (arr[(i + 2) % 4][1] == 1) f = 1; // if arr[(i + 2) % 4][1] = 1, set f to 1
      if (arr[(i + 3) % 4][2] == 1) f = 1; // if arr[(i + 3) % 4][2] = 1, set f to 1
    } 
  } 
  if (f == 1) // if f is 1
    cout << "YES"; // print "YES"
  else // else
    cout << "NO"; // print "NO"
  cout << endl; // print undefined
  return 0; 
} 