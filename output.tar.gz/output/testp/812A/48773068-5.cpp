
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x[5][5]; // x = integer 2d array of [5][5]
  bool f = false; // f = bool with f = false
  for (int i = 1; i <= 4; i++) { // for i = 1 to 4
    for (int j = 1; j <= 4; j++) { cin >> x[i][j]; } // for j = 1 to 4, read x[i][j]
  } 
  for (int i = 1; i <= 4; i++) { // for i = 1 to 4
    if (x[i][4]) { // if x[i][4]
      for (int j = 1; j <= 3; j++) { // for i = 1 to 3
        if (x[i][j]) f = true; // if x[i][j], f = true;
      } 
      for (int j = 1; j <= 3; j++) { // for j = 1 to 3
        int p = i + j; // p = integer with p = i + j
        if (p > 4) p -= 4; // if p > 4, p = p - 4
        if (x[p][j]) f = true; // if x[p][j], f = true
      } 
    } 
  } 
  if (f) // if f
    cout << "YES" << endl; // print YES
  else // else
    cout << "NO" << endl; // print NO
} 