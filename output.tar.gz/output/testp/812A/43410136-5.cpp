
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int a[5][5]; // a = integer 2d array of size 5, 5
  int p[5]; // p = integer array of size 5
  int flag = 0; // flag = int with flag = 0
  memset(p, 0, sizeof(p)); // set all the contents of p to 0
  for (int i = 0; i < 4; i++) // for i = 0 to 3
    for (int j = 0; j < 4; j++) { // for j = 0 to 3
      cin >> a[i][j]; // print a[i][j]
      if (j == 3 && a[i][j]) p[i] = 1; // if j is 3 and a[i][j], p[i] = 1
    } 
  for (int i = 0; i < 4; i++) { // for i = 0 to 3
    if (p[i]) // if p[i]
      for (int j = 0; j < 3; j++) // for j = 0 to 2
        if (a[(i + j + 1) % 4][j] || a[i][j]) { // if a[(i + j + 1) modulo 4][j] or a[i][j])
          flag = 1; // flag = 1
          break; // break loop
        } 
  } 
  puts(flag ? "YES" : "NO"); // call puts, if flag, print YES else print NO
} 