
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const long long linf = 1LL << 62; // create constant long long linf with linf = 1LL bitshift left 62
const int iinf = 1000000009; // create constant integer iinf with iinf = 1000000009
const double dinf = 1e15; // create constant double dinf with dinf = 1e15
const int Mod = 1e9 + 9; // create constant integer Mod with Mod = 1e9+9
const int maxn = 500005; // create constant integer maxn with maxn = 500005
int dcmp(double x) { // declare dcmp with double x as argument, returning integer
  if (fabs(x) <= 1e-9) return 0; // if absolute value of x is less than or equal to 1e-9, return 0 from function
  return x < 0 ? -1 : 1; // return -1 if x is less than 0, else 1
} 
int l[10], r[10], s[10], p[10]; // create integer arrays l, r, s, p, with l size 10, r size 10, s size 10, p size 10
void solve() { // declare solve with no arguments, returning void
  for (int i = 1; i <= 4; i++) cin >> l[i] >> s[i] >> r[i] >> p[i]; // for i = 1 to 4 inclusive, read l[i] read s[i] read r[i] read p[i]
  if (p[1] && (s[1] || l[1] || r[1] || s[3] || r[4] || l[2])) // if p[1] and (s[1] || l[1] || r[1] || s[3] || r[4] || l[2])
    cout << "YES" << '\n'; // print "YES" print '\n'
  else if (p[2] && (s[2] || l[2] || r[2] || s[4] || r[1] || l[3])) // else if p[2] and (s[2] || l[2] || r[2] || s[4] || r[1] || l[3])
    cout << "YES" << '\n'; // print "YES" print '\n'
  else if (p[3] && (s[1] || s[3] || l[3] || r[3] || r[2] || l[4])) // else if p[3] and (s[1] || s[3] || l[3] || r[3] || r[2] || l[4])
    cout << "YES" << '\n'; // print "YES" print '\n'
  else if (p[4] && (s[4] || l[4] || r[4] || s[2] || r[3] || l[1])) // else if p[4] and (s[4] || l[4] || r[4] || s[2] || r[3] || l[1])
    cout << "YES" << '\n'; // print "YES" print '\n'
  else // else
    cout << "NO" << '\n'; // print "NO" print '\n'
} 
int main() { 
  int tt = 1; // create integer tt with tt = 1
  while (tt--) solve(); // while decrementing tt, run solve
  return 0; 
} 