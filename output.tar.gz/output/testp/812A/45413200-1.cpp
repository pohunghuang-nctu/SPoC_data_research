
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long a[4][4]; // create 2d long long array a with size 4 by 4
  for (long long i = (0); i < (4); i++) // for i = 0 to 4 exclusive
    for (long long j = (0); j < (4); j++) cin >> a[i][j]; // for j = 0 to 4 exclusive, print a[i][j]
  for (long long i = (0); i < (4); i++) { // for i = 0 to 4 exclusive
    for (long long j = (0); j < (3); j++) { // for j = 0 to 3 exclusive
      if (a[i][j] == 1 && a[i][3] == 1) { // if a[i][j] is 1 and a[i][3] is 1
        cout << "YES" // print "YES"
          << "\n"; // print "\n"
        return 0; 
      } 
    } 
  } 
  for (long long i = (0); i < (4); i++) { // for i = 0 to 4 exclusive
    if (a[i][1] == 1) { // if a[i][1] is 1
      if (i >= 2 && a[i - 2][3] == 1) { // if i is greater than or equal to 2 and a[i-2][3] is 1
        cout << "YES" // print "YES"
          << "\n"; // print "\n"
        return 0; 
      } 
      if (i < 2 && a[i + 2][3] == 1) { // if i is less than 2 and a[i+2][3] is 1
        cout << "YES" // print "YES"
          << "\n"; // print "\n"
        return 0; 
      } 
    } 
  } 
  for (long long i = (0); i < (4); i++) { // for i = 0 to 4 exclusive
    if (a[i][0] == 1) { // if a[i][0] is 1
      if (i >= 1 && a[i - 1][3] == 1) { // if i is greater than 1 and a[i-1][3] is 1
        cout << "YES" // print "YES"
          << "\n"; // print "\n"
        return 0; 
      } 
      if (i == 0 && a[3][3] == 1) { // if i is 0 and a[3][3] is 1
        cout << "YES" // print "YES"
          << "\n"; // print "\n"
        return 0; 
      } 
    } 
  } 
  for (long long i = (0); i < (4); i++) { // for i = 0 to 4 exclusive
    if (a[i][2] == 1) { // if a[i][2] is 1
      if (i < 3 && a[i + 1][3] == 1) { // if i is less than 3 and a[i+1][3] is 1
        cout << "YES" // print "YES"
          << "\n"; // print "\n"
        return 0; 
      } 
      if (i == 3 && a[0][3] == 1) { // if i is 3 and a[0][3] is 1
        cout << "YES" // print "YES"
          << "\n"; // print "\n"
        return 0; 
      } 
    } 
  } 
  cout << "NO" // print "NO"
    << "\n"; // print "\n"
} 