
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int a[4][4]; // integers = a in 4 by 4 array
  for (int i = 0; i < 4; i++) // for i = 0 to i is less than 4 do the following
    for (int j = 0; j < 4; j++) cin >> a[i][j]; // for j = 0 to 3 read a[i][j]
  for (int i = 0; i < 4; i++) { // for i = 0 to less than 4 do the following
    if (a[i][3] == 1) { // if a[i][3] is 1 then do {
      if (a[i][0] == 1 || a[i][1] == 1 || a[i][2] == 1) { // if a[i][0] is 1 or a[i][1] is 1 or a[i][2] is 1 then do next command
        cout << "YES" << endl; // output "YES"
        return 0; 
      } else if (a[(i + 2) % 4][1] == 1) { // else
        cout << "YES" << endl; // output "YES"
        return 0; 
      } 
    } 
    if (a[i][3] == 1) // if a[i][3] is 1 then do
      if (a[(i + 1) % 4][0] == 1) { // if a[remainder of i +1 / 4][0] is 1 then do next commands
        cout << "YES" << endl; // output "YES"
        return 0; 
      } 
    if (a[i][3] == 1) // if a[i][3] is 1 then do
      if (a[(i + 3) % 4][2] == 1) { // if a[remainder of i +3 / 4][2] is 1 then do {
        cout << "YES" << endl; // output "YES"
        return 0; 
      } 
  } 
  cout << "NO" << endl; // output "NO"
  return 0; 
} 