
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int INF = 1 << 29; // constant integer INF = 1 << 29
int l[4], s[4], r[4], p[4]; // create int arrays l, s, r and p with 4 elements
int main() { 
  for (int i = 0; i < 4; i++) cin >> l[i] >> s[i] >> r[i] >> p[i]; // for i from 0 to 4 exclusive, read input to l[i], s[i], r[i] and p[i]
  for (int i = 0; i < 4; i++) { // for i from 0 to 4 exclusive
    if (p[i]) { // if p[i] is not 0
      if (l[(i + 1) % 4] || r[(i - 1 + 4) % 4] || s[(i + 2) % 4]) { // if l[(i + 1) % 4], r[(i - 1 + 4) % 4] or s[(i + 2) % 4] is not 0
        cout << "YES\n"; // print "YES\n"
        return 0; 
      } 
      if (l[i] || r[i] || s[i]) { // if l[i], r[i] or s[i] is not 0
        cout << "YES\n"; // print "YES\n"
        return 0; 
      } 
    } 
  } 
  cout << "NO\n"; // print "NO\n"
  return 0; 
} 