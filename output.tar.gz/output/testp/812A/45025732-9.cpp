
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int l1, l2, l3, l4, p1; // integers = l1,l2,l3,l4,p1
  int s1, s2, s3, s4, p2; // integers = s1,s2,s3,s4,p2
  int r1, r2, r3, r4, p3, p4; // integers = r1,r2,r3,r4,p3,p4
  cin >> l1 >> s1 >> r1 >> p1; // read l1,s1,r1,p1
  cin >> l2 >> s2 >> r2 >> p2; // read l2,s2,r2,p2
  cin >> l3 >> s3 >> r3 >> p3; // read l3,s3,r3,p3
  cin >> l4 >> s4 >> r4 >> p4; // read l4,s4,r4,p4
  if (l1 || s1 || r1 || l2 || r4 || s3) { // if l1 or s1 or r1 or l2 or r4 or s3 is true
    if (p1) { // if p1 is true
      puts("YES"); // write yes to stdout
      return 0; 
    } 
  } 
  if (l2 || s2 || r2 || r1 || s4 || l3) { // if l2 or s2 or r2 or r1 or s4 or l3 is true
    if (p2) { // if p2 is true
      puts("YES"); // write yes to stdout
      return 0; 
    } 
  } 
  if (l3 || r3 || s3 || l4 || r2 || s1) { // if l3 or r3 or s3 or l4 or r2 or s1 is true
    if (p3) { // if p3 is true
      puts("YES"); // write yes to stdout
      return 0; 
    } 
  } 
  if (l4 || r4 || s4 || l1 || r3 || s2) { // if l4 or r4 or s4 or l1 or r3 or s2 is true
    if (p4) { // if p4 is true
      puts("YES"); // write yes to stdout
      return 0; 
    } 
  } 
  puts("NO"); // write NO to stdout
  return 0; 
} 