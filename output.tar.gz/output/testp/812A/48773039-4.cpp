
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x[5][5]; // x = 2D array in strings with 5 rows and 5 columns
  bool f = false; // f = boolean with false
  for (int i = 1; i <= 4; i++) { // for i = 1 to 4 exclusive
    for (int j = 1; j <= 4; j++) { cin >> x[i][j]; } // Read 4 values into array x
  } 
  for (int i = 1; i <= 4; i++) { // for i = 0 to 4 exclusive
    if (x[i][4]) { // if x[i][4] is not equal to 0
      for (int j = 1; j <= 3; j++) { // for j = 1 to 3 exclusive
        if (x[i][j]) f = true; // if x[i][j] is not equal 0, then set f to true
      } 
      for (int j = 1; j <= 3; j++) { // for j = 1 to 3 exclusive
        int p = i + j; // p = integer, set to i + j
        if (p > 4) p -= 4; // if p is greater than 4, then set p to p - 4
        if (x[p][j]) f = true; // if x[p][j] is not equal 0, then set f to true
      } 
    } 
  } 
  if (f) // if f is true
    cout << "YES" << endl; // print YES new line
  else // else do the following
    cout << "NO" << endl; // print NO new line
} 