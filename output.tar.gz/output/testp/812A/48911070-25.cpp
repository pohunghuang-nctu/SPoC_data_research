
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int temp; // declare int temp
  map<int, int> c; // declare map c with int keys and int values
  map<int, int> m; // declare map m with int keys and int values
  cin >> temp; // read temp
  m[1] += temp; // increase m[1] by temp
  m[4] += temp; // increase m[4] by temp
  cin >> temp; // read temp
  m[1] += temp; // increase m[1] by temp
  m[3] += temp; // increase m[3] by temp
  cin >> temp; // read temp
  m[1] += temp; // increase m[1] by temp
  m[2] += temp; // increase m[2] by temp
  cin >> temp; // read temp
  c[1] += temp; // increase c[1] by temp
  cin >> temp; // read temp
  m[1] += temp; // increase m[1] by temp
  m[2] += temp; // increase m[2] by temp
  cin >> temp; // read temp
  m[2] += temp; // increase m[2] by temp
  m[4] += temp; // increase m[4] by temp
  cin >> temp; // read temp
  m[3] += temp; // increase m[3] by temp
  m[2] += temp; // increase m[2] by temp
  cin >> temp; // read temp
  c[2] += temp; // increase c[2] by temp
  cin >> temp; // read temp
  m[3] += temp; // increase m[3] by temp
  m[2] += temp; // increase m[2] by temp
  cin >> temp; // read temp
  m[1] += temp; // increase m[1] by temp
  m[3] += temp; // increase m[3] by temp
  cin >> temp; // read temp
  m[3] += temp; // increase m[3] by temp
  m[4] += temp; // increase m[4] by temp
  cin >> temp; // read temp
  c[3] += temp; // increase c[3] by temp
  cin >> temp; // read temp
  m[3] += temp; // increase m[3] by temp
  m[4] += temp; // increase m[4] by temp
  cin >> temp; // read temp
  m[4] += temp; // increase m[4] by temp
  m[2] += temp; // increase m[2] by temp
  cin >> temp; // read temp
  m[1] += temp; // increase m[1] by temp
  m[4] += temp; // increase m[4] by temp
  cin >> temp; // read temp
  c[4] += temp; // increase c[4] by temp
  int flag = 0; // define int flag = 0
  if (c[1] > 0) { // if c[1] is greater than 0
    if (m[1] > 0) flag = 1; // if m[1] is greater than 0: set flag to 1
  } 
  if (c[2] > 0) { // if c[2] is greater than 0
    if (m[2] > 0) flag = 1; // if m[2] is greater than 0: set flag to 1
  } 
  if (c[3] > 0) { // if c[3] is greater than 0
    if (m[3] > 0) flag = 1; // if m[3] is greater than 0: set flag to 1
  } 
  if (c[4] > 0) { // if c[4] is greater than 0
    if (m[4] > 0) flag = 1; // if m[4] is greater than 0: set flag to 1
  } 
  if (flag == 0) // if flag equals 0
    cout << "NO" << endl; // print "NO"
  else // else
    cout << "YES" << endl; // print "YES"
  return 0; 
} 