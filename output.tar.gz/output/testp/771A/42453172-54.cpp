
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

void read(int &x) { // function read with int argument &x
  char ch = getchar(); // declare char ch and read it from the input
  bool f = 0; // create boolean f = 0
  x = 0; // change x to 0
  while (ch > '9' || ch < '0') { // while ch is not a digit character
    if (ch == '-') f = 1; // if ch = '-', change f to 1
    ch = getchar(); // read ch from the input
  } 
  while (ch >= '0' && ch <= '9') { // while ch is a digit character
    x = x * 10 + ch - 48; // assign x * 10 + ch - 48 to x
    ch = getchar(); // read ch from the input
  } 
  if (f) x = -x; // if f is true, invert the sigh of x
} 
void read(long long &x) { // void function read with long long reference argument &x
  char ch = getchar(); // declare char ch and read it from the input
  bool f = 0; // create bool f = 0
  x = 0; // change x to 0
  while (ch > '9' || ch < '0') { // while ch is not a digit character
    if (ch == '-') f = 1; // if ch = '-', set f to 1
    ch = getchar(); // read ch from the input
  } 
  while (ch >= '0' && ch <= '9') { // while ch is a digit character
    x = x * 10 + ch - 48; // set x to x * 10 + ch - 48
    ch = getchar(); // read ch from the input
  } 
  if (f) x = -x; // if f is true, invert the sigh of x
} 
int parent[150001]; // create int array parent with 150001 element
int ranks[150001]; // declare int array ranks with size 150001
long long sizeedge[150001]; // let sizeedge be long long array with size 150001
long long size[150001]; // declare long long array size with size 150001
void build(int n) { // build is a void function with int argument n
  for (int i = 0; i <= n; i++) parent[i] = i, size[i] = 1LL; // for integer i = 0 to n inclusive, set parent[i] to i and set size[i] to 1LL
} 
int find(int x) { // int function find with int argument x
  return x = x == parent[x] ? x : find(parent[x]); // return x = x == parent[x] ? x : find(parent[x])
} 
void merge(int x, int y) { // void function merge with int arguments x and y
  x = find(x), y = find(y); // set x to find(x) and set y to find(y)
  if (ranks[x] > ranks[y]) swap(x, y); // if ranks[x] is greater than ranks[y]) swap x and y
  if (ranks[x] == ranks[y]) ranks[y]++; // if ranks[x] = ranks[y], increment ranks[y]
  if (x != y) { // if x != y
    parent[x] = y; // assign y to parent[x]
    size[y] = size[x] + size[y]; // set size[y] to size[x] + size[y]
    sizeedge[y] = sizeedge[x] + sizeedge[y] + 1LL; // set sizeedge[y] to sizeedge[x] + sizeedge[y] + 1LL
  } else { // else
    sizeedge[y]++; // increment sizeedge[y] by one
  } 
} 
int main() { 
  int v, e; // declare integers v and e
  read(v); // call read with argument v
  read(e); // call read with argument e
  build(v); // call build with argument v
  for (int i = 0; i < e; i++) { // for integer i = 0 to e exclusive
    int from, to; // declare ints from and to
    read(from); // call read with argument from
    read(to); // call read with argument to
    merge(from, to); // call merge with arguments from and to
  } 
  for (int i = 1; i <= v; i++) { // for integer i = 1 to v inclusive
    if (i == find(i)) { // if i is equal to find(i)
      if (sizeedge[i] != size[i] * (size[i] - 1) / 2) { // if sizeedge[i] != size[i] * (size[i] - 1) / 2
        puts("NO"); // print "NO"
        return 0; 
      } 
    } 
  } 
  puts("YES"); // print "YES"
  return 0; 
} 