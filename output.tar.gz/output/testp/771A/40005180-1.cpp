
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 150005; // create constant integer N with N = 150005
vector<int> g[N]; // create integer vector array g with size N
int n, m; // create integers n, m
vector<int> p; // create integer vector p
pair<long long, long long> bfs(int s) { // declare bfs with integer s as argument, returning pair of long long, long long
  p[s] = s; // set p[s] to s
  queue<int> q; // create integer queue q
  q.push(s); // add s to end of q
  long long ver = 0; // create long long ver with ver = 0
  long long cnted = 0; // create long long cnted with cnted = 0
  while (!q.empty()) { // while q is not empty
    int v = q.front(); // create integer v with v = front of q
    q.pop(); // remove next element of q
    ver++; // increment ver
    for (int i = 0; i < g[v].size(); i++) { // for i = 0 to size of g[v] exclusive
      int to = g[v][i]; // create integer to with to = g[v][i]
      cnted++; // increment cnted
      if (p[to] == -1) { // if p[to] is -1
        p[to] = v; // set p[to] to v
        q.push(to); // add element to to end of q
      } 
    } 
  } 
  return make_pair(ver, cnted / 2); // return new pair created with ( ver, cnted / 2 )
} 
int main() { 
  cin >> n >> m; // read n read m
  p = vector<int>(n, -1); // set p to vector integer initialized with (n, - 1)
  for (int i = 0; i < m; i++) { // for i = 0 to m exclusive
    int x, y; // create integers x, y
    cin >> x >> y; // read x read y
    x--; // decrement x
    y--; // decrement y
    g[x].push_back(y); // add element y to end of g[x]
    g[y].push_back(x); // add element x to end of g[y]
  } 
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    if (p[i] == -1) { // if p[i] is -1
      pair<long long, long long> t = bfs(i); // create pair of long long, long long t with t = result of run bfs with i as argument
      if ((t.first * (t.first - 1)) / 2 != t.second) { // if (first element of t * ( first element of t - 1 ) ) / 2 is not second element of t
        cout << "NO" << endl; // print "NO" print newline
        return 0; 
      } 
    } 
  } 
  cout << "YES" << endl; // print "YES" print newline
} 