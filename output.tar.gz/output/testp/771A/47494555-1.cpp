
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

vector<int> grafo[300000]; // create integer vector array grafo with size 300000
bool chegou[300000]; // create boolean array chegou with size 300000
vector<int> passou; // create integer vector passou
int n, m; // create integers n, m
void dfs(int v) { // declare dfs with integer v as argument, returning void
  chegou[v] = true; // set chegou[v] to true
  passou.push_back(v); // add element v to end of passou
  for (int i = 0; i < grafo[v].size(); i++) { // for i = 0 to size of grafo[v] exclusive
    int adj = grafo[v][i]; // create integer adj with adj = grafo[v][i]
    if (!chegou[adj]) { dfs(adj); } // if not chegou[adj], run dfs with adj as argument
  } 
} 
int main() { 
  cin >> n >> m; // read n read m
  for (int i = 0; i < m; i++) { // for i = 0 to m exclusive
    int a, b; // create integers a, b
    cin >> a >> b; // read a read b
    grafo[a].push_back(b); // add element b to end of grafo[a]
    grafo[b].push_back(a); // add element a to end of grafo[b]
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    if (!chegou[i]) { // if not chegou[i]
      dfs(i); // run dfs with i as argument
      int mini = passou.size() - 1; // create integer mini with mini = size of passou - 1
      for (int c = 0; c < passou.size(); c++) { // for c = 0 to size of passou exclusive
        if (grafo[passou[c]].size() < mini) { // if size of grafo[passou[c]] is less than mini
          cout << "NO\n"; // print "NO\n"
          return 0; 
        } 
      } 
      passou.clear(); // remove all elements from passou
    } 
  } 
  cout << "YES\n"; // print "YES\n"
  return 0; 
} 