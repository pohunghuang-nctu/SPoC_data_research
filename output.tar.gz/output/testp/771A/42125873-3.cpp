
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

vector<int> a[150005], v[150005]; // a, v = integer vectors both of length 150005
bool used[150005]; // used = boolean array of length 150005
int n, m, k, x, y; // n, m, k, x, y = integers
void dfs(int u) { // in function dfs that returns nothing and takes argument u = integer
  used[u] = 1; // set used[u] = 1
  v[k].push_back(u); // append u to the end of v[k]
  for (int i = 0; i < a[u].size(); i++) { // for i = 0 to the size of a[u] exclusive
    if (!used[a[u][i]]) dfs(a[u][i]); // if used[a[u][i]] is 0 then call dfs with argument a[u][i]
  } 
} 
int main() { 
  int p; // p = integer
  cin >> n >> m; // read n and m
  for (int i = 0; i < m; i++) { // for i = 0 to m exclusive
    cin >> x >> y; // read x and y
    a[x].push_back(y); // append y to the end of a[x]
    a[y].push_back(x); // append x to the end of a[y]
  } 
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    if (!used[i]) { // if used[i] is 0
      k++; // add 1 to k
      dfs(i); // call dfs with argument i
      p = v[k].size(); // set p to the size of v[k]
      for (int j = 0; j < p; j++) { // for j = 0 to p exclusive
        if (a[v[k][j]].size() != p - 1) { // if the size of a[v[k][j]] does not equal p-1
          cout << "NO" << endl; // print NO
          return 0; 
        } 
      } 
    } 
  } 
  cout << "YES" << endl; // print YES
  return 0; 
} 