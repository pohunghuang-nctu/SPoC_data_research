
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

vector<int> mp[150005]; // declare integers vector array mp with size 150005
int64_t n, m, a, b, ans, size, mark[150005]; // create int64_t variables n, m, a, b, ans and size and an array of int64_t called mark with 150005 elements
void dfs(int x, int prev) { // void function dfs with int arguments x and prev
  mark[x] = 1; // change mark[x] to 1
  if (prev != mp[x].size() || size > mp[x].size()) ans = 1; // if prev != length of mp[x] or size > length of mp[x], set ans to 1
  ++size; // increase size by one
  for (int i = 0; i < mp[x].size(); i++) // for i = 0 to length of mp[x] exclusive
    if (mark[mp[x][i]] == 0) dfs(mp[x][i], mp[x].size()); // if mark[mp[x][i]] = 0, call dfs of mp[x][i] and length of mp[x]
} 
int main() { 
  cin >> n >> m; // read n and m
  for (int i = 1; i <= m; i++) { // loop i from 1 to m inclusive incrementing i
    cin >> a >> b; // read a and b
    mp[a].push_back(b); // push b into mp[a]
    mp[b].push_back(a); // push a into mp[b]
  } 
  for (int i = 1; i <= n && !ans; i++) // for i from 1 to n inclusive
    if (mark[i] == 0 && mp[i].size() != 0) { // if mark[i] = 0 and mp[i] is not empty
      size = 0; // assign 0 to size
      dfs(i, mp[i].size()); // call function dfs with arguments i and length of mp[i]
    } 
  if (ans) // if ans is true
    cout << "NO\n"; // print "NO\n"
  else // else
    cout << "YES\n"; // print "YES\n"
  return 0; 
} 