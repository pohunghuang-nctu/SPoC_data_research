
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long x = 0; // x = long long with x = 0
void dfs(vector<int> *edges, int a, int v[]) { // in function dfs taking a pointer to an int vector edges, an int a and an int array v
  x++; // increment x
  v[a] = 1; // set v[a] to 1
  long long ans = edges[a].size(); // ans = long long with ans = size of edges[a]
  for (int i = 0; i < edges[a].size(); i++) // for i = 0 to size of edges[a]
    if (!v[edges[a][i]]) dfs(edges, edges[a][i], v); // if v[edges[a][i]] is 0 then call dfs on edges, edges[a][i] and v
} 
int main() { 
  int n, m; // n, m = int
  long long ans = 0; // ans = long long with ans = 0
  cin >> n >> m; // read n then m
  vector<int> edges[n]; // edges = int vector array of size n
  for (int i = 0; i < m; i++) { // for i = 0 to m
    int a, b; // a, b = int
    cin >> a >> b; // read a then b
    edges[a - 1].push_back(b - 1); // append b - 1 to edges[a - 1]
    edges[b - 1].push_back(a - 1); // append a - 1 to edges[b - 1]
  } 
  int v[n] = {0}; // v = int array of size n with all values set to 0
  for (int i = 0; i < n; i++) // for i = 0 to n
    if (!v[i]) { // if v[i] is 0
      x = 0; // set x to 0
      dfs(edges, i, v); // call dfs on edges, i and v
      ans += x * (x - 1) / 2; // add x * (x - 1) / 2 to ans
    } 
  if (ans == m) // if ans is m
    cout << "YES\n"; // print "YES"
  else // else
    cout << "NO\n"; // print "NO"
  return 0; 
} 