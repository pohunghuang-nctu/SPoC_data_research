
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

vector<int> grafo[150150]; // declare array of integer vectors grafo with size 150150
int n, m; // declare ints n and m
int grau[150150]; // create int array grau with 150150 elements
int visitado[150150]; // create int array visitado with 150150 elements
int grauCor[150150]; // create int array grauCor with 150150 elements
int dfs(int v, int cor) { // dfs is a int function with int arguments v and cor
  if (visitado[v] == cor) return 0; // return 0 if visitado[v] = cor
  visitado[v] = cor; // change visitado[v] to cor
  int sum = 1; // declare integer variable sum = 1
  for (int i = 0; i < (int)grafo[v].size(); i++) { // for i from 0 to size of grafo[v] exclusive incrementing i
    int u = grafo[v][i]; // create int u = grafo[v][i]
    sum += dfs(u, cor); // add dfs of u and cor to sum
  } 
  return sum; // return sum
} 
int main() { 
  cin >> n >> m; // read n and m
  int i; // declare integer variable i
  int u, v; // declare int variables u and v
  for (i = 1; i <= m; i++) { // loop i from 1 to m inclusive incrementing i
    cin >> u >> v; // read from the input to u and v
    grafo[u].push_back(v); // push v into grafo[u]
    grafo[v].push_back(u); // push u into grafo[v]
    grau[u]++; // increment grau[u] by one
    grau[v]++; // increment grau[v] by one
  } 
  int cor = 1; // declare integer variable cor = 1
  for (i = 1; i <= n; i++) { // for i from 1 to n inclusive
    if (visitado[i] == 0) { // if visitado[i] is 0
      grauCor[cor] = dfs(i, cor); // change grauCor[cor] to dfs of i and cor
      cor++; // increment cor
    } 
  } 
  int ok = 1; // declare int ok = 1
  for (i = 1; i <= n; i++) { // loop i from 1 to n inclusive
    if (grau[i] != grauCor[visitado[i]] - 1) ok = 0; // if grau[i] != grauCor[visitado[i]] - 1, change ok to 0
  } 
  if (ok) // if ok is true
    cout << "YES" << endl; // print "YES"
  else // else
    cout << "NO" << endl; // print "NO"
} 