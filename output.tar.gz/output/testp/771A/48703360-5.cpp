
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long node; // node = long long
const long long N = 150005; // N = const long long with N = 150005
vector<long long> vp[N]; // vp = vector of long long
long long vis[N]; // vis = long long array of size N
map<long long, long long> mp; // mp = map from long long to long long
void dfs(long long n) { // in the function dfs that takes long long n
  node++; // increment node
  mp[vp[n].size()] = n; // mp[vp[n].size()] = n
  vis[n] = 1; // vis[n] = 1
  for (long long i = 0; i < vp[n].size(); i++) { // for i = 0 to vp[n].size() exclusive
    if (!vis[vp[n][i]]) { dfs(vp[n][i]); } // if not vis[vp[n][i]], dfs on vp[n][i]
  } 
} 
int main() { 
  long long n, m; // n, m = long long
  cin >> n >> m; // read n, m
  long long a, b; // a, b = long long
  for (long long i = 0; i < m; i++) { // for i = 0 to m exclusive
    cin >> a >> b; // read a, b
    vp[a].push_back(b); // append b in vp[a]
    vp[b].push_back(a); // append a in vp[b]
  } 
  for (long long i = 1; i <= n; i++) { // for i = 1 to n
    if (!vis[i]) { // if not vis[i]
      node = 0; // node = 0
      dfs(i); // dfs on i
      if (mp.size() == 1 && vp[i].size() == node - 1) { // if mp.size() is 1 and vp[i].size() is node - 1
        mp.clear(); // clear mp
        continue; // continue next iteration
      } else { // else
        cout << "NO" // print NO
          << "\n"; // new line
        return 0; 
      } 
    } 
  } 
  cout << "YES" // print YES
    << "\n"; // new line
} 