
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long int n, m, c[150005], vert, edge; // n, m, vert, edge = long long int and c = long long int array of size 150005
vector<long long int> adj[150005]; // adj = long long int vector of size 150005
void dfs(long long int v) { // in function dfs taking a long long int v
  edge += adj[v].size(); // add size of adj[v] to edge
  vert++; // increment vert
  c[v] = 1; // set c[v] to 1
  for (long long int j = 0; j < adj[v].size(); j++) { // for j = 0 to size of adj[v]
    if (c[adj[v][j]] == 0) { dfs(adj[v][j]); } // if c[adj[v][j]] equals 0 then call dfs of adj[v][j]
  } 
} 
int main() { 
  long long int i, x, y; // i, x, y = long long int
  cin >> n >> m; // read n then m
  for (i = 0; i < m; i++) { // for i = 0 to m
    cin >> x >> y; // read x then y
    adj[x].push_back(y); // append y to adj[x]
    adj[y].push_back(x); // append x to adj[y]
  } 
  for (i = 1; i <= n; i++) { // for i = 1 to n inclusive
    vert = 0; // set vert to 0
    edge = 0; // set edge to 0
    if (c[i] == 0) { // if c[i] equals 0
      dfs(i); // call dfs of i
      if (vert * (vert - 1) != edge) cout << "NO\n", exit(0); // if vert * (vert - 1) does not equal edge then print "NO" and call exit of 0
    } 
  } 
  cout << "YES\n"; // print "YES"
} 