
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

void read(int &x) { // in function read taking a reference to an int x
  char ch = getchar(); // ch = char with ch = value of getchar
  bool f = 0; // f = bool with f = false
  x = 0; // set x to 0
  while (ch > '9' || ch < '0') { // loop while ch is greater than '9' or less than '0'
    if (ch == '-') f = 1; // if ch equals '-' then set f to 1
    ch = getchar(); // set ch to result of getchar
  } 
  while (ch >= '0' && ch <= '9') { // loop while ch is greater or equal to '0' and less or equal to '9'
    x = x * 10 + ch - 48; // set x to x * 10 + ch - 48
    ch = getchar(); // set ch to result of getchar
  } 
  if (f) x = -x; // if f is not 0 then set x to -x
} 
void read(long long &x) { // in function read taking a reference to a long long x
  char ch = getchar(); // ch = char with ch = result of getchar
  bool f = 0; // f = bool with f = false
  x = 0; // set x to 0
  while (ch > '9' || ch < '0') { // loop while ch is greater than '9' or less than '0'
    if (ch == '-') f = 1; // if ch equals '-' then set f to 1
    ch = getchar(); // set ch to result of getchar
  } 
  while (ch >= '0' && ch <= '9') { // loop while ch is greater or equal to '0' and ch is less or equal to '9'
    x = x * 10 + ch - 48; // set x to x * 10 + ch - 48
    ch = getchar(); // set ch to result of getchar
  } 
  if (f) x = -x; // if f equals true set x to -x
} 
int parent[150001]; // parent = int array of size 150001
int ranks[150001]; // ranks = int array of size 150001
long long sizeedge[150001]; // sizeedge = long long array of size 150001
long long size[150001]; // size = long long array of size 150001
void build(int n) { // in function build taking an int n
  for (int i = 0; i <= n; i++) parent[i] = i, size[i] = 1LL; // for i = 0 to n inclusive set parent[i] to i and size[i] to 1
} 
int find(int x) { // in function find taking an int x and returning an int
  return parent[x] = x == parent[x] ? x : find(parent[x]); // set parent[x] to x if parent[x] equals x else set it to find of parent[x] and return parent[x]
} 
void merge(int x, int y) { // in function merge taking two ints x and y
  x = find(x), y = find(y); // set x to find of x and set y to find of y
  if (ranks[x] > ranks[y]) swap(x, y); // if ranks[x] is greater than ranks[y] then call swap on x and y
  if (ranks[x] == ranks[y]) ranks[y]++; // if ranks[x] equals ranks[y] then increment ranks[y]
  if (x != y) { // if x does not equal y
    parent[x] = y; // set parent[x] to y
    size[y] = size[x] + size[y]; // add size[x] to size[y]
    sizeedge[y] = sizeedge[x] + sizeedge[y] + 1LL; // add sizeedge[x] + 1 to sizeedge[y]
  } else { // else
    sizeedge[y]++; // increment sizeedge[y]
  } 
} 
int main() { 
  int v, e; // v, e = int
  read(v); // call read of v
  read(e); // call read of e
  build(v); // call build of v
  for (int i = 0; i < e; i++) { // for i = 0 to e
    int from, to; // from, to = int
    read(from); // call read of from
    read(to); // call read of to
    merge(from, to); // call merge of from and to
  } 
  for (int i = 1; i <= v; i++) { // for i = 1 to v inclusive
    if (i == find(i)) { // if i equals the result of find of i
      if (sizeedge[i] != size[i] * (size[i] - 1) / 2) { // if sizeedge[i] does not equal size[i] * (size[i] - 1) / 2
        puts("NO"); // call puts of "NO"
        return 0; 
      } 
    } 
  } 
  puts("YES"); // call puts of "YES"
  return 0; 
} 