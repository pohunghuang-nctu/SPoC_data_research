
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, a, i, j, num5, num0, r; // declare integer variables n, a, i, j, num5, num0 and r
  while (cin >> n) { // while reading n in a loop
    num5 = 0; // set value of num5 to 0
    num0 = 0; // set value of num0 to 0
    for (i = 0; i < n; i++) { // for i = 0 to n exclusive
      cin >> a; // read a
      if (a == 5) { // if a = 5
        num5++; // increase num5 by one
      } else if (a == 0) { // else if a = 0
        num0++; // increase num0 by one
      } 
    } 
    r = num5 / 9; // r = num5 / 9
    if (!num0) { // if num0 is 0
      cout << "-1" << endl; // print "-1"
    } else { // else
      if (r && num0) { // if r && num0 are both not 0
        for (i = 0; i < r * 9; i++) { cout << "5"; } // for i = 0 to r * 9 exclusive print "5"
        for (i = 0; i < num0; i++) { cout << "0"; } // for i = 0 to num0 exclusive print "0"
      } else { // else
        cout << "0"; // print "0"
      } 
      cout << "" << endl; // print ""
    } 
  } 
  return 0; 
} 