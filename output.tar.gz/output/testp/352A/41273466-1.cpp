
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, x, num1, num2, ans; // create integers n, x, num1, num2, ans
  while (cin >> n) { // while read n is true
    num1 = 0; // set num1 to 0
    num2 = 0; // set num2 to 0
    for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
      cin >> x; // read x
      if (x == 0) // if x is 0
        num1++; // increment num1
      else if (x == 5) // else if x is 5
        num2++; // increment num2
    } 
    if (num1 == 0) // if num1 is 0
      cout << "-1" << endl; // print "-1" print newline
    else { // else
      ans = num2 / 9; // set ans to num2 / 9
      if (ans && num1) { // if ans and num1
        for (int i = 0; i < ans * 9; i++) cout << "5"; // for i = 0 to ans * 9 exclusive, print "5"
        for (int i = 0; i < num1; i++) cout << "0"; // for i = 0 to num1 exclusive, print "0"
      } else // else
        cout << "0"; // print "0"
      cout << endl; // print newline
    } 
  } 
  return 0; 
} 