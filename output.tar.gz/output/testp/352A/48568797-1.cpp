
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // create integer n
  cin >> n; // read n
  int cf = 0, cz = 0; // create integers cf, cz with cf = 0, cz = 0
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    int t; // create integer t
    cin >> t; // read t
    if (t == 5) // if t is 5
      cf++; // increment cf
    else // else
      cz++; // increment cz
  } 
  if (cz == 0) { // if cz is 0
    cout << -1 << endl; // print -1 print newline
    return 0; 
  } 
  for (int i = 0; i < cf / 9 * 9; i++) { cout << "5"; } // for i = 0 to cf / 9 * 9 exclusive, print "5"
  if (cf >= 9) // if cf is greater than or equal to 9
    for (int i = 0; i < cz; i++) cout << "0"; // for i = 0 to cz exclusive, print "0"
  else // else
    cout << "0"; // print "0"
  cout << endl; // print newline
} 