
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, temp; // n, temp = integers
  int zeros = 0, fives = 0; // zeros, fives = integers with zeros = 0 and fives = 0
  cin >> n; // read n
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> temp; // read temp
    if (temp == 5) // if temp = 5
      fives++; // increment fives
    else // else
      zeros++; // increment zeros
  } 
  if (zeros > 0 && fives >= 9) { // if zeros > 0 and fives > 9
    int i = 0; // i = 0
    for (int i = 1; i <= (fives - (fives % 9)); i++) { cout << 5; } // for i = 1 to ( fives - fives remainder 9 ) inclusive print 5
    while (zeros--) { cout << 0; } // while decrement zeros print 0
    cout << endl; // print newline
  } else if (zeros <= 0) { // else if zeros <= 0
    cout << "-1" << endl; // print -1
  } else { // else
    cout << 0 << endl; // print 0
  } 
} 