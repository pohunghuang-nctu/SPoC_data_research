
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long int i, n, m, j, a, count = 0, c = 0, last, have, sum = 0, rest; // create long long integers i, n, m, j, a, count, c, last, have, sum, rest with count = 0, c = 0, sum = 0
  cin >> n; // read n
  for (i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> a; // read a
    ; // end statement
    if (a == 0) // if a is 0
      c++; // increment c
    else { // else
      count++; // increment count
      sum += a; // increment sum by a
    } 
  } 
  if (count / 9 != 0 && c > 0) { // if count / 9 is not 0 and c is greater than 0
    have = sum / 9; // set have to sum / 9
    rest = have / 5; // set rest to have / 5
    for (i = 0; i < 9 * rest; i++) cout << 5; // for i = 0 to 9 * rest exclusive, print 5
    for (i = 0; i < c; i++) cout << 0; // for i = 0 to c exclusive, print 0
    cout << endl; // print newline
  } else if (c > 0) // else if c is greater than 0
    cout << 0 << endl; // print 0 print newline
  else // else
    cout << -1 << endl; // print -1 print newline
  return 0; 
} 