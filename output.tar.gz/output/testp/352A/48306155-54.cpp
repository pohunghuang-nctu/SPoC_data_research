
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n; // create long long n
  while (cin >> n) { // read n in a loop
    int z = 0, f = 0, ans = 0; // create integers z, f and ans = 0
    for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
      int tmp; // declare integer tmp
      cin >> tmp; // read tmp
      if (tmp == 5) f++; // if tmp = 5 increment f
      if (tmp == 0) z++; // if tmp = 0 increment z
      if (f % 9 == 0) ans = f; // if f % 9 = 0, set ans to f
    } 
    if (!z) // if z is 0
      cout << -1 << endl; // print -1 and a new line
    else if (f < 9) // else if f is less than 9
      cout << 0 << endl; // print 0 and a new line
    else { // else
      for (int i = 0; i < ans; i++) cout << 5; // print 5 ans times
      for (int i = 0; i < z; i++) cout << 0; // print 0 z times
      cout << endl; // print new line
    } 
  } 
  return 0; 
} 