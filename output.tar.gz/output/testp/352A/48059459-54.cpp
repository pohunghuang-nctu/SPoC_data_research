
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int zeroes = 0; // declare integer variable zeroes = 0
  int fives = 0; // declare integer variable fives = 0
  int n; // declare integer variable n
  cin >> n; // read n
  int temp; // declare integer variable temp
  for (int i = 0; i < n; i++) { // for integer i = 0 to n exclusive
    cin >> temp; // read temp
    if (temp == 0) zeroes++; // if temp = 0 increment zeroes
    if (temp == 5) fives++; // if temp = 5 increment fives
  } 
  if (zeroes && fives >= 9) { // if zeroes and fives >= 9
    for (int i = 0; i < fives / 9 * 9; i++) { cout << "5"; } // for integer i = 0 to fives / 9 * 9 exclusive print "5"
    for (int i = 0; i < zeroes; i++) { cout << "0"; } // for i = 0 to zeroes exclusive print "0"
    cout << "\n"; // print "\n"
  } else if (zeroes) { // else if zeroes is not 0
    cout << "0\n"; // print "0\n"
  } else { // else
    cout << "-1\n"; // print "-1\n"
  } 
} 