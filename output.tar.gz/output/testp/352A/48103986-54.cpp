
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, temp; // declare integer variables n and temp
  cin >> n; // read n
  int cont1 = 0, cont2 = 0; // declare integer variables cont1 and cont2 = 0
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> temp; // read temp
    if (temp == 5) // if temp = 5
      cont1++; // increase cont1 by one
    else // else
      cont2++; // increase cont2 by one
  } 
  if (cont2 == 0) // if cont2 = 0
    cout << "-1\n"; // print "-1\n"
  else { // else
    int ans = 0; // declare integer variable ans = 0
    temp = 0; // temp = 0
    for (int i = 1; i <= cont1; i++) { // for i = 1 to cont1 inclusive
      temp = temp * 10 + 5; // temp = temp * 10 + 5
      temp %= 9; // temp %= 9
      if (temp == 0) { ans = i; } // if temp = 0 assign i to ans
    } 
    if (ans == 0) { // if ans = 0
      cout << "0\n"; // print "0\n"
    } else { // else
      for (int i = 0; i < ans; i++) { cout << "5"; } // print "5" ans times
      for (int i = 0; i < cont2; i++) { cout << "0"; } // print "0" cont2 times
      cout << '\n'; // print '\n'
    } 
  } 
  return 0; 
} 