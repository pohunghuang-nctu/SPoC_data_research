
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // let n be a integer
  cin >> n; // read n
  int count5 = 0; // let count5 be a integer with value 0
  int count0 = 0; // let count0 be a integer with value 0
  for (int i = 0; i < n; i++) { // for integer i=0 to n exclusive
    int temp = 0; // let temp be a integer with value 0
    cin >> temp; // read temp
    if (temp == 0) // if (temp is equal to 0)
      count0++; // increase count0 by 1
    else // else do the following
      count5++; // increase count5 by 1
  } 
  int a = count5 / 9; // let a be an integer with value count5 / 9
  int b = count0; // let b be an integer with value count0
  if (b == 0) { // if ( b is equal to 0)
    cout << -1 << endl; // print -1 and newline
  } else if (a == 0) { // else if ( a is equal to 0 )
    cout << 0 << endl; // print 0 and newline
  } else { // else do the following
    for (int i = 0; i < a; i++) cout << 555555555; // for ( integer i=0 to a exclusive), print 555555555
    for (int i = 0; i < b; i++) cout << 0; // for ( integer i=0 to b exclusive), print 0
    cout << endl; // print newline
  } 
  return 0; 
} 