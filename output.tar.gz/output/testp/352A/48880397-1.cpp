
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // create integer n
  cin >> n; // read n
  int arr[n], number_of_5 = 0, number_of_0 = 0; // create integer array arr with size n, create integers number_of_5, number_of_0, with number_of_5 = 0, number_of_0=0
  ; // end statement
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> arr[i]; // read arr[i]
    if (arr[i] == 5) { // if arr[i] is 5
      number_of_5++; // increment number_of_5
    } else { // else
      number_of_0++; // increment number_of_0
    } 
  } 
  if (number_of_0 == 0) { // if number_of_0 is 0
    cout << "-1\n"; // print "-1\n"
    return 0; 
  } else { // else
    number_of_5 = floor(number_of_5 / 9); // set number_of_5 to round up ( number_of_5 / 9 )
    string answer = ""; // create string answer with answer = ""
    for (int i = 0; i < (number_of_5); i++) { answer += "555555555"; } // for i = 0 to number_of_5 exclusive, increment answer by "555555555"
    for (int i = 1; i <= number_of_0; i++) { // for i = 1 to number_of_0 inclusive
      if (answer.length() == 0) { // if length of answer is 0
        answer += "0"; // increment answer by "0"
        break; // break loop
      } else { // else
        answer += "0"; // increment answer by "0"
      } 
    } 
    cout << answer << endl; // print answer print newline
  } 
  return 0; 
} 