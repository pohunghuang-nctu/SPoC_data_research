
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // declare integer called n
  cin >> n; // read n
  int f = 0, z = 0; // let f and z be integers = 0
  for (int i = 0; i < n; ++i) { // for integer i = 0 to n exclusive
    int a; // declare integer a
    cin >> a; // read a
    if (a == 5) // if a = 5
      f += 1; // increase f by 1
    else // else
      z += 1; // increase z by 1
  } 
  f = f / 9 * 9; // f = f / 9 * 9
  if (z == 0) { // if z = 0
    cout << -1 << endl; // print -1 and a new line
    return 0; 
  } 
  cout << string(f, '5') << (f == 0 ? "0" : string(z, '0')) << endl; // print string(f, '5'), "0" if f = 0 or string(z, '0'), and a new line
} 