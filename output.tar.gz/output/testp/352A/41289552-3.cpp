
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, t, cnt0 = 0, cnt5 = 0; // n, t, cnt0, cnt5 = integers with cnt0 = 0 and cnt5 = 0
  cin >> n; // read n
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> t; // read t
    if (t == 0) // if t equals 0
      cnt0++; // add 1 to cnt0
    else // else
      cnt5++; // add 1 to cnt5
  } 
  int x = cnt5 / 9; // set x to cnt5/9
  string ans; // ans = string
  if (cnt0 == 0) { // if cnt0 equals 0
    ans = "-1"; // set ans to "-1"
  } else { // else
    if (x == 0) // if x equals 0
      ans = "0"; // set ans to "0"
    else { // else
      for (int i = 0; i < x; i++) { ans += "555555555"; } // for i = 0 to x exclusive add "555555555" to ans
      for (int i = 0; i < cnt0; i++) { ans += "0"; } // for i = 0 to cnt0 exclusive add "0" to ans
    } 
  } 
  cout << ans << endl; // print ans
  return 0; 
} 