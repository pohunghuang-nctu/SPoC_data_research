
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long int n; // declare long long integer variable n
  cin >> n; // read n
  long long int fives = 0, tmp = 0, zeroes = 0; // create long long integers fives, tmp and zeroes = 0
  while (n--) { // while n > 0, decrement it in a loop
    cin >> tmp; // read tmp
    if (tmp == 5) // if tmp = 5
      fives += 1; // increase fives by 1
    else // else
      zeroes += 1; // increase zeroes by 1
  } 
  fives /= 9; // divide fives by 9
  if (fives && zeroes) { // if fives and zeroes
    while (fives-- > 0) { cout << "555555555"; } // while fives > 0, decrement it in a loop and print "555555555"
    while (zeroes-- > 0) { cout << "0"; } // while zeroes > 0, decrement it in a loop and print "0"
    cout << endl; // print new line
  } else if (zeroes) // else if zeroes is not 0
    cout << "0" << endl; // print "0"
  else // else
    cout << "-1" << endl; // print "-1"
  return 0; 
} 