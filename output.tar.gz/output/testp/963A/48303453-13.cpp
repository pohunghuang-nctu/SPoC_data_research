
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int n, a, b, k; // make ints n, a, b, and k
int s[100000]; // let int array s of size 100000
string inp; // let string inp
map<int, int> dp; // make map dp from ints and ints
int bpow(int n, int e) { // declare bpow taking in ints n and e and returning integer
  int b[30]; // create integer array b of size 30
  b[0] = n; // set b[0] to n
  for (int i = 1; i < 30; i++) b[i] = ((long long)b[i - 1] * b[i - 1]) % 1000000009; // for i = 1 to 30 exclusive, set b[i] to ((long long)b[i - 1] * b[i - 1]) % 1000000009
  int ans = 1; // make integer ans = 1
  for (int i = 0; i < 30; i++) // for i = 0 to 30 exclusive
    if (e & (1 << i)) ans = ((long long)ans * b[i]) % 1000000009; // if e & (1 << i) are truthy set ans to ((long long)ans * b[i]) % 1000000009
  return ans; // return ans
} 
int bdiv(int n, int d) { // declare bdiv taking in integers n and d and returning integer
  return ((long long)n * bpow(d, 1000000009 - 2)) % 1000000009; // return the result of ((long long)n * bpow(d, 1000000009 - 2)) % 1000000009
} 
int alt(int e) { // declare alt taking in int e and returning int
  assert(e % k == 0); // if e % k is not 0, end function
  if (!dp.count(e)) { // if dp.count(e) is falsy
    if (e == 0) // if e is 0
      assert(0); // end function
    else if (e == k) // else if e is k
      dp[e] = 1; // set dp[e] to 1
    else { // else do
      int l = e / 2 / k * k; // create int l = e / 2 / k * k
      int r = e - l; // make integer r = e - 1
      int ans = (((long long)alt(l) * bpow(a, r)) + (long long)alt(r) * bpow(b, l)) % 1000000009; // let integer ans = (((long long)alt(l) * bpow(a, r)) + (long long)alt(r) * bpow(b, l)) % 1000000009
      dp[e] = ans; // set dp[e] to ans
    } 
  } 
  return dp[e]; // return dp[e]
} 
int main() { 
  cin >> n >> a >> b >> k; // read n, a, b, and k
  cin >> inp; // read inp
  for (int i = 0; i < k; i++) { // for i = 0 to k exclusive
    if (inp[i] == '+') // if inp[i] is '+'
      s[i] = 1; // set s[i] to 1
    else // else do
      s[i] = -1; // set s[i] to -1
  } 
  int x = 0; // create int x = 0
  for (int i = 0; i < k; i++) { // for i = 0 to k exclusive
    int toadd = ((long long)s[i] * bpow(a, k - 1 - i)) % 1000000009; // create integer toadd = ((long long)s[i] * bpow(a, k - 1 - i)) % 1000000009
    toadd = ((long long)toadd * bpow(b, i)) % 1000000009; // set toadd to ((long long)toadd * bpow(b, i)) % 1000000009
    x = ((long long)x + toadd + 1000000009) % 1000000009; // set x to ((long long)x + toadd + 1000000009) % 1000000009
  } 
  cerr << x << " " << alt(n + 1) << endl; // display x, " ", and alt(n + 1) to error
  int ans = ((long long)x * alt(n + 1)) % 1000000009; // create integer ans = ((long long)x * alt(n + 1)) % 1000000009
  cout << ans << endl; // display ans
} 