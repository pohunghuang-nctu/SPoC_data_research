
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 2e5 + 10; // declare constant integer N = 2e5 + 10
long long int n, a, b, k, MOD = 1e9 + 9; // declare long long integers n, a, b, k, MOD = 1e9 + 9
long long fast_power(long long base, long long power) { // declare fast_power with long longs base, power as arguments, returning long long
  long long result = 1; // declare long long result = 1
  while (power > 0) { // while power is greater than 0
    if (power % 2 == 1) { result = (result * base) % MOD; } // if power % 2 is 1, let result be (result * base) % MOD
    base = (base * base) % MOD; // let base be (base * base) % MOD
    power = power / 2; // let power be power / 2
  } 
  return result; // return result from function
} 
int main() { 
  cin >> n >> a >> b >> k; // read n, a, b, k
  string s; // declare string s
  cin >> s; // read s
  int l = (n + 1) / k - 1; // declare integer l = (n + 1) / k - 1
  long long int val = (b * fast_power(a, MOD - 2)) % MOD; // declare long long integer val = (b * result of run fast_power(a, MOD - 2)) % MOD
  long long int valp = fast_power(val, k); // declare long long integer valp = result of run fast_power(val, k)
  long long int ans = 0; // declare long long integer ans = 0
  long long int geo; // declare long long integer geo
  if (valp != 1) { // if valp is not 1
    geo = (fast_power(valp, l + 1) - 1) % MOD + MOD; // let geo be (result of run fast_power(valp, l + 1) - 1) % MOD + MOD
    geo = geo * fast_power((valp - 1) % MOD + MOD, MOD - 2) % MOD; // let geo be geo * result of run fast_power((valp - 1) % MOD + MOD, MOD - 2) % MOD
    geo %= MOD; // let geo be geo % MOD
  } else // else
    geo = l + 1; // let geo be l + 1
  for (int i = 0; i < k; i++) { // for i = 0 to k exclusive
    long long int calc = fast_power(b, i) * fast_power(a, n - i) % MOD; // declare long long integer calc = result of run fast_power(b, i) * result of run fast_power(a, n - i) % MOD
    if (s[i] == '-') // if s[i] is '-'
      ans = (ans - (geo * calc % MOD)) % MOD + MOD; // let ans be (ans - (geo * calc % MOD)) % MOD + MOD
    else // else
      ans = (ans + (geo * calc % MOD) % MOD); // let ans be (ans + (geo * calc % MOD) % MOD)
    ans %= MOD; // let ans be ans % MOD
  } 
  cout << ans << endl; // print ans and newline
  return 0; 
} 