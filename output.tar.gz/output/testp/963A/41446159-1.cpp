
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long MOD = 1000000009; // declare long long MOD = 1000000009
long long pw(long long a, long long b) { // declare pw with long longs a, b as arguments, returning long long
  if (b == 0) return 1; // if b is 0, return 1 from function
  if (b == 1) return a % MOD; // if b is 1, return a % MOD
  if (b % 2) { // if b % 2
    long long rs = pw(a, b - 1); // declare long long rs = result of run pw ( a, b - 1 )
    return (rs * a) % MOD; // return ( rs * a ) % MOD from function
  } 
  long long rs = pw(a, b / 2); // declare long long rs = result of run w with a, b / 2 as arguments
  return (rs * rs) % MOD; // return ( rs * rs ) % MOD
} 
vector<long long> sm; // declare long long vector sm
long long solve(long long a, long long b) { // declare solve with long longs a, b as arguments, returning long long
  if (b == 0) return 0; // if b is 0, return 0 from function
  for (long long i = 0; i < 35; i++) { // for i = 0 to 35 exclusive
    long long ba = (1LL << i) & b; // declare long long ba = (1LL bitshift left i ) bitwise and b
    if (ba == 0) continue; // if ba is 0, end current loop iteration
    return (sm[i] + solve(a, b - (1LL << i)) * pw(a, (1LL << i))) % MOD; // return ( sm[i] + result of run solve( a, b - ( 1LL bitshift left i )) * result of run pw(a, (1LL bitshift left i))) % MOD
  } 
} 
int main() { 
  long long n, a, b, k; // declare long longs n, a, b, k
  cin >> n >> a >> b >> k; // read n, a, b, k
  string s; // declare string s
  cin >> s; // read s
  long long X = 1, Y = 1; // declare long long X = 1, y + 1
  for (long long i = 0; i < k; i++) { // for i = 0 to k exclusive
    X *= b; // let X be X * b
    X %= MOD; // let X be X % MOD
  } 
  for (long long i = 0; i < k; i++) { // for i = 0 to k exclusive
    Y *= a; // let Y be Y * a
    Y %= MOD; // let Y be Y % MOD
  } 
  X *= pw(Y, MOD - 2); // let X be X * result of run pw(Y, MOD - 2)
  X %= MOD; // let X be X % MOD
  sm.push_back(1); // add 1 to end of sm
  for (long long i = 0; i < 40; i++) { // for i = 0 to 40 exclusive
    sm.push_back(sm.back() + sm.back() * pw(X, (1LL << i))); // add ( back of sm + back of sm * result of run pw(X, (1LL bitshift left i) ) to end of sm
    sm.back() %= MOD; // let back of sm be back of sm % MOD
  } 
  long long st = solve(X, (n + 1) / k); // declare long long st = result of run solve(X, (n + 1) / k)
  long long ans = 0; // declare long long ans = 0
  for (long long i = 0; i < k; i++) { // for i = 0 to k exclusive
    long long rs = (pw(b, i) * pw(a, n - i)) % MOD; // declare long long rs = (result of run pw(b,i) * result of run pw(a,n-1) ) % MOD
    if (s[i] == '-') rs *= -1; // if s[i] is '-', let rs be rs * -1
    rs *= st; // let rs be rs * st
    ans += rs; // increment ans by rs
    ans %= MOD; // let ans be ans % MOD
  } 
  if (ans < 0) ans += MOD; // if ans is less than 0, increment ans by MOD
  cout << ans << endl; // print ans and newline
} 