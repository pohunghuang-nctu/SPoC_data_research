
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long mod = 1e9 + 9; // create a long long integer mod=1e9+9
long long qm(long long a, long long b) { // into the function qm which takes two long long integers a and b and returns a long long int
  long long ans = 1; // let ans be long long int with ans=1
  while (b > 0) { // while b>0 do the following
    if (b & 1) ans = ans * a % mod; // if b&1 then set ans= ans * a % mod
    b >>= 1; // set b= b >> 1
    a = a * a % mod; // set a= a*a%mod
  } 
  return (ans % mod + mod) % mod; // return (ans % mod + mod) % mod
} 
char c[1000005]; // c= character array of size 1000005
int main() { 
  long long n, a, b, k; // n,a,b,k= long long ints
  cin >> n >> a >> b >> k; // read n,a,b,k
  cin >> c; // read c
  long long ans = 0; // create long long int ans=0
  if (n + 1 <= k) { // if n+1 <= k
    for (long long i = 0; i <= n; i++) { // for i=0 to n inclusive
      if (c[i] == '-') { // if c[i] = -
        ans = ans - qm(a, n - i) * qm(b, i); // then set ans = ans - qm(a, n - i) * qm(b, i)
        ans = (ans % mod + mod) % mod; // set ans = (ans % mod + mod) % mod
      } else { // else do the following
        ans = ans + qm(a, n - i) * qm(b, i); // set ans = ans + qm(a, n - i) * qm(b, i)
        ans = (ans % mod + mod) % mod; // set ans = (ans % mod + mod) % mod
      } 
    } 
    ans = (ans % mod + mod) % mod; // set ans = (ans % mod + mod) % mod
    cout << ans << endl; // print ans
  } else { // else do the following
    long long t = (n + 1) / k; // create long long t= (n+1) / k
    long long g = (n + 1) % k; // creaye long long integer g = (n+1) %k
    long long x = 0; // let x=0 be a long long integer
    if (g == 0) { // if g is equal to 0
      for (long long i = 0; i < k; i++) { // for i=0 to k exclusive
        if (c[i] == '-') { // if c[i] is equal to -
          x = x - qm(a, n - i) * qm(b, i); // then set x = x - qm(a, n - i) * qm(b, i)
          x = (x % mod + mod) % mod; // set x = (x % mod + mod) % mod
        } else { // else do the following
          x = x + qm(a, n - i) * qm(b, i); // set x = x + qm(a, n - i) * qm(b, i)
          x = (x % mod + mod) % mod; // assign (x % mod + mod) % mod to x
        } 
      } 
      if (qm(a, k) == qm(b, k)) { // if qm(a, k) = qm(b, k)
        ans = t * x; // then set ans = t*t
        ans = (ans % mod + mod) % mod; // assign (ans % mod + mod) % mod to ans
        cout << ans << endl; // print ans
        return 0; 
      } 
      long long jj = qm(a, t * k) - qm(b, t * k); // create long long integer jj = qm(a, t * k) - qm(b, t * k)
      jj = x * jj % mod; // set jj = x*jj%mod
      jj = jj * qm(a, k) % mod; // set jj= jj* qm(a,k) % mod
      ; // do nothing
      jj = jj % mod; // set jj = jj % mod
      long long nn = (qm(a, k) - qm(b, k)); // create long long integer nn = qm(a, k) - qm(b, k)
      nn = nn % mod; // set nn = nn % mod
      nn = nn * qm(a, t * k); // assign nn * qm(a, t * k) to nn
      nn = nn % mod; // set nn = nn % mod
      nn = qm(nn, mod - 2); // set nn = qm(nn, mod - 2)
      ans = jj * nn; // assign jj * nn to ans
      ans = (ans % mod + mod) % mod; // set ans to (ans % mod + mod) % mod
      cout << ans << endl; // print ans
    } else { // else do the following
      for (long long i = 0; i < k; i++) { // for i=0 to k exclusive
        if (c[i] == '-') { // if c[i] is equal to -
          x = x - qm(a, n - i) * qm(b, i); // set x = x - qm(a, n - i) * qm(b, i)
          x = (x % mod + mod) % mod; // set x = (x % mod + mod) % mod
        } else { // else do the following
          x = x + qm(a, n - i) * qm(b, i); // set x to x + qm(a, n - i) * qm(b, i)
          x = (x % mod + mod) % mod; // assign (x % mod + mod) % mod to x
        } 
      } 
      if (qm(a, k) == qm(b, k)) { // if qm(a, k) == qm(b, k)
        ans = t * x; // then set ans= t*x
        ans = (ans % mod + mod) % mod; // set ans = (ans % mod + mod) % mod
        for (long long hh = 0; hh < g; hh++) { // for hh=0 to g exclusive
          if (c[hh] == '-') { // if c[hh] is equal to -
            ans = ans - qm(a, n - (t * k + hh)) * qm(b, (t * k + hh)); // set ans = ans - qm(a, n - (t * k + hh)) * qm(b, (t * k + hh))
            ans = (ans % mod + mod) % mod; // set ans = (ans % mod + mod) % mod
          } else { // else do the following
            ans = ans + qm(a, n - (t * k + hh)) * qm(b, (t * k + hh)); // set ans = ans + qm(a, n - (t * k + hh)) * qm(b, (t * k + hh))
            ans = (ans % mod + mod) % mod; // set ans = (ans % mod + mod) % mod
          } 
        } 
        ans = (ans % mod + mod) % mod; // set ans = (ans % mod + mod) % mod
        cout << ans << endl; // print ans
        return 0; 
      } 
      long long jj = qm(a, t * k) - qm(b, t * k); // create long long integer jj = qm(a, t * k) - qm(b, t * k)
      jj = x * jj % mod; // set jj to x * jj % mod
      jj = jj * qm(a, k) % mod; // set jj = jj * qm(a, k) % mod
      ; // do nothing
      jj = jj % mod; // assign jj % mod to jj
      long long nn = (qm(a, k) - qm(b, k)); // create long long integer nn = (qm(a, k) - qm(b, k))
      nn = nn % mod; // set nn = nn % mod
      nn = nn * qm(a, t * k); // assign nn * qm(a, t * k) to nn
      nn = nn % mod; // set nn = nn % mod
      nn = qm(nn, mod - 2); // set nn = qm(nn, mod - 2)
      ans = jj * nn; // set ans = jj * nn
      ans = (ans % mod + mod) % mod; // set ans = (ans % mod + mod) % mod
      for (long long hh = 0; hh < g; hh++) { // for hh=0 to g exclusive
        if (c[hh] == '-') { // if c[hh] is -
          ans = ans - qm(a, n - (t * k + hh)) * qm(b, (t * k + hh)); // set ans = ans - qm(a, n - (t * k + hh)) * qm(b, (t * k + hh))
          ans = (ans % mod + mod) % mod; // set ans = (ans % mod + mod) % mod
        } else { // else do the following
          ans = ans + qm(a, n - (t * k + hh)) * qm(b, (t * k + hh)); // set ans = ans + qm(a, n - (t * k + hh)) * qm(b, (t * k + hh))
          ans = (ans % mod + mod) % mod; // set ans = (ans % mod + mod) % mod
        } 
      } 
      ans = (ans % mod + mod) % mod; // set ans = (ans % mod + mod) % mod
      cout << ans << endl; // print ans
    } 
  } 
} 