
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long const MOD = 1e9 + 9LL; // let MOD a constant long long with value 1e9 + 9LL
string s; // let s a string
long long n, a, b, k; // let n, a, b, and k long longs
long long MODULUS(long long b, long long p) { // in function MODULUS which takes long longs b and p and returns a long long
  long long ret = 1LL; // let ret a long long with value 1LL
  while (p) { // while p
    if (p & 1LL) ret = (ret * b) % MOD; // if p & 1LL, set ret to (ret * b) mod MOD
    b = (b * b) % MOD; // set b to (b * b) mod MOD1
    p >>= 1LL; // right shift p by 1LL
  } 
  return ret; // return ret
} 
long long MODINVERSE(long long x) { // in function MODINVERSE which takes long long x and returns a long long
  return MODULUS(x, MOD - 2LL); // return MODULUS applied to x and MOD - 2LL
} 
long long Add(long long x, long long y) { // in function Add which takes long longs x and y and returns a long long
  x += y; // add y to x
  if (x > MOD) return x - MOD; // if x > MOD, return x - MOD
  return x; // return x
} 
long long Sub(long long x, long long y) { // in function Sub which takes long longs x and y and returns a long long
  x -= y; // subtract y from x
  if (x < 0) return x + MOD; // if x < 0, return x + MOD
  return x; // return x
} 
long long Mul(long long x, long long y) { // in function MUL which takes long longs x and y and returns a long long
  x *= y; // multiply x by y
  return x % MOD; // return x mod MOD
} 
long long Div(long long x, long long y) { // in function Div which takes long longs x and y and returns a long long
  return (x * MODINVERSE(y)) % MOD; // return (x * MODINVERSE(y)) mod MOD
} 
int main() { 
  cin >> n >> a >> b >> k >> s; // read n, a, b, k, and s
  long long ans = 0LL; // let ans a long long with value 0LL
  long long x = Div(b, a); // let x a long long with value Div(b, a)
  long long c = MODULUS(a, n); // let c a long long with value MODULUS(a, n)
  for (int i = 0; i < k; i += 1) { // for i from 0 to k exclusive
    if (s[i] == '+') { // if s[i] is +
      ans = Add(ans, c); // set ans to Add(ans, c)
    } else { // otherwise
      ans = Sub(ans, c); // set ans to Sub(ans, c)
    } 
    c = Mul(c, x); // set c to Mul(c, x)
  } 
  if (ans < 0) ans += MOD; // if ans is negative, add MOD to ans
  x = MODULUS(x, k); // set x to MODULUS(x, k)
  if (x == 1) { // if x is 1
    ans = Mul(ans, (n + 1) / k); // set ans to Mul(ans, (n + 1) / k)
  } else { // otherwise
    ans = Mul(ans, Sub(MODULUS(x, (n + 1) / k), 1)); // set ans to Mul applied to ans and Sub(MODULUS(x, (n+1)/k), 1)
    ans = Div(ans, Sub(x, 1)); // set ans to Div(ans, Sub(x, 1))
  } 
  cout << ans % MOD << '\n'; // print ans mod MOD
  return 0; 
} 