
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int MAXN = 100000; // MAXN = constant integer = 100000
const long long MOD = 1000000009; // MOD = constant long long = 1000000009
long long poww_mod(long long a, long long b) { // in function poww_mod with arguments long long a and long long b that returns long long
  long long ans = 1; // ans = long long = 1
  a = a % MOD; // a = a modulo MOD
  while (b) { // while b is nonzero
    if (b & 1) ans = (a * ans) % MOD; // if b ends in a one in bits, then ans = (a * ans) modulo MOD
    a = (a * a) % MOD; // a = (a * a) modulo MOD
    b >>= 1; // b shifted by one bit to the right
  } 
  return ans % MOD; // return ans modulo MOD
} 
long long inv(long long t, long long p) { // in function inv with arguments of long long t and long long p that returns a long long
  t = t % p; // t = t modulo p
  return t == 1 ? 1 : (p - p / t) * inv(p % t, p) % p; // return 1 if t is 1 else return (p - p / t) * (call inv with arguments of p modulo t and p) modulo p
} 
int n = 0, k = 0, a = 0, b = 0; // n = integer = 0, k = integer = 0, a = integer = 0, b = integer = 0
long long ans[MAXN + 5], answer = 0; // ans = long long array of size MAX + 5, answer = long long = 0
string s; // s = string
int main() { 
  cin >> n >> a >> b >> k; // read n, a, b, k
  cin >> s; // read s
  long long pre = 0; // pre = long long = 0
  while (k < 10000 && k < n) { // while k < 10000 and k < n
    k = k * 2; // k = k * 2
    s = s + s; // s = s + s
  } 
  for (int i = 0; i < k; ++i) { // for i = 0 to k exclusive
    if (s[i] == '+') // if s[i] is +
      ans[i] = (pre + poww_mod(a, n - i) * poww_mod(b, i)) % MOD; // ans[i] = pre + (call poww_mod with arguments of a, n - i) * (call poww_mod with arguments of b, i) modulo MOD
    else // else
      ans[i] = (pre - poww_mod(a, n - i) * poww_mod(b, i)) % MOD; // ans[i] = pre - (call poww_mod with arguments of a, n - i) * (call poww_mod with arguments of b, i) modulo MOD
    pre = ans[i]; // pre = ans[i]
  } 
  if (n < k) { // if n < k
    if (ans[n] < 0) ans[n] += MOD; // if ans[n] < 0, then ans[n] = ans[n] + mod
    cout << ans[n] << endl; // print ans[n]
  } else { // else
    int beishu = n / k; // beishu = integer = n / k
    int save = n - n / k; // save = integer = n - n / k
    long long mode = (poww_mod(b, k) * inv(poww_mod(a, k), MOD)) % MOD; // mode = long long =(call poww_mod with arguments of b, k) * (inverse of arguments of (the result of calling poww_mod with arguments of a, k), i) MOD )modulo MOD
    answer = pre; // answer = pre
    for (int i = 1; i < beishu; ++i) { // for i = 1 to beishu exclusive
      pre = (pre * mode) % MOD; // pre = (pre * mode) modulo MOD
      answer = (answer + pre) % MOD; // answer = (answer + pre) modulo MOD
    } 
    for (int i = (n / k) * k; i <= n; ++i) { // for i = n / k * k to n inclusive
      if (s[i % k] == '+') // if s[i modulo k] is +
        answer = (answer + poww_mod(a, n - i) * poww_mod(b, i)) % MOD; // answer = (answer + (call poww_mod with arguments of a, n - i) * (call poww_mod with arguments of b, i)) modulo MOD
      else // else
        answer = (answer - poww_mod(a, n - i) * poww_mod(b, i)) % MOD; // answer = (answer - (call poww_mod with arguments of a, n - i) * (call poww_mod with arguments of b, i)) modulo MOD
    } 
    if (answer < 0) answer += MOD; // if answer < 0, then answer = answer + MOD
    cout << answer << endl; // print answer
  } 
} 