
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long const MOD = 1e9 + 9LL; // MOD = constant long long = 1e9 + 9LL
string s; // s = string
long long n, a, b, k; // n, a, b, k = long long
long long MODULUS(long long b, long long p) { // in function MODULUS with arguments of long long b and long long p that returns a long long
  long long ret = 1LL; // ret = long long = 1LL
  while (p) { // while p is nonzero
    if (p & 1LL) ret = (ret * b) % MOD; // if bitwise and of p and 1LL, then ret = (ret * b) modulo MOD
    b = (b * b) % MOD; // b = (b * b) modulo MOD
    p >>= 1LL; // p shifted by 1LL bits to the right
  } 
  return ret; // return ret
} 
long long MODINVERSE(long long x) { // in function MODINVERSE with an argument long long x that returns a long long
  return MODULUS(x, MOD - 2LL); // return the result of calling MODULUS with arguments of x, MOD - 2LL
} 
long long Add(long long x, long long y) { // in function Add with arguments of long long x and long long that returns a long long
  x += y; // x = x + y
  if (x > MOD) return x - MOD; // if x > MOD that returns x - MOD
  return x; // return x
} 
long long Sub(long long x, long long y) { // in function Sub with arguments of long long x and long long y that returns a long long
  x -= y; // x = x - y
  if (x < 0) return x + MOD; // if x < 0, then return x + MOD
  return x; // return x
} 
long long Mul(long long x, long long y) { // in function Mul with arguments of long long x and long long y that returns a long long
  x *= y; // x = x * y
  return x % MOD; // return x modulo MOD
} 
long long Div(long long x, long long y) { // in function Div with arguments of long long x and long long y that returns a long long
  return (x * MODINVERSE(y)) % MOD; // return (x * MODINVERSE(y)) modulo MOD
} 
int main() { 
  cin >> n >> a >> b >> k >> s; // read n, a, b, k, s
  long long ans = 0LL; // ans = long long = 0LL
  long long x = Div(b, a); // x = long long = call Div with arguments of b and a
  long long c = MODULUS(a, n); // c = long long = call MODULUS with arguments of a and n
  for (int i = 0; i < k; i += 1) { // for i = 0 to k exclusive
    if (s[i] == '+') { // if s[i] is +
      ans = Add(ans, c); // ans = ans + c
    } else { // else
      ans = Sub(ans, c); // ans = ans - c
    } 
    c = Mul(c, x); // c = call Mul with arguments c and x
  } 
  if (ans < 0) ans += MOD; // if ans < 0 then ans = ans + MOD
  x = MODULUS(x, k); // x = call MODULUS with arguments of x and k
  if (x == 1) { // if x is 1
    ans = Mul(ans, (n + 1) / k); // ans = call Mul with arguments ans and (n + 1) / k
  } else { // else
    ans = Mul(ans, Sub(MODULUS(x, (n + 1) / k), 1)); // ans = (call Mul with arguments x and (n + 1) / k) - 1
    ans = Div(ans, Sub(x, 1)); // ans = call Div with arguments of ans and x - 1
  } 
  cout << ans % MOD << '\n'; // print ans modulo MOD
  return 0; 
} 