
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long mod = 1e9 + 9; // declare new long long variable mod with value 1e9+9
char s[500005]; // new array of characters s with size 500005
long long power(long long a, long long b) { // long long function power with long long arguments a and b
  long long ret = 1; // create long long variable ret = 1
  a %= mod; // change a to a modulo mod
  while (b) { // while b is not 0
    if (b & 1) ret = ret * a % mod; // if b & 1 is not 0, change ret to ret * a % mod
    a = a * a % mod; // change a to a squared modulo mod
    b >>= 1; // set b to b >> 1
  } 
  return ret; // return ret
} 
int main() { 
  long long n, a, b, k; // declare long long variables n, a, b and k
  cin >> n >> a >> b >> k; // read n, a, b and k from the user input
  gets(s); // read input an store it into s
  gets(s); // read input into s
  long long t = (n + 1) / k; // declare new long long called t with value (n + 1) / k
  long long u = power(b, k) * power(power(a, k), mod - 2) % mod; // declare new long long u = power(b, k) * power(power(a, k), mod - 2) % mod
  t = (power(u, t) + mod - 1) % mod * power(u - 1 + mod, mod - 2) % mod; // assign (power(u, t) + mod - 1) % mod * power(u - 1 + mod, mod - 2) % mod to t
  if (u == 1) t = (n + 1) / k; // if u = 1, assign (n + 1) / k to t
  long long ans = 0; // declare long long variable with name ans with value 0
  for (int i = 0; i < k; ++i) { // for i = 0 to k exclusive incrementing i
    long long tmp; // declare long long variable tmp
    tmp = power(a, n - i) * power(b, i) % mod; // assign the new value = power(a, n - i) * power(b, i) % mod
    tmp = tmp * t % mod; // assign tmp * t % mod to tmp
    if (s[i] == '+') { // if s[i] = '+'
      ans = (ans + tmp) % mod; // change the value of ans to (ans + tmp) % mod
    } else { // else
      ans = ans - tmp + mod; // change ans to ans - tmp + mod
      ans %= mod; // change the value of ans to ans modulo mod
    } 
  } 
  cout << ans << endl; // print ans
  return 0; 
} 