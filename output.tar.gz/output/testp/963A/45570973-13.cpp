
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long int mod = 1e9 + 9; // make long long int mod = 1e9 + 9
int d, x, y; // create ints d, x, and y
long long int fastexp(long long int b, long long int p) { // declare fastexp taking in long long ints b and p and returning long long integer
  if (p == 0) return 1; // if p is 0, return 1
  long long int ans = fastexp(b, p / 2) % mod; // create long long int ans = fastexp(b, p / 2) % mod
  if (p % 2) // if p modulo 2 is truthy
    return ((1LL * b * ans % mod) * 1LL * ans) % mod; // return the result of ((1LL * b * ans % mod) * 1LL * ans) % mod
  else // else do
    return (1LL * ans * ans + mod) % mod; // return the result of (1LL * ans * ans + mod) % mod
} 
int main() { 
  long long int a, n, b, k; // make long long ints a, n, b, and k
  string s; // create string s
  long long int v1, v2, v3, sum = 0; // make long long integers v1, v2, v3, and sum = 0
  cin >> n >> a >> b >> k; // read n, a, b, and k
  cin >> s; // read s
  for (int h = 0; h < k; h++) { // for h = 0 to k exclusive
    if (s[h] == '+') { // if s[h] equals '+'
      v1 = fastexp(a, n - h) % mod; // set v1 to fastexp(a, n - h) % mod
      v2 = fastexp(b, h) % mod; // set v2 to fastexp(b, h) % mod
      v3 = (v1 * v2 + mod) % mod; // set v3 to (v1 * v2 + mod) % mod
      sum = (sum % mod + v3 % mod + mod) % mod; // set sum to (sum % mod + v3 % mod + mod) % mod
    } else { // else do
      v1 = fastexp(a, n - h); // set v1 to fastexp(a, n - h)
      v2 = fastexp(b, h); // set v2 to return value of fastexp(b, h)
      v3 = (v1 * v2 + mod) % mod; // set v3 to (v1 * v2 + mod) % mod
      sum = (sum % mod - v3 % mod + mod) % mod; // set sum to (sum % mod - v3 % mod + mod) % mod
    } 
  } 
  long long int vl = (n + 1) / k; // create long long int v1 = (n + 1) / k
  long long int inv_a = fastexp(a, mod - 2) % mod; // make long long integer inv_a = fastexp(a, mod - 2) % mod
  long long int vv = ((inv_a % mod) * (b % mod) + mod) % mod; // make long long integer vv = ((inv_a % mod) * (b % mod) + mod) % mod
  long long int vl1 = ((fastexp(vv, k) % mod)) % mod; // let long long integer vl1 = ((fastexp(vv, k) % mod)) % mod
  if (vl1 == 1) { // if vl1 is 1
    long long int ans = ((vl * sum) + mod) % mod; // create long long int ans = ((v1 * sum) + mod) % mod
    cout << ans << endl; // display ans
    return 0; 
  } 
  long long int vl4 = fastexp(vl1, vl) % mod; // create long long integer vl4 = fastexp(vl1, vl) % mod
  vl4 = (vl4 - 1 + mod) % mod; // set vl4 to (vl4 - 1 + mod) % mod
  vl4 = (vl4 * sum + mod) % mod; // set vl4 to (vl4 * sum + mod) % mod
  long long int vl2 = (((vl1 + mod) % mod) - 1 + mod) % mod; // make long long integer vl2 = (((vl1 + mod) % mod) - 1 + mod) % mod
  long long int vl3 = (vl4 * (fastexp(vl2, mod - 2)) + mod) % mod; // create long long integer vl3 = (vl4 * (fastexp(vl2, mod - 2)) + mod) % mod
  cout << vl3 % mod << endl; // print the result of vl3 % mod
} 