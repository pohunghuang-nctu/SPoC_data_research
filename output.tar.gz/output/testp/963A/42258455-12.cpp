
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long MOD = 1000000009; // create long long integer MOD = 1000000009
long long pw(long long a, long long b) { // into the function pw which takes two long long integers a and b and returns a long long integer
  if (b == 0) return 1; // if b is 0 then return 1
  if (b == 1) return a % MOD; // if b is 1 then return a % MOD
  if (b % 2) { // if b%2 is true
    long long rs = pw(a, b - 1); // create long long rs= pw(a,b-1)
    return (rs * a) % MOD; // return (rs * a) % MOD
  } 
  long long rs = pw(a, b / 2); // create long long integer rs= pw(a,b/2)
  return (rs * rs) % MOD; // return (rs * rs) % MOD
} 
vector<long long> sm; // sm = long long integer vector
long long solve(long long a, long long b) { // into the function solve which takes a and b
  if (b == 0) return 0; // if b is 0 then return 0
  for (long long i = 0; i < 35; i++) { // for i=0 to 35 exclusive
    long long ba = (1LL << i) & b; // create long long integer ba = (1LL << i) & b
    if (ba == 0) continue; // if ba is equal to 0 then continue
    return (sm[i] + solve(a, b - (1LL << i)) * pw(a, (1LL << i))) % MOD; // return sm[i] + solve(a, b - (1LL << i)) * pw(a, (1LL << i))) % MOD
  } 
} 
int main() { 
  long long n, a, b, k; // n,a,b,k = long long integers
  cin >> n >> a >> b >> k; // read n,a,b,k
  string s; // s=string
  cin >> s; // read s
  long long X = 1, Y = 1; // create long long integers X and Y with values 1
  for (long long i = 0; i < k; i++) { // for i=o to k exclusive
    X *= b; // set X = X * b
    X %= MOD; // set X = X % MOD
  } 
  for (long long i = 0; i < k; i++) { // for i=0 to k exclusive
    Y *= a; // set Y = Y * a
    Y %= MOD; // set Y = Y % MOD
  } 
  X *= pw(Y, MOD - 2); // set X = X * pw(Y, MOD - 2)
  X %= MOD; // set X = X % MOD
  sm.push_back(1); // add 1 to the end of sm
  for (long long i = 0; i < 40; i++) { // for i=0 to 40 exclusive
    sm.push_back(sm.back() + sm.back() * pw(X, (1LL << i))); // add sm.back() + sm.back() * pw(X, (1LL << i) to end of sm
    sm.back() %= MOD; // set sm.back() = sm.back() % MOD
  } 
  long long st = solve(X, (n + 1) / k); // create long long integer st = solve(X, (n + 1) / k)
  long long ans = 0; // create long long integer ans=0
  for (long long i = 0; i < k; i++) { // for i=0 to k exclusive
    long long rs = (pw(b, i) * pw(a, n - i)) % MOD; // create long long integer rs = (pw(b, i) * pw(a, n - i)) % MOD
    if (s[i] == '-') rs *= -1; // if s[i] is '-' then set rs = rs * -1
    rs *= st; // set rs = rs * st
    ans += rs; // set ans = ans + rs
    ans %= MOD; // set ans = ans % MOD
  } 
  if (ans < 0) ans += MOD; // if ans is less than 0 then set ans = ans + MOD
  cout << ans << endl; // print ans
} 