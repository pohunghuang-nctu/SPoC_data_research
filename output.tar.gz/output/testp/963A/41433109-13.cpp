
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const long long mod = 1e9 + 9; // create const long long integer mod = 1e9 + 9
long long mod_pow(long long x, long long n) { // declare mod_pow taking in long long ints x and n and returning long long integer
  long long res = 1; // make long long res = 1
  while (n > 0) { // while n is greater than 0
    if (n & 1) res = res * x % mod; // if n & 1 is truthy, set res to res * x % mod
    x = x * x % mod; // set x to x * x % mod
    n >>= 1; // move bits of n 1 place to right
  } 
  return res; // return res
} 
long long extgcd(long long a, long long b, long long &x, long long &y) { // declare extgcd taking in long long ints a, b, &x, and &y and returning long long integer
  long long d = a; // make long long int d = a
  if (b != 0) { // if b is not 0
    d = extgcd(b, a % b, y, x); // set d to extgcd(b, a % b, y, x)
    y -= (a / b) * x; // set y to y - (a / b) * x
  } else { // else do
    x = 1; // set x to 1
    y = 0; // set y to 0
  } 
  return d; // return d
} 
long long mod_inverse(long long a) { // declare mod_inverse taking in long long a and returning long long int
  long long x, y, m; // create long long ints x, y, and m
  m = mod; // set m to mod
  extgcd(a, m, x, y); // call extgcd(a, m, x, y)
  return (m + x % m) % m; // return the result of (m + x % m) % m
} 
int main() { 
  long long n, a, b, k, ans, temp, rec, q; // make long long ints n, a, b, k, ans, temp, rec, and q
  string s; // make string s
  cin >> n >> a >> b >> k; // read n, a, b, and k
  cin >> s; // read s
  ans = 0; // set ans to 0
  for (int i = 0; i < k; i++) { // for i = 0 to k exclusive
    temp = (mod_pow(a, n - i) * mod_pow(b, i)) % mod; // set temp to (mod_pow(a, n - i) * mod_pow(b, i)) % mod
    if (s[i] == '+') // if s[i] is equal to '+'
      ans = (ans + temp) % mod; // set ans to (ans + temp) % mod
    else // else do
      ans = (ans - temp) % mod; // set ans to (ans - temp) % mod
    if (ans < 0) ans += mod; // if ans is less than 0, set ans to ans + mod
  } 
  if (n + 1 == k) { // if n + 1 is k
    cout << ans << endl; // print ans
    return 0; 
  } 
  rec = (n + 1) / k; // set rec to (n + 1) / k
  q = mod_pow((mod_inverse(a) * b) % mod, k) % mod; // set q to mod_pow((mod_inverse(a) * b) % mod, k) % mod
  if (q == 1) // if q is equal to 1
    ans = (ans * rec) % mod; // set ans to (ans * rec) % mod
  else // otherwise
    ans = ((ans * (mod_pow(q, rec) - 1) % mod) * mod_inverse(q - 1)) % mod; // set ans to ((ans * (mod_pow(q, rec) - 1) % mod) * mod_inverse(q - 1)) % mod
  cout << ans << endl; // display ans
  return 0; 
} 