
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int n, k, a[88]; // create integers n and k, and an array of ints a with size 88
set<int> st; // create stack of integers st
int main() { 
  cin >> n >> k; // read input to n and k
  for (int i = 0; i < n; ++i) cin >> a[i]; // for i = 0 to n exclusive, read a[i]
  int num = 0; // declare int variable num = 0
  st.clear(); // clear st
  for (int i = 0; i < n; ++i) { // loop i from 0 to n exclusive
    if (find(st.begin(), st.end(), a[i]) == st.end()) { // if there is no a[i] in st
      if (st.size() == k) { // if size of st = k
        set<int>::iterator it; // create new integer set iterator it
        int maxpos = -1, j, val; // declare ints maxpos, j and val where maxpos = - 1
        for (it = st.begin(); it != st.end(); ++it) { // move it through st
          for (j = i; j < n; ++j) { // for j from i to n exclusive
            if (*it == a[j]) break; // if value at *it = a[j], break the loop
          } 
          if (j > maxpos) maxpos = j, val = *it; // if j is greater than maxpos, set maxpos to j and val = value at *it
        } 
        st.erase(val); // remove val from st
      } 
      st.insert(a[i]); // insert a[i] into st
      num++; // increment num by one
    } 
  } 
  cout << num << endl; // print num
  return 0; 
} 