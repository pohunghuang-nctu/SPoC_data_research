
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

void fun() { // define function fun
  int n, capacity; // declare integer variables n and capacity
  cin >> n >> capacity; // read n and capacity
  int count = 0; // declare int variable count = 0
  int num[n]; // create an array of integers num with size n
  int lib[capacity], j = 0; // create integer j = 0 and an array of integers lib with size = capacity
  for (int i = 0; i < n; i++) { cin >> num[i]; } // loop i from 0 to n exclusive, read num[i]
  for (int i = 0; i < n; i++) { // loop i from 0 to n exclusive
    int found = 0; // declare integer variable found = 0
    if (i == 0) { // if i is equal to 0
      lib[j] = num[i]; // change lib[j] to num[i]
      count++; // increment count
      j++; // increment j
    } else { // else
      for (int k = 0; k < j; k++) { // for k from 0 to j exclusive
        if (lib[k] == num[i]) { // if lib[k] = num[i]
          found = 1; // set found to 1
          break; // break
        } 
      } 
      if (found == 0) { // if found = 0
        if (j != capacity) { // if j != capacity
          lib[j] = num[i]; // assign num[i] to lib[j]
          j++; // increment j by one
          count++; // increment count by one
        } else { // else
          int min = j - 1, flag, min2 = n - 1, min3 = j - 1, prevmin = -1, min4 = j - 1; // new integers min = j - 1, flag, min2 = n - 1, min3 = j - 1, prevmin = -1, min4 = j - 1
          int counter = 0; // create int counter = 0
          for (int x = 0; x < j; x++) { // for x from 0 to j exclusive
            flag = 0; // set flag to 0
            for (int y = i; y < n; y++) { // for y = i to n exclusive
              if (num[y] == lib[x]) { // if num[y] = lib[x]
                min2 = y; // assign y to min2
                min3 = x; // change min3 to x
                flag = 1; // set flag to 1
                counter++; // increment counter by one
                break; // stop the loop
              } 
            } 
            if (flag == 0) { // if flag is equal to 0
              min = x; // change min to x
            } else { // else
              if (prevmin < min2) { // if prevmin is less than min2
                prevmin = min2; // assign min2 to prevmin
                min4 = x; // change min4 to x
              } 
            } 
          } 
          if (counter == j) { // if counter is equal to j
            lib[min4] = num[i]; // assign num[i] to lib[min4]
          } else { // else
            lib[min] = num[i]; // change lib[min] to num[i]
          } 
          count++; // increment count
        } 
      } 
    } 
  } 
  cout << count << endl; // print count
} 
int main() { 
  fun(); // call method fun()
  return 0; 
} 