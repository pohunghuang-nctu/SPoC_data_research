
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, k, x, cnt = 0, a[100]; // let n, k, x, cnt , a be integers with cnt = 0, a = array of integers of length 100
  set<int> s, t; // create empty set of integers s, create empty set of integers t
  cin >> n >> k; // read n and k
  for (int i = 0; i < n; i++) cin >> a[i]; // for i = 0 to n exclusive , read a[i]
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    x = a[i]; // the value of x is equal to a[i]
    if (s.find(x) == s.end()) { // if s.find(x) is equal to s.end()
      ++cnt; // increment cnt by 1
      s.insert(x); // insert x into s
    } 
    if (s.size() == k + 1) { // if size of s is equal to k + 1
      t = s; // the value of t is equal to s
      t.erase(x); // erase x from t
      for (int j = i + 1; j < n; j++) { // for j = i + 1 to n exclusive
        if (t.size() == 1) break; // if size of t is equal to 1 , stop
        t.erase(a[j]); // erase a[j] from t
      } 
      s.erase(*(t.begin())); // s.erase(*(t.begin()))
    } 
  } 
  cout << cnt << endl; // print cnt and newline
  return 0; 
} 