
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int search(int A[], int l, int u, int target) { // in the function search which takes an integer array A and integers l,u,target and returns an integer
  for (int i = l; i < u; i++) { // for i=1 to u exclusive
    if (A[i] == target) return i; // if A[i] = target then return i
  } 
  return -1; // return -1
} 
int main() { 
  int n, C; // n, C= integers
  cin >> n >> C; // read n and C
  int R[n]; // R= array of integers of size n
  for (int i = 0; i < n; i++) cin >> R[i]; // read n values into array R
  int B[C]; // B= array of integer of size C
  int curr_size = 0; // Create integer curr_size =0
  int ans = 0; // Create integer ans =0
  for (int i = 0; i < n; i++) { // for i =0 to n exclusive
    int idx = search(B, 0, curr_size, R[i]); // create integer idx= search(B,0,curr_size, R[i])
    if (idx != -1) continue; // if idx is not -1 then continue
    ans++; // add 1 to ans
    if (curr_size < C) { // if curr_size is less than C
      B[curr_size] = R[i]; // set B[curr_size] = R[i]
      curr_size++; // increment curr_size
    } else { // else do the following
      idx = 0; // set idx to 0
      int d = search(R, i + 1, n, B[idx]); // create integer d= search(R,i+1,n, B[idx])
      if (d != -1) { // if d is not -1
        for (int j = 1; j < C; j++) { // for j=1 to C exclusive
          int curr_d = search(R, i + 1, n, B[j]); // create integer curr_d = search(R, i+1, n , B[j])
          if (curr_d == -1) { // if curr_d is equal to -1
            d = curr_d; // set d to curr_d
            idx = j; // set idx to j
            break; // break
          } else { // else do the following
            if (curr_d > d) { // if curr_d is greater than d
              d = curr_d; // assign curr_d to d
              idx = j; // set idx= j
            } 
          } 
        } 
      } 
      B[idx] = R[i]; // set B[idx] = R[i]
    } 
  } 
  cout << ans << endl; // print ans
  return 0; 
} 