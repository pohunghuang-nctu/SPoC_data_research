
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int a[105], s[1005], num[105] = {0}; // a = array of integers of length 105, s = array of integers of length 1005, 105th element of num = 0
int main() { 
  int n, i, j, k, maxn; // let n, i, j, k, maxn be integers
  cin >> n >> maxn; // read n , maxn
  for (i = 1; i <= n; i++) { // for i = 1 to n inclusive
    cin >> a[i]; // read a[i]
    num[a[i]]++; // increment num[a[i]] by 1
  } 
  int sum = 0; // let sum be a integer with sum = 0
  int p = 0, top = 0; // let p , top be integers with p = 0, top = 0
  for (i = 1; i <= n; i++) { // for i = 1 to n inclusive
    for (j = p; j < top; j++) // for j = p to top exclusive
      if (s[j] == a[i]) break; // if s[j] is equal to a[i], stop
    if (j < top) // if j is less than top
      continue; // proceed to next
    else { // else do the following
      if (top - p < maxn) { // if top - p is less than maxn
        s[top++] = a[i]; // the value of s[top++] is equal to a[i]
        sum++; // increment sum by 1
        num[a[i]]--; // decrement num[a[i]] by 1
      } else { // else do the following
        k = 0; // the value of k is equal to 0
        for (j = 0; j < top; j++) { // for j = 0 to top exclusive
          int qq, ww; // let qq, ww be integers
          for (qq = i + 1; qq <= n; qq++) // for qq = i + 1 to n inclusive
            if (a[qq] == s[k]) break; // if a[qq] is equal to s[k], stop
          for (ww = i + 1; ww <= n; ww++) // for ww = i + 1 to n inclusive
            if (a[ww] == s[j]) break; // if a[ww] is equal to s[j], stop
          if (qq < ww) k = j; // if qq is less than ww, k is equal to j
        } 
        s[k] = a[i]; // s[k] is equal to a[i]
        sum++; // increment sum by 1
        num[a[i]]--; // decrement num[a[i]] by 1
      } 
    } 
  } 
  cout << sum << endl; // print sum and newline
} 