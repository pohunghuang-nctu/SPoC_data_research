
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 80 + 5; // create int constant N = 80 + 5
int n, mx; // create integers n and mx
int now = 0; // create int now = 0
bool active[N]; // create an array of bools active with size N
int v[N]; // create int array v with size N
int res = 0; // create int res = 0
int urm[N]; // create an array of integers urm with N elements
int main() { 
  cin >> n >> mx; // read input to n and mx
  for (int i = 1; i <= n; i++) { cin >> v[i]; } // for i = 1 to n inclusive, read v[i]
  for (int i = 1; i <= n; i++) { // loop i from 1 to n inclusive
    int x = v[i]; // create integer x = v[i]
    if (active[x]) continue; // if active[x] is true, go to the start of the loop
    if (now == mx) { // if now = mx
      res++; // increment res by one
      for (int j = 1; j <= n; j++) urm[j] = (1 << 30); // loop j from 1 to n inclusive, assign 1 << 30 to urm[j]
      for (int j = n; j > i; j--) { urm[v[j]] = j; } // for integer j = n to i exclusive counting down, set urm[v[j]] to j
      int maurm = 0, who; // create integers maurm and who with maurm = 0
      for (int j = 1; j <= n; j++) { // for j from 1 to n inclusive
        if (active[j]) { // if active[j] is true
          maurm = max(maurm, urm[j]); // change maurm to max of maurm and urm[j]
          if (urm[j] == maurm) { who = j; } // if urm[j] = maurm, assign j to who
        } 
      } 
      active[who] = 0; // set active[who] to 0
      active[x] = 1; // change active[x] to 1
    } else { // else
      now++; // increment now
      res++; // increment res
      active[x] = 1; // change active[x] to 1
    } 
  } 
  cout << res << "\n"; // print res and "\n"
  return 0; 
} 