
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, k, x; // create integers n, k and x
  int ans = 0, a[105]; // declare integer variable ans = 0 and an integer array a with size 105
  set<int> s; // s is a new set of unique integers
  set<int> t; // t is a new set of unique integers
  cin >> n >> k; // read input to n and k
  for (int i = 0; i < n; i++) cin >> a[i]; // for i = 0 to n exclusive, read input to a[i]
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    x = a[i]; // set x to a[i]
    if (s.find(x) == s.end()) { // if there is no x in s
      ans++; // increment ans by one
      s.insert(x); // insert x into s
    } 
    if (s.size() == k + 1) { // if length of s = k + 1
      t = s; // change t to s
      t.erase(x); // remove x from t
      for (int j = i + 1; j < n; j++) { // loop j from i + 1 to n exclusive
        if (t.size() == 1) break; // if length of t = 1, break the loop
        t.erase(a[j]); // remove a[j] from t
      } 
      s.erase(*(t.begin())); // remove first element of t from s
    } 
  } 
  cout << ans << endl; // print ans
  return 0; 
} 