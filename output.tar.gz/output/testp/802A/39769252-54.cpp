
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bool isIN(vector<int> &disk, int element) { // bool function isIN with reference to the vector of ints argument &disk and int argument element
  for (int i = 0; i < (int)disk.size(); i++) { // for i from 0 to length of disk exclusive
    if (disk[i] == element) return true; // if disk[i] is equal to element, return true
  } 
  return false; // return false
} 
int main() { 
  int n, m; // declare ints n and m
  cin >> n >> m; // read input to n and m
  vector<int> rstr; // declare vector of ints called rstr
  int v; // declare integer variable v
  for (int i = 0; i < n; i++) { // for i from 0 to n exclusive
    cin >> v; // read v
    rstr.push_back(v); // push v to rstr
  } 
  vector<int> disk; // declare vector of ints disk
  int ans = 0; // create integer ans = 0
  for (int i = 0; i < n; i++) { // for i from 0 to n exclusive
    if (isIN(disk, rstr[i])) { // if isIN(disk, rstr[i]) returned true
      ans++; // increment ans
      continue; // skip the rest of the loop
    } else if ((int)disk.size() < m) { // else if length of disk < m
      disk.push_back(rstr[i]); // push rstr[i] into disk
    } else { // else
      int ind = 0, mx = i + 1, k; // declare integer variables ind = 0, mx = i + 1 and k
      for (int j = 0; j < m; j++) { // loop j from 0 to m exclusive
        for (k = i + 1; k < n; k++) { // loop k from to n exclusive
          if (disk[j] == rstr[k]) { // if disk[j] = rstr[k]
            if (k > mx) { // if k is greater than mx
              mx = k; // set mx to k
              ind = j; // set ind to j
            } 
            break; // break the loop
          } 
        } 
        if (k == n) { // if k = n
          ind = j; // assign j to ind
          break; // break the loop
        } 
      } 
      if (mx == INT_MAX) { ind = 0; } // if mx = INT_MAX, set ind to 0
      disk[ind] = rstr[i]; // assign rstr[i] to disk[ind]
    } 
  } 
  cout << n - ans << endl; // print n - ans
  return 0; 
} 