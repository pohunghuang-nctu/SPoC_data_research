
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, k, x, cnt = 0, a[100]; // create integers n, k, x, cnt = 0 and integer array a of size 100
  set<int> s, t; // create integer sets s and t
  cin >> n >> k; // read n and k
  for (int i = 0; i < n; i++) cin >> a[i]; // for i = 0 to n exclusive, read a[i]
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    x = a[i]; // set x to a[i]
    if (s.find(x) == s.end()) { // if x is at the end of set s
      ++cnt; // increment cnt
      s.insert(x); // insert x into set s
    } 
    if (s.size() == k + 1) { // if the size of set s if equal to k + 1
      t = s; // set t to s
      t.erase(x); // erase x from set t
      for (int j = i + 1; j < n; j++) { // for j = i + 1 to n exclusive
        if (t.size() == 1) break; // if the size of set t is 1, break loop
        t.erase(a[j]); // erase a[j] from set t
      } 
      s.erase(*(t.begin())); // erase *(t.begin()) from set s
    } 
  } 
  cout << cnt << endl; // print cnt
  return 0; 
} 