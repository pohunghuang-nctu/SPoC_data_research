
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, k, cnt = 0; // create integers n, k, cnt with cnt = 0
  int maxx, maxn, ans = 0; // create integers maxx, maxn, ans with ans = 0
  int a[81], used[81], e[81]; // create integer arrays a, used, e, with a size 81, used size 81, e size 81
  memset(a, 0, sizeof(a)); // set bytes from a to size of a to value 0
  memset(used, 0, sizeof(used)); // set bytes from used to size of used to value 0
  cin >> n >> k; // read n read k
  for (int i = 1; i <= n; i++) cin >> a[i]; // for i = 1 to n inclusive, read a[i]
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    if (used[a[i]]) continue; // if used[a[i]], break current loop iteration
    if (cnt < k) { // if cnt is less than k
      cnt++; // increment cnt
      used[a[i]] = 1; // set used[a[i]] to 1
      ans++; // increment ans
    } else { // else
      memset(e, 0, sizeof(e)); // set bytes from e to size of e to value 0
      for (int j = 1; j < i; j++) // for j = 1 to i exclusive
        if (used[a[j]]) e[a[j]] = 81; // if used[a[j]] is true, set e[a[j]] to 81
      for (int j = 1; j < i; j++) // for j = 1 to i exclusive
        if (used[a[j]]) { // if used[a[j]] is true
          for (int k = i + 1; k <= n; k++) // for k = i + 1 to n inclusive
            if (a[k] == a[j]) { // if a[k] is a[j]
              e[a[j]] = k; // set e[a[j]] to k
              break; // break loop
            } 
        } 
      maxx = 0; // set maxx to 0
      maxn = -1; // set maxn to -1
      for (int j = 1; j < i; j++) // for j = 1 to i exclusive
        if (e[a[j]] > maxx) { // if e[a[j]] is greater than maxx
          maxx = e[a[j]]; // set maxx to e[a[j]]
          maxn = a[j]; // set maxn to a[j]
        } 
      used[maxn] = 0; // set used[maxn] to 0
      used[a[i]] = 1; // set used[a[i]] to 1
      ans++; // increment ans
    } 
  } 
  cout << ans << endl; // print ans print newline
  return 0; 
} 