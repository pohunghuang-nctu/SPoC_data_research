
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x, y, increment = 0, ansx = 0, ansy = 0, turns = 0; // x, y = integers, increment = integer = 0, ansx = integer = 0, ansy = integer = 0, turns = integer = 0
  cin >> x >> y; // read x, y
  if (x == 0 && y == 0) { // if x is 0 and y is 0
    cout << 0 << endl; // print 0
    return 0; 
  } 
  while (true) { // indefinitely perform the while loop
    increment++; // increase increment by 1
    for (int i = 0; i < increment; i++) { // for i = 0 to increment exclusive
      ansx++; // increase ansx by 1
      if (ansx == x && ansy == y) { // if ansx is x and ansy is y
        cout << turns << endl; // print turns
        return 0; 
      } 
    } 
    turns++; // increase turns by 1
    for (int i = 0; i < increment; i++) { // for i = 0 to increment exclusive
      ansy++; // increase ansy by 1
      if (ansx == x && ansy == y) { // if ansx is x and ansy is y
        cout << turns << endl; // print turns
        return 0; 
      } 
    } 
    turns++; // increase turns by 1
    increment++; // increase increment by 1
    for (int i = 0; i < increment; i++) { // for i = 0 to increment exclusive
      ansx--; // decrease ansx by 1
      if (ansx == x && ansy == y) { // if ansx is x and ansy is y
        cout << turns << endl; // print turns
        return 0; 
      } 
    } 
    turns++; // increase turns by 1
    for (int i = 0; i < increment; i++) { // for i = 0 to increment exclusive
      ansy--; // decrease ansy by 1
      if (ansx == x && ansy == y) { // if ansx is x and ansy is y
        cout << turns << endl; // print turns
        return 0; 
      } 
    } 
    turns++; // increase turns by 1
  } 
  return 0; 
} 