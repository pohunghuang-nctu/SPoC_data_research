
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x, y, ans = 0; // x, y, ans = 0
  cin >> x >> y; // read x then y
  int p; // p = int
  p = max(abs(x), abs(y)); // set p to max of absolute of x and absolute of y
  if (x == p && x > 0 && x + y > 1) { // if x is p and x is greater than 0 and x + y is greater than 1
    ans = --p; // decrement p then set ans to p
    ans *= 4; // set ans to ans * 4
    ++ans; // increment ans
  } else if (y == p && y > 0 && y - x > 0) { // else if y is p and y is greater than 0 and y - x is greater than 0
    ans = p; // set ans to p
    ans *= 4; // set ans to ans * 4
    ans -= 2; // decrement ans by 2
  } else if (x == (-1 * p) && x < 0 && x + y < 0) { // else if x is -1 * p and x is less than 0 and x + y is less than 0
    ans = p; // set ans to p
    ans *= 4; // set ans to ans * 4
    --ans; // decrement ans
  } else { // else
    if (x + y == 1) { // if x + y is 1
      x--; // decrement x
      ans = x; // set ans to x
      ans *= 4; // set ans to ans * 4
    } else { // else
      ans = p; // set ans to p
      ans *= 4; // set ans to ans * 4
    } 
  } 
  if (x == 0 && y == 0) { ans = 0; } // if x and y are both 0 set ans to 0
  ans = max(ans, 0); // set ans to max of ans and 0
  cout << ans << '\n'; // print ans
} 