
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

map<pair<int, int>, int> A; // create map A from pair of integer, integer to integer
int main() { 
  int x = 0, y = 0, k = 0, p = 1, ind = 1; // create integers x, y, k, p, ind with x = 0, y = 0, k = 0, p = 1, ind = 1
  while (x <= 100 or y <= 100) { // while x is less than or equal to 100 or y is less than or equal to 100
    for (int i = 1; i <= ind; i++) { // for i = 1 to ind inclusive
      x += p; // increment x by p
      A[make_pair(x, y)] = k; // set A[make pair from ( x, y) ] to k
    } 
    k++; // increment k
    for (int i = 1; i <= ind; i++) { // for i = 1 to ind inclusive
      y += p; // increment y by p
      A[make_pair(x, y)] = k; // set A[make pair from x, y] to k
    } 
    k++; // increment k
    ind++; // increment ind
    p *= -1; // set value of p to -1
  } 
  int a, b; // create integers a, b
  cin >> a >> b; // read a read b
  cout << A[make_pair(a, b)] << endl; // print A[make pair from a, b] print newline
} 