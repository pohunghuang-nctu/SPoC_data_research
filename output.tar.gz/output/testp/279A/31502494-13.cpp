
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x, y; // create integers x and y
  int ans; // create integer ans
  cin >> x >> y; // read x and y
  if (x == 0 && y == 0) // if x equals 0 and y equals 0
    cout << "0" << endl; // print "0"
  else { // else
    int n; // create integer n
    if (abs(x) >= abs(y)) // if the absolute value of x is greater than or equal to the absolute value of y
      n = abs(x); // set n to the absolute value of x
    else // else
      n = abs(y); // set n to the absolute value of y
    ans = (n - 1) * 4; // set ans to the result of (n - 1) * 4
    if (x >= n - 1 && x <= n && y == 1 - n) // if x is greater than or equal to n - 1 and x is less than or equal to n and y is equal to 1 - n
      ans; // ans
    else if (x == n && y >= 1 - n && y <= n) // else if x is equal to n and y is greater than of equal to 1 - n and y is less than or equal to n
      ans++; // increment ans
    else if (x >= -n && x <= n && y == n) // else if x is greater than of equal to -n and x is less than or equal to n and y is equal to n
      ans += 2; // set ans to the result of ans + 2
    else if (x == -n && y >= -n && y <= n) // else if x is equal to -n and y is greater than or equal to -n and y is less than or equal to n
      ans += 3; // set ans to the result of ans + 3
    else if (x >= -n && x <= n && y == -n) // else if x is greater than or equal to -n and x is less than or equal to n and y is equal to -n
      ans += 4; // set ans to the result of ans + 4
    cout << ans << endl; // print ans
  } 
  return 0; 
} 