
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x, y; // create integers x, y
  cin >> x >> y; // read x read y
  int tx, ty; // create integers tx, ty
  tx = abs(x), ty = abs(y); // set tx to absolute value of x, set ty to absolute value of y
  int mx = max(tx, ty) - 1; // create integer mx with mx = maximum of (tx and ty) - 1
  if ((x == 0 && y == 0) || (x == 1 && y == 0)) { // if ( x is 0 and y is 0 ) or ( x is 1 and y is 0 )
    cout << 0 << endl; // print 0 print newline
    return 0; 
  } 
  int ans = 0; // create integer ans with ans = 0
  if (x >= 0 && y >= 0) { // if x is greater than or equal to 0 and y is greater than or equal to 0
    if (tx >= ty) // if tx is greater than or equal to ty
      ans = (mx * 4) + 1; // set ans to ( mx * 4 ) + 1
    else // else
      ans = mx * 4 + 2; // set ans to mx * 4 + 2
  } else if (x < 0 && y >= 0) { // else if x is less than 0 and y is greater than or equal to 0
    if (tx > ty) // if tx is greater than ty
      ans = mx * 4 + 3; // set ans to mx * 4 + 3
    else // else
      ans = mx * 4 + 2; // set ans to mx * 4 + 2
  } else if (x <= 0 && y <= 0) { // else if x is less than or equal to 0 and y is less than or equal to 0
    if (tx >= ty) // if tx is greater than or equal to ty
      ans = mx * 4 + 3; // set ans to mx * 4 + 3
    else // else
      ans = mx * 4 + 4; // set ans to mx * 4 + 4
  } else if (x >= 0 && y < 0) { // else if x is greater than or equal to 0 and y is less than 0
    if (ty >= tx) // if ty is greater than or equal to tx
      ans = mx * 4 + 4; // set ans to mx * 4 + 4
    else // else
      ans = mx * 4; // set ans to mx * 4
    if (ty <= (tx - 2)) ans++; // if ty is less than or equal to ( tx - 2 ), increment ans
  } 
  cout << ans << endl; // print ans print newline
  return 0; 
} 