
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x, y; // let x, y be integers
  int ans; // let ans be a integer
  while (cin >> x >> y) { // while read x , y
    if (x == 0 && y == 0) { // if x is equal to 0 and y is equal to 0
      cout << "0" << endl; // print 0 and newline
      continue; // proceed to next
    } 
    int n = max(abs(x), abs(y)); // set integer n to maximum of absolute of x and absolute of y
    ans = (n - 1) * 4; // let ans is equal to (n - 1) * 4
    if (x >= n - 1 && x <= n && y == 1 - n) // if x >= n - 1 and x <= n and y is equal to 1 - n
      ans; // ans
    else if (x == n && y >= 1 - n && y <= n) // else if x is equal to n and y >= 1 - n and y <= n
      ans++; // increase ans by 1
    else if (x >= -n && x <= n && y == n) // else if x >= -n and x <= n and y is equal to n
      ans += 2; // increment ans by 2
    else if (x == -n && y >= -n && y <= n) // else if x is equal to -n and y >= -n and y <= n
      ans += 3; // increment ans by 3
    else if (x >= -n && x <= n && y == -n) // else if x >= -n and x <= n and y is equal to -n
      ans += 4; // increment ans by 4
    cout << ans << endl; // print ans and newline
  } 
  return 0; 
} 