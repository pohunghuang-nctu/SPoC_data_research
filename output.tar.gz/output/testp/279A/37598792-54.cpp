
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x, y, sum = 0; // let x, y and sum be ints with sum = 0
  cin >> x >> y; // read x and y
  if (x > y && x <= -y) { // if x > y and x <= -y
    sum = -y * 4; // assign -y * 4 to sum
  } else if (y > x && x >= -y) { // else if y > x and x >= -y
    sum = -2 + y * 4; // assign -2 + y * 4 to sum
  } else if (y >= x && x < -y) { // else if y >= x and x is less than -y
    sum = -1 - x * 4; // assign -1 - x * 4 to sum
  } else if (x > y && x <= -y + 1) { // else if x > y and x <= -y + 1
    sum = -y * 4; // change sum to -y * 4
  } else if (y <= x && x > -y + 1) { // else if y <= x and x is greater than -y + 1
    sum = -3 + x * 4; // set sum to -3 + x * 4
  } 
  cout << sum << endl; // print sum
  return 0; 
} 