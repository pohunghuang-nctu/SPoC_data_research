
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 1e5 + 100; // N = const int with N = 1e5 + 100
long long arr[N]; // arr = long long array of size N
int main() { 
  int x, y; // x, y = int
  cin >> x >> y; // read x then y
  int a = abs(x), b = abs(y); // a, b = int with a = absolute of x and b = absolute of y
  int mx = max(abs(x), abs(y)); // mx = int with mx = max of absolute of x and absolute of y
  if (mx == 0) { // if mx is 0
    cout << 0 << endl; // print 0
    return 0; 
  } 
  int c = (mx - 1) * 4; // c = int with c = (mx - 1) * 4
  if (mx == a) { // if mx is a
    if (x > 0) { // if x is greater than 0
      if (y <= 0 && b == mx - 1) { // if y is less or equal to 0 and b is mx - 1
        cout << c << endl; // print c
      } else if (y <= 0 && b == mx) { // else if y is less or equal to 0 and b is mx
        cout << c + 4 << endl; // print c + 4
      } else { // else
        cout << c + 1 << endl; // print c + 1
      } 
    } else { // else
      if (y > 0 && b == mx) { // if y is greater than 0 and b is mx
        cout << c + 2 << endl; // print c + 2
      } else { // else
        cout << c + 3 << endl; // print c + 3
      } 
    } 
  } else { // else
    if (y > 0) { // if y is greater than 0
      if (x > 0 && a == mx) { // if x is greater than 0 and a is mx
        cout << c + 1 << endl; // print c + 1
      } else // else
        cout << c + 2 << endl; // print c + 2
    } else { // else
      if (x < 0 && a == mx) { // if x is less than 0 and a is mx
        cout << c + 3 << endl; // print c + 3
      } else // else
        cout << c + 4 << endl; // print c + 4
    } 
  } 
} 