
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x = 0, y = 0, xx = 0, yy = 0, k = 2, c = 1; // create integers x, y, xx, yy, k, c, with x = 0, y = 0, xx = 0, yy = 0, k = 2, c = 1
  map<pair<int, int>, int> mp; // create map mp from pair of ( integer, integer ) to integer
  while (1) { // while 1 is true
    c++; // increment c
    x = (x * -1) + 1; // set x to ( x * -1 ) + 1
    if (x == xx) // if x is xx
      for (int i = min(y, yy); i <= max(y, yy); i++) mp[make_pair(x, i)] = c - 2; // for i = minimum of y and yy to maximum of y and yy inclusive, set mp[make pair from (x, i)] to c - 2
    else // else
      for (int i = min(x, xx); i <= max(x, xx); i++) mp[make_pair(i, y)] = c - 2; // for i = minimum of x and xx to maximum of x and xx inclusive, set mp[make pair from ( i, y )] to c - 2
    if (mp[make_pair(x, y)] == mp[make_pair(xx, yy)]) mp[make_pair(xx, yy)]--; // if mp[make pair from (x, y)] is mp[make pair from (xx, yy)], decrement mp[make pair from (xx, yy)]
    xx = x; // set xx to x
    y = (y * -1) + 1; // set y to ( y * -1 ) + 1
    c++; // increment c
    if (x == xx) // if x is xx
      for (int i = min(y, yy); i <= max(y, yy); i++) mp[make_pair(x, i)] = c - 2; // for i = minimum of y and yy to maximum of y and yy inclusive, set mp[make pair from ( x, i ) ] to c - 2
    else // else
      for (int i = min(x, xx); i <= max(x, xx); i++) mp[make_pair(i, y)] = c - 2; // for i = minimum of x and xx to maximum of x and xx, set mp[make pair from ( i, y ) ] to c - 2
    if (mp[make_pair(x, y)] == mp[make_pair(xx, yy)]) mp[make_pair(xx, yy)]--; // if mp[make pair from (x, y)] is mp[make pair from (xx, yy)], decrement mp[make pair from (xx, yy)]
    yy = y; // set yy to y
    x *= -1; // set value of x to -1
    c++; // increment c
    if (x == xx) // if x is xx
      for (int i = min(y, yy); i <= max(y, yy); i++) mp[make_pair(x, i)] = c - 2; // for i = minimum of y and yy to maximum of y and yy inclusive, set mp[make pair from ( x, i ) ] to c - 2
    else // else
      for (int i = min(x, xx); i <= max(x, xx); i++) mp[make_pair(i, y)] = c - 2; // for i = minimum of x and xx to maximum of x and xx, set mp[make pair from ( i, y ) ] to c - 2
    if (mp[make_pair(x, y)] == mp[make_pair(xx, yy)]) mp[make_pair(xx, yy)]--; // if mp[make pair from (x, y)] is mp[make pair from (xx, yy)], decrement mp[make pair from (xx, yy)]
    xx = x; // set xx to x
    y *= -1; // set value of y to -1
    c++; // increment c
    if (x == xx) // if x is xx
      for (int i = min(y, yy); i <= max(y, yy); i++) mp[make_pair(x, i)] = c - 2; // for i = minimum of y and yy to maximum of y and yy inclusive, set mp[make pair from ( x, i ) ] to c - 2
    else // else
      for (int i = min(x, xx); i <= max(x, xx); i++) mp[make_pair(i, y)] = c - 2; // for i = minimum of x and xx to maximum of x and xx, set mp[make pair from ( i, y ) ] to c - 2
    if (mp[make_pair(x, y)] == mp[make_pair(xx, yy)]) mp[make_pair(xx, yy)]--; // if mp[make pair from (x, y)] is mp[make pair from (xx, yy)], decrement mp[make pair from (xx, yy)]
    yy = y; // set yy to y
    if (x == -300 && y == -300) break; // if x is -300 and y is -300 break loop
  } 
  mp[make_pair(0, 0)] = 0; // set mp[make pair from ( 0, 0 )] to 0
  int a, b; // create integers a, b
  cin >> a >> b; // read a read b
  if ((a == 0 && b == 0) || (a == 1 && b == 0)) return cout << 0 << '\n', 0; // if ( a is 0 and b is 0 ) or ( a is 1 and b is 0), return print 0 print '\n', 0 from function
  cout << mp[make_pair(a, b)] << '\n'; // print mp[make pair from ( a, b )] print '\n'
} 