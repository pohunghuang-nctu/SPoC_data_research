
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x = 0, y = 0, xx = 0, yy = 0, k = 2, c = 1; // x,y,xx,yy=0, k=2, c=1
  map<pair<int, int>, int> mp; // mp=map from pair of int to int
  while (1) { // while true
    c++; // increment c
    x = (x * -1) + 1; // x=(x*-1)+1
    if (x == xx) // if x is xx
      for (int i = min(y, yy); i <= max(y, yy); i++) mp[make_pair(x, i)] = c - 2; // for i=min(y,yy) to max(y,yy) inclusive mp[make_pair(x,i)]=c-2
    else // else
      for (int i = min(x, xx); i <= max(x, xx); i++) mp[make_pair(i, y)] = c - 2; // for i=min(x,xx) to max(x,xx) inclusive mp[make_pair(i,y)]=c-2
    if (mp[make_pair(x, y)] == mp[make_pair(xx, yy)]) mp[make_pair(xx, yy)]--; // if mp[make_pair(x,y)] equal mp[make_pair(xx,yy)] decrement mp[make_pair(xx,yy)]
    xx = x; // xx=x
    y = (y * -1) + 1; // y=(y*-1)+1
    c++; // increment c
    if (x == xx) // if x is xx
      for (int i = min(y, yy); i <= max(y, yy); i++) mp[make_pair(x, i)] = c - 2; // for i=min(y,yy) to max(y,yy) inclusive mp[make_pair(x,i)]=c-2
    else // else
      for (int i = min(x, xx); i <= max(x, xx); i++) mp[make_pair(i, y)] = c - 2; // for i=min(x,xx) to max(x,xx) inclusive mp[make_pair(i,y)]=c-2
    if (mp[make_pair(x, y)] == mp[make_pair(xx, yy)]) mp[make_pair(xx, yy)]--; // if mp[make_pair(x,y)] equal mp[make_pair(xx,yy)] decrement mp[make_pair(xx,yy)]
    yy = y; // yy=y
    x *= -1; // multiply x by -1
    c++; // increment c
    if (x == xx) // if x is xx
      for (int i = min(y, yy); i <= max(y, yy); i++) mp[make_pair(x, i)] = c - 2; // for i=min(y,yy) to max(y,yy) inclusive mp[make_pair(x,i)]=c-2
    else // else
      for (int i = min(x, xx); i <= max(x, xx); i++) mp[make_pair(i, y)] = c - 2; // for i=min(x,xx) to max(x,xx) inclusive mp[make_pair(i,y)]=c-2
    if (mp[make_pair(x, y)] == mp[make_pair(xx, yy)]) mp[make_pair(xx, yy)]--; // if mp[make_pair(x,y)] equal mp[make_pair(xx,yy)] decrement mp[make_pair(xx,yy)]
    xx = x; // xx=x
    y *= -1; // multiply y by -1
    c++; // increment c
    if (x == xx) // if x is xx
      for (int i = min(y, yy); i <= max(y, yy); i++) mp[make_pair(x, i)] = c - 2; // for i=min(y,yy) to max(y,yy) inclusive mp[make_pair(x,i)]=c-2
    else // else
      for (int i = min(x, xx); i <= max(x, xx); i++) mp[make_pair(i, y)] = c - 2; // for i=min(x,xx) to max(x,xx) inclusive mp[make_pair(i,y)]=c-2
    if (mp[make_pair(x, y)] == mp[make_pair(xx, yy)]) mp[make_pair(xx, yy)]--; // if mp[make_pair(x,y)] equal mp[make_pair(xx,yy)] decrement mp[make_pair(xx,yy)]
    yy = y; // yy=y
    if (x == -100 && y == -100) break; // if x is -100 or y is -100 break
  } 
  mp[make_pair(0, 0)] = 0; // mp[make_pair(0,0)]=0
  int a, b; // a,b=int
  cin >> a >> b; // read a and b
  if ((a == 0 && b == 0) || (a == 1 && b == 0)) return cout << 0 << '\n', 0; // if (a is 0 and b is 0) or (a is 1 and b is 0) print 0, newline, 0
  if (mp[make_pair(a, b)] == 0) // if mp[make_pair(a,b)] is 0
    cout << mp[make_pair(b, a)] + 1 << '\n'; // print mp[make_pair(b,a)]+1
  else // else
    cout << mp[make_pair(a, b)] << '\n'; // print mp[make_pair(a,b)]
} 