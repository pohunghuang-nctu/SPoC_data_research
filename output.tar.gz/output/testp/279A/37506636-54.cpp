
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x, y; // declare int variables x and y
  cin >> x >> y; // read x and y
  if ((!x && !y) || (x == 1 && !y)) { // if x and y are both false or (x = 1 and y is false)
    cout << 0; // print 0
    cout << "\n"; // print "\n"
    return 0; 
  } 
  int up = max(abs(x), abs(y)) * 4; // declare int up = max of absolute value of x and max of absolute value of y * 4
  if (x > y || (x > 0 && x == y)) { // if x > y or (x > 0 and x = y)
    if (x > y && abs(x) <= abs(y)) // if x > y and abs(x) <= abs(y)
      cout << up; // print up
    else if (x > 0 && y < 0 && abs(x) - abs(y) == 1) // else if x > 0 and y < and abs(x) - abs(y) = 1
      cout << (up - 4); // print up - 4
    else // else
      cout << (up - 3); // print up - 3
  } else { // else
    if (x < y && abs(x) <= abs(y)) // if x < y and abs(x) <= abs(y)
      cout << (up - 2); // print up - 2
    else // else
      cout << up - 1; // print up - 1
  } 
  cout << "\n"; // print "\n"
  return 0; 
} 