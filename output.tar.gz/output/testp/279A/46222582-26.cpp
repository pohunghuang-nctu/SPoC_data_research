
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long x, y; // create long long x and y
  cin >> x >> y; // read x, y
  long long awalx = 0, awaly = 0, ans = 0, cnt = 0; // set awalz, awaly, and and cnt to 0
  long long add = 1; // add = 1
  while (awalx != x || awaly != y) { // while awalx different from x and awaly different from y
    if (cnt % 4 == 0) { // if cnt mod 4 = 0
      for (int i = 0; i < add; i++) { // for i=0 to add exclusive
        awalx++; // increment awalx
        if (awalx == x && awaly == y) break; // if awalx = x and awaly = y, break
      } 
    } 
    if (cnt % 4 == 1) { // if cnt mod 4 =1
      for (int i = 0; i < add; i++) { // for i=0 to add exclusive
        awaly++; // add 1 to awaly
        if (awalx == x && awaly == y) break; // if awalx = x and awaly = y, break
      } 
      add++; // increment add
    } 
    if (cnt % 4 == 2) { // if cnt mod 4 = 2
      for (int i = 0; i < add; i++) { // for i=0 to add exclusive
        awalx--; // decrement awalx
        if (awalx == x && awaly == y) break; // if awalx = x and awaly = y, break the loop
      } 
    } 
    if (cnt % 4 == 3) { // if cnt mod 4 = 3
      for (int i = 0; i < add; i++) { // for i=0 to add exclusive
        awaly--; // decrement awaly
        if (awalx == x && awaly == y) break; // if awalx = x and awaly = y, break the loop
      } 
      add++; // add 1 to add
    } 
    if (awalx == x && awaly == y) break; // if awalx = x and awaly = y, break
    cnt++; // increment cnt
    ans++; // increment ans
  } 
  cout << ans << endl; // print ans
} 