
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int p, x, y, i, k; // let p, x, y, i, k be integers
  while (cin >> x >> y) { // while read x, y
    if (x == 0 && y == 0) // if x is equal to 0 and y is equal to 0
      k = 0; // k is equal to 0
    else { // else do the following
      p = max(abs(x), abs(y)); // p is equal to maximum of absolute value of x and absolute value of y
      k = (p - 1) * 4; // k is equal to (p - 1) * 4
      if (x == p && y > 1 - p && y <= p) // if x is equal to p and y is greater than 1 - p and y <= p
        k += 1; // increment k by 1
      else if (y == p && x >= -p && x <= p) // else if y is equal to p and x >= -p and x <= p
        k += 2; // increment k by 2
      else if (x == -p && y >= -p && y <= p) // else if x is equal to -p and y >= -p and y <= p
        k += 3; // increment k by 3
      else if (y < 0 && x > y && x <= -y) // else if y is less than 0 and x is greater than y and x <= -y
        k += 4; // increment k by 4
    } 
    cout << k << endl; // print k and newline
  } 
  return 0; 
} 