
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int MAXN = 1e5 + 10; // create const int MAXN = 1e5 + 10
int mp[MAXN], dp[MAXN]; // create int arrays mp and dp with MAXN elements
int main() { 
  int x, y; // declare integers x and y
  cin >> x >> y; // read x and y
  if (!x || !y) { // if x is false or y is false
    if (!x && !y) // if x is false and y is false
      cout << 0 << endl; // print 0
    else { // else
      if (!y) { // if y is false
        if (x < 0) // if x is less than 0
          cout << 4 * (-x) - 1 << endl; // print 4 * (-x) - 1
        else { // else
          if (x == 1) // if x is equal to 1
            cout << 0 << endl; // print 0
          else // else
            cout << (x - 1) * 4 + 1 << endl; // print (x - 1) * 4 + 1
        } 
      } else { // else
        if (y > 0) // if y is greater than 0
          cout << (y - 1) * 4 + 2 << endl; // print (y - 1) * 4 + 2
        else // else
          cout << (-y) * 4 << endl; // print (-y) * 4
      } 
    } 
  } else { // else
    if (x > 0 && x >= y && y > (-x) + 1) { // if x > 0 and x >= y and y > -x + 1
      cout << (x - 1) * 4 + 1 << endl; // print (x - 1) * 4 + 1
    } else if (y > 0 && (-y) <= x && y > x) { // else if y > 0 and -y <= x and y > x
      cout << (y - 1) * 4 + 2 << endl; // print (y - 1) * 4 + 2
    } else if (x < 0 && y >= x && (-x) > y) { // else if x < 0 and y >= x and -x > y
      cout << 4 * (-x) - 1 << endl; // print 4 * -x - 1
    } else { // else
      cout << (-y) * 4 << endl; // print -y * 4
    } 
  } 
  return 0; 
} 