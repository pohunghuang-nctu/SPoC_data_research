
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x, y; // x, y = integers
  while (cin >> x >> y) { // while x and y can be read with valid values for integers
    if (x == 0 && y == 0) { // if x is 0 and y is 0
      cout << 0 << endl; // print 0
      continue; // continue
    } 
    int r = max(abs(x), abs(y)) - 1; // r = integer = the max value of the absolute value of x and the absolute of y and the result minus 1
    int ans = r * 4; // ans = integer = r * 4
    if (x - y >= 0 && x + y - 1 > 0) // if x - y >= 0 and x + y - 1 > 0
      ans = r * 4 + 1; // ans = r * 4 + 1
    else if (x - y < 0 && x + y >= 0) // else if x - y < 0 and x + y >= 0
      ans = r * 4 + 2; // ans = r * 4 + 2
    else if (x - y <= 0 && x + y < 0) // else if x - y <= 0 and x + y < 0
      ans = r * 4 + 3; // ans = r * 4 + 3
    else if (x - y > 0 && x + y - 1 < 0) // else if x - y > 0 and x + y - 1 < 0
      ans = r * 4 + 4; // ans = r * 4 + 4
    cout << ans << endl; // print ans
  } 
} 