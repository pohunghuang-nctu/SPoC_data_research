
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x, y; // x, y =integers
  cin >> x >> y; // Read x, y
  if (x == 0 && y == 0) { // if x is 0 and y is 0
    cout << "0\n"; // print 0 and a new line
    return 0; 
  } 
  if (x == 1 && y == 0) { // if x is 1 and y is 0
    cout << "0\n"; // print 0 and a new line
    return 0; 
  } 
  if (y == 1 && x == 1) { // if x is 1 and y is 1
    cout << "1\n"; // print 1 and a new line
    return 0; 
  } 
  if (y == 1 && -1 <= x && x <= 0) { // if y is 1 and -1 is less than or equal to x and x is less than or equal to 0
    cout << "2\n"; // print 2 and a new line
    return 0; 
  } 
  if (x == -1 && -1 <= y && y <= 1) { // if (x is -1 and -1 is less than or equal to y and y is less than or equal to 1
    cout << "3\n"; // print 3 and a new line
    return 0; 
  } 
  if (y == -1 && -1 <= x && x <= 2) { // if (y is -1 and -1 is less than or equal to x and x is less than or equal to 2)
    cout << "4\n"; // print 4 and a new line
    return 0; 
  } 
  int z = max(abs(x), abs(y)); // z = integer, set to maximum value of absolute value of x and absolute value of y
  if (x == z && y == -z + 1) { // if x is z and y is -z + 1
    cout << 4 * z - 4 << '\n'; // print 4 * z - 4 and a new line
    return 0; 
  } 
  if (x == z && y != -z) { // if x is z and y is not -z)
    cout << 4 * z - 3 << '\n'; // print 4 * z - 3 and a new line
    return 0; 
  } 
  if (y == z) { // if y is z
    cout << 4 * z - 2 << '\n'; // print 4 * z - 2 and a new line
    return 0; 
  } 
  if (x == -z) { // if x is -z
    cout << 4 * z - 1 << '\n'; // print 4 * z - 1 and a new line
    return 0; 
  } 
  cout << 4 * z + 0 << '\n'; // print 4 * z + 0 and a new line
} 