
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long x1, y1; // x1,y1 = long long integers
  cin >> x1 >> y1; // read x1,y1
  long long x = 1, y = 0; // x = 1,y = 0 = long long integers
  long long count = 0; // count set to 0= long long integer
  long long step = 1; // step equals 1 = long long integers
  if (x1 == 0 && y1 == 0) { // if x1 is 0 and y1 then do the following
    cout << 0 << endl; // output 0
    return 0; 
  } 
  if (x1 == 1 && y1 == 0) { // if x1 is 1 and y1 then do the following
    cout << 0 << endl; // output 0
    return 0; 
  } 
  while (1) { // if 1 is true do the following
    if (x == x1 && y == y1) { break; } // if x is x1 and y then do the following
    y += step; // y equals y plus step
    count++; // add one to count
    if (x == x1 && y1 <= y && y1 >= y - step) { break; } // if x = x1 and y1 is less than or equal to y and y1 >= y - step then break
    x -= step + 1; // subtract step + 1 from x
    count++; // add one to count
    if (y == y1 && x1 >= x && x1 <= x + step + 1) { break; } // if y = y1 and x1 >= x and x1 is less than or equal to x + step + 1 then break
    y -= step + 1; // subtract step + 1 from y
    count++; // add one to count
    if (x == x1 && y1 >= y && y1 <= y + step + 1) { break; } // if x = x1 and y1 >= y and y1 is less than or equal to y + step + 1 then break
    x += step + 2; // x equals x plus step + 2
    count++; // add one to count
    if (y == y1 && x1 <= x && x1 >= x - step - 2) { break; } // if y = y1 and x1 is less than or equal to x and x1 >= x - step - 2 then break
    step += 2; // step equals step plus 2
  } 
  cout << count << endl; // write count
} 