
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int arr[6969], change[6969], temp, cyka[6969], blyat; // arr,change,cyka=array of 6969 int, temp,blyat=int
int main() { 
  int c; // c=int
  cin >> c; // read c
  for (int a = 0; a < c; a++) { // for a=0 to c exclusive
    cin >> blyat; // read blyat
    change[a] = blyat; // change[a]=blyat
    arr[a] = blyat; // arr[a]=blyat
  } 
  for (int a = 0; a < c; a++) { // for a=0 to c exclusive
    temp = 1; // temp=1
    for (int x = 0; x < c; x++) { // for x=0 to c exclusive
      if (change[a] < arr[x]) temp++; // if change[a] < arr[x] increment temp
      cyka[a] = temp; // cyka[a]=temp
    } 
  } 
  for (int a = 0; a < c; a++) { // for a=0 to c exclusive
    if (a == c - 1) // if a is c-1
      cout << cyka[a] << "\n"; // print cyka[a], newline
    else // else
      cout << cyka[a] << " "; // print cyka[a], space
  } 
} 