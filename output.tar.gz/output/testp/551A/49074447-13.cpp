
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // create int n
  cin >> n; // read n
  int a[n] = {}; // make int array a of size n
  vector<int> banyakyangmilihini[2001]; // create int vector array banyakyangmilihini of size 2001
  int inilahhasilnya[n] = {}; // create int array inilahhasilnya of size n
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> a[i]; // read a[i]
    banyakyangmilihini[a[i]].push_back(i); // append i to banyakyangmilihini[a[i]]
  } 
  int i = 1; // make int i = 1
  for (int k = 2000; k > 0; k--) { // for k = 2000 to 0 exclusive
    if (banyakyangmilihini[k].size() > 0) { // if banyakyangmilihini[k].size() is more than 0
      for (int m = 0; m < banyakyangmilihini[k].size(); m++) { inilahhasilnya[banyakyangmilihini[k][m]] = i; } // for m = 0 to banyakyangmilihini[k].size() exclusive, set inilahhasilnya[banyakyangmilihini[k][m]] to i
      i = i + banyakyangmilihini[k].size(); // set i to i + banyakyangmilihini[k].size()
    } 
  } 
  for (int k = 0; k < n; k++) { // for k = 0 to n exclusive
    if (k == 0) { // if k is equal to 0
      cout << inilahhasilnya[k]; // print inilahhasilnya[k]
    } else { // else do
      cout << " " << inilahhasilnya[k]; // print " ", and inilahhasilnya[k]
    } 
  } 
  cout << endl; // print new line
} 