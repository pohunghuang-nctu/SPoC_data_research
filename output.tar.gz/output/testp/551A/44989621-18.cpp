
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int numberOfStudents; // numberOfStudents = integer
  int studentsRate; // studentsRate = integer
  int result = 1; // result = integer = 1
  cin >> numberOfStudents; // read numberOfStudents
  int arr[2000]; // arr = integer array of size 2000
  for (int x = 0; x < numberOfStudents; ++x) { // for x = 0 to numberOfStudents exclusive, increase x by 1 at the start of the loop
    cin >> studentsRate; // read studentsRate
    arr[x] = studentsRate; // arr[x] = studentsRate
  } 
  for (int x = 0; x < numberOfStudents; ++x) { // for x = 0 to numberOfStudents exclusive, increase x by 1 at the start of the loop
    result = 1; // result = 1
    for (int y = 0; y < numberOfStudents; ++y) { // for y = 0 to numberOfStudents exclusive, increase y by 1 at the start of the loop
      if (arr[x] < arr[y]) { ++result; } // if arr[x] < arr[y], then increase result by 1
    } 
    if (x == numberOfStudents - 1) // if x is numberOfStudents - 1
      cout << result << endl; // print result
    else // else
      cout << result << " "; // print result
  } 
  return 0; 
} 