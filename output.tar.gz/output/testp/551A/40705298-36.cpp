
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, i, j, a[2010][3], m; // n, i, j, m = integers, a = 2D array of integers, size 2010x3
  cin >> n; // read n
  for (i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> m; // read m
    a[i][0] = m; // set a[i][0] to m
    a[i][1] = i; // set a[i][1] to i
  } 
  for (i = 0; i < n; i++) { // for i = 0 to n exclusive
    for (j = i + 1; j < n; j++) { // for j = i + 1 to n exclusive
      if (a[i][0] < a[j][0]) { // if a[i][0] < a[j][0]
        int temp = a[i][0]; // tmp = integer set to a[i][0]
        a[i][0] = a[j][0]; // set a[i][0] to a[j][0]
        a[j][0] = temp; // set a[j][0] to temp
        temp = a[i][1]; // set temp to a[i][1]
        a[i][1] = a[j][1]; // set a[i][1] to a[j][1]
        a[j][1] = temp; // set a[j][1] to temp
      } 
      if (a[i][0] == a[j][0]) { // if a[i][0] is a[j][0]
        if (a[i][1] > a[j][1]) { // if a[i][1] > a[j][1]
          int temp = a[i][0]; // temp = integer set to a[i][0]
          a[i][0] = a[j][0]; // set a[i][0] to a[j][0]
          a[j][0] = temp; // set a[j][0] to temp
          temp = a[i][1]; // set temp to a[i][1]
          a[i][1] = a[j][1]; // set a[i][1] to a[j][1]
          a[j][1] = temp; // set a[j][1] to temp
        } 
      } 
    } 
  } 
  a[0][2] = 1; // set a[0][2] to 1
  for (i = 1; i < n; i++) { // for i = 1 to n exclusive
    if (a[i][0] == a[i - 1][0]) // if a[i][0] is a[i - 1][0]
      a[i][2] = a[i - 1][2]; // set a[i][2] to a[i - 1][2]
    else // else
      a[i][2] = i + 1; // set a[i][2] to i + 1
  } 
  for (i = 0; i < n; i++) { // for i = 0 to n exclusive
    for (j = i + 1; j < n; j++) { // for j = i + 1 to n exclusive
      if (a[i][1] > a[j][1]) { // if a[i][1] > a[j][1]
        int temp = a[i][1]; // temp = integer set to a[i][1]
        a[i][1] = a[j][1]; // set a[i][1] to a[j][1]
        a[j][1] = temp; // set a[j][1] to temp
        temp = a[i][0]; // set temp to a[i][0]
        a[i][0] = a[j][0]; // set a[i][0] to a[j][0]
        a[j][0] = temp; // set a[j][0] to temp
        temp = a[i][2]; // set temp to a[i][2]
        a[i][2] = a[j][2]; // set a[i][2] to a[j][2]
        a[j][2] = temp; // set a[j][2] to temp
      } 
    } 
  } 
  cout << a[0][2]; // print a[0][2]
  for (i = 1; i < n; i++) { cout << " " << a[i][2]; } // for i = 1 to n exlusive, print " ", a[i][2]
  cout << endl; // endline
  return 0; 
} 