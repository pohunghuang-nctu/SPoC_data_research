
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // let n be an integer
  cin >> n; // read in n
  vector<int> v(n); // let v be a vector of integers of size n
  for (int i = 0; i < n; ++i) { cin >> v[i]; } // iterate for n times, read in v[i]
  vector<int> v1 = v; // let v1 be a vector of integers, set v1 to v
  sort(v1.begin(), v1.end()); // sort v1 in ascending order
  for (int i = 0; i < n; ++i) { // iterate for n times
    if (i > 0) cout << " "; // if i is greater than 0, print " "
    cout << 1 + (v1.end() - upper_bound(v1.begin(), v1.end(), v[i])); // print 1 + (v1.end() - upper_bound(v1.begin(), v1.end(), v[i]))
  } 
  cout << endl; // print a newline
  return 0; 
} 