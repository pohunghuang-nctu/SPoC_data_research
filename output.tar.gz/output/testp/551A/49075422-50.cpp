
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int arr[6969], change[6969], temp, cyka[6969], blyat; // create integers temp, blyat and integer arrays arr, change, cyka with size 6969 each
int main() { 
  int c; // create integer c
  cin >> c; // read c
  for (int a = 0; a < c; a++) { // for integer a=0 to c-1 with increment a
    cin >> blyat; // read blyat
    change[a] = blyat; // set change[a] to blyat
    arr[a] = blyat; // set arr[a] to blyat
  } 
  for (int a = 0; a < c; a++) { // for integer a=0 to c-1 with increment a
    temp = 1; // set temp to 1
    for (int x = 0; x < c; x++) { // for integer x=0 to c-1 with increment x
      if (change[a] < arr[x]) temp++; // if change[a] less than arr[x] then increment temp
      cyka[a] = temp; // set cyka[a] to temp
    } 
  } 
  for (int a = 0; a < c; a++) { // for integer a=0 to c-1 with increment a
    if (a == c - 1) // if a is equal to c-1 then
      cout << cyka[a] << "\n"; // print cyka[a] and a new line
    else // else do the following
      cout << cyka[a] << " "; // print cyka[a] and "."
  } 
} 