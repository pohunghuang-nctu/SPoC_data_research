
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // n = integer
  cin >> n; // read n
  int a[n] = {}; // a = integer array of size n
  vector<int> banyakyangmilihini[2001]; // banyakyangmilihini = array of vector of integer of size 2001
  int inilahhasilnya[n] = {}; // inilahhasilnya = integer array of size n = {}
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> a[i]; // read a[i]
    banyakyangmilihini[a[i]].push_back(i); // append i in banyakyangmilihini[a[i]]
  } 
  int i = 1; // i = integer with i = 1
  for (int k = 2000; k > 0; k--) { // for k = 2000 down to 0 exclusive
    if (banyakyangmilihini[k].size() > 0) { // if (banyakyangmilihini[k].size() > 0)
      for (int m = 0; m < banyakyangmilihini[k].size(); m++) { inilahhasilnya[banyakyangmilihini[k][m]] = i; } // for m = 0 to banyakyangmilihini[k].size() exclusive, inilahhasilnya[banyakyangmilihini[k][m]] = i
      i = i + banyakyangmilihini[k].size(); // i = i + banyakyangmilihini[k].size()
    } 
  } 
  for (int k = 0; k < n; k++) { // for k = 0 to n exclusive
    if (k == 0) { // if (k is 0)
      cout << inilahhasilnya[k]; // print inilahhasilnya[k]
    } else { // else
      cout << " " << inilahhasilnya[k]; // print inilahhasilnya[k]
    } 
  } 
  cout << endl; // print new line
} 