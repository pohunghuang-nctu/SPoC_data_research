
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int numberOfStudents; // let numberOfStudents be a integer
  int studentsRate; // let studentsRate be a integer
  int result = 1; // let result be a integer with result = 1
  cin >> numberOfStudents; // read numberOfStudents
  int arr[2000]; // arr = array of integers of length 2000
  for (int x = 0; x < numberOfStudents; ++x) { // for x = 0 to numberOfStudents exclusive
    cin >> studentsRate; // read studentsRate
    arr[x] = studentsRate; // arr[x] is equal to studentsRate
  } 
  for (int x = 0; x < numberOfStudents; ++x) { // for x = 0 to numberOfStudents exclusive
    result = 1; // result is equal to 1
    for (int y = 0; y < numberOfStudents; ++y) { // for y = 0 to numberOfStudents exclusive
      if (arr[x] < arr[y]) { ++result; } // if arr[x] is less than arr[y], increment result by 1
    } 
    if (x == numberOfStudents - 1) // if x is equal to numberOfStudents - 1
      cout << result << endl; // print result and newline
    else // else do the following
      cout << result << " "; // print result and space
  } 
  return 0; 
} 