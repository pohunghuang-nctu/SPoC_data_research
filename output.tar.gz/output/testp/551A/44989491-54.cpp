
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int numberOfStudents; // declare integer variable numberOfStudents
  int studentsRate; // declare new integer variable studentsRate
  int result = 1; // create integer variable with name result with value 1
  cin >> numberOfStudents; // read numberOfStudents from the user input
  int *arr = new int[numberOfStudents]; // create an int pointer arr pointed to the new array of integers with numberOfStudents elements
  for (int x = 0; x < numberOfStudents; ++x) { // for integer x = 0 to numberOfStudents exclusive incrementing x
    cin >> studentsRate; // read studentsRate from the input
    arr[x] = studentsRate; // set arr[x] to studentsRate
  } 
  for (int x = 0; x < numberOfStudents; ++x) { // in a for loop, change x from 0 to numberOfStudents exclusive
    result = 1; // assign 1 to result
    for (int y = 0; y < numberOfStudents; ++y) { // lopp y from 0 to numberOfStudents exclusive incrementing by 1
      if (arr[x] < arr[y]) { ++result; } // if arr[x] is less than arr[y]
    } 
    if (x == numberOfStudents - 1) // if x = numberOfStudents - 1
      cout << result << endl; // print result
    else // else
      cout << result << " "; // print result and " "
  } 
  return 0; 
} 