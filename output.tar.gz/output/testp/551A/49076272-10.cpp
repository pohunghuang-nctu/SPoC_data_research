
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // n = int
  int a; // a = int
  vector<int> b; // b = int vector
  vector<int> c; // c = int vector
  vector<int> jawab; // jawab = int vector
  cin >> n; // read n
  for (int i = 0; i < n; i++) { // for i = 0 to n
    cin >> a; // read a
    b.push_back(a); // append a to b
    c.push_back(a); // append a to c
  } 
  sort(c.begin(), c.end(), greater<int>()); // sort c using greater of type int
  for (int i = 0; i < n; i++) { // for i = 0 to n
    for (int j = 0; j < n; j++) { // for j = 0 to n
      if (b[i] == c[j] && i == n - 1) { // if b[i] is c[j] and i is n - 1
        cout << j + 1 << "\n"; // print j + 1
        break; // break
      } else if (b[i] == c[j]) { // else if b[i] is c[j]
        cout << j + 1 << " "; // print j + 1 then " "
        break; // break
      } 
    } 
  } 
} 