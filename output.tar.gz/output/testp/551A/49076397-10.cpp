
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int arr[10000]; // arr = int array of size 10000
vector<int> v; // v = int vector
int brr[10000]; // brr = int array of size 10000
int main() { 
  int n; // n = int
  cin >> n; // read n
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    int m; // m = int
    cin >> m; // read m
    arr[i] = m; // set arr[i] to m
    v.push_back(m); // append m to v
  } 
  sort(v.begin(), v.end()); // sort v
  int idx = 1, cur; // idx, cur = int with idx = 1
  for (int i = n - 1; i >= 0; i--) { // for i = n - 1 to 0 inclusive decrementing i
    if (i == n - 1) { // if i is n - 1
      cur = v[i]; // set cur to v[i]
      brr[idx] = v[i]; // set brr[idx] to v[i]
    } else { // else
      if (cur != v[i]) { // if cur is not v[i]
        brr[idx] = v[i]; // set brr[idx] to v[i]
        cur = v[i]; // set cur to v[i]
      } 
    } 
    idx++; // increment idx
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    for (int j = 1; j <= n; j++) { // for j = 1 to n inclusive
      if (arr[i] == brr[j] && arr[i] != 0 && brr[j] != 0) { // if arr[i] is brr[j] and arr[i] is not 0 and brr[j] is not 0
        if (i == n) { // if i is n
          cout << j << endl; // print j
        } else { // else
          cout << j << " "; // print j then " "
        } 
      } 
    } 
  } 
} 