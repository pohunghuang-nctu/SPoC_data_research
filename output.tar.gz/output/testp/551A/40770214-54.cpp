
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int i, j, n, s[2005], k[2005]; // declare new integers i, j and n and arrays s and k with 2005 elements
  cin >> n; // read n from the input
  for (i = 0; i < n; i++) cin >> s[i]; // read n elements from the standard input into s
  memset(k, 0, sizeof(k)); // set first sizeof(k) bytes at the pointer k to 0
  for (i = 0; i < n; i++) { // start for loop from i = 0 to n exclusive
    for (j = 0; j < n; j++) { // increment j in a loop from 0 to n exclusive
      if (s[j] > s[i] && j != i) k[i]++; // if s[j] > s[i] and j != i, increment k[i]
      if (s[j] == s[i] && j == i) k[i]++; // if s[j] is equal to s[i] and j = i, increment k[i]
    } 
  } 
  for (i = 0; i < n; i++) { // start for loop from i = 0 to n exclusive incrementing i
    if (i == 0) // if i is equal to 0
      cout << k[i]; // print k[i] to the standard output
    else // else
      cout << " " << k[i]; // print " " and k[i]
  } 
  cout << endl; // print new line
  return 0; 
} 