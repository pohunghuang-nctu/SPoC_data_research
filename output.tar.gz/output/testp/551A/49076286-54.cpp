
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // new integer called n
  int a; // declare integer variable with name a
  vector<int> b; // declare vector of integers called b
  vector<int> c; // create vector of integers c
  vector<int> jawab; // jawab is a new vector of integers
  cin >> n; // read standard input to n
  for (int i = 0; i < n; i++) { // for i from 0 to n exclusive incrementing i
    cin >> a; // read from the input to a
    b.push_back(a); // push a into b
    c.push_back(a); // add a to the end of c
  } 
  sort(c.begin(), c.end(), greater<int>()); // sort c using greater<int>() as a comparator
  for (int i = 0; i < n; i++) { // in a for loop, change i from 0 to n exclusive
    for (int j = 0; j < n; j++) { // for j = 0 to n exclusive incrementing j
      if (b[i] == c[j] && i == n - 1) { // if b[i] is equal to c[j] and i is equal to n - 1
        cout << j + 1 << "\n"; // print j + 1 and "\n"
        break; // break
      } else if (b[i] == c[j]) { // else if b[i] = c[j]
        cout << j + 1 << " "; // print j + 1 and " "
        break; // break
      } 
    } 
  } 
} 