
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int arr[10000]; // declare integer array arr size 10000
vector<int> v; // declare integer veector v
int brr[10000]; // declare integer array brr size 10000
int main() { 
  int n; // declare integer n
  cin >> n; // read n
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    int m; // declare integer m
    cin >> m; // read m
    arr[i] = m; // let arr[i] be m
    v.push_back(m); // add m to end of v
  } 
  sort(v.begin(), v.end()); // sort from beginning of v to end of v
  int idx = 1, cur; // declare integers idx = 1, cur
  for (int i = n - 1; i >= 0; i--) { // for i = n - 1 to 0 inclusive, decrementing i
    if (i == n - 1) { // if i is n - 1
      cur = v[i]; // let cur be v[i]
      brr[idx] = v[i]; // let brr[idx] be v[i]
    } else { // else
      if (cur != v[i]) { // if cur is not v[i]
        brr[idx] = v[i]; // let brr[idx] be v[i]
        cur = v[i]; // let cur be v[i]
      } 
    } 
    idx++; // increment idx
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    for (int j = 1; j <= n; j++) { // for j = 1 to n inclusive
      if (arr[i] == brr[j] && arr[i] != 0 && brr[j] != 0) { // if arr[i] is brr[j] and arr[i] is not 0 and brr[j] is not 0
        if (i == n) { // if i is n
          cout << j << endl; // print j and newline
        } else { // else
          cout << j << " "; // print j and " "
        } 
      } 
    } 
  } 
} 