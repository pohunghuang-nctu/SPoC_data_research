
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int a[55], i, j, t, s, L = 0, c, b; // i, j, t, s, L, c, b =integers with L = 0 and a = array of 55 integers
  cin >> t; // Read t
  s = 0, c = 0; // set s = 0 and c = 0
  for (i = 0; i < t; i++) { // for i = 0 to t exclusive
    c++; // increment c
    cin >> b; // Read b
    if (b < 0) s++; // if b is less than 0, then increment s
    if (s == 3) { // if s is 3
      a[L++] = c - 1; // set a[L++] to c - 1
      c = 1; // set c to 1
      s = 1; // set s to 1
    } 
  } 
  if (c != 0) a[L++] = c; // if c is not 0, then set a[L++] to c
  cout << L << endl; // print L and new line
  for (i = 0; i < L; i++) { // for i = 0 to L exclusive
    if (i != 0) cout << " "; // if i is not 0, then print " "
    cout << a[i]; // print a[i]
  } 
  cout << endl; // print a new line
  return 0; 
} 