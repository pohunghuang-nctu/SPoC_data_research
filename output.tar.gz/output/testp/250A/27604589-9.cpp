
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

vector<int> out; // create integer vector out
int main() { 
  int N; // integers = N
  cin >> N; // read N
  int reports = 0; // set integer reports to 0
  int neg = 0; // set integer neg to 0
  for (int i = 0; i < N; i++) { // for i = 0 to less than N do the following
    int A; // integers = A
    cin >> A; // read A
    if (A >= 0) { // if A is greater than or equal to 0 then do the following
      reports++; // add one to reports
    } else if (neg == 2) { // else if neg is 2 then do the following
      out.push_back(reports); // push_back part of out = reports
      reports = 1; // set reports to 1
      neg = 1; // set neg to 1
    } else { // else
      reports++; // add one to reports
      neg++; // add one to neg
    } 
  } 
  if (reports > 0) { out.push_back(reports); } // if reports is greater than 0 then do the following out.push_back(reports
  cout << out.size() << endl; // output out.size()
  for (int i = 0; i < out.size(); i++) { // for i = 0 to less than out.size() do the following
    if (i > 0) { cout << " "; } // if i > 0 then print a space
    cout << out[i]; // output out[i]
  } 
  cout << endl; // output an endline
  return 0; 
} 