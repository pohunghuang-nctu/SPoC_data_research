
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // n = integer
  while (cin >> n) { // while read n
    int a[110]; // a = integer array of size 110
    int cnt = 0; // cnt = integer with cnt = 0
    int s[110]; // s = integer array of size 110
    memset(s, 0, sizeof(s)); // set all contents of s to 0
    int m = 0; // m = integer with m = 0
    for (int i = 0; i < n; i++) cin >> a[i]; // for i = 0 to n exclusive, read a[i]
    for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
      if (a[i] < 0) cnt++; // if a[i] < 0, increment cnt
      s[m]++; // increment s[m]
      if (cnt == 2 && i + 1 < n && a[i + 1] < 0) { // if cnt is 2 and i + 1 < n and a[i + 1] < 0
        m++; // increment m
        cnt = 0; // cnt = 0
      } 
    } 
    cout << m + 1 << endl; // print m + 1
    for (int i = 0; i <= m; i++) { // for i = 0 to m
      if (i) cout << " "; // if i, print " "
      cout << s[i]; // print s[i]
    } 
    cout << endl; // print new line
  } 
  return 0; 
} 