
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // n=int
  while (cin >> n) { // while read n
    int a[101]; // a=array of 101 int
    for (int i = 0; i < n; ++i) cin >> a[i]; // for i=0 to n exclusive read a[i]
    int num = 0; // num=0
    int t = 0; // t=0
    int b[101]; // b=array of 101 int
    int line = 0; // line=0
    for (int i = 0; i < n; ++i) { // for i=0 to n exclusive
      if (a[i] < 0 && t == 2) { // if a[i] < 0 and t is 2
        b[line++] = num; // b[line] = num, increment line
        num = 1; // num=1
        t = 1; // t=1
      } else { // else
        if (a[i] < 0) { t++; } // if a[i] < 0 increment t
        num++; // increment n
      } 
    } 
    b[line++] = num; // b[line]=num, increment line
    cout << line << endl; // print line
    for (int i = 0; i < line; ++i) { // for i=0 to line
      if (i == line - 1) // if i equal line-1
        cout << b[i] << endl; // print b[i]
      else // else
        cout << b[i] << " "; // print b[i] and space
    } 
  } 
  return 0; 
} 