
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // create integer n
  cin >> n; // read input to n
  int a[n]; // create an array of ints a with size n
  for (int i = 1; i <= n; i++) cin >> a[i]; // for i = 1 to n inclusive, read a[i]
  int c = 0, t = 0; // create integers c and t = 0
  for (int i = 1; i <= n; i++) { // for i from 1 to n inclusive
    if (a[i] < 0) { // if a[i] is less than 0
      c++; // increment c
    } else { // else
      t++; // increment t
    } 
  } 
  if (t == n || n == 1) { // if t = n or n = 1
    cout << "1" << endl << n << endl; // print "1" and n
    return 0; 
  } 
  if (c % 2 == 0) // if c is even
    cout << c / 2 << endl; // print c / 2
  else // else
    cout << c / 2 + 1 << endl; // print c / 2 + 1
  int f = 0, d = 0; // declare integers f and d = 0
  for (int i = 1; i < n; i++) { // for integer i = 1 to n exclusive
    if (a[i] < 0) { d++; } // if a[i] is less than 0, increment d
    if (d == 2 && a[i + 1] < 0) { // if d = 2 and a[i + 1] < 0
      cout << i - f << " "; // print i - f and " "
      f = i; // assign i to f
      d = 0; // set d to 0
    } 
  } 
  cout << n - f << endl; // print n - f
  return 0; 
} 