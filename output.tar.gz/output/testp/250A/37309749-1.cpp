
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // create integer n
  cin >> n; // read n
  int a[100005]; // create integer array a with size 100005
  for (int i = 1; i <= n; i++) cin >> a[i]; // for i = 1 to n inclusive, read a[i]
  int count = 1; // create integer count with count = 1
  int neg = 0; // create integer neg with neg = 0
  int b[10005]; // create integer b with b size 10005
  int i; // create integer i
  b[0] = 1; // set b[0] to 1
  for (i = 1; i <= n; i++) { // for i = 1 to n inclusive
    if (a[i] < 0) neg++; // if a[i] is less than 0, increment neg
    if (neg == 3) { // if neg is 3
      b[count++] = i; // set b[increment count] to i
      neg = 1; // set neg to 1
    } 
  } 
  cout << count << endl; // print count print newline
  for (int j = 1; j < count; j++) { cout << b[j] - b[j - 1] << " "; } // for j = 1 to count exclusive, print b[j] - b[j-1] print " "
  cout << n + 1 - b[count - 1] << endl; // print n + 1 - b[count-1] print newline
} 