
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, a[102], b[102]; // n = integer, a and b are both integer arrays both of size 102
  int k = 0, cnt = 0, res = 0; // k, cnt, res are all integers all set to 0
  int vis[102] = {0}; // let vis be an integer array of size 102 with vis = 0
  cin >> n; // input n
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    cin >> a[i]; // input a[i]
    k++; // increment k
    if (a[i] < 0) cnt++; // if a[i] is negative, increment cnt
    if (cnt > 2) { // if cnt is greater than 2
      res++; // increment res
      b[res] = k - 1; // assign k - 1 to b[res]
      k = 1; // assign 1 to k
      cnt = 1; // assign 1 to cnt
      vis[i - 1] = 1; // assign 1 to vis[i - 1]
    } 
  } 
  cnt = 0, k = 0; // assign 0 to both cnt and k
  for (int i = n; i >= 1; i--) { // for i = n to 1 inclusive with decrement i
    if (vis[i]) break; // if vis[i], break
    k++; // increment k
    if (a[i] < 0) cnt++; // if a[i] is negative, increment cnt
  } 
  if (cnt) res++; // if cnt is true, increment res
  if (res == 0) res++; // if res is equal to 0, increment res
  b[res] = k; // assign k to b[res]
  cout << res << endl; // display res
  for (int i = 1; i <= res - 1; i++) cout << b[i] << ' '; // for i = 1 to res inclusive, display b[i] and ' '
  cout << b[res] << endl; // display b[res]
  return 0; 
} 