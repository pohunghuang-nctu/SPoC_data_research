
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int a[110], b[110] = {0}; // a, b = integer arrays of length 110 both with value of 0
int main() { 
  int n; // n = integer
  cin >> n; // read n
  for (int i = 0; i < n; i++) cin >> a[i]; // for i = 0 to n exclusive read a[i]
  int sum = 0, num = 0, h = 0; // sum, num, h = integers with value of 0
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    if (a[i] < 0) num++; // if a[i] is less than 0 add 1 to num
    if (num == 3) { // if num equals 3
      b[h++] = sum; // set b[h] to sum then add 1 to h
      sum = 1; // set sum to 1
      num = 1; // set num to 1
      continue; // continue
    } 
    sum++; // add 1 to sum
  } 
  b[h++] = sum; // set b[h] to sum then add 1 to h
  cout << h << endl; // print h
  for (int i = 0; i < h; i++) { // for i = 0 to h exclusive
    if (i) cout << " "; // if i is not 0 print a space
    cout << b[i]; // print b[i]
  } 
  cout << endl; // print a line terminator
} 