
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

queue<int> q; // q is a queue of integers
int main() { 
  int n, x; // declare ints n and x
  cin >> n; // read input to n
  int ancnt = 0; // declare integer variable ancnt = 0
  int cnt = 1; // declare int variable cnt = 1
  int len = 0; // declare int len = 0
  while (n--) { // decrement n and loop further, while n != 0
    cin >> x; // read x
    len++; // increment len by one
    if (x < 0) { ancnt++; } // if x is less than 0, increment ancnt by one
    if (ancnt > 2) { // if ancnt is greater than 2
      ancnt = 1; // assign 1 to ancnt
      q.push(len - 1); // push len - 1 into q
      len = 1; // change len to 1
    } 
  } 
  q.push(len); // push len into q
  cout << q.size() << endl; // print length of q
  int numsize = q.size(); // declare integer numsize = length of q
  for (int i = 0; i < numsize; i++) { // loop i from 0 to numsize exclusive
    if (i != 0) { cout << " "; } // if i != 0, print " "
    cout << q.front(); // print first element of q
    q.pop(); // remove first element of q
    if (i == numsize - 1) { cout << endl; } // if i = numsize - 1, print new line
  } 
  return 0; 
} 