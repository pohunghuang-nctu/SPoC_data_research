
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // create integer n
  while (cin >> n) { // read n and loop further
    int a[101], b[100], f = 0; // declare integer arrays a with 101 and b with 100 elements, and an integer f = 0
    for (int i = 1; i <= n; i++) { // for i from 1 to n inclusive
      cin >> a[i]; // read a[i]
      if (a[i] < 0) f++; // if a[i] is less than 0, increment f by one
    } 
    if (f <= 2) { // if f <= 2
      cout << 1 << endl << n << endl; // print 1 and n
      continue; // continue the loop
    } 
    if (f % 2) // if f is odd
      cout << f / 2 + 1 << endl; // print f / 2 + 1
    else // else
      cout << f / 2 << endl; // print f / 2
    int t = 0; // declare int t = 0
    int x = 1; // declare int variable x = 1
    int sum = 0; // declare integer sum = 0
    for (int i = 1; i <= n; i++) { // loop i from 1 to n inclusive
      if (t == 2 && a[i] < 0) { // if t = 2 and a[i] < 0
        cout << i - x << " "; // print i - x and " "
        sum += (i - x); // add i - x to sum
        x = i; // change x to i
        t = 0; // change t to 0
        f -= 2; // decrease f by 2
      } 
      if (a[i] < 0) t++; // if a[i] is less than 0, increment t by one
    } 
    if (sum < n) cout << n - sum; // if sum is less than n, print n - sum
    cout << endl; // print new line
  } 
  return 0; 
} 