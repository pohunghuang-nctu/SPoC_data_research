
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int a[150]; // a = array of 150 integers
int b[150]; // b = array of 150 integers
int main() { 
  int n, m, i, j, k, flag = 1, t, g, sum = 0; // n, m, i, j, k, flag, t, g, sum = integers with flag = 1 and sum = 0
  cin >> n; // Read n
  for (i = 1; i <= n; i++) cin >> a[i]; // Read n values into array a
  int s = 0; // s = integer with 0
  g = 0; // set g to 0
  t = 0; // set t to 0
  for (i = 1; i <= n; i++) { // for i = 1 to n exclusive
    t++; // increment t
    if (a[i] < 0) g++; // if a[i] is less than 0, then increment g
    if (g == 3 || i == n) { // if g is 3 OR i is n
      if (i == n && g != 3) { // if i is n and g is not 3
        s++; // increment s
        b[s] = t; // set b[s] to t
        break; // Terminate the loop
      } 
      s++; // increment s
      b[s] = t - 1; // set b[s] to t - 1
      t = 0; // set t to 0
      g = 0; // set g to 0
      i--; // decrement i
    } 
  } 
  cout << s << endl; // print s and a new line
  for (i = 1; i <= s; i++) { // for i = 1 to n exclusive
    if (i == 1) // if i is 1
      cout << b[i]; // print b[i]
    else // else do the following
      cout << " " << b[i]; // print b[i]
  } 
  cout << "\n"; // print a new line
} 