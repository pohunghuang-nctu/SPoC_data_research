
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int a[101], b[100]; // declare integer array a with size 101 and b with size 100
int main() { 
  int n; // declare int variable n
  while (cin >> n) { // read n and keep looping
    int count = 0; // declare int count = 0
    for (int i = 1; i <= n; i++) { // for i from 1 to n inclusive
      cin >> a[i]; // read input to a[i]
      if (a[i] < 0) count++; // if a[i] is less than 0, increment count
    } 
    if (count <= 2) { // if count <= 2
      cout << 1 << endl << n << endl; // print 1, new line and n
      continue; // go to the start of the loop
    } 
    if (count % 2) // if count is odd
      cout << count / 2 + 1 << endl; // print count / 2 + 1
    else // else
      cout << count / 2 << endl; // print count / 2
    int t = 0; // declare integer variable t = 0
    int x = 1; // create int x = 1
    int sum = 0; // declare integer sum = 0
    for (int i = 1; i <= n; i++) { // loop i from 1 to n inclusive
      if (t == 2 && a[i] < 0) { // if t = 2 and a[i] < 0
        cout << i - x << " "; // print i - x and " "
        sum += (i - x); // add i - x to sum
        x = i; // assign i to x
        t = 0; // change t to 0
        count -= 2; // decrease count by 2
      } 
      if (a[i] < 0) t++; // if a[i] is less than 0, increment t
    } 
    if (sum < n) cout << n - sum; // if sum is less than n, print n - sum
    cout << endl; // print new line
  } 
  return 0; 
} 