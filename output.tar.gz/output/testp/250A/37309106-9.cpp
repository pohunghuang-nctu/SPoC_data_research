
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int num[110] = {0}; // set integer num[110] to 0
int main() { 
  int n; // integers = n
  cin >> n; // read n
  for (int i = 1; i <= n; i++) cin >> num[i]; // for i = 1 to less than or equal to n do the following
  vector<int> p; // create integer vector p
  int a = 0, b = 0, c = 0; // set integer a to 0, b
  for (int i = 1; i <= n; i++) { // for i = 1 to less than or equal to n do the following
    if (i == n) { // if i is n then do the following
      if (num[i] >= 0) { // if num[i] is greater than or equal to 0 then do the following
        a++; // add one to a
        b++; // add one to b
        p.push_back(b); // push_back part of p = b
      } else { // else
        if (c == 2) { // if c is 2 then do the following
          a += 2; // a equals a plus 2
          p.push_back(b); // push_back part of p = b
          p.push_back(1); // push_back part of p = 1
        } else { // else
          a++; // add one to a
          p.push_back(b + 1); // push_back part of p = b+1
        } 
      } 
    } else { // else
      if (num[i] >= 0) b++; // if num[i] is greater than or equal to 0 then do the following b++
      if (num[i] < 0) { // if num[i] is less than 0 then do the following
        if (c == 2) { // if c is 2 then do the following
          a++; // add one to a
          p.push_back(b); // push_back part of p = b
          b = 1; // set b to 1
          c = 1; // set c to 1
        } else { // else
          c++; // add one to c
          b++; // add one to b
        } 
      } 
    } 
  } 
  cout << a << endl; // output a
  for (int i = 0; i < p.size(); i++) { // for i = 0 to less than p.size() do the following
    if (!i) // if i is false
      cout << p[i]; // output p[i]
    else // else
      cout << " " << p[i]; // output ,p[i]
  } 
  cout << endl; // output endl
} 