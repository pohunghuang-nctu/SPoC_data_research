
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // integers = n
  int files = 0; // set int files to 0
  int f = 0; // set int f to 0
  int sum[500] = {0}; // set int sum[500] to 0
  int index = 0; // set int index to 0
  cin >> n; // read n
  int a; // integers = a
  while (n-- != 0) { // if n is not equal to 0 then do the following
    cin >> a; // read a
    if (a < 0) { f += 1; } // if a is less than 0 then increment f by 1
    if (f == 3) { // if f is 3 then do the following
      files += 1; // files equals files plus 1
      f = 1; // set f to 1
      index += 1; // index equals index plus 1
    } 
    sum[index] += 1; // sum[index] equals sum[index] plus 1
  } 
  files += 1; // files equals files plus 1
  cout << files << endl; // output files,endl
  for (int i = 0; i < files - 1; i++) { cout << sum[i] << ' '; } // for i = 0 to less than files - 1 then ouput sum[i] and a space
  cout << sum[files - 1] << endl; // output sum[files - 1]
  return 0; 
} 