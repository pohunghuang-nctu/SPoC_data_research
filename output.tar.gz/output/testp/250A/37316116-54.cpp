
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, a[110], i, k = 0; // n, i and k are integers where k = 0 and a is an integer array with 110 elements
  cin >> n; // read n
  for (i = 1; i <= n; i++) { // loop i from 1 to n inclusive
    cin >> a[i]; // read a[i]
    if (a[i] < 0) k++; // if a[i] is less than 0, increment k by one
  } 
  if (k <= 2) // if k <= 2
    cout << 1 << endl << n << endl; // print 1, new line and n
  else { // else
    if (k % 2 == 0) // if k is even
      cout << k / 2 << endl; // print k / 2
    else // else
      cout << k / 2 + 1 << endl; // print k / 2 + 1
    int t = 0, x = 1, sum = 0; // declare integers t, sum = 0 and x = 1
    for (i = 1; i <= n; i++) { // for i from 1 to n inclusive
      if (t == 2 && a[i] < 0) { // if t = 2 and a[i] < 0
        cout << i - x << " "; // print i - x and " "
        sum += (i - x); // add i - x to sum
        x = i; // change x to i
        t = 0; // set t to 0
      } 
      if (a[i] < 0) t++; // if a[i] is less than 0, increment t by one
    } 
    if (sum < n) cout << n - sum; // if sum is less than n, print n - sum
    cout << endl; // print new line
  } 
  return 0; 
} 