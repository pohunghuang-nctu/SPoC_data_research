
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int a[1000], n, b[1000], ans, r, o, f = 1; // create int a[1000], n, b[1000], ans, r, o, f, set f to 1
int main() { 
  cin >> n; // read n
  for (int i = 1; i <= n; i++) { cin >> a[i]; } // for i=1 to n inclusive, read a[i]
  for (int i = 1; i <= n; i++) { // for i=1 to n inclusive
    if (a[i] < 0) { // for a[i] less than 0
      if (o >= 2) { // if o >= 2
        ans++; // increment ans
        b[ans] = r; // b[ans] = r
        r = 0; // set r = 0
        o = 1; // assign 1 to o
        f = i; // set f = 1
      } else { // else
        o++; // increment o
      } 
    } 
    r++; // add 1 to r
  } 
  cout << ans + 1 << endl; // print ans + 1
  for (int i = 1; i <= ans; i++) { cout << b[i] << " "; } // for i=1 to ans inclusive, print b[i], " "
  cout << n - f + 1; // print n - f + 1
  cout << endl; // print a newline
  return 0; 
} 