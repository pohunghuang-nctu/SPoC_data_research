
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const long long MOD = 1000000007; // declare const long long MOD = 1000000007
const long double EPS = 1e-8; // create const long double EPS = 1e - 8
int main() { 
  int n; // declare integer n
  cin >> n; // read n
  vector<int> mas(n); // create int vector mas with n elements
  for (int i = 0; i < n; i++) cin >> mas[i]; // for i from 0 to n exclusive, read mas[i]
  vector<int> ans(1, 0); // create int vector ans with 1 element = 0
  int bad = 0; // declare int variable bad = 0
  for (int i = 0; i < n; i++) { // for i from 0 to n exclusive
    if (mas[i] < 0) bad++; // if mas[i] is less than 0, increment bad by one
    if (bad >= 3) { // if bad >= 3
      ans.push_back(1); // push 1 into ans
      bad = 1; // assign 1 to bad
    } else // else
      ans[ans.size() - 1]++; // increment ans[ans . size ( ) - 1]
  } 
  cout << ans.size() << endl; // print length of ans
  for (int i = 0; i < ans.size(); i++) { // for integer i = 0 to length of ans exclusive
    if (i) cout << ' '; // if i is true, print ' '
    cout << ans[i]; // print ans[i]
  } 
  cout << endl; // print new line
  return 0; 
} 