
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int A[100][100]; // create integer array A of size 100 X 100
int B[26000]; // create integer array B of size 26000
vector<int> NEB[27000]; // create vector integer array NEB of size 27000
int yy = 0; // let yy be integer with yy=0
int vis[27000], low[27000], malow[27000], tim[27000], F[27000]; // create integer arrays vis,low,malow,tim,F of sizes 27000 each
int t = 1; // create integer t=1
int uu = 0; // create integer uu=0
vector<int> check; // create integer vector check
void dfs(int s) { // in the function dfs which takes a integer s
  low[s] = t; // set low[s] = t
  vis[s] = 1; // set vis[s] = 1
  tim[s] = t; // set tim[s] =t
  t++; // add 1 to t
  int pp = 0; // create integer pp=0
  for (int i = 0; i < NEB[s].size(); i++) { // for i=0 to NEB[s].size exclusive
    int l = NEB[s][i]; // create integer l = NEB[s][i]
    if (F[s] != l) { // if F[s] is not equal to 1
      if (vis[l] == 1) { // if vis[l] is equal to 1
        low[s] = min(low[s], tim[l]); // set low[s] to minimum of low[s] and tim[l]
      } else { // else do the following
        pp++; // add 1 to pp
        F[l] = s; // set F[l] =s
        dfs(l); // call dfs with argument l
        int u = s; // create integer u=s
        low[u] = min(low[u], low[l]); // set low[u] = minimum of low[u] and low[l]
        malow[u] = max(malow[u], low[l]); // set malow[w] to maximum of malow[u] and low[l]
      } 
    } 
  } 
  int u = s; // create integer u = s
  if (s == yy && pp > 1) { // is s=yy and pp>1
    uu = 1; // set uu=1
    check.push_back(s); // add s to the end of check
  } else if (s != yy && malow[u] >= tim[u]) { // else if ss is not equal to yy and malow[u] >= tim[u]
    uu = 1; // set uu to 1
    check.push_back(s); // add s to end of check
  } 
} 
int main() { 
  int n, m; // n,m = integers
  cin >> n >> m; // read n and m
  int no = 0; // create integer no=0
  for (int i = 1; i <= n; i++) { // for i=1 to n inclusive
    for (int j = 1; j <= m; j++) { // for j=1 to m inclusive
      char c; // c= char
      cin >> c; // read c
      if (c == '#') { // if c is equal to #
        no++; // increment no
        A[i][j] = 1; // set A[i][j] to 1
        B[(m + 1) * i + j] = 1; // set B[(m + 1) * i + j] = 1
        yy = (m + 1) * i + j; // set yy = (m + 1) * i + j
      } 
    } 
  } 
  int P[4] = {-1, 1, (0 - m - 1), m + 1}; // create integer array of size 4 P = {-1, 1, (0 - m - 1), m + 1}{-1, 1, (0 - m - 1), m + 1}
  for (int i = 1; i < 2700; i++) { // for i=1 to 2700 exclusive
    for (int j = 0; j < 4; j++) { // for j=0 to 4 exclusive
      if (i + P[j] >= 0 && B[i + P[j]] == 1) NEB[i].push_back(i + P[j]); // if i + P[j] >= 0 and B[i + P[j]] = 1 then add i+P[j] to the end of NEB[i]
    } 
  } 
  dfs(yy); // call dfs on yy
  if (no < 3) // if no<3
    cout << -1 << endl; // then print -1
  else { // else do the following
    if (uu == 1) // if uu is 1
      cout << 1 << endl; // print 1 and new line
    else // else do the following
      cout << 2 << endl; // print 2
  } 
} 