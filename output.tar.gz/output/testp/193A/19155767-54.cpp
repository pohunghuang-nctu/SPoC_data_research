
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int MAX_N = 50; // create new constant integer MAX_N = 50
const int MAX_M = 50; // new integer constant MAX_M with value 50
int v[MAX_N][MAX_M]; // define new 2d array of integers v with size MAX_N by MAX_M
int u[MAX_N][MAX_M]; // define new 2d array of integers u MAX_N by MAX_M elements
int n, m; // define new integers n and m
void dfs(int x, int y, int first = 0) { // void function dfs with int arguments x, y and first
  if (!first) u[y][x] = 1; // if first is false, assign the new value = 1 to u[y][x]
  if (x > 0 && v[y][x - 1] && !u[y][x - 1]) dfs(x - 1, y); // if x > 0 and v[y][x - 1] is true and u[y][x - 1] is false, call dfs(x - 1, y)
  if (x < m - 1 && v[y][x + 1] && !u[y][x + 1]) dfs(x + 1, y); // call dfs(x + 1, y) if x < m - 1 and v[y][x + 1] is true and u[y][x + 1] is false
  if (y > 0 && v[y - 1][x] && !u[y - 1][x]) dfs(x, y - 1); // if y > 0 and v[y - 1][x] is true and u[y - 1][x] is false, run function dfs(x, y - 1)
  if (y < n - 1 && v[y + 1][x] && !u[y + 1][x]) dfs(x, y + 1); // if y < n - 1 and v[y + 1][x] is true and u[y + 1][x] is false, call method dfs(x, y + 1)
} 
int main() { 
  cin >> n >> m; // read n and m from the user input
  int k = 0; // create new integer called k = 0
  for (int i = 0; i < n; ++i) { // for i from 0 to n exclusive
    string s; // new string variable s
    cin >> s; // read variable s from the input
    for (int j = 0; j < m; ++j) { // start for loop from j = 0 to m exclusive
      v[i][j] = (s[j] == '#'); // assign the new value = (true if s[j]='#' or false otherwise), to v[i][j]
      k += v[i][j]; // add v[i][j] to k
    } 
  } 
  if (k <= 2) { // if k <= 2
    cout << -1 << endl; // print - 1
    return 0; 
  } 
  bool f = false; // define boolean f = false
  for (int i = 0; i < n; ++i) { // start for loop from i = 0 to n exclusive
    for (int j = 0; j < m; ++j) { // increment j in a loop from 0 to m exclusive
      if (!v[i][j]) continue; // if v[i][j] is false, skip the rest of the loop
      memset(u, 0, MAX_N * MAX_M * sizeof(int)); // set first MAX_N * MAX_M *sizeof(int) bytes at the pointer u to 0
      v[i][j] = 0; // assign 0 to v[i][j]
      bool f = false; // create boolean variable with name f = false
      for (int ii = 0; ii < n && !f; ++ii) { // for integer ii = 0 to n exclusive incrementing ii, while f is false
        for (int jj = 0; jj < m && !f; ++jj) { // in a for loop, change jj from 0 to m exclusive, while f is false
          if (v[ii][jj] != 0) { // if v[ii][jj] != 0
            dfs(jj, ii); // call dfs(jj, ii)
            f = true; // assign true to f
          } 
        } 
      } 
      for (int ii = 0; ii < n; ++ii) { // start for loop from ii = 0 to n exclusive
        for (int jj = 0; jj < m; ++jj) { // loop through jj from 0 to m exclusive incrementing by 1
          if (i == ii && j == jj) continue; // if i = ii and j = jj, go to the start of the loop
          if (v[ii][jj] != u[ii][jj]) { // if v[ii][jj] != u[ii][jj]
            cout << 1 << endl; // print 1 and a new line
            return 0; 
          } 
        } 
      } 
      v[i][j] = 1; // change the value of v[i][j] to 1
    } 
  } 
  cout << 2 << endl; // print 2
  return 0; 
} 