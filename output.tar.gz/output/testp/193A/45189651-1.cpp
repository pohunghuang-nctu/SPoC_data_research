
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int MAXN = 55; // declare constant integer MAXN = 55
int n, m, area; // declare integers n, m, area
int dx[] = {-1, 0, 1, 0}; // declare integer array dx = {-1, 0, 1, 0}
int dy[] = {0, 1, 0, -1}; // declare integer array dy = {0, 1, 0, -1}
int bio[MAXN][MAXN]; // declare integer array bio size MAXN by MAXN
char grid[MAXN][MAXN]; // declare character array grid size MAXN by MAXN
bool valid(int x, int y) { // declare valid with integers x, y as arguments, returning boolean
  if (x < 0 || x >= n) return false; // if x is less than 0 or x is greater than or equal to n, return false from function
  if (y < 0 || y >= m) return false; // if y is less than 0 or y is greater than or equal to m, return false from function
  return true; // return true from function
} 
void dfs(int x, int y) { // declare dfs with integers x, y as arguments, returning void
  bio[x][y] = 1; // let bio[x][y] be 1
  for (int i = 0; i < 4; i++) { // for i = 0 to 4 exclusive
    int xx = x + dx[i]; // declare integer xx = x + dx[i]
    int yy = y + dy[i]; // declare integer yy = y + dy[i]
    if (valid(xx, yy) && grid[xx][yy] == '#' && !bio[xx][yy]) { dfs(xx, yy); } // if result of run valid(xx,yy) and grid[xx][yy] is '#' and not bio[xx][yy], run dfs(xx,yy)
  } 
} 
int nc() { // declare nc with no arguments, returning integer
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    for (int j = 0; j < m; j++) { bio[i][j] = 0; } // for j = 0 to m exclusive, let bio[i][j] be 0
  } 
  int bk = 0; // declare integer bk = 0
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    for (int j = 0; j < m; j++) { // for j = 0 to m exclusive
      if (grid[i][j] == '.') continue; // if grid[i][j] is '.', end current loop iteration
      if (bio[i][j]) continue; // if bio[i][j], end current loop iteration
      dfs(i, j); // run dfs(i,j)
      bk++; // increment bk
    } 
  } 
  return bk; // return bk
} 
int main() { 
  cin >> n >> m; // read n and m
  for (int i = 0; i < n; i++) { cin >> grid[i]; } // for i = 0 to n exclusive, read grid[i]
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    for (int j = 0; j < m; j++) { // for j = 0 to m exclusive
      if (grid[i][j] == '#') area++; // if grid[i][j] is '#', increment area
    } 
  } 
  if (area < 3) { // if area is less than 3
    cout << "-1\n"; // print "-1\n"
    return 0; 
  } else if (area == 3) { // else if area is 3
    cout << "1\n"; // print "1\n"
    return 0; 
  } else { // else
    for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
      for (int j = 0; j < m; j++) { // for j = 0 to m exclusive
        if (grid[i][j] == '.') continue; // if grid[i][j] is '.', end current loop iteration
        grid[i][j] = '.'; // let gird[i][j] be '.'
        if (nc() > 1) { // if result of run nc is greater than 1
          cout << "1\n"; // print "1\n"
          return 0; 
        } 
        grid[i][j] = '#'; // let grid[i][j] be '#'
      } 
    } 
    cout << "2\n"; // print "2\n"
  } 
  return 0; 
} 