
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const long long mnx = 8e6 + 9; // mnx=8000009
const long long mod = 1e9 + 7; // mod=1000000007
const long long dx[4] = {-1, 0, 0, 1}; // dx=array of 4 long long filled with -1, 0, 0, 1
const long long dy[4] = {0, -1, 1, 0}; // dy=array of 4 long long filled with 0, -1, 1, 0
long long n, m; // n,m=long long
char s[111][111]; // s=array of 111 by 111 char
bool u[111][111]; // u=array of 111 by 111 bool
bool check(long long x, long long y) { // function check (get long long x and y, return bool)
  return 0 < x && x < n + 1 && 0 < y && y < m + 1; // return 0 < x and x < n+1 and 0 < y and y < m+1
} 
void dfs(long long x, long long y) { // function dfs (get long long x and y, return nothing)
  if (u[x][y]) { return; } // if u[x][y] return
  u[x][y] = true; // u[x][y]=true
  for (long long i = 0; i < 4; i++) { // for i=0 to 4 exclusive
    if (check(x + dx[i], y + dy[i]) && s[x + dx[i]][y + dy[i]] == '#') { dfs(x + dx[i], y + dy[i]); } // if check(x+dx[i], y+dy[i]) and s[x+dx[i]][y+dy[i]] is '#' dfs(x+dx[i], y+dy[i])
  } 
} 
int main() { 
  cin >> n >> m; // read n,m
  for (long long i = 1; i <= n; i++) { // for i=1 to n inclusive
    for (long long j = 1; j <= m; j++) { cin >> s[i][j]; } // for j=1 to m inclusive read s[i][j]
  } 
  long long qwe = 0; // qwe=0
  for (long long i = 1; i <= n; i++) { // for i=1 to n inclusive
    for (long long j = 1; j <= m; j++) { // for j=1 to m inclusive
      if (s[i][j] == '#') { qwe++; } // if s[i][j] is '#' increment qwe
    } 
  } 
  long long res = 11111111111111; // res=11111111111111
  for (long long i = 1; i <= n; i++) { // for i=1 to n inclusive
    for (long long j = 1; j <= m; j++) { // for j=1 to m inclusive
      if (s[i][j] == '#') { // if s[i][j] is '#'
        long long q = 0; // q=0
        for (long long k = 0; k < 4; k++) { // for k=0 to 4 exclusive
          if (check(i + dx[k], j + dy[k]) && s[i + dx[k]][j + dy[k]] == '#') q++; // if check(i+dx[k], j+dy[k]) and s[i+dx[k]][j+dy[k]] is '#' increment q
        } 
        if (q + 1 < qwe) { res = min(res, q); } // if q+1 < qwe res=min(res, q)
        if (qwe > 1) { // if qwe>1
          s[i][j] = '0'; // s[i][j]='0'
          for (long long k = 1; k <= n; k++) { // for k=1 to n inclusive
            for (long long l = 1; l <= m; l++) { u[k][l] = false; } // for l=1 to m inclusive u[k][l]=false
          } 
          long long cnt = 0; // cnt=0
          for (long long k = 1; k <= n; k++) { // for k=1 to n inclusive
            for (long long l = 1; l <= m; l++) { // for l=1 to m inclusive
              if (s[k][l] == '#' && !u[k][l]) { // if s[k][l] is '#' and not u[k][l]
                dfs(k, l); // dfs(k,l)
                cnt++; // increment cnt
              } 
            } 
          } 
          if (cnt > 1) { res = min(res, 1LL); } // if cnt>1 res=min(res, 1)
          s[i][j] = '#'; // s[i][j]='#'
        } 
      } 
    } 
  } 
  if (res == 11111111111111) res -= 11111111111112; // if res is 11111111111111 subtract 11111111111112 from res
  cout << res << '\n'; // print res
  return 0; 
} 