
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

char a[55][55]; // declare character array a size 55 by 55
int is[55][55]; // declare integer array is size 55 by 55
int n, m; // declare integers n, m
int dx[4] = {-1, 1, 0, 0}, dy[4] = {0, 0, -1, 1}; // declare integer arrays dx size 4 = {-1, 1, 0, 0}, dy size 4 = {0, 0, -1, 1}
inline void work(int x, int y) { // declare inline work with integers x, y as arguments, returning void
  if (is[x][y] == 1) return; // if is[x][y] is 1, return from function
  if (a[x][y] != '#') return; // if a[x][y] is not '#', return from function
  is[x][y] = 1; // let is[x][y] be 1
  int i; // declare integer i
  for (i = 0; i < 4; i++) work(x + dx[i], y + dy[i]); // for i = 0 to 4 exclusive, run work with x + dx[i], y + dy[i] as arguments
} 
inline bool check(int x, int y) { // declare inline check with integers x, y as arguments, returning boolean
  a[x][y] = '.'; // let a[x][y] be '.'
  int kk = 0; // declare integer kk = 0
  memset(is, 0, sizeof(is)); // set bytes from is to size of is to value 0
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    for (int j = 1; j <= m; j++) // for j = 1 to m inclusive
      if (a[i][j] == '#' && (is[i][j] == 0)) { // if a[i][j] is '#' and is[i][j] is 0
        kk++; // increment kk
        work(i, j); // run work(i,j)
      } 
  } 
  a[x][y] = '#'; // let a[x][y] be '#'
  return kk > 1; // return kk is greater than 1
} 
int main() { 
  cin >> n >> m; // read n, m
  int kk = 0; // declare integer kk = 0
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    for (int j = 1; j <= m; j++) { // for j = 1 to m inclusive
      cin >> a[i][j]; // read a[i][j]
      if (a[i][j] == '#') kk++; // if a[i][j] is '#', increment kk
    } 
  } 
  if (kk < 3) { // if kk is less than 3
    cout << -1 << endl; // print -1 and newline
    return 0; 
  } 
  int ans = 2; // declare integer ans = 2
  for (int i = 0; i <= n; i++) { // for i = 0 to n inclusive
    for (int j = 1; j <= m; j++) // for j = 1 to m inclusive
      if (a[i][j] == '#') { // if a[i][j] is '#'
        if (check(i, j)) ans = 1; // if result of run check(i,j) is true, let ans be 1
      } 
  } 
  cout << ans << endl; // print ans and newline
  return 0; 
} 