
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int tab[55][55]; // declare integer array tab size 55 by 55
int vis[55][55]; // declare integer array vis size 55 by 55
int n, m; // declare integers n, m
void czysc() { // declare czysc with no arguments, returning void
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    for (int j = 1; j <= m; j++) { vis[i][j] = 0; } // for j = 1 to m inclusive, let vis[i][j] be 0
  } 
  return; // return from function
} 
void dfs(int i, int j) { // declare dfs with integers i, j as arguments, returning void
  vis[i][j] = 1; // let vis[i][j] be 1
  if (tab[i + 1][j] == 1 && vis[i + 1][j] == 0) { dfs(i + 1, j); } // if tab[i+1][j] is 1 and vis[i+1][j] is 0, run dfs(i+1 and j)
  if (tab[i - 1][j] == 1 && vis[i - 1][j] == 0) { dfs(i - 1, j); } // if tab[i-1][j] is 1 and vis[i-1][j] is 0, run dfs(i-1, j)
  if (tab[i][j + 1] == 1 && vis[i][j + 1] == 0) { dfs(i, j + 1); } // if tab[i][j+1] is 1 and vis[i][j+1] is 0, run dfs with i, j + 1 as arguments
  if (tab[i][j - 1] == 1 && vis[i][j - 1] == 0) { dfs(i, j - 1); } // if tab[i][j-1] is 1 and vis[i][j-1] is 0, run dfs(i,j-1)
  return; // return from function
} 
int main() { 
  char c; // declare character c
  cin >> n >> m; // read n, m
  int licz = 0; // declare integers licz = 0
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    for (int j = 1; j <= m; j++) { // for j = 1 to m inclusive
      cin >> c; // read c
      if (c == '#') { // if c is '#'
        tab[i][j] = 1; // let tab[i][j] be 1
        licz++; // increment licz
      } 
    } 
  } 
  if (licz < 3) { // if licz is less than 3
    cout << "-1" << endl; // print "-1" and newline
    return 0; 
  } 
  int wynik = 5; // declare integers wynik = 5
  int akt; // declare integer akt
  int odw; // declare integer odw
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    for (int j = 1; j <= m; j++) { // for j = 1 to m inclusive
      if (tab[i][j] == 1) { // if tab[i][j] is 1
        akt = 0; // let akt be 0
        akt = tab[i + 1][j] + tab[i - 1][j] + tab[i][j + 1] + tab[i][j - 1]; // let akt be tab[i + 1][j] + tab[i - 1][j] + tab[i][j + 1] + tab[i][j - 1]
        if (akt == 1) { // if akt is 1
          cout << "1" << endl; // print "1" and newline
          return 0; 
        } else { // else
          czysc(); // run czysc
          tab[i][j] = 0; // let tab[i][j] be 0
          if (tab[i + 1][j] == 1) { // if tab[i+1][j] is 1
            dfs(i + 1, j); // run dfs with i + 1, j as arguments
          } else { // else
            if (tab[i - 1][j] == 1) { // if tab[i-1][j] is 1
              dfs(i - 1, j); // run dfs(i-1,j)
            } else { // else
              dfs(i, j + 1); // run dfs(i,j+1)
            } 
          } 
          tab[i][j] = 1; // let tab[i][j] be 1
        } 
        odw = vis[i + 1][j] + vis[i - 1][j] + vis[i][j + 1] + vis[i][j - 1]; // let odw be vis[i + 1][j] + vis[i - 1][j] + vis[i][j + 1] + vis[i][j - 1]
        if (odw < akt) { // if odw is less than akt
          cout << "1" << endl; // print "1" and newline
          return 0; 
        } 
      } 
    } 
  } 
  cout << "2" << endl; // print "2" and newline
  return 0; 
} 