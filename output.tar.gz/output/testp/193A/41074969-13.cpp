
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int MAXN = 55; // create constant integer MAXN = 55
char mp[MAXN][MAXN]; // let char array mp of size MAXN with array of size MAXN
bool vis[MAXN][MAXN]; // make bool vis of size MAXN with array of size MAXN
const int go[4][2] = {0, 1, 0, -1, -1, 0, 1, 0}; // create constant integer array go of size 4 with array of size 2 containing {0, 1, 0, -1, -1, 0, 1, 0}
int n, m, all = 0; // make ints n, m, and all = 0
int dfs(int x, int y) { // declare dfs taking in ints x and y and returning integer
  int ans = 1; // create int ans = 1
  for (int i = 0; i < 4; i++) { // for i = 0 to 4 exclusive
    int xx = x + go[i][0], yy = y + go[i][1]; // create ints xx = x + go [i][0] and yy = y + go[i][1]
    if (mp[xx][yy] == '#' && !vis[xx][yy]) { // if mp[xx][yy] is equal to '#' and vis[xx][yy] is falsy
      vis[xx][yy] = true; // set vis[xx][yy] to true
      ans += dfs(x + go[i][0], y + go[i][1]); // set ans to ans + dfs(x + go[i][0], y + go[i][1])
    } 
  } 
  return ans; // return ans
} 
int solve() { // declare solve
  if (all <= 2) return -1; // if all is less than or equal to 2, return -1
  for (int i = 1; i <= n; i++) { // for i = 1 to n
    for (int j = 1; j <= m; j++) { // for j = 1 to m
      if (mp[i][j] == '#') { // if mp[i][j] is equal to '#'
        mp[i][j] = '.'; // set mp[i][j] to '.'
        int t = 0; // create integer t = 0
        for (int k = 0; k < 4; k++) { // for k = 0 to 4 exclusive
          int xx = i + go[k][0], yy = j + go[k][1]; // make ints xx = i + go[k][0] and yy = j + go[k][1]
          if (mp[xx][yy] == '#') { // if mp[xx][yy] is equal to '#'
            memset(vis, 0, sizeof(vis)); // set all contents of vis to 0
            vis[xx][yy] = true; // set vis[xx][yy] to true
            t = dfs(xx, yy); // set t to dfs(xx, yy)
            break; // break loop
          } 
        } 
        mp[i][j] = '#'; // set mp[i][j] to '#'
        if (t == 0) return -1; // if t is 0, return -1
        if (t != all - 1) { return 1; } // if t is not all - 1, return 1
      } 
    } 
  } 
  return 2; // return 2
} 
int main() { 
  cin >> n >> m; // read n and m
  memset(mp, '.', sizeof(mp)); // set all contents of mp to '.'
  for (int i = 1; i <= n; i++) { // for i = 1 to n
    for (int j = 1; j <= m; j++) { // for j = 1 to m
      cin >> mp[i][j]; // read mp[i][j]
      if (mp[i][j] == '#') ++all; // if mp[i][j] is equal to '#', increment all
    } 
  } 
  cout << solve() << endl; // print result of solve()
  return 0; 
} 