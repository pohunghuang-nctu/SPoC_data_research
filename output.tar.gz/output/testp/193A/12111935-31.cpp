
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

char data[51][51]; // data=array of 51 by 51 char
bool visited[51][51]; // visited=array of 51 by 51 bool
int dr[] = {0, 0, 1, -1}; // dr=array of 4 int filled with 0,0,1,-1
int dc[] = {1, -1, 0, 0}; // dc=array of 4 int filled with 1,-1,0,0
int Counter(int i, int j) { // function Counter (get int i and j, return int)
  if (visited[i][j]) return 0; // if visited[i][j] return 0
  visited[i][j] = true; // visited[i][j]=true
  int ans = 0; // ans=0
  if (data[i][j] == '#') { // if data[i][j] is '#'
    ans++; // increment ans
    for (int x = 0; x < 4; x++) { ans += Counter(i + dr[x], j + dc[x]); } // for x=0 to 4 exclusive add Counter(i+dr[x],j+dc[x]) to ans
  } 
  return ans; // return ans
} 
int main() { 
  int n, m; // n,m=int
  cin >> n >> m; // read n,m
  int Total = 0; // Total=0
  pair<int, int> start; // start=pair of int, int
  for (int i = 0; i < n; i++) { // for i=0 to n exclusive
    for (int j = 0; j < m; j++) { // for j=o to m exclusive
      cin >> data[i][j]; // read data[i][j]
      if (data[i][j] == '#') Total++, start = pair<int, int>(i, j); // if data[i][j] is '#' increment Total, start=i,j
    } 
  } 
  memset(visited, false, sizeof visited); // fill visited with false
  int t = Counter(start.first, start.second); // t=Counter(first item of start, second item of start)
  if (t < Total) { // if t < Total
    cout << 0 << endl; // print 0
    return 0; 
  } else if (Total < 3) { // else if Total < 3
    cout << -1 << endl; // print -1
    return 0; 
  } else { // else
    int ans = 0; // ans=0
    for (int i = 0; i < n; i++) { // for i=0 to n exclusive
      for (int j = 0; j < m; j++) { // for j=0 to m exclusive
        if (data[i][j] == '#') { // if data[i][j] is '#'
          if (i == 6 && j == 5) { int r = 1; } // if i is 6 and j is 5 r=1
          memset(visited, false, sizeof visited); // fill visited with false
          visited[i][j] = true; // visited[i][j]=true
          int x, y; // x,y=int
          for (int k = 0; k < 4; k++) { // for k=0 to 4 exclusive
            if (data[i + dr[k]][j + dc[k]] == '#') { // if data[i+dr[k]][j+dc[k]] is '#'
              x = i + dr[k]; // x=i+dr[k]
              y = j + dc[k]; // y=j+dc[k]
              break; // break
            } 
          } 
          int t = Counter(x, y); // t=Counter(x,y)
          if (t < Total - 1) { // if t<Total-1
            cout << "1" << endl; // print 1
            return 0; 
          } 
        } 
      } 
    } 
  } 
  cout << 2 << endl; // print 2
  return 0; 
} 