
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int M = 100 + 10; // M = const int with M = 100 + 10
int main() { 
  int n, m, a, b; // n, m, a, b = int
  cin >> n >> m >> a >> b; // read n then m then a then b
  if (m == 1) { // if m is 1
    cout << "1" << endl; // print "1"
  } else { // else
    if ((a - 1) % m == 0) { // if (a - 1) mod m is 0
      int rowa = (a - 1) / m + 1; // rowa = int with rowa = (a - 1) / m + 1
      int trow = (n - 1) / m + 1; // trow = int with trow = (n - 1) / m + 1
      if (rowa == trow) { // if rowa is trow
        cout << "1" << endl; // print "1"
      } else { // else
        if (b <= rowa * m) { // if b <= rowa * m
          cout << "1" << endl; // print "1"
        } else { // else
          if ((b - a + 1) % m == 0) { // if (b - a + 1) mod m is 0
            cout << "1" << endl; // print "1"
          } else { // else
            if (b != n) // if b is not n
              cout << "2" << endl; // print "2"
            else // else
              cout << "1" << endl; // print "1"
          } 
        } 
      } 
    } else { // else
      int rowa = (a - 1) / m + 1; // rowa = int with rowa = (a - 1) / m + 1
      int rowb = (b - 1) / m + 1; // rowb = int with rowb = (b - 1) / m + 1
      int trow = (n - 1) / m + 1; // trow = int with trow = (n - 1) / m + 1
      if (rowa == trow) { // if rowa is trow
        cout << "1" << endl; // print "1"
      } else { // else
        int lastrowa = rowa * m; // lastrowa = int with lastrowa = rowa * m
        if (b <= lastrowa) { // ig b <= lastrowa
          cout << "1" << endl; // print "1"
        } else { // else
          if (b <= lastrowa + m) { // if b <= lastrowa + m
            cout << "2" << endl; // print "2"
          } else { // else
            if (b % m == 0) { // if b mod m is 0
              cout << "2" << endl; // print "2"
            } else { // else
              if ((b - a + 1) % m == 0) { // if (b - a + 1) mod m is 0
                cout << "2" << endl; // print "2"
              } else { // else
                if (b != n) // if b is not n
                  cout << "3" << endl; // print "3"
                else // else
                  cout << "2" << endl; // print "2"
              } 
            } 
          } 
        } 
      } 
    } 
  } 
  return 0; 
} 