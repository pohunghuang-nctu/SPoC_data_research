
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, m, a, b, ans1, ans2; // n, m, a, b, ans1, ans2 = integer
  cin >> n >> m >> a >> b; // read n, m, a, b
  int row1 = (a - 1) / m; // row1 = integer = (a - 1) / m
  int row2 = (b - 1) / m; // row2 = integer = (a - 1) / m
  int col1 = a % m == 0 ? m : a % m; // col1 = integer = m if a modulo m is 0 else col1 = a modulo m
  int col2 = b % m == 0 ? m : b % m; // col2 = integer = m if b modulo m is 0 else col2 = b modulo m
  if (row1 == row2) // if row1 is row2
    ans1 = 1; // ans1 = 1
  else if (row2 - row1 == 1) { // else if row2 - row1 is 1
    ans1 = 2; // ans1 = 2
    if (col1 == 1 && b == n) // if col1 is 1 and b is n
      ans1 = 1; // ans1 = 1
    else if (col1 == 1 && col2 == m) // else if col1 is 1 and col2 is m
      ans1 = 1; // ans1 = 1
  } else { // else
    ans1 = 3; // ans1 = 3
    if (b == n || col2 == m) --ans1; // if b is n or col2 is m, decrease ans1 by 1
    if (col1 == 1) --ans1; // if col1 is 1, decrease ans1 by 1
  } 
  ans2 = 3; // ans2 = 3
  if (col1 - 1 == col2) --ans2; // if col1 - 1 is col2, then increase ans2 by 1
  cout << min(ans1, ans2) << endl; // print the lower value between ans1 and ans2
  return 0; 
} 