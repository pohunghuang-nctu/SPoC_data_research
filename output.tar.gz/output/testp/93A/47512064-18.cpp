
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, m, a, b; // n, m, a, b = long long
  cin >> n >> m >> a >> b; // read n, m, a, b
  a--, b--; // decrease a by 1, decrease b by 1
  if (a / m == b / m) { // if a / m is b / m
    cout << "1\n"; // print 1
    return 0; 
  } 
  if (a % m == 0 && b % m == m - 1) { // if a modulo m is 0 and b modulo m is m - 1
    cout << "1\n"; // print 1
    return 0; 
  } 
  if (b + 1 == n) { // if b + 1 is n
    if (a % m == 0) { // if a modulo m is 0
      cout << "1\n"; // print 1
      return 0; 
    } 
    cout << "2\n"; // print 2
    return 0; 
  } 
  if (a % m == 0 || b % m == m - 1) { // if a modulo m is 0 or b modulo m is m - 1
    cout << "2\n"; // print 2
    return 0; 
  } 
  if (abs((a / m) - (b / m)) <= 1) { // if the absolute value of the following (a / m) - (b / m) <= 1
    cout << "2\n"; // print 2
    return 0; 
  } 
  if (((a + m - 1) % m) == (b % m)) { // if (a + m - 1) modulo m is b modulo m
    cout << "2\n"; // print 2
    return 0; 
  } 
  cout << "3\n"; // print 3
  return 0; 
} 