
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int n, m, a, b; // n, m, a, b = integer
void solve() { // in function solve that returns nothing
  int x = a / m + (a % m != 0), y = b / m + (b % m != 0); // x= integer = a / m + (a modulo m is not 0), y = integer = b / m + (b modulo m is not 0)
  if (m == 1) // if m is 1
    cout << 1; // print 1
  else if (b == n) { // else if b is n
    if (a % m == 1 || x == y) // if a modulo m is 1 or x is y
      cout << 1; // print 1
    else // else
      cout << 2; // print 2
  } else if ((a % m == 1 && b % m == 0) || x == y) // else if a modulo is 1 and b modulo m is 0 or x is y
    cout << 1; // print 1
  else if (a % m == 1 || b % m == 0 || y == x + 1 || (b + 1) % m == a % m) // else if a modulo is 1 or b modulo m is 0 or y is x + 1 or (b + 1) modulo m is a modulo m
    cout << 2; // print 2
  else // else
    cout << 3; // print 3
  cout << endl; // print endline
} 
int main() { 
  while (cin >> n >> m >> a >> b) solve(); // while n, m, a, b can be read as valid integers, call solve
} 