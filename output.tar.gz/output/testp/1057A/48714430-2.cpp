
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int par[200001]; // par is a integer array of size 200001
vector<int> v; // v is a vector of integers
int main() { 
  int n; // n be integer
  cin >> n; // read n
  for (int i = 2; i <= n; i++) cin >> par[i]; // for integer i = 2 to n inclusive, read par[i]
  int cur = n; // integer cur equals n
  while (cur != 1) { // while cur is not 1
    v.push_back(cur); // push cur into v
    cur = par[cur]; // cur equals par[cur]
  } 
  v.push_back(cur); // push cur into v
  reverse(v.begin(), v.end()); // reverse v
  for (int i = 0; i < (int)v.size(); i++) { // for integer i = 0 to size of v exclusive
    cout << v[i]; // print v[i]
    if (i != (int)v.size() - 1) cout << ' '; // if i not equals i != (int)v.size() - 1, print space
  } 
  cout << endl; // print endline
  return 0; 
} 