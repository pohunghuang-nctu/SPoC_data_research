
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // integer as n
  cin >> n; // read n
  int p[n]; // integer as p[n]
  vector<int> v[n]; // create integer vector of v[n]
  p[0] = -1; // set p[0] to -1
  for (int i = 1; i < n; i++) { // for i = 1 to less than n do the following
    cin >> p[i]; // read p[i]
    v[p[i] - 1].push_back(i); // add new element i to end of vector v[p[i] - 1]
    v[i].push_back(p[i] - 1); // add new element p[i] - 1 to end of vector v[i]
  } 
  vector<int> ans; // create integer vector of ans
  ans.push_back(n); // add new element n to end of vector ans
  int cur = n; // integer as cur = n
  while (cur != 1) { // if cur is not equal to 1 then do the following
    cur = p[cur - 1]; // set cur to p[cur - 1]
    ans.push_back(cur); // add new element cur to end of vector ans
  } 
  for (int i = ans.size() - 1; i >= 0; i--) { // for i = ans.size() - 1 to greater than or equal to 0 do the following
    cout << ans[i]; // output ans[i]
    if (i != 0) { cout << " "; } // if i is not equal to 0 then print space
  } 
  cout << endl; // output end line
  return 0; 
} 