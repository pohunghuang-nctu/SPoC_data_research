
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // let n be a integer
  cin >> n; // read n
  int ar[n + 1]; // ar = array of integers of length n + 1
  for (int i = 2; i <= n; i++) cin >> ar[i]; // for i = 2 to n inclusive , read ar[i]
  stack<int> s; // create a stack of integers by name s
  int i = n; // the integer value of i = n
  s.push(n); // push n into s
  while (1) { // while the condition is true
    s.push(ar[i]); // push ar[i] into s
    i = ar[i]; // i is equal to ar[i]
    if (i == 1) break; // if i equals 1 , stop
  } 
  cout << s.top(); // print s.top()
  s.pop(); // pop s
  while (s.empty() != true) { // while s.empty() is not equal to true
    cout << " " << s.top(); // print space and s.top()
    s.pop(); // pop s
  } 
  cout << endl; // print newline
} 