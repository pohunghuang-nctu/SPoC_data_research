
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // let n be a integer
  int a[200007]; // a = array of integers of length 200007
  int b[200007]; // b = array of integers of length 200007
  while (cin >> n) { // while read n
    int p = 1; // the integer value of p = 1
    a[1] = 1; // a[1] is equal to 1
    for (int i = 2; i <= n; i++) { cin >> a[i]; } // for i = 2 to n exclusive , read a[i]
    b[p++] = n; // b[p++] is equal to n
    int t = a[n]; // the integer value of t = a[n]
    if (t != 1) // if t is not equal to 1
      while (1) { // while the condition is true
        b[p++] = t; // b[p++] is equal to t
        t = a[t]; // t is equal to a[t]
        if (t == 1) break; // if t is equal to 1 , stop
      } 
    b[p] = 1; // b[p] is equal to 1
    for (int i = p; i > 1; i--) cout << b[i] << " "; // for integer i is equal to p , i is greater than 1 , decrement i by 1, print b[i] and space
    cout << b[1] << endl; // print b[i] and newline
  } 
  return 0; 
} 