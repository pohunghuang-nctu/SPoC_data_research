
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

string a[10], day1, day2; // array a of size 10, day1, day2 = string
int main() { 
  a[1] = "monday"; // set a[1] to monday
  a[2] = "tuesday"; // set a[2] to tuesday
  a[3] = "wednesday"; // set a[3] to wednesday
  a[4] = "thursday"; // set a[4] to thursday
  a[5] = "friday"; // set a[5] to friday
  a[6] = "saturday"; // set a[6] to saturday
  a[7] = "sunday"; // set a[7] to sunday
  cin >> day1 >> day2; // read day1,day2
  int num1 = 0, num2 = 0, i = 0, j = 0; // integer as num1 = 0,num2 = 0,i = 0,j = 0
  for (i = 1; i <= 7; i++) { // for = 1 to less than or equal to 7 do the following
    if (day1 == a[i]) { num1 = i; } // if day1 is a[i] then do the following num1 = i
  } 
  for (i = 1; i <= 7; i++) { // for = 1 to less than or equal to 7 do the following
    if (day2 == a[i]) { num2 = i; } // if day2 is a[i] then num2 = i
  } 
  if (num2 < num1) { num2 += 7; } // if num2 is less than num1 then add 7 to num2
  int sum = num2 - num1; // integer as sum = num2 - num1
  if (sum == 0 || sum == 2 || sum == 3) { // if sum is 0, 2 or 3 then do the following
    cout << "YES" << endl; // output YES
  } else { // else
    cout << "NO" << endl; // output NO
  } 
  return 0; 
} 