
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // n is an integer
  string a; // a is a string
  string b; // b is a string
  cin >> a >> b; // read a, b
  map<string, int> mp; // map mp from string to integer
  mp["monday"] = 1; // mp["monday"] equals 1
  mp["tuesday"] = 2; // mp["tuesday"] equals 2
  mp["wednesday"] = 3; // mp["wednesday"] equals 3
  mp["thursday"] = 4; // mp["thursday"] equals 4
  mp["friday"] = 5; // mp["friday"] equals 5
  mp["saturday"] = 6; // mp["saturday"] equals 6
  mp["sunday"] = 0; // mp["sunday"] equals 0
  int p1 = mp[a]; // let p1 equals mp[a]
  int p2 = mp[b]; // let p2 equals mp[b]
  if ((p1 + 30) % 7 == p2) { // if (p1 + 30) % 7 equals p2
    puts("YES"); // put YES
    return 0; 
  } 
  if ((p1 + 28) % 7 == p2) { // if (p1 + 28) % 7 equals p2
    puts("YES"); // put YES
    return 0; 
  } 
  if ((p1 + 31) % 7 == p2) { // if (p1 + 31) % 7 equals p2
    puts("YES"); // put YES
    return 0; 
  } 
  cout << "NO" << endl; // print NO and endline
  return 0; 
} 