
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int aa, bb, flag = 0; // aa, bb, flag = int with flag = 0
  ; // noop
  char a[15]; // a = char array of size 15
  char b[15]; // b = char array of size 15
  int month[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}; // month = int array of size 12 with values 31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31
  cin >> a; // read a
  cin >> b; // read b
  if (strcmp(a, "monday") == 0) { // if a is "monday"
    aa = 1; // set aa to 1
  } else if (strcmp(a, "tuesday") == 0) { // else if a is "tuesday"
    aa = 2; // set aa to 2
  } else if (strcmp(a, "wednesday") == 0) { // else if a is "wednesday"
    aa = 3; // set aa to 3
  } else if (strcmp(a, "thursday") == 0) { // else if a is "thursday"
    aa = 4; // set aa to 4
  } else if (strcmp(a, "friday") == 0) { // else if a is "friday"
    aa = 5; // set aa to 5
  } else if (strcmp(a, "saturday") == 0) { // else if a is "saturday"
    aa = 6; // set aa to 6
  } else if (strcmp(a, "sunday") == 0) { // else if a is "sunday"
    aa = 7; // set aa to 7
  } 
  if (strcmp(b, "monday") == 0) { // if b is "monday"
    bb = 1; // set bb to 1
  } else if (strcmp(b, "tuesday") == 0) { // else if b is "tuesday"
    bb = 2; // set bb to 2
  } else if (strcmp(b, "wednesday") == 0) { // else if b is "wednesday"
    bb = 3; // set bb to 3
  } else if (strcmp(b, "thursday") == 0) { // else if b is "thursday"
    bb = 4; // set bb to 4
  } else if (strcmp(b, "friday") == 0) { // else if b is "friday"
    bb = 5; // set bb to 5
  } else if (strcmp(b, "saturday") == 0) { // else if b is "saturday"
    bb = 6; // set bb to 6
  } else if (strcmp(b, "sunday") == 0) { // else if b is "sunday"
    bb = 0; // set bb to 0
  } 
  for (int i = 0; i < 12; i++) { // for i = 0 to 12
    if ((aa + month[i]) % 7 == bb) { // if (aa + month[i]) mod 7 is bb
      flag = 1; // set flag to 1
      break; // break
    } 
  } 
  if (flag == 1) { // if flag is 1
    cout << "YES" << endl; // print "YES"
  } else { // else
    cout << "NO" << endl; // print "NO"
  } 
  return 0; 
} 