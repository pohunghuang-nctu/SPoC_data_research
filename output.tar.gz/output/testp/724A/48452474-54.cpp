
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

map<string, int> day; // day = map from strings to integers
int main() { 
  day["monday"] = 1; // set the value of day["monday"] to 1
  day["tuesday"] = 2; // change day["tuesday"] to 2
  day["wednesday"] = 3; // assign the new value = 3 to day["wednesday"]
  day["thursday"] = 4; // assign the new value = 4 to day["thursday"]
  day["friday"] = 5; // assign 5 to day["friday"]
  day["saturday"] = 6; // set the value of day["saturday"] to 6
  day["sunday"] = 7; // set the value of day["sunday"] to 7
  string fd, sd; // create new strings fd and sd
  cin >> fd >> sd; // read variables fd and sd from the input
  int f = day[fd], s = day[sd]; // new integers f = day[fd] and s = day[sd]
  int k = (s - f + 7) % 7; // create integer k with value (s - f + 7) % 7
  if (k == 0 || k == 2 || k == 3) // if k = 0, 2 or 3
    cout << "YES" << endl; // print "YES"
  else // else
    cout << "NO" << endl; // print "NO"
} 