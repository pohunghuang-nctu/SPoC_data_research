
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

map<string, int> m; // create map m using string and integer
int main() { 
  string a, b; // a, b = string array
  int s; // integer as s
  m["saturday"] = 1; // set m[saturday] to 1
  m["sunday"] = 2; // set m[sunday] to 2
  m["monday"] = 3; // set m[monday] to 3
  m["tuesday"] = 4; // set m[tuesday] to 4
  m["wednesday"] = 5; // set m[wednesday] to 5
  m["thursday"] = 6; // set m[thursday] to 6
  m["friday"] = 7; // set m[friday] to 7
  cin >> a >> b; // read a,b
  s = ((m[b] + 7) - m[a]) % 7; // set s to ((m[b] + 7) - m[a]) modulo 7
  if (s == 0 || s == 2 || s == 3) { // if s is 0,2 or 3 then do the following
    cout << "YES" << endl; // output YES
    return 0; 
  } else { // else
    cout << "NO" << endl; // output NO
    return 0; 
  } 
} 