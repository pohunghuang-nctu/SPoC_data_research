
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // declare integer n
  string a; // declare string a
  string b; // declare string b
  cin >> a >> b; // read a and b
  map<string, int> mp; // declare map mp of strings to ints
  mp["monday"] = 1; // set mp["monday"] to 1
  mp["tuesday"] = 2; // set mp["tuesday"] to 2
  mp["wednesday"] = 3; // set mp["wednesdya"] to 3
  mp["thursday"] = 4; // set mp["thursday"] to 4
  mp["friday"] = 5; // set mp["friday"] to 5
  mp["saturday"] = 6; // set mp["saturday"] to 6
  mp["sunday"] = 0; // set mp["sunday"] to 0
  int p1 = mp[a]; // define int p1 = mp[a]
  int p2 = mp[b]; // define int p2 = mp[b]
  if ((p1 + 30) % 7 == p2) { // if (p1 + 30) mod 7 is p2
    puts("YES"); // print "YES"
    return 0; 
  } 
  if ((p1 + 28) % 7 == p2) { // if (p1 + 28) mod 7 is p2
    puts("YES"); // print "YES"
    return 0; 
  } 
  if ((p1 + 31) % 7 == p2) { // if (p1 + 31) mod 7 is p2
    puts("YES"); // print "YES"
    return 0; 
  } 
  cout << "NO" << endl; // print "NO"
  return 0; 
} 