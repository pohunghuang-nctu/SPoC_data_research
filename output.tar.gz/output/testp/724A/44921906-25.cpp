
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const long long MOD = 1e9 + 7; // create const long long MOD = 1e9 + 7
long long powmod(long long a, long long b, long long m = MOD) { // in function powmod return long long and accepting long long a, long long b, long long m = MOD
  long long r = 1; // make long long r = 1
  while (b > 0) { // while b greater than 0
    if (b & 1) r = r * a % m; // if b bitwise and 1, set r to r * a % m
    a = a * a % m; // set a to a * a % m
    b >>= 1; // bitwise shift b right by itself and 1
  } 
  return r; // return r
} 
long long power(long long a, long long b) { // in function power returning long long and having long long a and long long b as parameters
  long long r = 1; // create long long r = 1
  while (b > 0) { // while b greater than 0
    if (b & 1) r = r * a; // if b bitwise and 1, set r to r * a
    a = a * a; // set a to a * a
    b >>= 1; // bitwise shift b right by itself and 1
  } 
  return r; // return r
} 
long long gcd(long long a, long long b) { // in function gcd, taking long long a and long long b and returning long long
  if (!b) return a; // if not b, return a
  return gcd(b, a % b); // return gcd(b, a % b)
} 
long long inv(long long a, long long m = MOD) { // in function inv, returning long long with parameters long long a, long long m = MOD
  return powmod(a, m - 2, m); // return powmod(a, m - 2, m)
} 
long long lcm(long long a, long long b) { // in function lcm with long long a and long long b as parameters and return type of long long
  return (a * b) / gcd(a, b); // return (a * b) / gcd(a, b)
} 
map<string, long long> mmap; // create map mmap of string to long long
void init() { // in function init
  mmap["monday"] = 0; // set mmap["monday"] to 0
  mmap["tuesday"] = 1; // set mmap["tuesday"] to 1
  mmap["wednesday"] = 2; // set mmap["wednesday"] to 2
  mmap["thursday"] = 3; // set mmap["thursday"] to 3
  mmap["friday"] = 4; // set mmap["friday"] to 4
  mmap["saturday"] = 5; // set mmap["saturday"] to 5
  mmap["sunday"] = 6; // set mmap["sunday"] to 6
} 
int main() { 
  init(); // call init
  string s1, s2; // create string s1 and s2
  cin >> s1 >> s2; // read s1 and s2
  long long n1 = mmap[s1], n2 = mmap[s2]; // create long longs n1 = mmap[s1] and n2 = mmap[s2]
  if (((n1 + 31) % 7 == n2) || ((n1 + 30) % 7 == n2) | ((n1 + 28) % 7 == n2)) { // if ((n1 + 31) % 7 equals n2) or ((n1 + 30) % 7 equals n2) or ((n1 + 28) % 7 equals n2)
    cout << "YES" // print "YES"
      << "\n"; // newline
  } else { // else
    cout << "NO" // print "NO"
      << "\n"; // newline
  } 
} 