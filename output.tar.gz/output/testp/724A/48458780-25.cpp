
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  char s1[10], s2[10]; // make character array s1 and s2, both of size 10
  int a, b; // make integers a and b
  cin >> s1 >> s2; // read s1 and s2
  if (s1[0] == 'm') a = 1; // if s1[0] is equal to 'm', set a to 1
  if (s1[0] == 't' && s1[1] == 'u') a = 2; // if s1[0] is equal to 't' and s1[1] is equal to 'u', set a to 2
  if (s1[0] == 'w') a = 3; // if s1[0] is equal to 'w', set a to 3
  if (s1[0] == 't' && s1[1] == 'h') a = 4; // if s1[0] is equal to 't' AND s1[1] is equal to 'h', assign 4 to a
  if (s1[0] == 'f') a = 5; // if s1[0] is equal to 'f', assign 5 to a
  if (s1[0] == 's' && s1[1] == 'a') a = 6; // if s1[0] is equal to 's' and s1[1] is equal to 'a', set a to 6
  if (s1[0] == 's' && s1[1] == 'u') a = 7; // if s1[0] is equal to 's' and s1[1] is equal to 'u', set a to 7
  if (s2[0] == 'm') b = 1; // if s1[0] is equal to 'm', assign 1 to b
  if (s2[0] == 't' && s2[1] == 'u') b = 2; // if s2[0] is equal to 't' and s2[1] is equal to 'u', set b to 2
  if (s2[0] == 'w') b = 3; // if s2[0] is equal to 'w', assign 3 to b
  if (s2[0] == 't' && s2[1] == 'h') b = 4; // if s2[0] is equal to 't' and s2[1] is equal to 'h', set b to 4
  if (s2[0] == 'f') b = 5; // if s2[0] is equal to 'f', set b to 5
  if (s2[0] == 's' && s2[1] == 'a') b = 6; // if s2[0] is equal to 's' and s2[1] is equal to 'a', set b to 6
  if (s2[0] == 's' && s2[1] == 'u') b = 7; // if s2[0] is equal to 's' and s2[1] is equal to 'u', set b to 7
  if (a > b) b += 7; // if a greater than b, increase b by 7
  int flag = 0; // make integer flag = 0
  if ((b - a) == 2 || (b - a) == 3 || (a == b)) flag = 1; // if (b - a) is equal to 2 OR (b - a) is equal to 3 OR a is equal to b, set flag to 1
  if (flag == 1) // if flag is equal to 1
    cout << "YES" << endl; // print "YES"
  else // else
    cout << "NO" << endl; // print "NO"
  return 0; 
} 