
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  char s1[10], s2[10]; // s1 = array of characters of length 10 , s2 = array of characters of length 10
  cin >> s1; // read s1
  cin >> s2; // read s2
  int x, y; // let x, y be integers
  if (strcmp(s1, "monday") == 0) // if string compare of s1 and monday equals 0
    x = 1; // x is equal to 1
  else if (strcmp(s1, "tuesday") == 0) // else if string compare of s1 and tuesday equals 0
    x = 2; // x is equal to 2
  else if (strcmp(s1, "wednesday") == 0) // else if string compare of s1 and wednesday equals 0
    x = 3; // x is equal to 3
  else if (strcmp(s1, "thursday") == 0) // else if string compare of s1 and thursday equals 0
    x = 4; // x is equal to 4
  else if (strcmp(s1, "friday") == 0) // else if string compare of s1 and friday equals 0
    x = 5; // x is equal to 5
  else if (strcmp(s1, "saturday") == 0) // else if string compare of s1 and saturday equals 0
    x = 6; // x is equal to 6
  else if (strcmp(s1, "sunday") == 0) // else if string compare of s1 and sunday equals 0
    x = 7; // x is equal to 7
  if (strcmp(s2, "monday") == 0) // if string compare of s2 and monday equals 0
    y = 1; // y is equal to 1
  else if (strcmp(s2, "tuesday") == 0) // else if string compare of s2 and tuesday equals 0
    y = 2; // y is equal to 2
  else if (strcmp(s2, "wednesday") == 0) // else if string compare of s2 and wednesday equals 0
    y = 3; // y is equal to 3
  else if (strcmp(s2, "thursday") == 0) // else if string compare of s2 and thursday equals 0
    y = 4; // y is equal to 4
  else if (strcmp(s2, "friday") == 0) // else if string compare of s2 and friday equals 0
    y = 5; // y is equal to 5
  else if (strcmp(s2, "saturday") == 0) // else if string compare of s2 and saturday equals 0
    y = 6; // y is equal to 6
  else if (strcmp(s2, "sunday") == 0) // else if string compare of s2 and sunday equals 0
    y = 7; // y is equal to 7
  int x1 = x + 31 % 7; // the integer value of x1 = x + 31 modulo 7
  if (x1 > 7) x1 %= 7; // if x1 is greater than 7 , x1 = x1modulo 7
  int x2 = x + 30 % 7; // the integer value of x2 = x + 30 modulo 7
  if (x2 > 7) x2 %= 7; // if x2 is greater than 7 , x2 = x2 modulo 7
  int x3 = x + 28 % 7; // the integer value of x3 = x + 28 modulo 7
  if (x3 > 7) x3 %= 7; // if x3 is greater than 7 , x3 = x3 modulo 7
  if ((x1 == y) || (x2 == y) || (x3 == y)) // if x1 equals y or x2 equals y or x3 equals y
    cout << "YES" << endl; // print YES and newline
  else // else do the following
    cout << "NO" << endl; // print NO and newline
  return 0; 
} 