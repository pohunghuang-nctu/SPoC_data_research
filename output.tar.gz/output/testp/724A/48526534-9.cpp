
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int m[12] = {3, 0, 3, 2, 3, 2, 3, 3, 2, 3, 2, 3}; // integer as array m of size 12 = 3,0,3,2,3,2,3,3,2,3,2,3
int main() { 
  string a, b; // a, b = string array
  cin >> a >> b; // read a,b
  int a1, b1; // integer as a1,b1
  if (a == "monday") a1 = 1; // if a is monday then a1 = 1
  if (a == "tuesday") a1 = 2; // if a is tuesday then do the following a1 = 2
  if (a == "wednesday") a1 = 3; // if a is wednesday then do the following a1 = 3
  if (a == "thursday") a1 = 4; // if a is thursday then do the following a1 = 4
  if (a == "friday") a1 = 5; // if a is friday then do the following a1 = 5
  if (a == "saturday") a1 = 6; // if a is saturday then do the following a1 = 6
  if (a == "sunday") a1 = 0; // if a is sunday then do the following a1 = 0
  if (b == "monday") b1 = 1; // if b is monday then do the following b1 = 1
  if (b == "tuesday") b1 = 2; // if b is tuesday then b1 = 2
  if (b == "wednesday") b1 = 3; // if b is wednesday then make b1 = 3
  if (b == "thursday") b1 = 4; // if b is thursday then do the following b1 = 4
  if (b == "friday") b1 = 5; // if b is friday then b1 = 5
  if (b == "saturday") b1 = 6; // if b is saturday b1 = 6
  if (b == "sunday") b1 = 0; // if b is sunday then do the following b1 = 0
  for (int i = 0; i < 12; i++) { // for i = 0 to less than 12 do the following
    if ((a1 + m[i]) % 7 == b1) { // if is a1+m[i] modulo 7 is b1 then do the following
      cout << "YES" << endl; // output YES
      return 0; 
    } 
  } 
  cout << "NO" << endl; // output NO
  return 0; 
} 