
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int days[12] = {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}; // let int array days of size 12 with {31, 28, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31}
int main() { 
  string s1, s2; // make strings s1 and s2
  cin >> s1 >> s2; // read s1 and s2
  map<string, int> have; // make map have from strings to ints
  have["monday"] = 1; // set have["monday"] to 1
  have["tuesday"] = 2; // set have["tuesday"] to 2
  have["wednesday"] = 3; // set have["wednesday"] to 3
  have["thursday"] = 4; // set have["thursday"] to 4
  have["friday"] = 5; // set have["friday"] to 5
  have["saturday"] = 6; // set have["saturday"] to 6
  have["sunday"] = 7; // set have["sunday"] to 7
  int d1 = have[s1]; // create integer d1 to have[s1]
  int d2 = have[s2]; // make int d1 to have[s2]
  d1--; // decrease d1 by 1
  d2--; // decrease d2 by 1
  for (int i = 0; i < 12; i++) { // for i = 0 to 12 exclusive
    int now = d1; // make int now to d1
    now += days[i]; // set now to now + days[i]
    now %= 7; // modulo now by 7
    if (now == d2) { // if now is d2
      puts("YES"); // show "YES"
      return 0; 
    } 
  } 
  puts("NO"); // display "NO"
  return 0; 
} 