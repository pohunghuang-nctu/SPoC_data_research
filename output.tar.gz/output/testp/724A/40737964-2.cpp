
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

string s[15], x, y; // let x, y be strings , s = array of strings of length 15
int main() { 
  s[1] = "monday"; // s[1] is equal to monday
  s[2] = "tuesday"; // s[2] is equal to tuesday
  s[3] = "wednesday"; // s[3] is equal to wednesday
  s[4] = "thursday"; // s[4] is equal to thursday
  s[5] = "friday"; // s[5] is equal to friday
  s[6] = "saturday"; // s[6] is equal to saturday
  s[7] = "sunday"; // s[7] is equal to sunday
  cin >> x >> y; // read x , y
  int num1 = 0, num2 = 0; // let num1 , num2 be integers with num1 = 0, num2 = 0
  for (int i = 1; i <= 7; i++) { // for integer i = 1 to 7 inclusive
    if (x == s[i]) { num1 = i; } // if x is equal to s[i] , num1 is equal to i
  } 
  for (int i = 1; i <= 7; i++) { // for integer i = 1 to 7 inclusive
    if (y == s[i]) { num2 = i; } // if y is equal to s[i] , num2 is equal to i
  } 
  if (num2 < num1) { num2 += 7; } // if num2 is less than num1 , increment num2 by 7
  int sum = num2 - num1; // the integer value of sum = num2 - num1
  if (sum == 0 || sum == 2 || sum == 3) { // if sum equals 0 or sum equals 2 or sum equals 3
    cout << "YES" << endl; // print YES and newline
  } else { // else do the following
    cout << "NO" << endl; // print NO and newline
  } 
  return 0; 
} 