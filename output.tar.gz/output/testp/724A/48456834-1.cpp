
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int N[2]; // declare integer array N size 2
  for (int i = 0; i < 2; i++) { // for i = 0 to 2 exclusive
    char str[100]; // declare character array str size 100
    cin >> str; // read str
    if (strcmp(str, "monday") == 0) // if string compare between str and "monday" is 0
      N[i] = 1; // let N[i] be 1
    else if (strcmp(str, "tuesday") == 0) // else if string compare between str and "tuesday" is 0
      N[i] = 2; // let N[i] be 2
    else if (strcmp(str, "wednesday") == 0) // else if string compare between str and "wednesday" is 0
      N[i] = 3; // let N[i] be 3
    else if (strcmp(str, "thursday") == 0) // else if string compare between str and "thursday" is 0
      N[i] = 4; // let N[i] be 4
    else if (strcmp(str, "friday") == 0) // else if string compare between str and "friday" is 0
      N[i] = 5; // let N[i] be 5
    else if (strcmp(str, "saturday") == 0) // else if string compare between str and "saturday" is 0
      N[i] = 6; // let N[i] be 6
    else if (strcmp(str, "sunday") == 0) // else if string compare between str and "sunday" is 0
      N[i] = 7; // let N[i] be 7
  } 
  int arr[11] = {3, 0, 3, 2, 3, 2, 3, 3, 2, 3, 2}; // declare integer array arr size 11 = {3, 0, 3, 2, 3, 2, 3, 3, 2, 3, 2}
  int t = N[1] - N[0]; // declare integer t = N[1] - N[0]
  if (t < 0) t += 7; // if t is less than 0, increment t by 7
  int flag = 0; // declare integer flag = 0
  for (int i = 0; i < 11; i++) { // for i = 0 to 11 exclusive
    if (t == arr[i]) flag = 1; // if t is arr[i], let flag be 1
  } 
  if (flag) // if flag is true
    cout << "YES" << endl; // print "YES", newline
  else // else
    cout << "NO" << endl; // print "NO", newline
  return 0; 
} 