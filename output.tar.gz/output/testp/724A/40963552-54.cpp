
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

string s[15], x, y; // create new strings x and y and an array s with size 15
int main() { 
  s[1] = "monday"; // set the value of s[1] to "monday"
  s[2] = "tuesday"; // change the value of s[2] to "tuesday"
  s[3] = "wednesday"; // assign "wednesday" to s[3]
  s[4] = "thursday"; // change s[4] to "thursday"
  s[5] = "friday"; // set s[5] to "friday"
  s[6] = "saturday"; // change s[6] to "saturday"
  s[7] = "sunday"; // assign the new value = "sunday" to s[7]
  cin >> x >> y; // read x and y from the user input
  int num1 = 0, num2 = 0; // declare integers num1 and num2 = 0
  for (int i = 1; i <= 7; i++) { // in a for loop, change i from 1 to 7 inclusive incrementing i
    if (x == s[i]) { num1 = i; } // if x = s[i], change the value of num1 to i
  } 
  for (int i = 1; i <= 7; i++) { // in a for loop, change i from 1 to 7 inclusive incrementing i
    if (y == s[i]) { num2 = i; } // if y is equal to s[i], set the value of num2 to i
  } 
  if (num2 < num1) { num2 += 7; } // if num2 is less than num1, change num2 to num2 + 7
  int sum = num2 - num1; // define integer variable sum with value num2 - num1
  if (sum == 0 || sum == 2 || sum == 3) { // if sum = 0 or sum is equal to 2 or sum = 3
    cout << "YES" << endl; // print "YES"
  } else { // else
    cout << "NO" << endl; // print "NO" to the output
  } 
  return 0; 
} 