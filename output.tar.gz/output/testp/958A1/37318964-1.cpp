
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int maxn = 1e2 + 20; // declare constant integer maxn = 1e2 + 20
int n; // declare integer n
string s[maxn], t[maxn], x[maxn]; // declare string arrays s size maxn, t size maxn, x size maxn
bool is() { // declare is with no arguments, returning boolean
  for (int i = 0; i < n; i++) // for i = 0 to n exclusive
    if (s[i] != t[i]) return 0; // if s[i] is not t[i], return 0 from function
  return 1; // return 1 from function
} 
void rotate() { // declare rotate with no arguments, returning void
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    x[i] = ""; // let x[i] be ""
    for (int j = 0; j < n; j++) x[i] += s[j][n - i - 1]; // for j = 0 to n exclusive, increment x[i] by s[j][n-i-1]
  } 
  for (int i = 0; i < n; i++) s[i] = x[i]; // for i = 0 to n exclusive, let s[i] be x[i]
} 
bool solve() { // declare solve with no arguments, returning boolean
  for (int i = 0; i < 2; i++) { // for i = 0 to 2 exclusive
    for (int i = 0; i < n; i++) reverse(s[i].begin(), s[i].end()); // for i = 0 to n exclusive, reverse sort ( beginning of s[i] to end of s[i] )
    for (int j = 0; j < 4; j++) { // for j = 0 to 4 exclusive
      if (is()) return 1; // if result of run is, is true, return 1 from function
      rotate(); // run rotate
    } 
  } 
  return 0; 
} 
int main() { 
  cin >> n; // read n
  for (int i = 0; i < n; i++) cin >> s[i]; // for i = 0 to n exclusive, read s[i]
  for (int i = 0; i < n; i++) cin >> t[i]; // for i = 0 to n exclusive, read t[i]
  bool f = 0; // declare boolean f = 0
  f |= solve(); // let f be f bitwise or result of run solve
  for (int i = 0; i < n - i - 1; i++) swap(s[i], s[n - i - 1]); // for i = 0 to n - i - 1 exclusive, swap values between s[i] and s[n-i-1]
  f |= solve(); // let f be f bitwise or result of run solve
  cout << (f ? "Yes" : "No") << endl; // print "Yes" if f is true, else "No", print newline
} 