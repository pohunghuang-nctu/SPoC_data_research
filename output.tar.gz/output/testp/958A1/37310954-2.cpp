
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int n; // let n be a integer
vector<string> g() { // create a vector of strings by name v
  vector<string> q(n); // create a vector of strings by name q which is of size n
  for (int i = 0; i < n; i++) { cin >> q[i]; } // for i = 0 to n exclusive, read q[i]
  return q; // return the value of q
} 
vector<string> rot(vector<string> q) { // rot = vector of strings , q = vector of strings
  vector<string> a = q; // assign the vector of strings a to q
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    for (int j = 0; j < n; j++) { a[i][j] = q[n - 1 - j][i]; } // for j = 0 to n exclusive, a[i][j] is equal to q[n - 1 - j][i]
  } 
  return a; // return the value of a
} 
int main() { 
  cin >> n; // read n
  vector<string> a = g(); // vector<string> a is equal to g()
  vector<string> b = g(); // vector<string> b is equal to g()
  int ok1 = (a == b || a == rot(b) || a == rot(rot(b)) || a == rot(rot(rot(b)))); // let integer ok1 = (a is equal to b or a is equal to rot(b) or a is equal to rot(rot(b)) or a is equal to rot(rot(rot(b))))
  reverse(b.begin(), b.end()); // reverse the values of string b from beginning to end
  int ok2 = (a == b || a == rot(b) || a == rot(rot(b)) || a == rot(rot(rot(b)))); // let integer ok2 = (a is equal to b or a is equal to rot(b) or a is equal to rot(rot(b)) or a is equal to rot(rot(rot(b))))
  if (ok1 || ok2) { // if ok1 or ok2
    cout << "Yes" << endl; // print Yes and newline
  } else { // else do the following
    cout << "No" << endl; // print No and new line
  } 
} 