
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, i, j; // n,i,j=long long
  cin >> n; // read n
  vector<string> a(n); // a=vector of n string
  for (i = 0; i < n; i++) cin >> a[i]; // for i=0 to n exclusive read a[i]
  vector<string> b(n); // b=vector of n string
  for (i = 0; i < n; i++) cin >> b[i]; // for i=0 to n exclusive read b[i]
  for (long long ti = 0; ti < 4; ti++) { // for ti=0 to 4 exclusive
    vector<string> c(n); // c=vector of n string
    c = b; // c=b
    for (i = 0; i < n; i++) { // for i=0 to n exclusive
      for (j = 0; j < n; j++) { c[j][n - 1 - i] = b[i][j]; } // fpr j=0 to n exclusive c[j][n-1-i]=b[i][j]
    } 
    b = c; // b=c
    vector<string> d(n); // d=vector of n string
    d = b; // d=b
    for (i = 0; i < n; i++) d[i] = b[n - 1 - i]; // for i=0 to n exclusive d[i]=b[n-1-i]
    if (a == c || a == d) { // if a is c or d
      cout << "Yes" << endl; // print Yes
      return 0; 
    } 
  } 
  cout << "No" << endl; // print No
} 