
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

void win() { // function win (no args, no return value)
  cout << "Yes" << endl; // print Yes
  exit(0); // exit
} 
void reflect(vector<string> &a) { // function reflect (get address of vector of string a, return nothing)
  int N = a.size(); // N=size of a
  for (int i = 0; i < N; i++) reverse(a[i].begin(), a[i].end()); // for i=0 to N exclusive reverse a[i]
} 
void rot(vector<string> &a) { // function rot (get address of vector of string a, return nothing)
  int N = a.size(); // N=size of a
  for (int x = 0; x < N / 2; x++) { // for x=0 to n/2 exclusive
    for (int y = x; y < N - x - 1; y++) { // for y=x to N-x-1 exclusive
      char tmp = a[x][y]; // tmp=a[x][y]
      a[x][y] = a[y][N - 1 - x]; // a[x][y] = a[y][N-1-x]
      a[y][N - 1 - x] = a[N - 1 - x][N - 1 - y]; // a[y][N-1-x]=a[N-1-x][N-1-y]
      a[N - 1 - x][N - 1 - y] = a[N - 1 - y][x]; // a[N-1-x][N-1-y]=a[N-1-y][x]
      a[N - 1 - y][x] = tmp; // a[N-1-y][x]=tmp
    } 
  } 
} 
int main() { 
  int N; // N=int
  cin >> N; // read N
  vector<string> a(N), b(N); // a and b=vector of N string
  for (int i = 0; i < N; i++) cin >> a[i]; // for i=0 to N exclusive read a[i]
  for (int j = 0; j < N; j++) cin >> b[j]; // for j=0 to N exclusive read b[j]
  for (int j = 0; j < 2; j++) { // for j=0 to 2 excluisve
    reflect(a); // reflect(a)
    for (int i = 0; i < 4; i++) { // for i=0 to 4 exclusive
      rot(a); // rot(a)
      if (a == b) win(); // if a is b win()
    } 
  } 
  cout << "No" << endl; // print No
  return 0; 
} 