
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

vector<string> R(vector<string> A) { // in function R taking string vector A and returning string vector
  auto B = A; // B = auto with B = A
  for (int i = 0; i < A.size(); i++) // for i = 0 to size of A
    for (int j = 0; j < A.size(); j++) B[j][i] = A[i][j]; // for j = 0 to size of B set B[j][i] to a[i][j]
  for (auto &s : B) reverse(s.begin(), s.end()); // iterate over B with reference to auto s reverse s
  return B; // return B
} 
int main() { 
  int n; // n = int
  cin >> n; // read n
  vector<string> A(n), B(n); // A, B = string vector of size n each
  for (auto &s : A) cin >> s; // read n values into A
  for (auto &s : B) cin >> s; // read n values into B
  bool OK = A == B; // OK = bool with OK = A is B
  for (int j = 0; j < 4; j++) { // for j = 0 to 4
    A = R(A); // set A to R of A
    if (A == B) OK = 1; // if A is B set OK to 1
  } 
  for (auto &s : A) reverse(s.begin(), s.end()); // iterate over A with reference to auto s reverse s
  for (int j = 0; j < 4; j++) { // for j = 0 to 4
    A = R(A); // set A to R of A
    if (A == B) OK = 1; // if A is B set OK to 1
  } 
  for (int i = 0; i < n / 2; i++) swap(A[i], A[n - 1 - i]); // for i = 0 to n / 2 call swap of A[i], A[n - 1 - i]
  for (int j = 0; j < 4; j++) { // for j = 0 to 4
    A = R(A); // set A to R of A
    if (A == B) OK = 1; // if A is B set OK to 1
  } 
  cout << (OK ? "Yes\n" : "No\n"); // if OK print "Yes" else print "No"
} 