
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

char x[11][11], y[11][11]; // x,y=array of 11 by 11 char
int b[10], n; // b=array of 10 int, n=int
int main() { 
  cin >> n; // read n
  for (int i = 0; i < 10; i++) b[i] = 1; // for i=0 to 10 exclusive b[i]=1
  for (int i = 0; i < n; i++) // for i=0 to n exclusive
    for (int j = 0; j < n; j++) cin >> x[i][j]; // for j=0 to n exclusive read x[i][j]
  for (int i = 0; i < n; i++) // for i=0 to n exclusive
    for (int j = 0; j < n; j++) cin >> y[i][j]; // for j=0 to n exclusive read y[i][j]
  for (int i = 0; i < n; i++) // for i=0 to n exclusive
    for (int j = 0; j < n; j++) { // for j=0 to n exclusive
      if (x[i][j] != y[i][j]) b[0] = 0; // if x[i][j] is not y[i][j] b[0]=0
      if (x[i][j] != y[i][n - j - 1]) b[1] = 0; // if x[i][j] is not y[i][n-j-1] b[1]=0
      if (x[i][j] != y[n - i - 1][j]) b[2] = 0; // if x[i][j] is not y[n-i-1][j] b[2]=0
      if (x[i][j] != y[n - i - 1][n - j - 1]) b[3] = 0; // if x[i][j] is not y[n-i-1][n-j-1] b[3]=0
      if (x[i][j] != y[j][n - i - 1]) b[4] = 0; // if x[i][j] is not y[j][n-i-1] b[4]=0
      if (x[i][j] != y[n - j - 1][n - i - 1]) b[5] = 0; // if x[i][j] is not y[n-j-1][n-j-1] b[5]=0
      if (x[i][j] != y[j][i]) b[6] = 0; // if x[i][j] is not y[j][i] b[6]=0
      if (x[i][j] != y[n - j - 1][i]) b[7] = 0; // if x[i][j] is not y[n-j-1][i] b[7]=0
    } 
  for (int i = 0; i < 8; i++) // for i=0 to 8 exclusive
    if (b[i] == 1) { // if b[i] is 1
      cout << "Yes\n"; // print Yes
      return 0; 
    } 
  cout << "No\n"; // print No
  return 0; 
} 