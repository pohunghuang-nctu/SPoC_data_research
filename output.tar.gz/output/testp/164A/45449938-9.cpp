
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long gcd1(long long a, long long b) { // long long = (long long a,long long b)
  if (a == 0) return b; // if a is 0 then do the following return b
  return gcd1(b % a, a); // return gcd1(b modulo a, a)
} 
long long modx(long long base, long long ex) { // long long = (long long base,long long ex)
  long long ans = 1LL, val = base; // long long = ans = 1LL,val = base
  while (ex > 0LL) { // if ex is greater than 0LL then do the following
    if (ex & 1LL) ans = (ans * val) % 1000000009LL; // if ex & 1LL is true
    val = (val * val) % 1000000009LL; // set val to (val * val) modulo 1000000009LL
    ex = ex >> 1LL; // set ex to ex >> 1LL
  } 
  return ans; // return ans
} 
const int maxn = 1e5 + 10; // integer = t integer maxn = 1e5 + 10
bool visit[maxn], visit1[maxn]; // make boolean visit and visit1 with size of maxn
int n, m, x, y, a[maxn]; // integer = n,m,x,y,a[maxn]
bool D[maxn], P[maxn]; // make boolean d and p with size maxn
vector<int> adj[maxn], v[maxn]; // create vector of adj and v with size maxn
void dfs(int start) { // declare function dfs with input start
  visit[start] = true; // set visit[start] to true
  for (int i = 0; i < adj[start].size(); i++) { // for i = 0 to less than adj[start].size() do the following
    int pt = adj[start][i]; // integer as pt = adj[start][i]
    if (!visit[pt]) dfs(pt); // if visit[pt] is false then run dfs(pt)
  } 
} 
void dfs2(int start) { // integer = dfs2(integer start)
  visit1[start] = true; // set visit1[start] to true
  for (int i = 0; i < v[start].size(); i++) { // for i = 0 to less than v[start].size() do the following
    int pt = v[start][i]; // integer = pt = v[start][i]
    if (!visit1[pt]) dfs2(pt); // if !visit1[pt] is true
  } 
} 
int main() { 
  cin >> n >> m; // read n,m
  for (int i = 1; i <= n; i++) cin >> a[i]; // for i = 1 to less than or equal to n do the following
  for (int i = 1; i <= m; i++) { // for i = 1 to less than or equal to m do the following
    cin >> x >> y; // read x,y
    adj[x].push_back(y); // add new element y to end of vector adj[x]
    if (a[x] != 1 && a[y] != 1) v[y].push_back(x); // if a[x] is not equal to 1 and a[y] then do the following
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to less than or equal to n do the following
    if (!visit[i] && a[i] == 1) dfs(i); // if !visit[i] and a[i] is 1 then do the following dfs(i
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to less than or equal to n do the following
    if (!visit1[i] && a[i] == 2) dfs2(i); // if !visit1[i] and a[i] is 2 then do the following dfs2(i
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to less than or equal to n do the following
    if (a[i] != 1) continue; // if a[i] is not equal to 1 then continue
    for (int j = 0; j < adj[i].size(); j++) { // for j = 0 to less than adj[i].size() do the following
      int pt = adj[i][j]; // integer as pt = adj[i][j]
      if (visit1[pt] && a[pt] != 1) visit1[i] = true; // if visit1[pt] and a[pt] is not equal to 1 then do the following visit1[i] = true
    } 
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to less than or equal to n do the following
    if (visit1[i] && visit[i]) // if visit1[i] and visit[i] is true
      cout << 1 << endl; // output 1
    else // else
      cout << 0 << endl; // output 0
  } 
  return 0; 
} 