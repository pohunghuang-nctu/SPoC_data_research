
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int maxn = 1e5 + 100; // create constant integer maxn= 1e5+100
vector<int> v[maxn], w[maxn]; // let w and v be vector integer array of size maxn
long long a[maxn]; // a= long long integer array of size maxn
bool d[maxn]; // d= array of boolean of size maxn
long long c[maxn][5]; // c= 2D long long integer array of size maxn by 5
long long n, m; // n,m = long long integers
bool mark[maxn][2]; // mark= array of booleans of size maxn by 2
void dfs1(long long i) { // into the function dfs1 which takes a long long integer i
  c[i][0] = 1; // set c[i][0] to 1
  mark[i][0] = 1; // set mark[i][0] to 1
  for (long long y = 0; y < v[i].size(); y++) { // for y=0 to size of v[i] exclusive
    if (!mark[v[i][y]][0]) { dfs1(v[i][y]); } // if mark[v[i][y]][0] is not true then call dfs1(v[i][y])
  } 
} 
void dfs2(long long i) { // into the function dfs2 which takes a long long integer i
  mark[i][1] = 1; // set mark[i][1] = 1;
  c[i][1] = 1; // set c[i][1] = 1
  if (a[i] == 1) return; // if a[i] = 1 then return
  for (long long y = 0; y < w[i].size(); y++) { // for y=0 to size of w[i] exclusive
    if (!mark[w[i][y]][1]) { dfs2(w[i][y]); } // if mark[w[i][y]][1] is false then call dfs2(w[i][y]
  } 
} 
int main() { 
  cin >> n >> m; // read n and m
  for (long long y = 1; y <= n; y++) { // for y=1 to n inclusive
    cin >> a[y]; // read a[y]
    if (a[y] == 1) { v[100000 + 1].push_back(y); } // if a[y] is 1 then add y to end of v[100000 + 1]
    if (a[y] == 2) { w[100000 + 1].push_back(y); } // if a[y] is 2 then add y to end of w[100000 + 1]
  } 
  while (m--) { // while m is true, decrement m and do the following
    long long i, j; // create long long integers i,j
    cin >> i >> j; // read i and j
    v[i].push_back(j); // add i to end of v[i]
    w[j].push_back(i); // add i to end of w[j]
  } 
  dfs1(100000 + 1); // call dfs1 with argument 100000 + 1
  dfs2(100000 + 1); // call dfs2(100000 + 1)
  for (long long y = 1; y <= n; y++) { cout << (c[y][0] && c[y][1]) << endl; } // for y=0 to n inclsuive print c[y][0] && c[y][1]
} 