
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int maxn = 1e5 + 10; // create constant int maxn = 1e5 + 10
bool mark[maxn], rmark[maxn]; // create bool array mark of size maxn and rmark of size maxn
int a[maxn]; // make integer a of size maxn
vector<int> v[maxn], rv[maxn]; // create int vector v of size maxn and rv of size maxn
inline void dfs(int x, int par) { // declare inline dfs taking in ints x and par
  if (mark[x]) return; // if mark[x] is true, return
  if (par != -1 && a[x] == 1) return; // if par is not equal to -1 and a[x] is equal to 1, return
  mark[x] = 1; // set mark[x] to 1
  for (int i = 0; i < v[x].size(); i++) // for i = 0 to v[x].size() exclusive
    if (!mark[v[x][i]]) dfs(v[x][i], x); // if mark[v[x][i]] is falsy, call dfs(v[x][i], x)
} 
inline void rdfs(int x) { // declare inline rdfs taking in integer x
  if (rmark[x]) return; // if rmark[x] is true, return
  rmark[x] = 1; // set rmark[x] to 1
  if (a[x] == 1) return; // if a[x] is 1, end function
  for (int i = 0; i < rv[x].size(); i++) // for i = 0 to rv[x].size() exclusive
    if (!rmark[rv[x][i]]) rdfs(rv[x][i]); // if rmark[rv[x][i]] is falsy, call rdfs(rv[x][i])
} 
int main() { 
  int n, m, x, y; // create ints n, m, x, and y
  cin >> n >> m; // read n and m
  for (int i = 0; i < n; i++) cin >> a[i]; // for i = 0 to n exclusive, read a[i]
  for (int i = 0; i < m; i++) { // for i = 0 to m exclusive
    cin >> x >> y; // read x and y
    x--; // subtract 1 from x
    y--; // decrease y by 1
    v[x].push_back(y); // append y to v[x]
    rv[y].push_back(x); // append x to rv[y]
  } 
  for (int i = 0; i < n; i++) // for i = 0 to n exclusive
    if (a[i] == 1) dfs(i, -1); // if a[i] is equal to 1, call dfs(i, -1)
  for (int i = 0; i < n; i++) // for i = 0 to n exclusive
    if (a[i] == 2) rdfs(i); // if a[i] is equal to 2, call rdfs(i)
  for (int i = 0; i < n; i++) // for i = 0 to n exclusive
    if (mark[i] && rmark[i]) // if mark[i] and rmark[i] are truthy
      cout << 1 << "\n"; // print 1
    else // else
      cout << 0 << "\n"; // print 0
} 