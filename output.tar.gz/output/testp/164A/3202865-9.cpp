
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int n, m, x, y, curr; // integers = n,m,x,y,curr
vector<int> graph[100010]; // create a vector using integers of array called graph of 100010 size
vector<int> rgraph[100010]; // create vector rgraph of size 100010
int f[100010]; // integers = f[100010]
int a[100010]; // integers = a[100010]
bool used[100010]; // make boolean array called used of size 100010
bool rused[100010]; // make boolean array called rused with size 100010
queue<int> q, rq; // create queue with integers q and rq
int main() { 
  cin >> n >> m; // read n,m
  for (int i = 0; i < n; i++) { // for i = 0 to less than n do the following
    cin >> f[i]; // read f[i]
    if (f[i] == 1) { // if f[i] is 1 then do the following
      q.push(i); // put i into next position of q
      used[i] = true; // set used[i] to true
    } 
    if (f[i] == 2) { // if f[i] is 2 then do the following
      rq.push(i); // put i into next position of rq
      rused[i] = true; // set rused[i] to true
    } 
  } 
  for (int i = 0; i < m; i++) { // for i = 0 to less than m do the following
    cin >> x >> y; // read x,y
    x--; // minus 1 from x
    y--; // minus 1 from y
    graph[x].push_back(y); // add new element y to end of vector graph[x]
    rgraph[y].push_back(x); // add new element x to end of vector rgraph[y]
  } 
  while (!q.empty()) { // if !q.empty is true do the following
    curr = q.front(); // set curr to q.front()
    q.pop(); // remove element on top of stack q
    a[curr]++; // add one to a[curr]
    for (int i = 0; i < graph[curr].size(); i++) { // for i = 0 to less than graph[curr].size() do the following
      if (!used[graph[curr][i]]) { // if !used[graph[curr][i]] is true
        used[graph[curr][i]] = true; // set used[graph[curr][i]] to true
        q.push(graph[curr][i]); // put graph[curr][i] at top of stack
      } 
    } 
  } 
  while (!rq.empty()) { // if !rq.empty is true do the following
    curr = rq.front(); // set curr to rq.front()
    rq.pop(); // remove element on top of stack rq
    a[curr]++; // add one to a[curr]
    if (f[curr] != 1) { // if f[curr] is not equal to 1 then do the following
      for (int i = 0; i < rgraph[curr].size(); i++) { // for i = 0 to less than rgraph[curr].size() do the following
        if (!rused[rgraph[curr][i]]) { // if !rused[rgraph[curr][i]] is true
          rused[rgraph[curr][i]] = true; // set rused[rgraph[curr][i]] to true
          rq.push(rgraph[curr][i]); // put rgraph[curr][i] at the top of stack rq
        } 
      } 
    } 
  } 
  for (int i = 0; i < n; i++) { (a[i] == 2) ? cout << 1 << endl : cout << 0 << endl; } // for i = 0 to less than n do the following
} 