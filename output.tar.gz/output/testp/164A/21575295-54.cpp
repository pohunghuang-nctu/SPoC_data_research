
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int maxn = 1e5 + 10; // declare constant integer variable maxn = 1e5 + 10
bool mark[maxn], rmark[maxn]; // create bool arrays mark and rmark with maxn elements
int a[maxn]; // a is an array of integers with maxn elements
vector<int> v[maxn], rv[maxn]; // declare an arrays of int vectors v and rv with size maxn
inline void dfs(int x, int par) { // inlined void function dfs with int arguments x and par
  if (mark[x]) return; // return if mark[x] is true
  if (par != -1 && a[x] == 1) return; // if par != - 1 and a[x] = 1, return
  mark[x] = 1; // assign 1 to mark[x]
  for (int i = 0; i < v[x].size(); i++) // start for loop from i = 0 to length of v[x] exclusive incrementing i
    if (!mark[v[x][i]]) dfs(v[x][i], x); // if mark[v[x][i]] is false, call function dfs for v[x][i] and x
} 
inline void rdfs(int x) { // inlined void function rdfs with int argument x
  if (rmark[x]) return; // if rmark[x] is true, return
  rmark[x] = 1; // assign 1 to rmark[x]
  if (a[x] == 1) return; // if a[x] is equal to 1, return
  for (int i = 0; i < rv[x].size(); i++) // start for loop from i = 0 to length of rv[x] exclusive
    if (!rmark[rv[x][i]]) rdfs(rv[x][i]); // if rmark[rv[x][i]] is false, call rdfs(rv[x][i])
} 
int main() { 
  int n, m, x, y; // declare integers n, m, x and y
  cin >> n >> m; // read from the input to n and m
  for (int i = 0; i < n; i++) cin >> a[i]; // in a loop, read n elements into array a
  for (int i = 0; i < m; i++) { // for i from 0 to m exclusive incrementing i
    cin >> x >> y; // read from the input to x and y
    x--; // decrement x by one
    y--; // decrement y
    v[x].push_back(y); // push new value = y into v[x]
    rv[y].push_back(x); // push x to the end of rv[y]
  } 
  for (int i = 0; i < n; i++) // start for loop from i = 0 to n exclusive incrementing i
    if (a[i] == 1) dfs(i, -1); // call dfs(i, -1) if a[i] is equal to 1
  for (int i = 0; i < n; i++) // for i from 0 to n exclusive incrementing i
    if (a[i] == 2) rdfs(i); // if a[i] = 2, run rdfs with i as an argument
  for (int i = 0; i < n; i++) // start for loop from i = 0 to n exclusive
    if (mark[i] && rmark[i]) // if both mark[i] and rmark[i] are true
      cout << 1 << "\n"; // print 1 and "\n"
    else // else
      cout << 0 << "\n"; // print 0 and "\n" to the standard output
} 