
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int Maxn = 1e5 + 100; // declare constant integer Maxn = 1e5 + 100
int n, m, a[Maxn]; // declare integers n, m, integer array a size Maxn
bool mark[2][Maxn]; // declare boolean array mark size 2 by Maxn
vector<int> nei[2][Maxn]; // declare integer vector nei size 2 by Maxn
void dfs(int x, int v) { // delare dfs initialized with integers x and v
  for (int i = 0; i < (int)nei[x][v].size(); i++) { // for i = 0 to integer casted size of nei[x][v] exclusive
    int u = nei[x][v][i]; // declare integer u = nei[x][v][i]
    if (!mark[x][u]) { // if not mark[x][u]
      mark[x][u] = true; // let mark[x][u] be true
      if (x == 0 || a[u] != 1) dfs(x, u); // if x is 0 or a[u] is not 1, run dfs with x, u as arguments
    } 
  } 
} 
int main() { 
  cin >> n >> m; // read n and m
  for (int i = 0; i < n; i++) { cin >> a[i]; } // for i = 0 to n exclusive, read a[i]
  for (int i = 0, u, v; i < m; i++) { // for i = 0, u, v to m exclusive
    cin >> u >> v; // read u and v
    nei[0][u - 1].push_back(v - 1); // add ( v - 1 ) to end of nei[0][u-1]
    nei[1][v - 1].push_back(u - 1); // add ( u - 1 ) to end of nei[1][v-1]
  } 
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    if (a[i] == 1 && !mark[0][i]) // if a[i] is 1 and not mark[0][i]
      mark[0][i] = true, dfs(0, i); // let mark[0][i] be true, run dfs with 0, i as arguments
    else if (a[i] == 2 && !mark[1][i]) // else if a[i] is 2 and not mark[1][i]
      mark[1][i] = true, dfs(1, i); // let mark[1][i] be true, run dfs(1,i)
  } 
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    if (mark[0][i] && mark[1][i]) // if mark[0][i] and mark[1][i]
      cout << 1 << endl; // print 1 and newline
    else // else
      cout << 0 << endl; // print 0 and newline
  } 
} 