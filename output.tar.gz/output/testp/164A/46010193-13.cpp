
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long gcd1(long long a, long long b) { // declare gcd1 taking in long long ints a and b and returning long long
  if (a == 0) return b; // if a is 0, return b
  return gcd1(b % a, a); // return the return value of gcd1(b % a, a)
} 
long long modx(long long base, long long ex) { // declare modx taking in long long ints base and ex and returning long long
  long long ans = 1LL, val = base; // make long long ints ans = 1LL and val = base
  while (ex > 0LL) { // while ex is greater than 0LL
    if (ex & 1LL) ans = (ans * val) % 1000000009LL; // if ex & 1LL is truthy, set ans to (ans * val) % 1000000009LL
    val = (val * val) % 1000000009LL; // set val to (val * val) % 1000000009LL
    ex = ex >> 1LL; // set ex to ex >> 1LL
  } 
  return ans; // return ans
} 
const int maxn = 1e5 + 10; // create constant integer maxn = 1e5 + 10
bool visit[maxn], visit1[maxn]; // set bool arrays visit of size maxn and visit1 of size maxn
int n, m, x, y, a[maxn]; // create ints n, m, x, and y and int array a of size maxn
bool D[maxn], P[maxn]; // create bool arrays D of size maxn and P of size maxn
vector<int> adj[maxn], v[maxn]; // make int vectors adj of size maxn and v of size maxn
void dfs(int start) { // declare dfs taking in int start
  visit[start] = true; // set visit[start] to true
  for (int i = 0; i < adj[start].size(); i++) { // for i = 0 to adj[start].size() exclusive
    int pt = adj[start][i]; // make integer pt = adj[start][i]
    if (!visit[pt]) dfs(pt); // if visit[pt] is falsy, call dfs(pt)
  } 
} 
void dfs2(int start) { // declare dfs2 taking in int start
  visit1[start] = true; // set visit1[start] to true
  for (int i = 0; i < v[start].size(); i++) { // for i = 0 to v[start].size() exclusive
    int pt = v[start][i]; // make integer pt = v[start][i]
    if (!visit1[pt]) dfs2(pt); // if visit1[pt] is falsy, call dfs2(pt)
  } 
} 
int main() { 
  cin >> n >> m; // read n and m
  for (int i = 1; i <= n; i++) cin >> a[i]; // for i = 1 to n, read a[i]
  for (int i = 1; i <= m; i++) { // for i = 1 to m
    cin >> x >> y; // read x and y
    adj[x].push_back(y); // append y to adj[x]
    if (a[x] != 1 && a[y] != 1) v[y].push_back(x); // if a[x] is not equal to 1 and a[y] is not equal to 1, append x to v[y]
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to n
    if (!visit[i] && a[i] == 1) dfs(i); // if visit[i] is falsy and a[i] is 1, call dfs(i)
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to n
    if (!visit1[i] && a[i] == 2) dfs2(i); // if visit1[i] is falsy and a[i] is 2, call dfs2(i)
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to n
    if (a[i] != 1) continue; // if a[i] is not equal to 1, continue to next loop iteration
    for (int j = 0; j < adj[i].size(); j++) { // for j = 0 to adj[i].size() exclusive
      int pt = adj[i][j]; // create int pt = adj[i][j]
      if (visit1[pt] && a[pt] != 1) visit1[i] = true; // if visit1[pt] is truthy and a[pt] is not equal to 1, set visit1[i] to true
    } 
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to n
    if (visit1[i] && visit[i]) // if visit1[i] and visit[i] are truthy
      cout << 1 << endl; // show 1
    else // else
      cout << 0 << endl; // display 0
  } 
  return 0; 
} 