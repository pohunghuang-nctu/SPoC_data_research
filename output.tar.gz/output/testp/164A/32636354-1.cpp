
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int inf = 0x3f3f3f3f; // declare constant integer inf = 0x3f3f3f3f
const long long linf = 1e18; // declare constant long long linf = 1e18
const int N = 100000 + 10; // declare constant integer N = 100000 + 10
const double eps = 1e-10; // declare constant double eps = 1e-10
const int mo = 1e9 + 7; // declare constant integer mo = 1e9 + 7
int n, m; // declare integers n, m
int st[N]; // declare integer array st size N
vector<int> g[N], r[N]; // declare integer vector arrays g size N, r size N
bool vis[N], path[N][2]; // declare boolean arrays vis size N, path size N by 2
void dfs(int x, vector<int> g[], int k) { // declare dfs with integer x, integer vector array g, integer k as arguments, returning void
  vis[x] = path[x][k] = 1; // let vis[x] be path[x][k] be 1
  for (int i = 0; i < g[x].size(); i++) { // for i =0 to size of g[x] exclusive
    int y = g[x][i]; // declare integer y = g[x][i]
    if (!vis[y]) { // if not vis[y]
      if (st[y] == 1) { // if st[y] is 1
        if (k == 1) path[y][k] = 1; // if k is 1, let path[y][k] be 1
        continue; // end current loop
      } 
      dfs(y, g, k); // run dfs with y, g, k as arguments
    } 
  } 
} 
int main() { 
  cin >> n >> m; // read n and m
  for (int i = 1; i <= n; i++) cin >> st[i]; // for i = 1 to n inclusive, read st[i]
  for (int i = 1; i <= m; i++) { // for i = 1 to m inclusive
    int x, y; // declare integers x, y
    cin >> x >> y; // read x and y
    g[x].push_back(y); // add y to end of g[x]
    r[y].push_back(x); // add x to end of r[y]
  } 
  for (int i = 1; i <= n; i++) // for i = 1 to n inclusive
    if (!vis[i] && st[i] == 1) dfs(i, g, 0); // if not vis[i] and st[i] is 1, run dfs(i,g,0)
  memset(vis, 0, sizeof vis); // set bytes from vis to size of vis to value 0
  for (int i = 1; i <= n; i++) // for i = 1 to n inclusive
    if (!vis[i] && st[i] == 2) dfs(i, r, 1); // if not vis[i] and st[i] is 2, run dfs(i,r,1)
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    if (path[i][0] && path[i][1]) // if path[i][0] and path[i][1]
      cout << 1 << endl; // print 1 and newline
    else // else
      cout << 0 << endl; // print 0 and newline
  } 
  return 0; 
} 