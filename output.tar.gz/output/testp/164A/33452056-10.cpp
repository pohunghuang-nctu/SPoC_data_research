
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long const M = 2e5 + 10; // M = long long const with M = 2e5 + 10
long long col[M], q[M], head = 0, tail = 0, ans[M], ans2[M]; // head, tail = long long with head = 0 and tails = 0 and col, q, ans, ans2 = long long array of size M each
vector<long long> adj[M], adj2[M]; // adj, adj2 = long long vector array of size M each
int main() { 
  long long n, m, a, b; // n, m, a, b = long long
  cin >> n >> m; // read n then m
  for (long long i = 1; i <= n; i++) { // for i = 1 to n inclusive
    cin >> col[i]; // read col[i]
    col[i] = (3 - col[i]) % 3; // set col[i] to (3 - col[i]) mod 3
    if (col[i] == 2) q[head++] = i, ans[i] = 1; // of col[i] is 2 set q[head] to i then set ans[i] to 1 then increment head
  } 
  for (long long i = 1; i <= m; i++) cin >> a >> b, adj[a].push_back(b), adj2[b].push_back(a); // for i = 1 to m inclusive read a then b then append b to adj[a] then append a to adj2[b]
  while (head > tail) { // loop while head > tail
    long long v = q[tail++]; // v = long long with v = q[tail] then increment tail
    for (long long i = 0; i < adj[v].size(); i++) { // for i = 0 to size of adj[v]
      long long u = adj[v][i]; // u = long long with u = adj[v][i]
      if (!ans[u] && col[u] != 2) q[head++] = u, ans[u] = 1; // if not ans[u] and col[u] is not 2 set q[head] to u then set ans[u] to 1 then increment head
    } 
  } 
  head = 0, tail = 0; // set head to 0 then set tail to 0
  for (long long i = 1; i <= n; i++) { // for i = 1 to n inclusive
    if (col[i] == 1) q[head++] = i, ans2[i] = 1; // if col[i] is 1 set q[head] to i then set ans2 to 1 then increment head
  } 
  while (head > tail) { // loop while head > tail
    long long v = q[tail++]; // v = long long with v = q[tail] then increment tail
    for (long long i = 0; i < adj2[v].size(); i++) { // for i = 0 to size of adj2[v]
      long long u = adj2[v][i]; // u = long long with u = adj2[v][i]
      if (!ans2[u] && col[u] != 2) // if not ans2[u] and col[u] is not 2
        ans2[u] = 1, q[head++] = u; // set ans2[u] to 1 then set q[head] to u then increment head
      else if (col[u] == 2) // else if col[u] is 2
        ans2[u] = 1; // set ans2[u] to 1
    } 
  } 
  for (long long i = 1; i <= n; i++) { // for i = 1 to n inclusive
    if (ans[i] == 1 && ans2[i] == 1) // if ans[i] is 1 and ans2[i] is 1
      cout << 1 << endl; // print 1
    else // else
      cout << 0 << endl; // print 0
  } 
} 