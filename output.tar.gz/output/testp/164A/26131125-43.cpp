
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const long long N = 100005; // N = const long long = 100005
long long dp[N], f[N]; // dp, f = long long arrays of length N
long long dpback[N]; // dpback = long long array of length N
vector<long long> g[N]; // g = long long vector of length N
vector<long long> gback[N]; // gback = long long vector of length N
void go(long long p) { // in void function go taking p = long long
  if (dp[p] == 1) return; // if dp at p = 1 then return
  dp[p] = 1; // set dp at p to 1
  if (f[p] != 1) { // if f at p isn't 1
    for (long long i = 0; i < (g[p].size()); i++) { go(g[p][i]); } // for long long i = 0 to size of g at p, call go on g[p][i]
  } 
} 
void goback(long long p, bool first) { // in void fucntion goback taking p = long long and first = bool
  if (dpback[p] == 1) return; // if dpback at p = 1 then return
  if (first || f[p] != 1) { // if first isn't 0 ot f at p isn't 1
    dpback[p] = 1; // dpback at p = 1
    for (long long i = 0; i < (gback[p].size()); i++) { goback(gback[p][i], false); } // for long long i = 0 to size of gback at p then call goback on goback[p][i] and false
  } 
} 
int main() { 
  long long n, m; // n, m = long long
  cin >> n >> m; // read n, m
  for (long long i = 0; i < (n); i++) { cin >> f[i]; } // read the first n elements of f
  for (long long i = 0; i < (m); i++) { // for long long i = 0 to m exclusive
    long long x, y; // x, y = long long
    cin >> x >> y; // read x, y
    x--; // decrement x
    y--; // decrement y
    g[y].push_back(x); // push back x into g at y
    gback[x].push_back(y); // push back y into gback at x
  } 
  for (long long i = 0; i < (n); i++) { // for long long i = 0 to n exclusive
    if (f[i] == 2) { go(i); } // if f at i = 2 then call go on i
    if (f[i] == 1) goback(i, true); // if f at i = 1 then call goback on i and true
  } 
  for (long long i = 0; i < (n); i++) { // for long long i = 0 to n exl
    long long ans = dp[i] == 1 && dpback[i] == 1 ? 1 : 0; // ans = long long, are dp[i] 1 and dpback[i] = 1 ? then set ans = 1, else set ans = 0
    cout << ans << "\n"; // print ans
  } 
} 