
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long gcd1(long long a, long long b) { // in function gcd1 taking long long a, long long b and returning long long
  if (a == 0) return b; // if a is 0 return b
  return gcd1(b % a, a); // return gcd1 of b mod a, a
} 
long long modx(long long base, long long ex) { // in function modx taking long long base, long long ex and returning long long
  long long ans = 1LL, val = base; // ans, val = long long with ans = 1LL and val = base
  while (ex > 0LL) { // loop while ex > 0LL
    if (ex & 1LL) ans = (ans * val) % 1000000009LL; // if ex bitwise-and 1LL set ans to (ans * val) mod 1000000009LL
    val = (val * val) % 1000000009LL; // set val to (val * val) mod 1000000009LL
    ex = ex >> 1LL; // set ex to ex bitshift right by 1LL
  } 
  return ans; // return ans
} 
const int maxn = 1e5 + 10; // maxn = const int with maxn = 1e5 + 10
bool visit[maxn], visit1[maxn]; // visit, visit1 = bool array of size maxn each
int n, m, x, y, a[maxn]; // n, m, x, y = int and a = int array of size maxn
bool D[maxn], P[maxn]; // D, P = bool array of size maxn each
vector<int> adj[maxn], v[maxn]; // adj, v = int vector array of size maxn each
void dfs(int start) { // in function dfs taking int start
  visit[start] = true; // set visit[start] to true
  for (int i = 0; i < adj[start].size(); i++) { // for i = 0 to size of adj[start]
    int pt = adj[start][i]; // pt = int with pt = adj[start][i]
    if (!visit[pt]) dfs(pt); // if not visit[pt] call dfs of pt
  } 
} 
void dfs2(int start) { // in function dfs2 taking int start
  visit1[start] = true; // set visit1[start] to true
  for (int i = 0; i < v[start].size(); i++) { // for i = 0 to size of v[start]
    int pt = v[start][i]; // pt = int with pt = v[start][i]
    if (!visit1[pt]) dfs2(pt); // if not visit1[pt] call dfs2 of pt
  } 
} 
int main() { 
  cin >> n >> m; // read n then m
  for (int i = 1; i <= n; i++) cin >> a[i]; // for i = 1 to n inclusive read a[i]
  for (int i = 1; i <= m; i++) { // for i = 1 to m inclusive
    cin >> x >> y; // read x then y
    adj[x].push_back(y); // append y to adj[x]
    if (a[x] != 1 && a[y] != 1) v[y].push_back(x); // if a[x] != 1 and a[y] != 1 append x to v[y]
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    if (!visit[i] && a[i] == 1) dfs(i); // if not visit[i] and a[i] is 1 call dfs of i
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    if (!visit1[i] && a[i] == 2) dfs2(i); // if not visit1[i] and a[i] is 2 call dfs2 of i
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    if (a[i] != 1) continue; // if a[i] is not 1 continue
    for (int j = 0; j < adj[i].size(); j++) { // for j = 0 to size of adj[i]
      int pt = adj[i][j]; // pt = int with pt = adj[i][j]
      if (visit1[pt] && a[pt] != 1) visit1[i] = true; // if visit1[pt] and a[pt] is not 1 set visit1[i] to true
    } 
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    if (visit1[i] && visit[i]) // if visit1[i] and visit[i]
      cout << 1 << endl; // print 1
    else // else
      cout << 0 << endl; // print 0
  } 
  return 0; 
} 