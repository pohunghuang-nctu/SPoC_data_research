
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 200; // declare constant integer N = 200
int k, mark[N][N]; // declare integer k, integer array mark size N by N
void f(int val) { // declare f with integer val as argument, returning void
  memset(mark, 1 - val, sizeof mark); // set bytes from mark to size of mark to value 1 - val
  for (int i = 0; i < k; i++) // for i = 0 to k exclusive
    for (int j = i; j < k - i; j++) // for j = i to k - i exclusive
      if (i % 2 == 0) mark[i][j] = val; // if i % 2 is 0, let mark[i][j] be val
  for (int i = k - 1; i > 0; i--) // for i = k - 1 to 0 exclusive, decrementing i
    for (int j = i; j >= k - 1 - i; j--) // for j = i to k - 1 - i inclusive, decrementing j
      if ((k - 1 - i) % 2 == 0) mark[i][j] = val; // if ( k - 1 - i ) % 2 is 0, let mark[i][j] be val
  for (int j = 0; j < k; j++) // for j = 0 to k exclusive
    for (int i = j; i < k - j; i++) // for i = j to k - j exclusive
      if (j % 2 == 0) mark[i][j] = val; // if j % 2 is 0, let mark[i][j] be val
  for (int j = k - 1; j > 0; j--) // for j = k - 1 to 0 exclusive, decrementing j
    for (int i = j; i >= k - 1 - j; i--) // for i = j to k - 1 - j inclusive, decrementing i
      if ((k - 1 - j) % 2 == 0) mark[i][j] = val; // if ( k - 1 - j ) % 2 is 0, let mark[i][j] be val
} 
int main() { 
  cin >> k; // read k
  if (k % 2) // if k % 2
    cout << -1 << endl; // print -1 and newline
  else { // else
    for (int i = 0; i < k; i++) { // for i = 0 to k exclusive
      f(i % 2); // run f with i % 2 as argument
      for (int r = 0; r < k; r++) { // for r = 0 to k exclusive
        for (int c = 0; c < k; c++) cout << (mark[r][c] ? 'w' : 'b'); // for c = 0 to k exclusive, print 'w' if mark[r][c] is true, else 'b'
        cout << endl; // print newline
      } 
      if (i < k - 1) cout << endl; // if i is less than k - 1, print newline
    } 
  } 
} 