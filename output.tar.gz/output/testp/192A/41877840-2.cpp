
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

inline bool isTriangular(long long n) { // create a function isTriangular that accepts long integer n
  double r = sqrt((double)(1 + (n << 3LL))); // r be a double integer and equals to the square root of 1 + (n << 3LL)
  if (r == floor(r)) { // if r == floor(r)
    long long s = (long long)r; // long integer s equals long integer r
    return s > 1LL and (s - 1LL) & 1LL == 0; // return s > 1LL and (s - 1LL) & 1LL == 0
  } 
  return false; // return 0
} 
inline long long sum(long long n) { // create a function sum that accepts long integer n
  return (n * (n + 1)) >> 1LL; // return (n * (n + 1)) >> 1LL
} 
int main() { 
  long long n; // let n be a long integer
  while (cin >> n) { // while read n
    long long x = 1; // let x be a long inter with x = 1
    bool possible = false; // let possible be a boolean value false
    while (n - sum(x) > 0) { // while n - sum of x is greater than 0
      long long y = n - sum(x); // let y be a long integer with y = n - sum of x
      long long m; // let m be a long integer
      long long l = 1; // let l be a long integer with l = 1
      long long r = y; // let r be a long integer with r = y
      while (l < r) { // while l is less than r
        m = (l + r) >> 1LL; // shift bitwise the value of l+r by 1Ll
        long long fm = sum(m); // store sum of m in long integer fm
        if (fm == y) { // if fm is equal to y
          possible = true; // possible is equal to true
          break; // stop
        } 
        if (fm < y) // if fm is less than y
          l = m + 1; // l is equal to m + 1
        else // else do the following
          r = m; // r is equal to m
      } 
      if (possible) break; // if possible is 1, stop
      if ((sum(x) << 1LL) == n) { // if sum(x) << 1LL == n
        possible = true; // set possible to true
        break; // stop
      } 
      ++x; // increment x by 1
    } 
    if (possible) // if possible is 1
      cout << "YES\n"; // print YES and new line
    else // else
      cout << "NO\n"; // print NO and new line
  } 
  return 0; 
} 