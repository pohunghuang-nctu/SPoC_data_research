
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // n = integer
  cin >> n; // read n
  bool ans = false; // ans = bool with ans = false
  int sqr = ceil(sqrt(2 * n)); // sqr = integer with sqr = ceil(sqrt(2 * n))
  for (int i = 1; i <= sqr; i++) { // for i = 1 to sqr
    for (int j = i; j <= sqr; j++) { // for j = i to sqr
      if (i * (i + 1) + j * (j + 1) == 2 * n) { // if i * (i + 1) + j * (j + 1) is 2 * n
        ans = true; // ans = true
        break; // break loop
      } 
    } 
    if (ans) break; // if (ans) break loop
  } 
  cout << (ans ? "YES" : "NO") << endl; // if ans print YES, else NO
  return 0; 
} 