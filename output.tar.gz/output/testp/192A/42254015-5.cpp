
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int binaria(int x, int &n) { // in the function binaria that takes integer x, reference n and returns integer
  int l = 1, r = sqrt(n) + 1; // l, r = integers with l = 1, r = sqrt(n) + 1
  while (l <= r) { // while l <= r
    int mid = (l + r) / 2; // mid = integer with mid = (l + r) / 2
    if (mid * (mid + 1) == x) // if mid * (mid + 1) is x
      return 1; // return 1
    else if (mid * (mid + 1) < x) // else if mid * (mid + 1) < x
      l = mid + 1; // l = mid + 1
    else // else
      r = mid - 1; // r = mid - 1
  } 
  return 0; 
} 
int main() { 
  int n; // n = integer
  cin >> n; // read n
  bool flag = false; // flag = bool with flag = false
  for (int i = 1; i <= sqrt(n * 2); i++) // for i = 1 to sqrt(n * 2)
    if (binaria(2 * n - i * (i + 1), n)) { // if binaria(2 * n - i * (i + 1), n)
      flag = true; // flag = true
      break; // break loop
    } 
  if (!flag) // if not flag
    cout << "NO" << endl; // print NO
  else // else
    cout << "YES" << endl; // print YES
} 