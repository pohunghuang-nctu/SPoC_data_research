
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, N, i; // n,N,i=long long
  n = 1; // n=1
  vector<long long> vec; // vec=vector of long long
  for (; n < 1e5; n++) vec.push_back(n * (n + 1) / 2); // while n<10000 put n*(n+1)/2 at end of vec, increment n
  cin >> N; // read N
  if (N == 1) { // if N is 1
    cout << "NO" << endl; // print "NO"
    return 0; 
  } 
  for (i = 0; i < 1e5 - 1; i++) { // for i=0 to 99999 exclusive
    if (binary_search(vec.begin(), vec.end(), N - vec[i])) { // if binary_search(start of vec, end of vec, N-vec[i])
      cout << "YES" << endl; // print "YES"
      return 0; 
    } 
  } 
  cout << "NO" << endl; // print "NO"
  return 0; 
} 