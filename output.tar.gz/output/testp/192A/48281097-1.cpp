
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long tri(long long k) { // declare tri with long long k as argument, returning long long
  return k * (k + 1) / 2; // return k * ( k + 1 ) / 2 from function
} 
int main() { 
  long long n; // declare long long n
  cin >> n; // read n
  bool flag = false; // declare boolean flag = false
  for (int i = 1; i <= sqrt(n * 2); i++) { // for i = 1 to square root of ( n * 2 ) inclusive
    long long k = n - tri(i); // declare long long k = n - result of run tri with i as argument
    long long l = i; // declare long long l = i
    long long r = sqrt(n * 2); // declare long long r = square root of ( n * 2 )
    while (l <= r) { // while l is less than or equal to r
      long long m = (l + r) >> 1; // declare long long m = ( l + r ) bitshift right 1
      if (tri(m) < k) { // if result of run tri(m) is less than k
        l = m + 1; // let l be m + 1
      } else if (tri(m) > k) { // else if result of run tri(m) is greater than k
        r = m - 1; // let r be m - 1
      } else { // else
        flag = true; // let flag be true
        break; // end loop
      } 
    } 
    if (flag) break; // if flag is true, end loop
  } 
  if (flag) // if flag is true
    cout << "YES" << endl; // print "YES" and newline
  else // else
    cout << "NO" << endl; // print "NO" and newline
} 