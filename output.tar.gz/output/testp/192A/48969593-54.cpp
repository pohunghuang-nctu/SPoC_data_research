
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // n is a new integer variable
  cin >> n; // read user input to n
  int sq = sqrt(n * 2); // declare integer variable sq = square root of (n * 2)
  for (int i = 1; i <= sq; i++) // in a for loop, change i from 1 to sq inclusive incrementing i
    for (int j = 1; j <= i; j++) // for j from 1 to i inclusive incrementing j
      if (i * i + i + j * j + j == n * 2) { // if i * i + i + j * j + j = n * 2
        cout << "YES" << endl; // print "YES"
        return 0; 
      } 
  cout << "NO" << endl; // print "NO" to the standard output
  return 0; 
} 