
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long n; // create new long long variable n
bool search(long long t1) { // search is a bool function with long long argument t1
  int l = 0, r = sqrt(8 * n + 1) / 2; // declare new integers l = 0 and r = (square root of (8 * n + 1)) / 2
  int m; // declare integer variable m
  int it = 0; // create new integer called it = 0
  while (it <= 100) { // while it <= 100
    m = (l + r) >> 1; // change m to (l + r)
    long long t2 = m * (m + 1) / 2; // declare long long variable t2 = m * (m + 1) / 2
    if (t2 == t1 && t1 != 0) // if t2 = t1 when t1 != 0
      return true; // return true
    else if (t2 > t1) // else if t2 is greater than t1
      r = m; // set r to m
    else // else
      l = m; // assign m to l
    it++; // increment it
  } 
  return false; // return false
} 
int main() { 
  long long t1 = 0; // create new long long called t1 = 0
  cin >> n; // read variable n from the input
  bool found = false; // create boolean variable with name found and value = false
  if (n != 1) { // if n != 1
    for (int i = 1; i <= n && (i * (i + 1) / 2) <= n; i++) { // start for loop from i = 1 to n inclusive, while (i * (i + 1) / 2) <= n
      t1 = n - (i * (i + 1) / 2); // assign n - (i * (i + 1) / 2) to t1
      found = search(t1); // change found to the result of search(t1)
      if (found) { // if found is true
        cout << "YES" << '\n'; // print "YES" and '\n' to the standard output
        break; // stop the loop
      } 
    } 
  } 
  if (!found) cout << "NO" << '\n'; // if found is false, print "NO" and '\n'
  return 0; 
} 