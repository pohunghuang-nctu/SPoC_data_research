
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

vector<int> a; // create vector of integers a
int main() { 
  long long n, z = 0; // declare new long long variables n and z with z = 0
  cin >> n; // read from the input to n
  for (long long i = 1; i <= n; i++) { // in a for loop, change i from 1 to n inclusive incrementing i
    if ((i * (i + 1)) / 2 <= n) // if (i * (i + 1)) / 2 <= n
      a.push_back(((i + 1) * i) / 2); // push ((i + 1) * i) / 2 into a
    else // else
      break; // stop the loop
  } 
  for (long long i = 0; i < a.size(); i++) // start for loop from i = 0 to length of a exclusive
    if (binary_search(a.begin(), a.end(), (n - a[i]))) { // if binary_search of n - a[i] in a returned true
      cout << "YES" << endl; // print "YES" to the standard output
      z++; // increment z by one
      break; // break
    } 
  if (z == 0) cout << "NO" << endl; // if z = 0, print "NO"
  return 0; 
} 