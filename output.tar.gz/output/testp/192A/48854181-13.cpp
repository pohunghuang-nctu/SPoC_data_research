
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int const N = 1e5 + 1; // create constant N = 1e5 + 1
long long arr[N]; // let long long int array of size N
int main() { 
  int n; // let int n
  cin >> n; // read n
  arr[0] = 0; // let arr[0] = 0
  for (int i = 1; i < N; i++) arr[i] = arr[i - 1] + i; // for i = 1 to N exclusive, set arr[i] to arr[i - 1] + i
  for (int i = 1; i < N; i++) // for i = 1 to N exclusive
    if (binary_search(arr + 1, arr + N, n - arr[i])) { // if binary_search(arr + 1, arr + N, n - arr[i]) is truthy
      cout << "YES" << endl; // print "YES"
      return 0; 
    } 
  cout << "NO" << endl; // print "NO"
  return 0; 
} 