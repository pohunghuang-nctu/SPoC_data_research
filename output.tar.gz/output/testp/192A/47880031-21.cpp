
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int const N = 1e5 + 1; // let N be a constant interger, set N to 1e5 + 1
long long arr[N]; // let arr be of array of length N of long long integers
int main() { 
  int n; // let n be an integer
  cin >> n; // read in n
  arr[0] = 0; // set arr[0] to 0
  for (int i = 1; i < N; i++) arr[i] = arr[i - 1] + i; // iterate for N - 1 times, set arr[i] to arr[i - 1] + i
  for (int i = 1; i < N; i++) // iterate for N - 1 times
    if (binary_search(arr + 1, arr + N, n - arr[i])) { // if n - arr[i] is in the array
      cout << "YES" << endl; // print YES
      return 0; 
    } 
  cout << "NO" << endl; // print NO
  return 0; 
} 