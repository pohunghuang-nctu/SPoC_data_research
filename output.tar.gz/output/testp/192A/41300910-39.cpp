
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, x, a, b, c; // let n, x, a, b, c = long longs
  cin >> n; // read n
  for (int i = 1;; i++) // for integer i=1 to infinity do the following
    if ((i * i + 1) / 2 > n) { // if (i * i + 1) / 2 is greater than n dothe following
      x = i; // set x = i
      break; // exit the loop
    } 
  for (int i = 1; i <= x; i++) { // for integer i=1 to x inclusive
    a = i * (i + 1) / 2; // set a = i * (i+1) / 2
    b = (n - a) * 2; // set b = (n - a) * 2
    c = sqrt(b); // set c= square root of b
    if (c * (c + 1) == b && (b / 2) + a == n && a && b) { // if c * (c+1) is b and (b / 2) +a is n and a and b do the following
      cout << "YES" << endl; // print YES
      return 0; 
    } 
  } 
  cout << "NO" << endl; // print NO
} 