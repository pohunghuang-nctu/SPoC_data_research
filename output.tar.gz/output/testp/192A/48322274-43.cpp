
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long const N = 1e5 + 1; // let N = 1e5 + 1 be a long long const
  long long n, arr[N]; // let n, arr be long long with arr an array of length N
  cin >> n; // read n
  arr[0] = 0; // set arr[0] to 0
  for (int i = 1; i < N; i++) arr[i] = arr[i - 1] + i; // for i = 1 to N exclusive then set arr[i] to arr[i-1]+i
  for (int i = 1; i < N; i++) // for i = 1 to N exclusive
    if (binary_search(arr + 1, arr + N, n - arr[i])) { // if the binary search of arr+1, arr+N, n-arr[i] isn't 0
      cout << "YES" << endl; // print YES and new line
      return 0; 
    } 
  cout << "NO" << endl; // print NO and new line
  return 0; 
} 