
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long int n; // n = long long int
long long int ini, med, fin, test; // ini, med, fin, test = long long int
int main() { 
  cin >> n; // read n
  ini = 1; // set ini to 1
  fin = (-1 + sqrt(1 + 8 * n)) / 2; // set fin to (-1 + sqrt of (1 + 8 * n)) / 2
  while (ini <= fin) { // loop while ini <= fin
    test = (((ini * (ini + 1)) / 2) + ((fin * (fin + 1)) / 2)); // set test to (((ini * (ini + 1)) / 2) + ((fin * (fin + 1)) / 2))
    if (test == n) break; // if test is n break
    if (test < n) // if test < n
      ini++; // increment ini
    else // else
      fin--; // decrement fin
  } 
  if (ini <= fin) // if ini <= fin
    cout << "YES\n"; // print "YES"
  else // else
    cout << "NO\n"; // print "NO"
  return 0; 
} 