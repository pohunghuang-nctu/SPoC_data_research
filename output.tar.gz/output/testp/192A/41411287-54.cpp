
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  vector<long long> v; // new vector of long longs v
  int p = 0; // declare integer p = 0
  long long i, n, x, num, numm; // declare long long variables i, n, x, num and numm
  cin >> n; // read input to n
  for (i = 1; i < 100000; i++) { // start for loop from i = 1 to 100000 exclusive incrementing i
    x = (i * (i + 1)) / 2; // change x to (i * (i + 1)) / 2
    v.push_back(x); // push x to the end of v
  } 
  for (i = 1; i < 100000; i++) { // for i from 1 to 100000 exclusive
    num = (i * (i + 1)) / 2; // set num to (i * (i + 1)) / 2
    numm = n - num; // assign n - num to numm
    if (binary_search(v.begin(), v.end(), numm)) { // if numm is found in v using binary_search
      p = p + 1; // assign the new value = p + 1 to p
      break; // break
    } 
  } 
  if (p == 1) // if p = 1
    cout << "YES" << endl; // print "YES"
  else // else
    cout << "NO" << endl; // print "NO"
  return 0; 
} 