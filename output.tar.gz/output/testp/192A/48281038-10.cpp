
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long tri(long long k) { // in function tri taking long long k and returning long long
  return k * (k + 1) / 2; // return k * (k + 1) / 2
} 
int main() { 
  long long n; // n = long long
  cin >> n; // read n
  bool flag = false; // flag = bool with flag = false
  for (int i = 1; i <= sqrt(n * 2); i++) { // for i = 1 to sqrt of 2 * n inclusive
    long long k = n - tri(i); // k = long long with k = n - tri of i
    long long l = i; // l = long long with l = i
    long long r = sqrt(n * 2); // r = long long with r = sqrt of n * 2
    while (l <= r) { // loop while l <= r
      long long m = (l + r) >> 1; // m = long long with m = (l + r) bitshift right by 1
      if (tri(m) < k) { // if tri of m < k
        l = m + 1; // set l to m + 1
      } else if (tri(m) > k) { // else if tri of m > k
        r = m - 1; // set r to m - 1
      } else { // else
        flag = true; // set flag to true
        break; // break
      } 
    } 
    if (flag) break; // if flag break
  } 
  if (flag) // if flag
    cout << "YES" << endl; // print "YES"
  else // else
    cout << "NO" << endl; // print "NO"
} 