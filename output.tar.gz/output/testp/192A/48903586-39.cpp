
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // let n = integer
  cin >> n; // read n
  n *= 2; // set n = n * 2
  bool ans = false; // let ans = boolean with value false
  int sqr = ceil(sqrt(n)); // let sqr = integer with value = square root of n rounded up
  for (int i = 1; i <= sqr; i++) { // for integer i=1 to sqr inclusive do the following
    int l = 1, r = sqr, j; // let l, r, j = integers with l=1 and r = sqr
    while (l <= r) { // wile l is less than or equal to r do the following
      j = l + (r - l) / 2; // set j = l + (r - 1) / 2
      int t = i * (i + 1) + j * (j + 1); // let integer t = i * (i + 1) + j * (j + 1)
      if (t == n) { // if t is n do the following
        ans = true; // set ans = true
        break; // exit the loop
      } else if (t < n) // else if t is less than n
        l = j + 1; // set l = j + 1
      else // else
        r = j - 1; // set r = j - 1
    } 
    if (ans) break; // if ans is true exit the loop
  } 
  cout << (ans ? "YES" : "NO") << endl; // if ans is true print YES else print NO
  return 0; 
} 