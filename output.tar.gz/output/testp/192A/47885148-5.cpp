
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long l[100009]; // l = long long array of size 100009
int main() { 
  for (long long i = 1; i < 100005; i++) { l[i] = i * (i + 1) / 2; } // for i = 1 to 100004, l[i] = i * (i + 1) / 2
  int n; // n = integer
  cin >> n; // read n
  long long k = 1, r = 100000; // k, r = long long with k = 1, r = 100000
  while (k <= r) { // while k <= r
    if (l[k] + l[r] == n) { // if l[k] + l[r] is n
      cout << "YES" << endl; // print YES
      return 0; 
    } else if (l[k] + l[r] < n) { // else if l[k] + l[r] < n
      k++; // increment k
    } else { // else
      r--; // decrement r
    } 
  } 
  cout << "NO" << endl; // print NO
  return 0; 
} 