
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int maxn = 1e6; // declare constant integer variable maxn = 1e6
int n, t, f; // create new integers n, t and f
int main() { 
  bool b = true; // create boolean variable with name b with value true
  cin >> n; // read n
  for (int i = int(0); i < int(n); i++) { // in a loop from i = 0 to n exclusive
    int x; // declare new integer called x
    cin >> x; // read x
    if (x == 25) // if x is equal to 25
      t++; // increment t
    else if (x == 50) { // else if x is equal to 50
      if (t >= 1) // if t >= 1
        t--, f++; // decrement t by one and increment f
      else // else
        b = false; // change the value of b to false
    } else if (x == 100) { // else if x is equal to 100
      if (f >= 1 && t >= 1) // if f >= 1 and t >= 1
        f--, t--; // decrement f and decrement t
      else if (f <= 0 && t >= 3) // else if f <= 0 and t >= 3
        t -= 3; // change t to t - 3
      else // else
        b = false; // change the value of b to false
    } 
  } 
  b ? cout << "YES" << '\n' : cout << "NO" << '\n'; // print "YES" and "\n
  return 0; 
} 