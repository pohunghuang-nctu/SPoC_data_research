
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

map<int, int> hit; // create map hit from int to int
int main() { 
  int n, a[100005], temp, flag = 0; // create integers n, a[100005], temp, flag, set flag to 0
  cin >> n; // read n
  for (int i = 0; i < n; i++) { // for i=0 to n exclusive
    cin >> temp; // read temp
    hit[temp]++; // increment hit[temp]
    if (temp == 50) { // if temp = 50
      if (hit[25] >= 1) { // if hit[25] >=1
        hit[25]--; // decrement hit[25]
        continue; // continue
      } 
      flag = 1; // flag=1
    } else if (temp == 100) { // else if temp equal to 100
      if (hit[50] >= 1 && hit[25] >= 1) { // if hit[50] >= 1 and hit[25] >= 1
        hit[50]--; // decrement hit[50]
        hit[25]--; // decrement hit[25]
        continue; // continue
      } else if (hit[25] >= 3) { // else if hit[25] >= 3
        hit[25] -= 3; // set hit[25] to hit[25] - 3
        continue; // continue
      } 
      flag = 1; // flag=1
    } 
  } 
  if (flag == 0) // if flag=0
    cout << "YES" << endl; // print YES
  else // else
    cout << "NO" << endl; // print NO
  return 0; 
} 