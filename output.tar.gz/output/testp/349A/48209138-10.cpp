
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, p; // n, p = int
  vector<int> v; // v = int vector
  stack<int> s25, s50; // s25, s50 = int stack
  cin >> n; // read n
  for (int i = 0; i < n; i++) { // for i = 0 to n
    cin >> p; // read p
    v.push_back(p); // append p to v
  } 
  if (v[0] != 25) { // if v[0] is not 25
    cout << "NO" << endl; // print "NO"
    return 0; 
  } 
  for (int i = 0; i < n; i++) { // for i = 0 to n
    if (v[i] == 25) { // if v[i] is 25
      s25.push(v[i]); // append v[i] to s25
      continue; // continue
    } 
    if (v[i] == 50) { // if v[i] is 50
      if (s25.empty()) { // if s25 is empty
        cout << "NO" << endl; // print "NO"
        return 0; 
      } 
      s50.push(v[i]); // append v[i] to s50
      s25.pop(); // pop s25
    } 
    if (v[i] == 100) { // if v[i] is 100
      if (s25.size() == 0) { // if size of s25 is 0
        cout << "NO" << endl; // print "NO"
        return 0; 
      } 
      if ((s25.size() < 3 && s50.size() == 0)) { // if size of s25 < 3 and size of s50 is 0
        cout << "NO" << endl; // print "NO"
        return 0; 
      } 
      if (s50.empty()) { // if s50 is empty
        s25.pop(); // pop s25
        s25.pop(); // pop s25
        s25.pop(); // pop s25
      } else { // else
        s25.pop(); // pop s25
        s50.pop(); // pop s50
      } 
    } 
  } 
  cout << "YES" << endl; // print "YES"
  return 0; 
} 