
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int a = 0, b = 0, c = 0; // a,b,c=0
  int n, x; // n,c=int
  cin >> n; // read n
  while (n--) { // while decremented value of n is not 0
    cin >> x; // read x
    if (x == 25) { // if x is 25
      a++; // increment a
    } else if (x == 50 && a != 0) { // else if x is 50 and a is not 0
      a--; // decrement a
      b++; // increment b
    } else if (x == 50 && a == 0) { // else if x is 50 and a is 0
      cout << "NO" << endl; // print NO
      return 0; 
    } else if (x == 100 && a != 0 && b != 0) { // else if x is 100 and a is not 0 and b is not 0
      a--; // decrement a
      b--; // decrement b
      c++; // increment c
    } else if (x == 100 && a >= 3 && b == 0) { // else if x is 100 and a>=3 and b is 0
      a -= 3; // subtract 3 from a
      c++; // increment c
    } else { // else
      cout << "NO" << endl; // print NO
      return 0; 
    } 
  } 
  cout << "YES" << endl; // print YES
  return 0; 
} 