
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int cnt[3] = {0}; // 3rd element of integer array cnt is equal to 0
  int n; // let n be a integer
  cin >> n; // read n
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    int x; // let x be a integer
    cin >> x; // read x
    if (x == 25) cnt[0]++; // if x is equal to 25, increment cnt[0] by 1
    if (x == 50) { // if x is equal to 50
      if (cnt[0] >= 1) { // if cnt[0] >= 1
        cnt[0]--; // decrement cnt[0] by 1
        cnt[1]++; // increment cnt[1] by 1
      } else { // else do the following
        cout << "NO\n"; // print NO and newline
        return 0; 
      } 
    } 
    if (x == 100) { // if x is equal to 100
      if (cnt[1] >= 1 && cnt[0] >= 1) { // if cnt[1] >= 1 and cnt[0] >= 1
        cnt[0]--; // decrement cnt[0] by 1
        cnt[1]--; // decrement cnt[1] by 1
        cnt[2]++; // increment cnt[2] by 1
      } else if (cnt[0] >= 3) { // else if cnt[0] >= 3
        cnt[0] -= 3; // decrement cnt[0] by 3
        cnt[2]++; // increment cnt[2] by 1
      } else { // else do the following
        cout << "NO\n"; // print NO and newline
        return 0; 
      } 
    } 
  } 
  cout << "YES\n"; // print YES and newline
  return 0; 
} 