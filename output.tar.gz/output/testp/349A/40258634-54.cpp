
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int i, j = 0, n, k = 0, p, t = 0, b[51], coun = 0, temp = 0; // let i, j, n, k, p, t, coun and temp be integers where j, k, t, coun and temp = 0, and b is an integer array b with 51 element
  cin >> n; // read variable n from the input
  for (i = 0; i < n; i++) { // in a for loop, change i from 0 to n exclusive incrementing i
    cin >> p; // read variable p from the input
    if (p == 25) j++; // if p is equal to 25, increment j by one
    if (p == 50) { // if p = 50
      j--; // decrement j
      k++; // increment k by one
      if (j < 0) temp = 1; // if j is less than 0, change temp to 1
    } else if (p == 100) { // else if p is equal to 100
      if (k != 0 & j != 0) { // if k != 0 & j != 0
        k--; // decrement k by one
        j--; // substract 1 from j
      } else { // else
        j -= 3; // decrease j by 3
      } 
      if (j < 0) temp = 1; // if j is less than 0, assign 1 to temp
    } 
  } 
  if (temp == 0) // if temp = 0
    cout << "YES" << endl; // print "YES"
  else // else
    cout << "NO" << endl; // print "NO"
} 