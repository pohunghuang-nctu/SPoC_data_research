
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int i, k, x, a, b, c, n; // i, k, x, a, b, c, n = integers
int main() { 
  cin >> n; // Read n
  for (i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> x; // Read x
    if (x == 25) { // if x is 25
      a++; // increment a
    } else if (x == 50) { // else if x is 50
      b++; // increment b
      if (a > 0) { // if a is greater than 0
        a--; // decrement a
      } else { // else do the following
        cout << "NO" << endl; // print NO and a new line
        break; // Terminate the loop
      } 
    } else if (x == 100) { // else if x is 100
      if (b > 0 && a > 0) { // if b is greater than 0 and a is greater than 0
        b--; // decrement b
        a--; // decrement a
      } else if (a > 2) { // else if a is greater than 2
        a -= 3; // set a to a - 3
      } else { // else do the following
        cout << "NO" << endl; // print NO and a new line
        break; // Terminate the loop
      } 
    } 
  } 
  if (i == n) { cout << "YES" << endl; } // if i is n, then print YES and a new line
} 