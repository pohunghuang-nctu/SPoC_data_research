
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n; // create long long integer n
  cin >> n; // read n
  long long ans = 0; // make long long integers ans = 0
  long long b = 0; // make long long int b = 0
  long long a[n]; // let long long array a of size n
  long long sum = 0; // let long long sum = 0
  for (int i = 0; i < n; i++) { cin >> a[i]; } // for i = 0 to n exclusive, read a[i]
  if (a[0] == 50 || a[0] == 100) { return cout << "NO" << endl, 0; } // if a[0] is equal to 50 or a[0] is equal to 100, print "NO" and return 0
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    if (a[i] == 25) { // if a[i] is equal to 25
      ans++; // increment ans
    } else { // else do
      if (a[i] == 50) { // if a[i] is equal to 50
        if (ans >= 1) { // if ans is greater than or equal to 1
          ans--; // subtract 1 from ans
          sum++; // add 1 to sum
        } else { // else do
          return cout << "NO" << endl, 0; // print "NO" and return 0
        } 
      } else { // otherwise
        if (ans >= 1 && sum >= 1) { // if ans is greater than or equal to 1 and sum is greater than or equal to 1
          ans--; // subtract 1 from ans
          sum--; // subtract 1 from sum
        } else if (ans >= 3) { // else if ans is greater than or equal to 3
          ans -= 3; // set ans to ans - 3
        } else { // else do
          return cout << "NO" << endl, 0; // print "NO" and return 0
        } 
      } 
    } 
  } 
  return cout << "YES" << endl, 0; // display "YES" and return 0
} 