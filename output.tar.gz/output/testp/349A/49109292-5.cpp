
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // n = integer
  cin >> n; // read n
  vector<int> v(n); // v = vector of integer with v = n
  for (int i = 0; i < n; i++) cin >> v[i]; // for i = 0 to n exclusive, read v[i]
  int a = 0, b = 0; // a, b = integers with a = 0, b = 0
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    if (v[i] == 25) // if (v[i] is 25)
      a++; // increment a
    else if (v[i] == 50 && a >= 1) // else if (v[i] is 50 and a >= 1)
      a--, b++; // decrement a, increment b
    else if (v[i] == 100 && b >= 1 && a >= 1) // else if (v[i] is 100 and b >= 1 and a >= 1)
      b--, a--; // decrement b, a
    else if (v[i] == 100 && a >= 3) // else if (v[i] is 100 and a >= 3)
      a -= 3; // a = a - 3
    else { // else
      cout << "NO\n"; // print NO
      return 0; 
    } 
  } 
  cout << "YES\n"; // print YES
  return 0; 
} 