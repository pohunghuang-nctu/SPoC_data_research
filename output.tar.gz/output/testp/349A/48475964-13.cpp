
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, a = 0, b = 0, c; // create ints n, a = 0, b = 0, and c
  cin >> n; // read n
  while (n--) { // while n-- is truthy
    cin >> c; // read c
    if (c == 25) // if c is equal to 25
      a++; // increment a
    else if (c == 50) { // else if c is equal to 50
      b++; // add 1 to b
      if (!a) { // if a is falsy
        puts("NO"); // print "NO"
        return 0; 
      } 
      a--; // decrease a by 1
    } else { // else do
      if (a && b) // if a and b are truthy
        a--, b--; // decrease a and b by 1
      else if (a >= 3) // else if a is greater than or equal to 3
        a -= 3; // set a to a - 3
      else { // else
        puts("NO"); // print "NO"
        return 0; 
      } 
    } 
  } 
  puts("YES"); // print "YES"
} 