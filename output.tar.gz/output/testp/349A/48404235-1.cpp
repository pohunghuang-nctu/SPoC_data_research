
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, i; // declare integers n, i
  int arr[100005]; // declare integer array arr size 100005
  cin >> n; // read n
  for (i = 0; i < n; i++) { cin >> arr[i]; } // for i = 0 to n exclusive, read arr[i]
  int counter = 0, flag = 0, found = 0; // declare integers counter = 0, flag = 0, found = 0
  for (i = 0; i < n; i++) { // for i = 0 to n exclusive
    if (arr[i] == 25) { counter++; } // if arr[i] is 25, increment counter
    if (arr[i] == 50) { // if arr[i] is 50
      if (counter < 1) { // if counter is less than 1
        flag++; // increment flag
        break; // end loop
      } else { // else
        found++; // increment found
        counter--; // decrement counter
      } 
    } 
    if (arr[i] == 100) { // if arr[i] is 100
      if (counter < 0 || (found < 1 && counter < 1)) { // if counter is less than 0 or ( found is less than 1 and counter is less than 1 )
        flag++; // increment flag
        break; // end loop
      } else { // else
        if (found > 0 && counter > 0) { // if found is greater than 0 and counter is greater than 0
          found--; // decrement found
          counter--; // decrement counter
        } else { // else
          if (counter < 3) { // if counter is less than 3
            flag++; // increment flag
            break; // end loop
          } 
          counter -= 3; // decrement counter by 3
        } 
      } 
    } 
  } 
  if (flag == 0) { // if flag is 0
    cout << "YES" << endl; // print "YES" and newline
  } else { // else
    cout << "NO" << endl; // print "NO" and newline
  } 
} 