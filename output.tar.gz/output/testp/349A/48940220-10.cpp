
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int i, n, m, cash = 0, count = 0, need, flag = 1, c50, c25; // i, n, m, cash, count, need, flag, c50, c25 = int with cash = 0 and count = 0 and flag = 1
  cin >> n; // read n
  map<int, int> mp; // mp = int, int map
  while (n--) { // loop n times
    cin >> m; // read m
    if (m != 25 && flag) { // if m is not 25 and flag
      need = m - 25; // set need to m - 25
      c25 = need / 25; // set c25 to need / 25
      c50 = need / 50; // set c50 to need / 50
      if (c50) { // if c50
        if (mp[50]) // if mp[50]
          mp[50]--; // decrement mp[50]
        else if (mp[25] > 1) // else if mp[25] > 1
          mp[25] -= 2; // decrement mp[25] by 2
        else { // else
          flag = 0; // set flag to 0
          continue; // continue
        } 
        need -= 50; // decrement need by 50
        c25 -= 2; // decrement c25 by 2
      } 
      if (c25) { // if c25
        if (mp[25]) // if mp[25]
          mp[25]--; // decrement mp[25]
        else { // else
          flag = 0; // set flag to 0
          continue; // continue
        } 
      } 
    } 
    mp[m]++; // increment mp[m]
  } 
  if (flag) // if flag
    cout << "YES" << endl; // print "YES"
  else // else
    cout << "NO" << endl; // print "NO"
  return 0; 
} 