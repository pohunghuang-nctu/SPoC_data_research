
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int a = 0, b = 0, c = 0; // create ints a, b and c = 0
  int n, x; // declare integers n and x
  cin >> n; // read input to n
  while (n--) { // while n != 0, decrement it and continue the loop
    cin >> x; // read x from the input
    if (x == 25) { // if x = 25
      a++; // increment a
    } else if (x == 50 && a != 0) { // else if x = 50 and a != 0
      a--; // decrement a
      b++; // increment b by one
    } else if (x == 50 && a == 0) { // else if x is equal to 50 and a = 0
      cout << "NO" << endl; // print "NO" to the standard output
      return 0; 
    } else if (x == 100 && a != 0 && b != 0) { // else if x = 100 and a != 0 and b != 0
      a--; // decrement a
      b--; // decrement b
      c++; // increment c
    } else if (x == 100 && a >= 3 && b == 0) { // else if x = 100 and a >= 3 and b = 0
      a -= 3; // change a to a - 3
      c++; // increment c by one
    } else { // else
      cout << "NO" << endl; // print "NO" to the standard output
      return 0; 
    } 
  } 
  cout << "YES" << endl; // print "YES" to the output
  return 0; 
} 