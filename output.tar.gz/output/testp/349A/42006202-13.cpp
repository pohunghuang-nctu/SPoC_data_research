
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, x, r25 = 0, r50 = 0; // create ints n, x, r25 = 0, and r50 = 0
  cin >> n; // read n
  for (int i = 0; i < n; ++i) { // for i = 0 to n exclusive
    cin >> x; // read x
    if (x == 25) r25++; // if x is equal to 25, increment r25
    if (x == 50) { // if x is 50
      if (r25 == 0) { // if r25 is equal to 0
        cout << "NO\n"; // print "NO\n"
        return 0; 
      } 
      r25--; // reduce r25 by 1
      r50++; // increase r50 by 1
    } 
    if (x == 100) { // if x is equal to 100
      if (r50 == 0 ? r25 < 3 : r25 < 1) { // if r50 == 0 ? r25 < 3 : r25 < 1
        cout << "NO\n"; // print "NO\n"
        return 0; 
      } 
      if (r50 > 0) { // if r50 is greater than 0
        r50--; // reduce r50 by 1
        r25--; // reduce r25 by 1
      } else { // else do
        r25 -= 3; // subtract 3 from r25
      } 
    } 
  } 
  cout << "YES\n"; // print "YES\n"
  return 0; 
} 