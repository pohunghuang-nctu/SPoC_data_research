
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // create int n
  cin >> n; // read n
  int a[n]; // create int a[n]
  int count25 = 0, count50 = 0, count100 = 0; // set count25, count50 and count100 to 0
  for (int i = 0; i < n; i++) cin >> a[i]; // for i=0 to n exclusive, read a[i]
  int i; // create int i
  for (i = 0; i < n; i++) { // for i=0 to n exclusive
    if (i == 0 && a[i] == 50) { // if i=0 and a[i]=50
      cout << "NO" << endl; // print No
      break; // break
    } else if (a[i] == 25) // else if a[i]=25
      count25++; // increment count25
    else if (a[i] == 50) { // else if a[i]=50
      if (count25 == 0) { // if count25=0
        cout << "NO" << endl; // print NO and a newline
        break; // break
      } else { // else
        count25--; // decrement count25
        count50++; // increment count50
      } 
    } else if (a[i] == 100) { // else if a[i]=100
      if (count50 > 0 && count25 > 0) { // if count50 >0 and count25>0
        count50--; // decrement count50
        count25--; // decrement count25
      } else if (count25 >= 3) { // else if count25 >= 3
        count25 -= 3; // set count25 to count25 -3
      } else { // else
        cout << "NO" << endl; // print NO
        break; // break
      } 
    } 
  } 
  if (i == n) cout << "YES" << endl; // if i=n, print YES
  return 0; 
} 