
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, d, x[100005], m = 0; // create long long ints n, d, and m = 0 and int array x of size 100005
  cin >> n >> d; // read n and d
  for (int i = 1; i <= n; i++) cin >> x[i]; // for i = 1 to n, read x[i]
  for (int i = 1; i <= n - 2; i++) { // for i = 1 to n - 2
    long long l = i, r = n + 1; // make long long ints l = i and r = n + 1
    while (r - l > 1) { // while r - 1 is greater than 1
      long long mid = (l + r) / 2; // make long long mid = (l + r) / 2
      if (x[mid] - x[i] > d) // if x[mid] - x[i] is greater than d
        r = mid; // set r to mid
      else // else do
        l = mid; // set l to mid
    } 
    m += max(0 * 1ll, (l - i - 1)) * (l - i) / 2; // add max(0 * 1ll, (l - i - 1)) * (l - i) / 2 to m
  } 
  cout << m << endl; // display m
  return 0; 
} 