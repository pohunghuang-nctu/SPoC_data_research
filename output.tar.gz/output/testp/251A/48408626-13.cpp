
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

void solve() { // declare solve
  int n, d; // make ints n and d
  cin >> n >> d; // read n and d
  int a[n]; // create int array a of size n
  for (int i = 0; i < n; i++) { cin >> a[i]; } // for i = 0 to n exclusive, read a[i]
  if (n == 1 or n == 2) { // if n is equal to 1 or n is equal to 2
    cout << 0 << endl; // print 0
    return; // return
  } 
  long long cnt = 0; // make long long integer cnt = 0
  int r = 0; // create int r = 0
  bool b = true; // let bool b = true
  for (int i = 0; i < n - 2; i++) { // for i = 0 to n - 2 exclusive
    long long k = r - i - 2; // make long long int k = r - i - 2
    if (k < 0) k = 0; // if k is less than 0, set k to 0
    cnt += (k * (k + 1) / 2); // set cnt to cnt + (k * (k + 1) / 2)
    for (int j = r; j < n; j++) { // for j = r to n exclusive
      if (a[j] <= a[i] + d) { // if a[j] is less than or equal to a[i] + d
        cnt += (max(0, j - i - 1)); // add max(0, j - i - 1) to cnt
      } else { // else do
        r = j; // set r to j
        b = false; // set b to false
        break; // break loop
      } 
    } 
    if (b) // if b is truthy
      r = n - 1; // set r to n - 1
    else // else do
      b = true; // set b to true
  } 
  cout << cnt << endl; // display cnt
} 
int main() { 
  solve(); // call solve()
  return 0; 
} 