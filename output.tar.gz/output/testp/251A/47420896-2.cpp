
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, d; // let n, d be integers
  cin >> n >> d; // read n, d
  vector<int> v(n, 0); // create a vector v of integers with values n, 0
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    int point; // let point be a integer
    cin >> point; // read point
    v[i] = point; // v[i] is equal to point
  } 
  long long result = 0; // let result be a long integer with result = 0
  for (int right = 0, left = 0; right < n; right++) { // for integer right is equal to 0, left is equal to 0, right is less than n, increment right by 1
    while (v[right] - v[left] > d) { left++; } // while v[right] - v[left] is greater than d , increment left by 1
    result += (long long)(right - left) * (right - left - 1) / 2; // result is equal to result + (long long)(right - left) * (right - left - 1) / 2
  } 
  cout << result << endl; // print result and newline
  return 0; 
} 