
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

void init_ios() {} // empty void function init_ios
const long long N = (long long)1e5 + 10; // declare new long long constant N = 1e5 + 10
long long n, d, res, a[N]; // declare new long long variables n, d and res, and an array of long longs a with N elements
int main() { 
  init_ios(); // call init_ios()
  cin >> n >> d; // read n and d from the input
  for (long long i = 1; i <= n; ++i) cin >> a[i]; // read input into a from the index i to n inclusive
  long long j = 3; // create long long variable j = 3
  for (long long i = 1; i + 2 <= n; ++i) { // for i = 1 while i + 2 <= n
    j = max(j, i + 2); // change the value of j to max of j and i + 2
    while (j <= n && a[j] - a[i] <= d) ++j; // while j <= n and a[j] - a[i] <= d
    --j; // decrement j
    res += ((j - i - 1) * (j - i)) / 2; // add ((j - i - 1) * (j - i)) / 2 to res
  } 
  cout << res << "\n"; // print res and "\n" to the standard output
} 