
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int maxn = 1e5 + 5; // let maxn be a constant integer with maxn = 1e5 + 5
const int mx = 1e6 + 5; // let mx be a constant integer with mx = 1e6 + 5
const int mod = 1e9 + 7; // let mod be a constant integer with mod = 1e9 + 7
long long n, d; // let n, d be long integers
long long a[maxn]; // a = array of long integers of length maxn
long long st[maxn]; // st = array of long integers of length maxn
int main() { 
  while (cin >> n >> d) { // while read n, d
    for (int i = 1; i <= n; i++) { cin >> a[i]; } // for i = 1 to n inclusive, read a[i]
    int top = 1; // let top be a integer with top = 1
    long long ans = 0; // let ans be a long integer with ans = 0
    int tail = 0; // let tail be a integer with tail = 0
    for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
      tail++; // increment tail by 1
      while (top <= tail && a[tail] - a[top] > d) top++; // while top <= tail and a[tail] - a[top] is greater than d , increment top by 1
      int res = tail - top; // let res be a integer with res = tail - top
      ans += (long long)res * (res - 1) / 2; // increment ans by (long long)res * (res - 1) / 2
    } 
    cout << ans << endl; // print ans and newline
  } 
} 