
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long x[1000 * 100 + 5]; // create long long array x of size 1000 * 100 + 5
long long n, d, ans = 0; // make long long ints n, d, and ans = 0
long long f(int k) { // declare f taking in int k and returning long long
  long long l = k, r = n; // make long long ints l = k and r = n
  while (r - l > 1) { // while r - 1 > 1 is truthy
    long long mid = (l + r) / 2; // create long long ints mid = (l + r) / 2
    if (x[mid] - x[k] <= d) // if x[mid] - x[k] is less than or equal to d
      l = mid; // set l to mid
    else // else do
      r = mid; // set r to mid
  } 
  return l; // return l
} 
int main() { 
  cin >> n >> d; // read n and d
  for (int i = 0; i < n; i++) cin >> x[i]; // for i = 0 to n exclusive, read x[i]
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    long long k = f(i) - i; // make long long int k = f(i) - i
    ans += k * (k - 1) / 2; // add k * (k - 1) / 2 to ans
  } 
  cout << ans << endl; // print ans
  return 0; 
} 