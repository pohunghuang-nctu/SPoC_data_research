
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long int choose(int n, int k) { // let choose be a function that accepts integers n , k and returns a long integer value
  long long int ans = 1; // let ans be a long integer with ans = 1
  if (n < k) return 0; // if n is less than k , return 0
  for (int i = n - k + 1; i <= n; i++) { ans *= i; } // for i = n - k + 1 to n inclusive , ans = ans * i
  if (k == 3) { // if k is equal to 3
    assert(ans % 6 == 0); // assert(ans modulo 6 is equal to 0)
    ans /= 6; // ans is equal to ans / 6
  } else { // else do the following
    assert(ans % 2 == 0); // assert(ans modulo 2 is equal to 0)
    ans /= 2; // ans is equal to ans / 2
  } 
  return ans; // return the value of ans
} 
int main() { 
  int n, d, tmp, l = 0; // let n, d, tmp, l be integers with l = 0
  long long int ans = 0; // let ans be a long integer with ans is equal to 0
  cin >> n >> d; // read n , d
  int points[n]; // points = array of integers of length n
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> tmp; // read tmp
    points[i] = tmp; // points[i] is equal to tmp
    while (abs(tmp - points[l]) > d) l++; // while absolute value of (tmp - points[l]) is greater than d , increment l by 1
    if (ans == 0) // if ans is equal to 0
      ans += choose(i + 1 - l, 3); // increment ans by choose(i + 1 - l, 3)
    else // else do the following
      ans += choose(i - l, 2); // increment ans by choose(i - l, 2)
  } 
  cout << ans << endl; // print ans and newline
  return 0; 
} 