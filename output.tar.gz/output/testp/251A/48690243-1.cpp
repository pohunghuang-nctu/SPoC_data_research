
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int dx[] = {1, 0, -1, 0}, dy[] = {0, 1, 0, -1}; // declare integer arrays dx = {1, 0, -1, 0}, dy = {0, 1, 0, -1}
int main() { 
  long long n, d; // declare long longs n, d
  cin >> n >> d; // read n and d
  long long a[n]; // declare long long array a size n
  for (int i = 0; i < n; i++) { cin >> a[i]; } // for i = 0 to n exclusive, read a[i]
  long long ans = 0; // declare long long ans = 0
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    int u = upper_bound(a, a + n, a[i] + d) - a; // declare integer u = (first element between a and a + n comparing greater than a[i]+d) - a
    u = u - i - 1; // let u be u - i - 1
    if (u >= 2) { ans = ans + ((long long)u * (u - 1)) / 2; } // if u is greater than or equal to 2, let ans be ans + (long long casted u * ( u - 1 ) ) / 2
  } 
  cout << ans << endl; // print ans and newline
  return 0; 
} 