
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

void solve() { // declare solve with no argument, returning void
  int n, d; // declare integers n, d
  cin >> n >> d; // read n, d
  int a[n]; // declare integer array a size n
  for (int i = 0; i < n; i++) { cin >> a[i]; } // for i = 0 to n exclusive, read a[i]
  if (n == 1 or n == 2) { // if n is 1 or n is 2
    cout << 0 << endl; // print 0 and newline
    return; // return from function
  } 
  long long cnt = 0; // declare long long cnt = 0
  int r = 0; // declare integer r = 0
  bool b = true; // declare boolean b = true
  for (int i = 0; i < n - 2; i++) { // for i = 0 to n - 2 exclusive
    long long k = r - i - 2; // declare long long k = r - i - 2
    if (k < 0) k = 0; // if k is less than 0, let k be 0
    cnt += (k * (k + 1) / 2); // increment cnt by (k * (k + 1) / 2)
    for (int j = r; j < n; j++) { // for j = r to n exclusive
      if (a[j] <= a[i] + d) { // if a[j] is less than or equal to a[i] + d
        cnt += (max(0, j - i - 1)); // increment cnt by maximum of ( 0 and j - i - 1 )
      } else { // else
        r = j; // let r be j
        b = false; // let b be false
        break; // end loop
      } 
    } 
    if (b) // if b is true
      r = n - 1; // let r be n - 1
    else // else
      b = true; // let b be true
  } 
  cout << cnt << endl; // print cnt and newline
} 
int main() { 
  solve(); // run solve
  return 0; 
} 