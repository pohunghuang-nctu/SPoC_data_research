
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, d; // n, d = integers
  cin >> n >> d; // read n and d
  int v[1000005]; // v = array of integers with length of 1000005
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    int point; // point = integer
    cin >> point; // read point
    v[i] = point; // set v[i] to point
  } 
  long long result = 0; // result = long long integer set to 0
  for (int right = 2, left = 0; right < n; right++) { // for right = 2, left = 0, right to n exclusive
    while (v[right] - v[left] > d) { left++; } // while v[right] - v[left] > d, increment left by 1
    result += (long long)(right - left) * (right - left - 1) / 2; // increment result by right - left * right - left - 1 / 2
  } 
  cout << result << endl; // print result
  return 0; 
} 