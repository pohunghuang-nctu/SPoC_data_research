
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

inline char nc() { // function nc (no args, return char)
  return getchar(); // return getchar()
} 
inline void read(int &x) { // function read (get address of int x, return nothing)
  char c = nc(); // c=nc()
  int b = 1; // b=1
  for (; !(c >= '0' && c <= '9'); c = nc()) // while not (c>='0' and <='9') c=nc()
    if (c == '-') b = -1; // if c is '-' b=-1
  for (x = 0; c >= '0' && c <= '9'; x = x * 10 + c - '0', c = nc()) // x=0, while c>='0' and c<='9' x=x*10+c-'0', c=nc()
    ; // do nothing
  x *= b; // multiply x by b
} 
inline void read(long long &x) { // function read (get address of long long x, return nothing)
  char c = nc(); // c=nc()
  long long b = 1; // b=1
  for (; !(c >= '0' && c <= '9'); c = nc()) // while not (c>='0' and <='9') c=nc()
    if (c == '-') b = -1; // if c is '-' b=-1
  for (x = 0; c >= '0' && c <= '9'; x = x * 10 + c - '0', c = nc()) // x=0, while c>='0' and c<='9' x=x*10+c-'0', c=nc()
    ; // do nothing
  x *= b; // multiply x by b
} 
inline int read(char *s) { // function read (get pointer to char s, return nothing)
  char c = nc(); // c=nc()
  int len = 1; // len=1
  for (; !(c >= 'a' && c <= 'z'); c = nc()) // while not (c>='a' and c<='z') c=nc()
    if (c == EOF) return 0; // if c is EOF return 0
  for (; (c >= 'a' && c <= 'z'); s[len++] = c, c = nc()) // while c>='a' and c<='z' s[len]=c, increment len, c=nc()
    ; // do nothing
  s[len++] = '\0'; // s[len] = null byte, increment len
  return len - 2; // return len-2
} 
inline void read(char &x) { // function read (get address of char x, return nothing)
  for (x = nc(); !(x >= 'a' && x <= 'z'); x = nc()) // x=nc(), while not (x>='a' and x<='z') x=nc()
    ; // do nothing
} 
int wt, ss[19]; // wt=int, ss=array of 19 int
inline void print(int x) { // function print (get int x, return nothing)
  if (x < 0) x = -x, putchar('-'); // if x<0 x=-x, print '-'
  if (!x) // if not x
    putchar(48); // print char with value 48
  else { // else
    for (wt = 0; x; ss[++wt] = x % 10, x /= 10) // wt=0, while x ss[wt]=x modulo 10, increment wt, divide x by 10
      ; // do nothing
    for (; wt; putchar(ss[wt] + 48), wt--) // while wt puchar(ss[wt]+48), decrement wt
      ; // do nothing
  } 
} 
inline void print(long long x) { // function print (get long long x, return nothing)
  if (x < 0) x = -x, putchar('-'); // if x<0 x=-x, print '-'
  if (!x) // if not x
    putchar(48); // print char with value 48
  else { // else
    for (wt = 0; x; ss[++wt] = x % 10, x /= 10) // wt=0, while x ss[wt]=x modulo 10, increment wt, divide x by 10
      ; // do nothing
    for (; wt; putchar(ss[wt] + 48), wt--) // while wt puchar(ss[wt]+48), decrement wt
      ; // do nothing
  } 
} 
int n, m, a[100010]; // n,m=int, a=array of 100010 int
int Find(int x) { // function Find (get int x, return int)
  int l = 1, r = n, res = 0, mid; // l=1,r=n,res=0,mid=int
  while (l <= r) { // while l<=r
    mid = l + r >> 1; // mid=l+r >> 1
    if (a[mid] <= x) // if a[mid] <= x
      res = mid, l = mid + 1; // res=mid, l=mid+1
    else // else
      r = mid - 1; // r=mid-1
  } 
  return res; // return res
} 
int main() { 
  read(n); // read(n)
  read(m); // read(m)
  for (int i = 1; i <= n; i++) read(a[i]); // for i=1 to n inclusive read a[i]
  long long ans = 0; // ans=0
  for (int i = 1; i <= n; i++) { // for i=1 to n inclusive
    int x = Find(a[i] + m); // x=Find(a[i]+m)
    if (x - i + 1 >= 3) { // if x-i+1 >= 3
      long long y = ((long long)x) - ((long long)i) - 1LL; // y=x-i-1
      ans += y * (y + 1LL) / 2LL; // add y*(y+1)/2 to ans
    } 
  } 
  print(ans), puts(""); // print ans
  return 0; 
} 