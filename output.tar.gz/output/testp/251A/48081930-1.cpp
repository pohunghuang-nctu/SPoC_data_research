
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const long long MAXN = 100 * 1000; // declare constant long long MAXN = 100 * 1000
long long arr[MAXN + 10], n, d; // declare long long array arr size MAXN + 10, long longs n, d
long long bs(long long x) { // declare bs with long long x as argument, returning long long
  long long l = x, r = n; // declare long longs l = x, r = n
  while (r - l > 1) { // while r - l is greater than 1
    long long mid = (l + r) / 2; // declare long long mid = ( l + r ) / 2
    if (arr[mid] - arr[x] <= d) // if arr[mid] - arr[x] is less than or equal to d
      l = mid; // let l be mid
    else // else
      r = mid; // let r be mid
  } 
  return l; // return l from function
} 
int main() { 
  cin >> n >> d; // read n and d
  for (long long i = 0; i < n; i++) cin >> arr[i]; // for i = 0 to n exclusive, read arr[i]
  long long ans = 0; // declare long long ans = 0
  for (long long i = 0; i < n; i++) { // for i = 0 to n exclusive
    long long k = bs(i) - i; // declare long long k = result of run bs(i) - i
    ans += k * (k - 1) / 2; // increment ans by k * ( k - 1 ) / 2
  } 
  cout << ans << endl; // print ans and newline
  return 0; 
} 