
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 1e5 + 5; // let N be const integer with N = 1e5 + 5
int n, d, x[N]; // let n, d be integers and x an array of integers of size N
long long ans; // let ans be long long
int main() { 
  cin >> n >> d; // read n and d
  for (int i = 0, p = 0; i < n; i++) { // for i = 0 to n exclusive and p = 0
    cin >> x[i]; // read x[i]
    while (x[i] - x[p] > d) p++; // while x[i] - x[p] is greater than d, increment p by 1
    ans += (i - p - 1LL) * (i - p) / 2; // update ans to ans + (i - p - 1LL) * (i - p) / 2
  } 
  cout << ans << endl; // print out ans with newline
  return 0; 
} 