
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

void solve() { // let solve be a void function
  long long n, i, j, d; // let n, i, j, d be long integers
  cin >> n >> d; // read n , d
  long long arr[n]; // arr = array of long integers of length n
  for (long long i = 0; i < n; ++i) { cin >> arr[i]; } // for long integer i = 0 to n exclusive, read arr[i]
  if (n < 3) { // if n is less than 3
    cout << 0 << '\n'; // print 0 and newline
    return; // return value
  } 
  long long l = 0, r = 2; // let l , r be long integers with l = 0, r = 2
  long long sum = 0; // let sum be a long integer with sum = 0
  while (l < n - 2 && r < n) { // while l is less than n - 2 and r is less than n
    if (arr[r] - arr[l] <= d) { // if arr[r] - arr[l] <= d
      sum += (r - l - 1) * (r - l) / 2; // increment sum by (r - l - 1) * (r - l) / 2
      r++; // increment r by 1
    } else { // else do the following
      l++; // increment l by 1
    } 
    if (r - l == 1) r++; // if r - l is equal to 1 ,increment r by 1
  } 
  cout << sum << '\n'; // print sum and newline
} 
int main() { 
  long long t = 1; // let t be a long integer with t = 1
  while (t--) { solve(); } // while t is decremented by 1 , call solve function
  return 0; 
} 