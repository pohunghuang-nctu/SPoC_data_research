
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, d; // create long long ints n and d
  cin >> n >> d; // read n and d
  vector<long long> v(n); // create long long vector v of size n
  for (int i = 0; i < n; i++) { cin >> v[i]; } // for i = 0 to n exclusive, read v[i]
  unsigned long long ans = 0; // create unsigned long long ans = 0
  long long j = 0; // let long long int j = 0
  for (long long i = 0; i < n; i++) { // for i = 0 to n exclusive
    while (j < n && v[j] - v[i] <= d) j++; // while j is less than n and v[j] - v[i] is less than or equal to d, increment j
    ans += (j - i - 1) * (j - i - 2) / 2; // set ans to ans + (j - i - 1) * (j - i - 2) / 2
  } 
  cout << ans << "\n"; // display ans
} 