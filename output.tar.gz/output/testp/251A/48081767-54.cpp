
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int MAXN = 1000 * 100 + 10; // declare new constant integer MAXN with value 1000 * 100 + 10
int arr[MAXN]; // arr is an array of integers with size MAXN
long long n, d; // create long longs n and d
int bs(int t, int i) { // integer function bs with int arguments t and i
  int l = i, r = n; // create new integer variable l = i and r = n
  while (r - l > 1) { // while r - l > 1
    int mid = (r + l) / 2; // create integer mid with value (r + l) / 2
    if (arr[mid] - t <= d) // if arr[mid] - t <= d
      l = mid; // change l to mid
    else // else
      r = mid; // change r to mid
  } 
  return l; // return l
} 
int main() { 
  long long ans = 0; // declare long long ans with value 0
  cin >> n >> d; // read input to n and d
  for (int i = 0; i < n; i++) cin >> arr[i]; // in a for loop, change i from 0 to n exclusive, reading input to arr[i]
  for (int i = 0; i < n; i++) { // for integer i = 0 to n exclusive
    int k = (bs(arr[i], i) - i); // k is a new integer with value = bs(arr[i], i) - i
    ans += (1LL * k * (k - 1)) / 2; // change ans to the sum of ans and (1LL * k * (k - 1)) / 2
  } 
  cout << ans << endl; // print ans to the standard output
  return 0; 
} 