
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long m1[100001]; // m1 = array of long integers of length 100001
long long ans; // let ans be a long integer
int main() { 
  long long n, d; // let n, d be long integers
  cin >> n; // read n
  cin >> d; // read d
  for (int i = 0; i < n; i++) { cin >> m1[i]; } // for i = 0 to n exclusive , read m1[i]
  long h = 0; // let h be a long integer with h = 0
  long long t; // let t be a long integer
  ans = 0; // ans is equal to 0
  for (long long i = 0; i < n; i++) { // for long integer i = 0 to n exclusive
    while (h < n && m1[h] - m1[i] <= d) h++; // while h is less than n and m1[h] - m1[i] <= d, increment h by 1
    long long t = h - i - 1; // let t be a long integer with t = h - i - 1
    if (t - 1 > 0) ans += t * (t - 1) / 2; // if t - 1 is greater than 0 , increment ans by t * (t - 1) / 2
  } 
  cout << ans << '\n'; // print ans and newline
} 