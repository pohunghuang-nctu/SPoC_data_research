
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bool check(int x1, int y1, int x2, int y2, int x3, int y3) { // in function check taking int x1, int y1, int x2, int y2, int x3, int y3 and returning bool
  int a, b, c; // a, b, c = int
  a = (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2); // set a to (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2)
  b = (x1 - x3) * (x1 - x3) + (y1 - y3) * (y1 - y3); // set b to (x1 - x3) * (x1 - x3) + (y1 - y3) * (y1 - y3)
  c = (x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2); // set c to (x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2)
  if (a == 0 || b == 0 || c == 0) return 0; // if a or b or c is 0 return 0
  if (a + b == c || a + c == b || b + c == a) // if a + b is c or a + c is b or b + c is a
    return 1; // return 1
  else // else
    return 0; 
} 
int main() { 
  int move[4][2] = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}}; // move= two dimensional array of sizes 4 and 2 with the values {0, 1}, {1, 0}, {0, -1}, {-1, 0}
  int x1[4], y1[4]; // x1, y1 = int array of size 4 each
  for (int i = 0; i < 3; i++) { cin >> x1[i] >> y1[i]; } // for i = 0 to 3 read x1[i] then y1[i]
  if (check(x1[0], y1[0], x1[1], y1[1], x1[2], y1[2])) { // if check of x1[0], y1[0], x1[1], y1[1], x1[2], y1[2]
    cout << "RIGHT" << endl; // print "RIGHT"
    return 0; 
  } 
  int tx, ty; // tx, ty = int
  for (int i = 0; i <= 3; i++) { // for i = 0 to 3 inclusive
    for (int j = 0; j <= 3; j++) { // for j = 0 to 3 inclusive
      tx = x1[i] + move[j][0]; // set tx to x1[i] + move[j][0]
      ty = y1[i] + move[j][1]; // set ty to y1[i] + move[j][1]
      if (i == 0 && check(tx, ty, x1[1], y1[1], x1[2], y1[2])) { // if i is 0 and check of tx, ty, x1[1], y1[1], x1[2], y1[2]
        cout << "ALMOST" << endl; // print "ALMOST"
        return 0; 
      } 
      if (i == 1 && check(x1[0], y1[0], tx, ty, x1[2], y1[2])) { // if i is 1 and check of x1[0], y1[0], tx, ty, x1[2], y1[2]
        cout << "ALMOST" << endl; // print "ALMOST"
        return 0; 
      } 
      if (i == 2 && check(x1[0], y1[0], x1[1], y1[1], tx, ty)) { // if i = 2 and check of x1[0], y1[0], x1[1], y1[1], tx, ty
        cout << "ALMOST" << endl; // print "ALMOST"
        return 0; 
      } 
    } 
    if (i == 3) cout << "NEITHER" << endl; // if i is 3 print "NEITHER"
  } 
  return 0; 
} 