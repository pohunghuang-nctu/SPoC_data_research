
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int l1, l2, l3; // create integers l1, l2, l3
int a[5], b[5], c[5], d[5], j, i; // create integer arrays a, b, c, d, with a size 5, b size 5, c size 5, d size 5, create integers j, i
int dix[] = {1, 0, -1, 0}; // create integer array dix with dix = {1, 0, -1, 0}
int diy[] = {0, 1, 0, -1}; // create integer array diy with diy = {0, 1, 0, -1}
int main() { 
  for (i = 1; i <= 3; i++) { cin >> a[i] >> b[i]; } // for i = 1 to 3 inclusive, read a[i] read b[i]
  l1 = abs(a[1] - a[2]) * abs(a[1] - a[2]) + abs(b[1] - b[2]) * abs(b[1] - b[2]); // set l1 to abs(a[1] - a[2]) * abs(a[1] - a[2]) + abs(b[1] - b[2]) * abs(b[1] - b[2])
  l2 = abs(a[2] - a[3]) * abs(a[2] - a[3]) + abs(b[2] - b[3]) * abs(b[2] - b[3]); // set l2 to abs(a[2] - a[3]) * abs(a[2] - a[3]) + abs(b[2] - b[3]) * abs(b[2] - b[3])
  l3 = abs(a[3] - a[1]) * abs(a[3] - a[1]) + abs(b[3] - b[1]) * abs(b[3] - b[1]); // set l3 to abs(a[3] - a[1]) * abs(a[3] - a[1]) + abs(b[3] - b[1]) * abs(b[3] - b[1])
  if (l1 + l2 == l3 || l1 + l3 == l2 || l2 + l3 == l1) { // if l1 + l2 is l3 or l1 + l3 is l2 or l2 + l3 is l1
    if (l1 != 0 && l2 != 0 && l3 != 0) { // if l1 is not 0 and l2 is not 0 and l3 is not 0
      cout << "RIGHT" << endl; // print "RIGHT" print newline
      return 0; 
    } 
  } 
  for (i = 1; i <= 3; i++) { // for i = 1 to 3 inclusive
    c[1] = a[1], c[2] = a[2], c[3] = a[3]; // set c[1] to a[1], set c[2] to a[2], set c[3] to a[3]
    d[1] = b[1], d[2] = b[2], d[3] = b[3]; // set d[1] to b[1], set d[2] to b[2], set d[3] to b[3]
    for (j = 0; j < 4; j++) { // for j = 0 to 4 exclusive
      c[i] = a[i] + dix[j]; // set c[i] to a[i] + dix[j]
      d[i] = b[i] + diy[j]; // set d[i] to b[i] + diy[j]
      l1 = abs(c[1] - c[2]) * abs(c[1] - c[2]) + abs(d[1] - d[2]) * abs(d[1] - d[2]); // set l1 to abs(c[1] - c[2]) * abs(c[1] - c[2]) + abs(d[1] - d[2]) * abs(d[1] - d[2])
      l2 = abs(c[2] - c[3]) * abs(c[2] - c[3]) + abs(d[2] - d[3]) * abs(d[2] - d[3]); // set l2 to abs(c[2] - c[3]) * abs(c[2] - c[3]) + abs(d[2] - d[3]) * abs(d[2] - d[3])
      l3 = abs(c[3] - c[1]) * abs(c[3] - c[1]) + abs(d[3] - d[1]) * abs(d[3] - d[1]); // set l3 to abs(c[3] - c[1]) * abs(c[3] - c[1]) + abs(d[3] - d[1]) * abs(d[3] - d[1])
      if (l1 + l2 == l3 || l1 + l3 == l2 || l2 + l3 == l1) { // if l1 + l2 is l3 or l1 + l3 is l2 or l2 + l3 is l1
        if (l1 != 0 && l2 != 0 && l3 != 0) { // if l1 is not 0 and l2 is not 0 and l3 is not 0
          cout << "ALMOST" << endl; // print "ALMOST" print newline
          return 0; 
        } 
      } 
    } 
  } 
  cout << "NEITHER" << endl; // print "NEITHER" print newline
} 