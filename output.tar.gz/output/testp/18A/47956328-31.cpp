
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int distance(int a, int b, int x, int y) { // function distance (get int a,b,x and y, return int)
  return ((a - x) * (a - x) + (b - y) * (b - y)); // return (a-x)^2+(b-y)^2
} 
bool check(vector<int> cod) { // function check (get vector of int cod, return bool)
  int d1, d2, d3; // d1,d2,d3=int
  unsigned int i = 0; // i=0
  for (i = 0; i < cod.size(); i += 1) { // for i=0 to size of cod exclusive
    cod[i] -= 1; // decrement cod[i]
    d1 = distance(cod[0], cod[1], cod[2], cod[3]); // d1=distance(cod[0], cod[1], cod[2], cod[3])
    d2 = distance(cod[0], cod[1], cod[4], cod[5]); // d2=distance(cod[0], cod[1], cod[4], cod[5])
    d3 = distance(cod[2], cod[3], cod[4], cod[5]); // d3=distance(cod[2], cod[3], cod[4], cod[5])
    cod[i] += 1; // increment cod[i]
    if (d1 == 0 or d2 == 0 or d3 == 0) continue; // if d1 is 0 or d2 is 0 or d3 is 0 continue
    if ((d1 == d2 + d3) or (d2 == d1 + d3) or (d3 == d2 + d1)) { return 1; } // if d1 is d2+d3 or d2 is d1+d3 or d3 is d2+d1 return 1
  } 
  for (i = 0; i < cod.size(); i += 1) { // for i=0 to size of cod exclusive
    cod[i] += 1; // increment cod[i]
    d1 = distance(cod[0], cod[1], cod[2], cod[3]); // d1=distance(cod[0], cod[1], cod[2], cod[3])
    d2 = distance(cod[0], cod[1], cod[4], cod[5]); // d2=distance(cod[0], cod[1], cod[4], cod[5])
    d3 = distance(cod[2], cod[3], cod[4], cod[5]); // d3=distance(cod[2], cod[3], cod[4], cod[5])
    cod[i] -= 1; // decrement cod[i]
    if (d1 == 0 or d2 == 0 or d3 == 0) continue; // if d1 is 0 or d2 is 0 or d3 is 0 continue
    if ((d1 == d2 + d3) or (d2 == d1 + d3) or (d3 == d2 + d1)) { return 1; } // if d1 is d2+d3 or d2 is d1+d3 or d3 is d2+d1 return 1
  } 
  return 0; 
} 
int main() { 
  vector<int> cod; // cod=vector of int
  unsigned int i; // i=unsigned int
  for (i = 0; i < 6; i += 1) { // for i=0 to 6 exclusive
    int temp; // temp=int
    cin >> temp; // read temp
    cod.push_back(temp); // add temp to end of cod
  } 
  int d1, d2, d3; // d1,d2,d3=int
  d1 = distance(cod[0], cod[1], cod[2], cod[3]); // d1=distance(cod[0], cod[1], cod[2], cod[3])
  d2 = distance(cod[0], cod[1], cod[4], cod[5]); // d2=distance(cod[0], cod[1], cod[4], cod[5])
  d3 = distance(cod[2], cod[3], cod[4], cod[5]); // d3=distance(cod[2], cod[3], cod[4], cod[5])
  if ((d1 == d2 + d3) or (d2 == d1 + d3) or (d3 == d2 + d1)) { // if d1 is d2+d3 or d2 is d1+d3 or d3 is d2+d1
    cout << "RIGHT" << endl; // print "RIGHT"
    return 0; 
  } else if (check(cod)) // else if check(cod)
    cout << "ALMOST" << endl; // print "ALMOST"
  else // else
    cout << "NEITHER" << endl; // print "NEITHER"
  return 0; 
} 