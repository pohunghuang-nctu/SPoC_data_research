
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bool check(int x1, int y1, int x2, int y2, int x3, int y3) { // bool function check wih integer arguments x1, y1, x2, y2, x3 and y3
  int a, b, c; // a, b and c = integers
  a = (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2); // set value of a to (x1 - x2) * (x1 - x2) + (y1 - y2) * (y1 - y2)
  b = (x1 - x3) * (x1 - x3) + (y1 - y3) * (y1 - y3); // b = (x1 - x3) * (x1 - x3) + (y1 - y3) * (y1 - y3)
  c = (x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2); // c = (x3 - x2) * (x3 - x2) + (y3 - y2) * (y3 - y2)
  if (a == 0 || b == 0 || c == 0) return 0; // if a == 0 or b == 0 or c is equal to 0 return 0
  if (a + b == c || a + c == b || b + c == a) // if a + b = c or a + c = b or b + c = a
    return 1; // return 1
  else // else
    return 0; 
} 
int main() { 
  int move[4][2] = {{0, 1}, {1, 0}, {0, -1}, {-1, 0}}; // move = 2d array of integers with values {{0, 1}, {1, 0}, {0, -1}, {-1, 0}}
  int x1[4], y1[4]; // x1 and y1 = arrays of integers of size 4
  for (int i = 0; i < 3; i++) { cin >> x1[i] >> y1[i]; } // read 3 values into x1 and y1
  if (check(x1[0], y1[0], x1[1], y1[1], x1[2], y1[2])) { // if check(x1[0], y1[0], x1[1], y1[1], x1[2], y1[2]) returns true
    cout << "RIGHT" << endl; // print "RIGHT" and a new line
    return 0; 
  } 
  int tx, ty; // let tx and ty be integers
  for (int i = 0; i <= 3; i++) { // for i = 0 to 3 inclusive
    for (int j = 0; j <= 3; j++) { // for integer j = 0 to 3 inclusive
      tx = x1[i] + move[j][0]; // set tx to x1[i] + move[j][0]
      ty = y1[i] + move[j][1]; // set ty to y1[i] + move[j][1]
      if (i == 0 && check(tx, ty, x1[1], y1[1], x1[2], y1[2])) { // if i is equal to 0 and check(tx, ty, x1[1], y1[1], x1[2], y1[2]) returns true
        cout << "ALMOST" << endl; // print "ALMOST" and a new line
        return 0; 
      } 
      if (i == 1 && check(x1[0], y1[0], tx, ty, x1[2], y1[2])) { // if i is equal to 1 && check(x1[0], y1[0], tx, ty, x1[2], y1[2]) is true
        cout << "ALMOST" << endl; // print "ALMOST" and a new line
        return 0; 
      } 
      if (i == 2 && check(x1[0], y1[0], x1[1], y1[1], tx, ty)) { // if i is equal to 2 && check(x1[0], y1[0], x1[1], y1[1], tx, ty) is true
        cout << "ALMOST" << endl; // print "ALMOST" and a new line
        return 0; 
      } 
    } 
    if (i == 3) cout << "NEITHER" << endl; // if i is equal to 3 print "NEITHER" and a new line
  } 
  return 0; 
} 