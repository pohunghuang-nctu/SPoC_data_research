
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int l1, l2, l3; // declare new integer variables l1, l2 and l3
int a[5], b[5], c[5], d[5], j, i; // declare new integer variables j and i, and an arrays of integers a, b, c and d with 5 elements
int dix[] = {1, 0, -1, 0}; // dx is a new array of int with 4 elements = 1, 0, -1, 0
int diy[] = {0, 1, 0, -1}; // let dy be a new array of integers with 4 values = 0, 1, 0, -1
int main() { 
  for (i = 1; i <= 3; i++) { cin >> a[i] >> b[i]; } // in a for loop, change i from 1 to 3 inclusive and read a[i] and b[i] from the input on each loop
  l1 = abs(a[1] - a[2]) * abs(a[1] - a[2]) + abs(b[1] - b[2]) * abs(b[1] - b[2]); // set l1 to abs(a[1] - a[2]) * abs(a[1] - a[2]) + abs(b[1] - b[2]) * abs(b[1] - b[2])
  l2 = abs(a[2] - a[3]) * abs(a[2] - a[3]) + abs(b[2] - b[3]) * abs(b[2] - b[3]); // set l2 to abs(a[2] - a[3]) * abs(a[2] - a[3]) + abs(b[2] - b[3]) * abs(b[2] - b[3])
  l3 = abs(a[3] - a[1]) * abs(a[3] - a[1]) + abs(b[3] - b[1]) * abs(b[3] - b[1]); // change l3 to abs(a[3] - a[1]) * abs(a[3] - a[1]) + abs(b[3] - b[1]) * abs(b[3] - b[1])
  if (l1 + l2 == l3 || l1 + l3 == l2 || l2 + l3 == l1) { // if l1 + l2 is equal to l3 or l1 + l3 is equal to l2 or l2 + l3 = l1
    if (l1 != 0 && l2 != 0 && l3 != 0) { // if l1 != 0 and l2 != 0 and l3 != 0
      cout << "RIGHT" << endl; // print "RIGHT"
      return 0; 
    } 
  } 
  for (i = 1; i <= 3; i++) { // in a for loop, change i from 1 to 3 inclusive
    c[1] = a[1], c[2] = a[2], c[3] = a[3]; // change c[1] to a[1], c[2] to a[2] and c[3] to a[3]
    d[1] = b[1], d[2] = b[2], d[3] = b[3]; // change d[1] to b[1], value of d[2] to b[2] and d[3] to b[3]
    for (j = 0; j < 4; j++) { // for j from 0 to 4 exclusive incrementing j
      c[i] = a[i] + dix[j]; // assign a[i] + dix[j] to c[i]
      d[i] = b[i] + diy[j]; // assign b[i] + diy[j] to d[i]
      l1 = abs(c[1] - c[2]) * abs(c[1] - c[2]) + abs(d[1] - d[2]) * abs(d[1] - d[2]); // set l1 to abs(c[1] - c[2]) * abs(c[1] - c[2]) + abs(d[1] - d[2]) * abs(d[1] - d[2])
      l2 = abs(c[2] - c[3]) * abs(c[2] - c[3]) + abs(d[2] - d[3]) * abs(d[2] - d[3]); // assign abs(c[2] - c[3]) * abs(c[2] - c[3]) + abs(d[2] - d[3]) * abs(d[2] - d[3]) to l2
      l3 = abs(c[3] - c[1]) * abs(c[3] - c[1]) + abs(d[3] - d[1]) * abs(d[3] - d[1]); // set l3 to abs(c[3] - c[1]) * abs(c[3] - c[1]) + abs(d[3] - d[1]) * abs(d[3] - d[1])
      if (l1 + l2 == l3 || l1 + l3 == l2 || l2 + l3 == l1) { // if l1 + l2 = l3 or l1 + l3 is equal to l2 or l2 + l3 = l1
        if (l1 != 0 && l2 != 0 && l3 != 0) { // if none of l1, l2 and l3 is 0
          cout << "ALMOST" << endl; // print "ALMOST" to the standard output
          return 0; 
        } 
      } 
    } 
  } 
  cout << "NEITHER" << endl; // print "NEITHER" to the standard output
} 