
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bool right_tri(int x1, int y1, int x2, int y2, int x3, int y3) { // bollean function right_tri with int arguments x1, y1, x2, y2, x3 and y3
  int a = ((x3 - x1) * (x3 - x1)) + ((y3 - y1) * (y3 - y1)); // a = ((x3 - x1) * (x3 - x1)) + ((y3 - y1) * (y3 - y1))
  int b = ((x2 - x1) * (x2 - x1)) + ((y2 - y1) * (y2 - y1)); // b = ((x2 - x1) * (x2 - x1)) + ((y2 - y1) * (y2 - y1))
  int c = ((x3 - x2) * (x3 - x2)) + ((y3 - y2) * (y3 - y2)); // c = ((x3 - x2) * (x3 - x2)) + ((y3 - y2) * (y3 - y2))
  vector<int> temp; // temp = vector of integers
  temp.push_back(a), temp.push_back(b), temp.push_back(c); // push a, b and c into temp
  sort(temp.rbegin(), temp.rend()); // sort temp
  if (temp[2] == 0) return false; // if temp[2] is equal to 0, return false
  if (temp[1] + temp[2] == temp[0]) return true; // if temp[1] + temp[2] is equal to temp[0], return true
  return false; // return false
} 
int main() { 
  vector<int> a(6); // a = vector of integers of size 6
  for (int i = 0; i < 6; i++) cin >> a[i]; // read 6 values into a
  if (right_tri(a[0], a[1], a[2], a[3], a[4], a[5]) == true) { // if right_tri(a[0], a[1], a[2], a[3], a[4], a[5]) is true
    cout << "RIGHT" << endl; // print "RIGHT" and a new line
    return 0; 
  } 
  for (int i = 0; i < 6; i++) { // for i = 0 to 6 exclusive
    for (int j = 0; j < 2; j++) { // for integer j = 0 to 2 exclusive
      int offset = (j == 0) ? (-1) : (1); // offset = -1 if j is 0 and 1 otherwise
      a[i] += offset; // increase a[i] by offset
      if (right_tri(a[0], a[1], a[2], a[3], a[4], a[5]) == true) { // if right_tri(a[0], a[1], a[2], a[3], a[4], a[5]) is true
        cout << "ALMOST" << endl; // print "ALMOST" and a new line
        return 0; 
      } 
      a[i] -= offset; // decrease a[i] by offset
    } 
  } 
  cout << "NEITHER" << endl; // print "NEITHER" and a new line
} 