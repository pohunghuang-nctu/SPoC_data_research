
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int d[6]; // d = array of integers of size 6
int sqr(int n) { // define function sqr with argument n
  return n * n; // return n * n
} 
void check(string s) { // define function check with string argument s
  int a, b, c; // a, b and c = integers
  a = sqr(d[0] - d[2]) + sqr(d[1] - d[3]); // a = sqr(d[0] - d[2]) + sqr(d[1] - d[3])
  b = sqr(d[0] - d[4]) + sqr(d[1] - d[5]); // b = sqr(d[0] - d[4]) + sqr(d[1] - d[5])
  c = sqr(d[2] - d[4]) + sqr(d[3] - d[5]); // c = sqr(d[2] - d[4]) + sqr(d[3] - d[5])
  if ((a && b && c) == 0) return; // if (a, b and c) are equal to 0, return
  if (a + b == c || a + c == b || b + c == a) { // if a + b = c or a + c = b or b + c is equal to a
    cout << s; // print s
    exit(0); // call exit(0)
  } 
} 
int main() { 
  int i; // let i be integer
  for (i = 0; i < 6; i++) { cin >> d[i]; } // read 6 value into d
  check("RIGHT\n"); // call function check with argument "RIGHT\n"
  for (i = 0; i < 6; i++) { // for i = 0 to 6 exclusive
    d[i]--; // decrease d[i] by one
    check("ALMOST\n"); // call function check with argument "ALMOST\n"
    d[i] += 2; // increase d[i] by 2
    check("ALMOST\n"); // call function check with argument "ALMOST\n"
    d[i]--; // decrease d[i]
  } 
  cout << "NEITHER\n"; // print "NEITHER\n"
  return 0; 
} 