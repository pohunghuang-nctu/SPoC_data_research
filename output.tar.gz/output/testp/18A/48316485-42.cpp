
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bool ra(int x1, int y1, int x2, int y2, int x3, int y3) { // in function ra with parameters integers x1, y1, x2, y2, x3, y3 and return boolean
  int d1 = (abs(x1 - x2)) * (abs(x1 - x2)) + (abs(y1 - y2)) * (abs(y1 - y2)); // d1 is an integer set to (absolute value (x1 - x2)) * (absolute value (x1 - x2)) + (absolute value (y1 - y2)) * (absolute value (y1 - y2))
  int d2 = (abs(x1 - x3)) * (abs(x1 - x3)) + (abs(y1 - y3)) * (abs(y1 - y3)); // d2 is an integer set to (absolute value (x1 - x3)) * (absolute value (x1 - x3)) + (absolute value (y1 - y3)) * (absolute value (y1 - y3))
  int d3 = (abs(x3 - x2)) * (abs(x3 - x2)) + (abs(y3 - y2)) * (abs(y3 - y2)); // d3 is an integer set to (absolute value (x3 - x2)) * (absolute value (x3 - x2)) + (absolute value (y3 - y2)) * (absolute value (y3 - y2))
  if ((d1 && d2 && d3) == 0) return false; // if d1, d2, and d3 are all equal to 0, return false
  if (d1 + d2 == d3 || d1 + d3 == d2 || d2 + d3 == d1) return true; // if d1 + d2 equals d3 or d1 + d3 equals d2 or d2 + d3 equals d1, return true
  return false; // return false
} 
int main() { 
  int n, x1, x2, x3, y1, y2, y3; // n, x1, x2, x3, y1, y2, y3 are integers
  cin >> x1 >> y1 >> x2 >> y2 >> x3 >> y3; // read x1, y1, x2, y2, x3, y3
  if (ra(x1, y1, x2, y2, x3, y3)) { // if call ra with x1, y1, x2, y2, x3, y3
    cout << "RIGHT" << endl; // display RIGHT
    return 0; 
  } 
  x1++; // increment x1
  if (ra(x1, y1, x2, y2, x3, y3)) { // if call ra with x1, y1, x2, y2, x3, y3
    cout << "ALMOST" << endl; // display ALMOST
    return 0; 
  } 
  x1 -= 2; // subtract 2 from x1
  if (ra(x1, y1, x2, y2, x3, y3)) { // if call ra with x1, y1, x2, y2, x3, y3
    cout << "ALMOST" << endl; // display ALMOST
    return 0; 
  } 
  x1++; // increment x1
  y1++; // increment y1
  if (ra(x1, y1, x2, y2, x3, y3)) { // if call ra with x1, y1, x2, y2, x3, y3
    cout << "ALMOST" << endl; // display ALMOST
    return 0; 
  } 
  y1 -= 2; // subtract 2 from y1
  if (ra(x1, y1, x2, y2, x3, y3)) { // if call ra with x1, y1, x2, y2, x3, y3
    cout << "ALMOST" << endl; // display ALMOST
    return 0; 
  } 
  y1++; // increment y1
  x2++; // increment x2
  if (ra(x1, y1, x2, y2, x3, y3)) { // if call ra with x1, y1, x2, y2, x3, y3
    cout << "ALMOST" << endl; // display ALMOST
    return 0; 
  } 
  x2 -= 2; // subtract 2 from x2
  if (ra(x1, y1, x2, y2, x3, y3)) { // if call ra with x1, y1, x2, y2, x3, y3
    cout << "ALMOST" << endl; // display ALMOST
    return 0; 
  } 
  x2++; // increment x2
  y2++; // increment y2
  if (ra(x1, y1, x2, y2, x3, y3)) { // if call ra with x1, y1, x2, y2, x3, y3
    cout << "ALMOST" << endl; // display ALMOST
    return 0; 
  } 
  y2 -= 2; // subtract 2 from y2
  if (ra(x1, y1, x2, y2, x3, y3)) { // if call ra with x1, y1, x2, y2, x3, y3
    cout << "ALMOST" << endl; // display ALMOST
    return 0; 
  } 
  y2++; // increment y2
  x3++; // increment x3
  if (ra(x1, y1, x2, y2, x3, y3)) { // if call ra with x1, y1, x2, y2, x3, y3
    cout << "ALMOST" << endl; // display ALMOST
    return 0; 
  } 
  x3 -= 2; // subtract 2 from x3
  if (ra(x1, y1, x2, y2, x3, y3)) { // if call ra with x1, y1, x2, y2, x3, y3
    cout << "ALMOST" << endl; // display ALMOST
    return 0; 
  } 
  x3++; // increment x3
  y3++; // increment y3
  if (ra(x1, y1, x2, y2, x3, y3)) { // if call ra with x1, y1, x2, y2, x3, y3
    cout << "ALMOST" << endl; // display ALMOST
    return 0; 
  } 
  y3 -= 2; // subtract 2 from y3
  if (ra(x1, y1, x2, y2, x3, y3)) { // if call ra with x1, y1, x2, y2, x3, y3
    cout << "ALMOST" << endl; // display ALMOST
    return 0; 
  } 
  cout << "NEITHER" << endl; // display NEITHER
  return 0; 
} 