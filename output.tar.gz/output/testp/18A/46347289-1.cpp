
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bool check(int x1, int y1, int x2, int y2, int x3, int y3) { // declare check with integers x1, y1, x2, y2, x3, y3 as arguments, returning boolean
  if ((x1 == x2 && y1 == y2) || (x1 == x3 && y1 == y3) || (x3 == x2 && y3 == y2)) return false; // if (x1 is x2 and y1 is y2) or ( x1 is x3 and y1 is y3 ) or ( x3 is x2 and y3 is y2 ) return false from function
  if ((y2 - y1) * (y3 - y2) == ((x1 - x2) * (x3 - x2))) return true; // if (y2 - y1)*(y3-y2) is (x1-x2)*(x3-x2) return true from function
  if ((y3 - y2) * (y1 - y3) == ((x2 - x3) * (x1 - x3))) return true; // if (y3-y2)*(y1-y3) is (x2-x3)*(x1-x3) return true from function
  if ((y1 - y3) * (y2 - y1) == ((x3 - x1) * (x2 - x1))) return true; // if (y1-y3)*(y2-y1) is (x3-x1)*(x2-x1) return true from function
  return false; // return false from function
} 
int main() { 
  int x1, y1, x2, y2, x3, y3; // create integers x1, y1, x2, y2, x3, y3
  cin >> x1 >> y1 >> x2 >> y2 >> x3 >> y3; // read x1 read y1 read x2 read y2 read x3 read y3
  if (check(x1, y1, x2, y2, x3, y3)) { // if result of run check with arguments x1, y1, x2, y2, x3, y3 is true
    cout << "RIGHT" << endl; // print "RIGHT" print newline
    return 0; 
  } 
  if (check(x1 - 1, y1, x2, y2, x3, y3)) { // if result of run check with arguments x1 - 1, y1, x2, y2, x3, y3 is true
    cout << "ALMOST" << endl; // print "ALMOST" print newline
    return 0; 
  } 
  if (check(x1 + 1, y1, x2, y2, x3, y3)) { // if result of run check with arguments x1 + 1, y1, x2, y2, x3, y3 is true
    cout << "ALMOST" << endl; // print "ALMOST" print newline
    return 0; 
  } 
  if (check(x1, y1 - 1, x2, y2, x3, y3)) { // if result of run check with arguments x1, y1 - 1, x2, y2, x3, y3 is true
    cout << "ALMOST" << endl; // print "ALMOST" print newline
    return 0; 
  } 
  if (check(x1, y1 + 1, x2, y2, x3, y3)) { // if result of run check with arguments x1, y1 + 1, x2, y2, x3, y3 is true
    cout << "ALMOST" << endl; // print "ALMOST" print newline
    return 0; 
  } 
  if (check(x1, y1, x2 - 1, y2, x3, y3)) { // if result of run check with arguments x1, y1, x2 - 1, y2, x3, y3 is true
    cout << "ALMOST" << endl; // print "ALMOST" print newline
    return 0; 
  } 
  if (check(x1, y1, x2 + 1, y2, x3, y3)) { // if result of run check with arguments x1, y1, x2 + 1, y2, x3, y3 is true
    cout << "ALMOST" << endl; // print "ALMOST" print newline
    return 0; 
  } 
  if (check(x1, y1, x2, y2 - 1, x3, y3)) { // if result of run check with arguments x1, y1, x2, y2 - 1, x3, y3 is true
    cout << "ALMOST" << endl; // print "ALMOST" print newline
    return 0; 
  } 
  if (check(x1, y1, x2, y2 + 1, x3, y3)) { // if result of run check with arguments x1, y1, x2, y2 + 1, x3, y3 is true
    cout << "ALMOST" << endl; // print "ALMOST" print newline
    return 0; 
  } 
  if (check(x1, y1, x2, y2, x3 - 1, y3)) { // if result of run check with arguments x1, y1, x2, y2, x3 - 1, y3 is true
    cout << "ALMOST" << endl; // print "ALMOST" print newline
    return 0; 
  } 
  if (check(x1, y1, x2, y2, x3 + 1, y3)) { // if result of run check with arguments x1, y1, x2, y2, x3 + 1, y3 is true
    cout << "ALMOST" << endl; // print "ALMOST" print newline
    return 0; 
  } 
  if (check(x1, y1, x2, y2, x3, y3 - 1)) { // if result of run check with arguments x1, y1, x2, y2, x3, y3 - 1 is true
    cout << "ALMOST" << endl; // print "ALMOST" print newline
    return 0; 
  } 
  if (check(x1, y1, x2, y2, x3, y3 + 1)) { // if result of run check with arguments x1, y1, x2, y2, x3, y3 + 1 is true
    cout << "ALMOST" << endl; // print "ALMOST" print newline
    return 0; 
  } 
  cout << "NEITHER" << endl; // print "NEITHER" print newline
  return 0; 
} 