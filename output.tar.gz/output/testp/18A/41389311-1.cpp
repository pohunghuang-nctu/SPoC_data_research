
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bool right_tri(int x1, int y1, int x2, int y2, int x3, int y3) { // declare right_tri with integers x1, y1, x2, y2, x3, y3 as arguments, return boolean
  int a = ((x3 - x1) * (x3 - x1)) + ((y3 - y1) * (y3 - y1)); // create integer a with a = ((x3 - x1) * (x3 - x1)) + ((y3 - y1) * (y3 - y1))
  int b = ((x2 - x1) * (x2 - x1)) + ((y2 - y1) * (y2 - y1)); // create integer b with b = ((x2 - x1) * (x2 - x1)) + ((y2 - y1) * (y2 - y1))
  int c = ((x3 - x2) * (x3 - x2)) + ((y3 - y2) * (y3 - y2)); // create integer c with c = ((x3 - x2) * (x3 - x2)) + ((y3 - y2) * (y3 - y2))
  vector<int> temp; // create integer vector temp
  temp.push_back(a), temp.push_back(b), temp.push_back(c); // add element a to end of temp, add element b to end of temp, add element c to end of temp
  sort(temp.rbegin(), temp.rend()); // sort elements from reverse beginning of temp to reverse ending of temp
  if (temp[2] == 0) return false; // if temp[2] is 0, return false from function
  if (temp[1] + temp[2] == temp[0]) return true; // if temp[1] + temp[2] is temp[0], return true from function
  return false; // return false from function
} 
int main() { 
  vector<int> a(6); // create integer vector a initialized with 6
  for (int i = 0; i < 6; i++) cin >> a[i]; // for i = 0 to 6 exclusive, read a[i]
  if (right_tri(a[0], a[1], a[2], a[3], a[4], a[5]) == true) { // if result of run right_tri with arguments a[0], a[1], a[2], a[3], a[4], a[5] is true
    cout << "RIGHT" << endl; // print "RIGHT" print newline
    return 0; 
  } 
  for (int i = 0; i < 6; i++) { // for i = 0 to 6 exclusive
    for (int j = 0; j < 2; j++) { // for j = 0 to 2 exclusive
      int offset = (j == 0) ? (-1) : (1); // create integer offset with offset = -1 if j is 0, else 1
      a[i] += offset; // increment a[i] by offset
      if (right_tri(a[0], a[1], a[2], a[3], a[4], a[5]) == true) { // if result of run right_tri with a[0], a[1], a[2], a[3], a[4], a[5] as arguments is true
        cout << "ALMOST" << endl; // print "ALMOST" print newline
        return 0; 
      } 
      a[i] -= offset; // decrement a[i] by offset
    } 
  } 
  cout << "NEITHER" << endl; // print "NEITHER" print newline
} 