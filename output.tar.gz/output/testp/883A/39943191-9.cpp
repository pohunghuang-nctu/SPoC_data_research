
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long n, m, a, d, i, lp, lst, io, ans, rao; // long long integer as ,m,a,d,i,lp,lst,io,ans,rao
long long x[300002]; // long long integer array x size of 300002
int main() { 
  cin >> n >> m >> a >> d; // read n,m,a,d
  for (i = 1; i <= m; i++) { cin >> x[i]; } // read x[i]
  lst = -1; // set lst to -1
  lp = 1; // set lp to 1
  for (i = 1; i <= m; i++) { // for = 1 to less than or equal to m do the following
    if (lst + d >= x[i] && lst != -1) continue; // if lst + d >= x[i] and lst is not equal to -1 then continue
    if (lp <= n && a * lp < x[i]) { // if lp is less than or equal to n and a * lp is less than x[i] then do the following
      io = d / a + 1; // set io to d / a + 1
      rao = min(n, (x[i] - 1) / a); // set rao to minimum of n and (x[i] - 1) / a)
      ans += (rao - lp + io) / io; // ans equals ans plus (rao - lp + io) / io
      lst = (lp + ((rao - lp + io) / io) * io - io) * a; // set lst to (lp + ((rao - lp + io) / io) * io - io) * a
      i--; // minus 1 from i
    } else { // else
      ans++; // add one to ans
      lst = x[i]; // set lst to x[i]
    } 
    lp = (lst + d) / a + 1; // set lp to (lst + d) / a + 1
  } 
  lp = min(lp, n + 1); // set lp to minimum of lp, n + 1
  io = d / a + 1; // set io to d / a + 1
  ans += (n - lp + io) / io; // ans equals ans plus (n - lp + io) / io
  cout << ans << endl; // output ans
} 