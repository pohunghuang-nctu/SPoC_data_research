
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const long long oo = 4000000000000000000LL; // create const long long oo = 4000000000000000000LL
long long n, m, a, d; // make long long ints n, m, a, and d
long long t[100100]; // create long long array t of 100100
int main() { 
  cin >> n >> m >> a >> d; // read n, m, a, and d
  for (int i = 0; i < m; ++i) { cin >> t[i]; } // for i = 0 to m exclusive, read t[i]
  t[m++] = oo - 1; // set t[m++] to oo - 1
  long long ans = 0; // create long long ans = 0
  long long k = (d / a + 1) * a; // make long long k = (d / a + 1) * a
  long long last_start = -d - 1; // let long long last_start = -d - 1
  for (int i = 0; i < m; ++i) { // for i = 0 to m exclusive
    if (t[i] <= last_start + d) continue; // if t[i] is less than or equal to last_start + d, continue loop
    long long first_ai; // make long long first_ai
    if (last_start + d < a) { // if last_start + d is less than d
      first_ai = a; // set first_ai to a
    } else if (last_start + d >= n * a) { // else if last_start + d is greater than or equal to n * a
      first_ai = oo; // set first_ai to oo
    } else { // else
      first_ai = ((last_start + d) / a + 1) * a; // set first_ai to ((last_start + d) / a + 1) * a
    } 
    if (t[i] < first_ai) { // if t[i] is less than first_ai
      last_start = t[i]; // set last_start to t[i]
      ++ans; // increment ans
    } else { // else do
      last_start = first_ai; // set last_start to first_ai
      ++ans; // increment ans
      long long steps; // make long long int steps
      if (t[i] > n * a) { // if t[i] is greater than n * a
        steps = (n * a - last_start) / k; // set steps to (n * a - last_start) / k
      } else { // else do
        steps = (t[i] - last_start) / k; // set steps to (t[i] - last_start) / k
      } 
      last_start += steps * k; // add steps * k to last_start
      ans += steps; // add steps to ans
      if (t[i] <= last_start + d) { // if t[i] is less than or equal to last_start + d
        continue; // continue loop
      } else { // else do
        last_start = t[i]; // set last_start = t[i]
        ans++; // increment ans
      } 
    } 
  } 
  cout << ans - 1 << "\n"; // display result of ans - 1
  return 0; 
} 