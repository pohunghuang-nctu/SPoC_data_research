
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, m, a, d, i, j, r = 0, x, y; // n, m, a, d, i, j, r, x, y are long longs with r = 0
  cin >> n >> m >> a >> d; // read n, m, a, d
  vector<long long> v(m + 1); // v = long long vector of size m + 1
  for (i = 1; i <= m; i++) cin >> v[i]; // for i = 1 to m inclusive, read v[i]
  i = j = 1; // set i to j to 1
  x = (d / a) + 1; // set x to (d / a) + 1
  while (i <= m && j <= n) { // while i is at most m and j is at most n
    y = j * a; // set y to j * a
    if (v[i] > y) { // if v[i] is greater than y
      y = (min(n * a, v[i]) - y) / a; // set y to ((call min with n * a, v[i]) - y) / a
      y = (y / x) + 1; // set y to (y / x) + 1
      r += y, j += x * y; // add y to r, add x * y to j
      y = (j - x) * a + d + 1; // set y to (j - x) * a + d + 1
      while (i <= m && v[i] < y) i++; // while i is at most m and v[i] is less than y, increment i
    } else { // else
      r++; // increment r
      y = v[i] + d; // set y to v[i] + d
      while (i <= m && v[i] <= y) i++; // while i is at most m and v[i] is at most y, increment i
      j = (y / a) + 1; // set j to (y / a) + 1
    } 
  } 
  while (i <= m) { // while i is at most m
    r++; // increment r
    y = v[i] + d; // set y to v[i] + d
    while (i <= m && v[i] <= y) i++; // while i is at most m and v[i] is at most y, increment i
  } 
  if (j <= n) { // if j is at most n
    j = n - j; // assign n - j to j
    r += (j / x) + 1; // add (j / x) + 1 to r
  } 
  cout << r << endl; // display r
} 