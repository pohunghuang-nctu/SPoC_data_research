
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long n, m, a, d, t[100005], pt, pa, da, ans, sa, sl; // long long integer as ,m,a,d, array t of size 100005,pt,pa,da,ans,sa,sl
void readf() { // create readf function
  cin >> n >> m >> a >> d; // read n,m,a,d
  for (int i = (1); i <= (m); ++i) cin >> t[i]; // for i = (1) to less than or equal to (m) do the following
  m = unique(t + 1, t + m + 1) - t - 1; // set m to unique(t + 1, t + m + 1) - t - 1
} 
void solve() { // create function solve
  pt = pa = 1; // set pt to pa
  da = d / a + 1; // set da to d / a + 1
  ans = 0; // set ans to 0
  while (pt <= m) { // if pt is less than or equal to m then do the following
    sa = min(t[pt] / a, n) - pa + 1; // set sa to minimum of (t[pt] / a, n) - pa + 1
    if (sa > 0) { // if sa is greater than 0 then do the following
      sl = (sa + da - 1) / da; // set sl to (sa + da - 1) / da
      ans += sl; // ans equals ans plus sl
      pa += (sl - 1) * da; // pa equals pa plus (sl - 1) * da
      while (t[pt] <= pa * a + d && pt <= m) pt++; // if t[pt] is less than or equal to pa * a + d and pt is less or equal to m then add one to pt
      pa = (pa * a + d) / a + 1; // set pa to (pa * a + d) / a + 1
    } else { // else
      ans++; // add one to ans
      int tmp = pt; // integer as tmp = pt
      while (t[pt] <= t[tmp] + d && pt <= m) pt++; // if t[pt] is less than or equal to t[tmp] + d and pt is less or equal to m add one to pt
      pa = (t[tmp] + d) / a + 1; // set pa to t[tmp] + d) / a + 1
    } 
  } 
  if (pa <= n) ans += (n - pa + 1 + da - 1) / da; // if pa is less than or equal to n then do the following ans += (n - pa + 1 + da - 1
  cout << ans << '\n'; // output ans
} 
int main() { 
  readf(); // run readf function
  solve(); // run solve function
} 