
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 1e5 + 10; // N = const int with N = 1e5 + 10
long long n, a, m, d; // n, a, m, d = long long
long long t[N], da; // da = long long and t = long long array of size N
long long nextDiv(long long bound, long long div) { // in function nextDiv taking long long bound, long long div and returning long long
  return (bound % div == 0 ? bound : bound + div - bound % div); // return bound if bound is a multiple of div else return bound + div - bound mod div
} 
long long nextDiv(long long bound, long long num, long long div) { // in function nextDiv taking long long bound, long long num, long long div and returning long long
  if (bound % div == 0) return bound + (num)*div; // if bound is a multiple of div return bound + num * div
  return nextDiv(bound, div) + (num - 1) * div; // return nextDiv of bound, div + (num - 1) * div
} 
long long prevDiv(long long bound, long long div) { // in function prevDiv taking long long bound, long long div and returning long long
  return (bound % div == 0 ? bound : bound - bound % div); // return bound if bound is a multiple of div else return bound - bound mod div
} 
long long numDiv(long long L, long long R, long long div) { // in function numDiv taking long long L, long long R, long long div and returning long long
  return prevDiv(R, div) / div - prevDiv(L - 1, div) / div; // return prevDiv of (R, div) / div - prevDiv (L - 1, div) / div
} 
pair<long long, long long> numOpen(long long L, long long R) { // in function numOpen taking long long L, long long R and returning long long, long long pair
  long long realR = min(R, n * a); // realR = long long with realR = min of R, n * a
  long long xx = numDiv(L, realR, a); // xx = long long with xx = numDiv of L, realR, a
  if (xx <= da) return {1, nextDiv(L, a) + d}; // if xx <= da return {1m nextDiv of (L, a) + d}
  long long noob = (xx % da == 0 ? xx - da : xx - xx % da); // noob = long long with noob = xx - da if xx is a multiple of da else xx - xx mod da
  long long nextt = nextDiv(L, noob, a); // nextt = long long with nextt = nextDiv of L, noob, a
  if (xx % da == 0) return {xx / da, nextt + d}; // if xx is a multiple of da return {xx / da, nextt + d}
  return {1 + xx / da, nextt + d}; // return {1 + xx / da, nextt + d}
} 
void solve() { // in function solve
  long long cur = min(a, t[1]); // cur = long long with cur = min of a, t[1]
  long long pt = 1; // pt = long long with pt = 1
  long long ans = 0; // ans = long long with ans = 0
  while (pt <= m) { // loop while pt <= m
    if (cur != t[pt]) { // if cur is not t[pt]
      pair<long long, long long> xop = numOpen(cur, t[pt] - 1); // xop = long long, long long pair with xop = numOpen of cur, t[pt] - 1
      ans += xop.first; // increment ans by xop.first
      while (pt <= m && t[pt] <= xop.second) pt++; // loop while pt <= m and t[pt] <= xop.second increment pt
      if (pt == m + 1) { // if pt is m + 1
        cur = nextDiv(xop.second + 1, a); // set cur to nextDiv of xop.second + 1, a
        if (n < numDiv(a, xop.second, a)) break; // if n < numDiv of a, xop.second, a break
        long long numLeft = n - numDiv(a, xop.second, a); // numLeft = long long with numLeft = n - numDiv of a, xop.second, a
        if (numLeft > 0) ans += numOpen(cur, nextDiv(cur, numLeft - 1, a)).first; // if numLeft > 0 increment ans by numOpen of (cur, nextDiv of cur, numLeft - 1, a).first
        break; // break
      } 
      cur = t[pt]; // set cur to t[pt]
      if (numDiv(a, xop.second, a) < n) cur = min(t[pt], nextDiv(xop.second + 1, a)); // if numDiv of a, xop.second, a < n set cur to min of t[pt], nextDiv of xop.second + 1, a
    } else { // else
      ans++; // increment ans
      long long neo = pt; // neo = long long with neo = pt
      while (pt < m && t[pt + 1] - t[neo] <= d) pt++; // loop while pt < m and t[pt + 1] - t[neo] <= d increment pt
      if (pt == m) { // if pt is m
        long long cur = nextDiv(t[neo] + d + 1, a); // cur = long long with cur = nextDiv of t[neo] + d + 1, a
        if (n < numDiv(a, t[neo] + d, a)) break; // if n < numDiv of a, t[neo] + d, a break
        long long numLeft = n - numDiv(a, t[neo] + d, a); // numLeft = long long with numLeft = n - numDiv of a, t[neo] + d, a
        if (numLeft > 0) ans += numOpen(cur, nextDiv(cur, numLeft - 1, a)).first; // if numLeft > 0 increment ans by numOpen of (cur, nextDiv of cur, numLeft - 1, a).first
        break; // break
      } 
      pt++; // increment pt
      cur = t[pt]; // set cur to t[pt]
      if (numDiv(a, t[neo] + d, a) < n) cur = min(t[pt], nextDiv(t[neo] + d + 1, a)); // if numDiv of a, t[neo] + d, a < n set cur to min of t[pt], nextDiv of t[neo] + d + 1, a
    } 
  } 
  cout << ans << '\n'; // print ans
} 
int main() { 
  cin >> n >> m >> a >> d; // read n then m then a then d
  for (int i = 1; i <= m; i++) cin >> t[i]; // for i = 1 to m inclusive read t[i]
  da = numDiv(a, a + d, a); // set da to numDiv of a, a + d, a
  solve(); // call solve
} 