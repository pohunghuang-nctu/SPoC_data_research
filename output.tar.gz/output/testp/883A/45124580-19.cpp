
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 2e6 + 10; // let N a constant int with value 2e6 + 10
long long n, a, m, d; // let n, a, m and d long longs
long long t[N]; // let t a long long array of length N
int main() { 
  cin >> n >> m >> a >> d; // read n, m, a, and d
  long long x = d / a + 1, ma = 0; // let x and ma long longs with x = d / a + 1 and ma = 0
  for (int i = 1; i <= m; ++i) cin >> t[i], ma = max(ma, t[i]); // for i from 1 to m, read t[i] and set ma to max of ma and t[i]
  t[m + 1] = max(n * a + d + d, ma + d + d); // set t[m+1] to max of n * a + d + d and ma + d + d
  long long ans = 1, now = min(t[1], a) + d; // let ans and now long longs with ans = 1 and now = min(t[1], a) + d
  long long cur = now / a + 1; // let cur long long with value now / a + 1
  for (int i = 1; i <= m + 1; ++i) // for i from 1 to m + 1
    if (t[i] > now) { // if t[i] > now
      if (cur > n) { // if cur > n
        for (int j = i; j <= m + 1; ++j) // for j from i to m + 1
          if (t[j] > now) { ++ans, now = t[j] + d; } // if t[j] > now, increment ans and set now to t[j] + d
        break; // end loop
      } 
      if (t[i] <= cur * a) { // if t[i] at most cur * a
        ++ans; // increment ans
        now = t[i] + d; // set now to t[i] + d
        cur = now / a + 1; // set cur to now / a + 1
      } else { // otherwise
        long long tmp = min(t[i] / a, n) - cur; // let tmp a long long with value min(t[i] / a, n) - cur
        ans += tmp / x + 1; // add tmp / x + 1 to ans
        cur += (tmp / x + 1) * x; // add (tmp / x + 1) * x to cur
        now = cur * a - a + d % a; // set now to cur * a - a + d mod a
        if (t[i] > now) { // if t[i] > now
          ++ans; // increment ans
          now = t[i] + d; // set now to t[i] + d
          cur = now / a + 1; // set cur to now / a + 1
        } 
      } 
    } 
  cout << ans - 1 << endl; // print ans - 1
} 