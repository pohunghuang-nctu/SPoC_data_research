
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 1e5 + 10; // declare constant integer N = 1e5 + 10
long long n, a, m, d; // declare long longs n, a, m, d
long long t[N], da; // declare long long array t size N, long long da
long long nextDiv(long long bound, long long div) { // declare nextDiv with long longs bound, div as arguments, returning long long
  return (bound % div == 0 ? bound : bound + div - bound % div); // return ( bound if bound % div is 0, else bound + div - bound % div )
} 
long long nextDiv(long long bound, long long num, long long div) { // declare nextDiv with long longs bound, num, div as arguments, returning long long
  if (bound % div == 0) return bound + (num)*div; // if ( bound % div is 0 ) return bound + num * div
  return nextDiv(bound, div) + (num - 1) * div; // return result of run nextDiv(bound,div) + (num - 1 ) * div
} 
long long prevDiv(long long bound, long long div) { // declare prevDiv with long longs bound, div as arguments, returning long long
  return (bound % div == 0 ? bound : bound - bound % div); // return bound if bound % div is 0, else bound - bound % div
} 
long long numDiv(long long L, long long R, long long div) { // declare numDiv with long longs L, R, div as arguments, returning long long
  return prevDiv(R, div) / div - prevDiv(L - 1, div) / div; // return result of run prevDiv(R,div) / div - result of run prevDiv(L-1,div) / div
} 
pair<long long, long long> numOpen(long long L, long long R) { // declare numOpen with long longs L, R as arguments, returning pair of long long, long long
  long long realR = min(R, n * a); // declare long long realR = minimum of ( R and n * a )
  long long xx = numDiv(L, realR, a); // declare long long xx = result of numDiv(L, realR, a)
  if (xx <= da) return {1, nextDiv(L, a) + d}; // if xx is less than or equal to da, return {1, result of run nextDiv(L,a) + d }
  long long noob = (xx % da == 0 ? xx - da : xx - xx % da); // declare long long noob = xx - da if xx % da is 0, else xx - xx % da
  long long nextt = nextDiv(L, noob, a); // declare long long nextt = result of run nextDiv(L,noob,a)
  if (xx % da == 0) return {xx / da, nextt + d}; // if xx % da is 0, return { xx / da, nextt + d }
  return {1 + xx / da, nextt + d}; // return { 1 + xx / da, nextt + d } from function
} 
long long special(long long bound) { // declare special with long long bound as argument, returning long long
  long long cur = nextDiv(bound + 1, a); // declare long long cur = result of run nextDiv(bound+1, a)
  if (n < numDiv(a, bound, a)) return 0; // if n is less than result of run numDiv(a, bound, a ), return 0 from function
  long long numLeft = n - numDiv(a, bound, a); // declare long long numLeft = n - result of run numDiv(a, bound, a )
  if (numLeft > 0) // if numLeft is greater than 0
    return numOpen(cur, nextDiv(cur, numLeft - 1, a)).first; // return first element of result of run numOpen( cur, result of run nextDiv( cur, numLeft -1, a) )
  else // else
    return 0; 
} 
void solve() { // declare solve with no arguments, returning void
  long long cur = min(a, t[1]); // declare long long cur = minimum of ( a, t[1] )
  long long pt = 1; // declare long long pt = 1
  long long ans = 0; // declare long long ans = 0
  while (pt <= m) { // while pt is less than or equal to m
    if (cur != t[pt]) { // if cur is not t[pt]
      pair<long long, long long> xop = numOpen(cur, t[pt] - 1); // declare pair of long long, long long xop = result of run numOpen(cur,t[pt] - 1 )
      ans += xop.first; // increment ans by first element xop
      while (pt <= m && t[pt] <= xop.second) pt++; // while pt is less than or equal to m and t[pt] is less than or equal to second element of xop, increment pt
      if (pt == m + 1) { // if pt is m + 1
        ans += special(xop.second); // increment ans by result of run special(second element of xop)
        break; // end loop
      } 
      cur = t[pt]; // let cur be t[pt]
      if (numDiv(a, xop.second, a) < n) cur = min(t[pt], nextDiv(xop.second + 1, a)); // if result of run numDiv(a, second element of xop, a ) is less than n, let cur be minimum of ( t[pt] and result of run nextDiv(second element of xop + 1, a ) )
    } else { // else
      ans++; // increment ans
      long long neo = pt; // declare long long neo = pt
      while (pt < m && t[pt + 1] - t[neo] <= d) pt++; // while pt is less than m and t[pt+1] - t[neo] is less than or equal to d, increment pt
      if (pt == m) { // if pt is m
        ans += special(t[neo] + d); // increment ans by result of run special(t[neo]+d)
        break; // end loop
      } 
      pt++; // increment pt
      cur = t[pt]; // let cur be t[pt]
      if (numDiv(a, t[neo] + d, a) < n) cur = min(t[pt], nextDiv(t[neo] + d + 1, a)); // if (result of run numDiv(a, t[neo] + d, a) is less than n) cur = minimum of(t[pt] and result of run nextDiv(t[neo] + d + 1, a))
    } 
  } 
  cout << ans << '\n'; // print ans and '\n'
} 
int main() { 
  cin >> n >> m >> a >> d; // read n, m, a, d
  for (int i = 1; i <= m; i++) cin >> t[i]; // for i = 1 to m inclusive, read t[i]
  da = numDiv(a, a + d, a); // let da be result of run numDiv(a,a+d,a)
  solve(); // run solve
} 