
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bool is_vowel(char ch) { // declare is_vowel with character ch as argument, returning boolean
  string vowels = "AEIOUY"; // declare strings vowels = "AEIOUY"
  return vowels.find(ch) != string::npos; // return first index of ch in vowels is not end of string
} 
int main() { 
  string s; // declare string s
  cin >> s; // read s
  vector<int> d; // declare integer vector d
  d.push_back(0); // add 0 to end of d
  for (int i = 0; i < s.length(); ++i) // for i = 0 to length of s exclusive
    if (is_vowel(s[i])) d.push_back(i + 1); // if result of run is_vowel(s[i]) is true, add ( i + 1 ) to end of d
  d.push_back(s.length() + 1); // add ( length of s + 1 ) to end of d
  int mx = 0; // declare integer mx = 0
  for (int i = 0; i < d.size() - 1; ++i) mx = max(d.at(i + 1) - d.at(i), mx); // for i = 0 to size of d - 1 exclusive, let mx be maximum of ( character at ( i + 1 ) in d - character at (i) in d and mx )
  cout << mx << endl; // print mx and newline
  return 0; 
} 