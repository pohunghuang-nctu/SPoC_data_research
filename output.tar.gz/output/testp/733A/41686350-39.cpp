
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int jl[300]; // let j1 = array of integers with size = 300
int main() { 
  string s1; // let s1 = string
  char yy[] = {'A', 'E', 'O', 'U', 'I', 'Y'}; // let yy = array of characters with values A, E, O, U, I, Y
  int i, j, n, k = 0, ans = -1; // let i, j, n, k, ans = integers with k = 0 and ans = -1
  cin >> s1; // read s1
  n = s1.size(); // set n = size of s1
  s1[n] = 'P'; // set s1[n] = P
  for (i = 0; i <= n; i++) { // for i=0 to n inclusive do the following
    jl[k]++; // increment j1[k]
    if (jl[k] > ans) ans = jl[k]; // if j1[k] is greater than ans set ans = j1[k]
    for (j = 0; j < 6; j++) { // for j=0 to 6 exclusive do the following
      if (s1[i] == yy[j]) { // if s1[i] is yy[j] do the following
        k++; // increment k
        break; // exit the loop
      } 
    } 
  } 
  cout << ans << endl; // print ans
  return 0; 
} 