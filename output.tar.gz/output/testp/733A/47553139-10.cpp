
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long a[500000 + 5000]; // a = long long array of size 500000 + 5000
bool isvowel(char a) { // in function isvowel taking char a and returning bool
  return a == 'A' || a == 'E' || a == 'I' || a == 'O' || a == 'U' || a == 'Y'; // return a is 'a' or 'E' or 'I' or 'O' or 'U' or 'Y'
} 
int main() { 
  string n; // n = string
  cin >> n; // read n
  long long ans = -1, lastpos = -1; // ans, lastpos = long long with ans = -1 and lastpos = -1
  for (int i = 0; i < n.size(); i++) { // for i = 0 to size of n
    if (isvowel(n[i])) ans = max(ans, i - lastpos), lastpos = i; // if isvowel of n[i] set ans to max of ans, i - lastpos then set lastpos to i
  } 
  ans = max(ans, (long long)n.size() - lastpos); // set ans to max of ans, size of n as long long - lastpos
  cout << ans << endl; // print ans
  return 0; 
} 