
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bool is_vowel(char ch) { // declare is_vowel taking in char ch and returning bool
  string vowels = "AEIOUY"; // make string vowels = "AEIOUY"
  return vowels.find(ch) != string::npos; // return the result of vowels.find(ch) != string::npos
} 
int main() { 
  string s; // make string s
  cin >> s; // read s
  vector<int> d; // create int vector d
  d.push_back(0); // append 0 to d
  for (int i = 0; i < s.length(); ++i) // for i = 0 to s.length() exclusive
    if (is_vowel(s[i])) d.push_back(i + 1); // if is_vowel(s[i]) is truthy, append i + 1 to d
  d.push_back(s.length() + 1); // append s.length() + 1 to d
  int mx = 0; // create int mx = 0
  for (int i = 0; i < d.size() - 1; ++i) mx = max(d.at(i + 1) - d.at(i), mx); // for i = 0 to d.size() exclusive, set mx to max(d.at(i + 1) - d.at(i), mx)
  cout << mx << endl; // show mx
  return 0; 
} 