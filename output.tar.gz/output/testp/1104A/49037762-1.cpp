
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // create integer n
  cin >> n; // read n
  cout << n << endl; // print n print newline
  ; // end statement
  for (int i = 1; i < n; i++) { cout << 1 << " "; } // for i = 1 to n exclusive, print 1 print " "
  cout << 1 << endl; // print 1 print newline
} 