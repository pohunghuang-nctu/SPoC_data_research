
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, t; // create int n and t
  while (cin >> n >> t) { // while read n and t
    if (t < 10) // if t < 10
      while (n--) { cout << t; } // while decrement n, print t
    else { // else
      if (n == 1) // if n=1
        cout << -1; // print -1
      else { // else
        cout << 1; // print 1
        n--; // decrement n
        while (n--) cout << 0; // while decrement n, print 0
      } 
    } 
    cout << endl; // print a newline
  } 
  return 0; 
} 