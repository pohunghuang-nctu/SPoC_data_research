
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, t; // n, t = integers
  cin >> n >> t; // read n, t
  if (t != 10) { // if (t is not 10)
    for (int i = 0; i < n; i++) cout << t; // for i = 0 to n exclusive, print t
    cout << endl; // print new line
  } else { // else
    if (n == 1) // if (n is 1)
      cout << "-1\n"; // print -1
    else { // else
      cout << '1'; // print 1
      for (int i = 0; i < n - 1; i++) { cout << '0'; } // for i = 0 to n-1 exclusive, print 0
      cout << endl; // print new line
    } 
  } 
  return 0; 
} 