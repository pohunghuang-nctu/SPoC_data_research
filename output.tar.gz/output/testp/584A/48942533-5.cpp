
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, t; // n, t = integers
  cin >> n >> t; // read n, t
  if (t != 10) { // if (t is not 10)
    while (n--) cout << t; // while decrement n, print t
  } else { // else
    if (n != 1) { // if (n is not 1)
      n -= 2; // n = n - 2
      cout << "10"; // print 10
      while (n--) cout << "0"; // while decrement n, print 0
    } else // else
      cout << "-1"; // print -1
  } 
  cout << endl; // print new line
  return 0; 
} 