
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, t; // n, t = integer
  while (cin >> n >> t) { // while n and t can be read as valid integers
    if (t < 10) // if t < 10
      while (n--) { cout << t; } // while looping decrease n by 1, print t
    else { // else
      if (n == 1) // if n is 1
        cout << -1; // print -1
      else { // else
        cout << 1; // print 1
        n--; // decrease n by 1
        while (n--) cout << 0; // while looping decrease n by 1, print 0
      } 
    } 
    cout << endl; // print endline
  } 
  return 0; 
} 