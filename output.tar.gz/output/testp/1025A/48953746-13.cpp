
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int vis[30]; // create int array vis of size 30
int main() { 
  int n; // let int n
  cin >> n; // read n
  string s; // let string s
  cin >> s; // read s
  for (int i = 0; i < s.length(); i++) { // for i = 0 to s.length() exclusive
    if (vis[s[i]]) { // if vis[s[i]] is truthy
      cout << "Yes" << endl; // print "Yes"
      return 0; 
    } 
    vis[s[i]] = 1; // set vis[s[i]] to 1
  } 
  if (n == 1) // if n is equal to 1
    cout << "Yes" << endl; // print "Yes"
  else // else
    cout << "No" << endl; // print "No"
  return 0; 
} 