
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

char s[200000 + 5]; // s = character array of size 200005
int n; // n = integer
map<char, int> mp; // mp = map from char to integer
int main() { 
  cin >> n >> s; // read n, s
  mp.clear(); // clear mp
  for (int i = 0; i < n; i++) { mp[s[i]]++; } // for i = 0 to n exclusive, increment mp[s[i]]
  int flag = 1; // flag = integer with flag = 1
  for (int i = 'a'; i <= 'z'; i++) { // for i = a to z
    if (mp[i] > 1) { // if mp[i] > 1
      cout << "Yes" << endl; // print Yes
      return 0; 
    } 
  } 
  if (n == 1) // if n is 1
    cout << "Yes" << endl; // print Yes
  else // else
    cout << "No" << endl; // print No
  return 0; 
} 