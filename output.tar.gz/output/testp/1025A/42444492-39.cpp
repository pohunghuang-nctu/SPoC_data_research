
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, ts[26]; // let n = integer and ts = array of integers size 26
  string s; // let s = string
  cin >> n >> s; // read n, s
  if (n == 1) { // if n is 1 do the following
    cout << "Yes" << endl; // print Yes
    return 0; 
  } 
  memset(ts, 0, sizeof(ts)); // set sizeof(ts) bytes starting at ts to 0
  for (int i = 0; i < n; i++) { ts[s[i] - 'a']++; } // for integer i=0 to n exclusive increment ts[s[i]-a]
  sort(ts, ts + 26); // call sort on ts and ts + 26
  if (ts[25] < 2) // if ts[25] is less than 2
    cout << "No" << endl; // print No
  else // else
    cout << "Yes" << endl; // print Yes
  return 0; 
} 