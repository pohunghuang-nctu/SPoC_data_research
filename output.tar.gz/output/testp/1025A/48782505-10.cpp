
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int a[30]; // a = int array of size 30
int main() { 
  int n; // n = int
  cin >> n; // read n
  if (n == 1) { // if n is 1
    cout << "Yes" << endl; // print "Yes"
    return 0; 
  } 
  while (n--) { // loop n times
    char s; // s = char
    cin >> s; // read s
    a[s - 96]++; // increment a[s - 96]
  } 
  int flag = 0; // flag = int with flag = 0
  for (int i = 1; i <= 26; i++) // for i = 1 to 26 inclusive
    if (a[i] >= 2) flag += 1; // if a[i] >= 2 increment flag
  if (flag == 0) // if flag is 0
    cout << "No" << endl; // print "No"
  else // else
    cout << "Yes" << endl; // print "Yes"
  return 0; 
} 