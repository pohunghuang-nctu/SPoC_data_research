
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // declare integer n
  string colors; // declare colors as string
  map<char, int> freq; // declare freq as map from character to integer
  cin >> n; // read n
  cin >> colors; // read colors
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    freq[colors[i]]++; // increment freq[colors[i]]
    if (n == 1 || freq[colors[i]] >= 2) { // if n is 1 or freq[colors[i]] is greater than or equal to 2
      cout << "Yes" << endl; // print "Yes", newline
      return 0; 
    } 
  } 
  cout << "No" << endl; // print "No", newline
  return 0; 
} 