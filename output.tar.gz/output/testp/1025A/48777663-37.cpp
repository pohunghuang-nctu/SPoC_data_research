
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int MAXN = 100000 + 10; // create an const integer MAXN with MAXN=100000+10
int a[MAXN]; // a= array of integer of size MAXN
string s; // string=s
int main() { 
  int n; // n=integer
  cin >> n >> s; // read n,s
  bool flag = false; // create a boolean flag with flag = false
  for (int i = 0; i < n; i++) { // for i=0 to n exclusive
    a[s[i] - 'a']++; // increment a[s[i] - 'a']
    if (a[s[i] - 'a'] > 1 || n == 1) flag = true; // if a[s[i]-'a']>1 or n=1 then set flag = true
  } 
  flag ? puts("Yes") : puts("No"); // if flag is true then print YES else print NO
  return 0; 
} 