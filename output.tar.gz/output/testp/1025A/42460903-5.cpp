
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long int n; // n = long integer
  while (cin >> n) { // while read n
    string s; // s = string
    long i, cnt = 0, ar[150] = {0}, f = 0; // i, cnt, ar, f = long with cnt = 0, ar = array of size 150 = {0}, f = 0
    cin >> s; // read s
    sort(s.begin(), s.end()); // sort s.begin() and s.end()
    long x; // x = long
    for (i = 0; i < n; i++) { // for i = 0 to n exclusive
      x = s[i] - 97; // x = s[i] - 97
      ar[x]++; // increment ar[x]
      if (ar[x] >= 2) { f = 1; } // if ar[x] >= 2, f = 1
    } 
    if (f == 1 || n == 1) // if f is 1 or n is 1
      cout << "Yes" << endl; // print Yes
    else // else
      cout << "No" << endl; // print No
  } 
} 