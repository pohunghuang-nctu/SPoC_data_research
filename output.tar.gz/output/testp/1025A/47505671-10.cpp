
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int a[30], t, i; // t, i = int and a = int array of size 30
  string s; // s = string
  cin >> t >> s; // read t then s
  if (t == 1) { // if t is 1
    cout << "Yes" << endl; // print "Yes"
    return 0; 
  } 
  for (i = 0; i < 29; i++) a[i] = 0; // for i = 0 to 29 set a[i] to 0
  for (i = 0; i < t; i++) { a[s[i] - 'a']++; } // for i = 0 to t increment a[s[i] - 'a']
  for (i = 0; i < 27; i++) { // for i = 0 to 27
    if (a[i] > 1) { // if a[i] > 1
      cout << "Yes" << endl; // print "Yes"
      return 0; 
    } 
  } 
  cout << "No" << endl; // print "No"
  return 0; 
} 