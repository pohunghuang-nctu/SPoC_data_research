
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int len, a[30]; // let len, a = int with a = arrya of length 30
string str; // str = string
int main() { 
  cin >> len >> str; // read len and str
  for (int i = 0; i < len; i++) a[str[i] - 'a']++; // for i = 0 to len exclusive, increment a[str[i]-'a']
  if (len == 1 || a[max_element(a, a + 30) - a] >= 2) // if len is 1 or a[(max element of a) - a] >= 2
    cout << "Yes" << endl; // print Yes
  else // else
    cout << "No" << endl; // print No
  return 0; 
} 