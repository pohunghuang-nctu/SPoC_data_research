
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

char s[10000010]; // s=array of 10000010 char
int num[100010]; // num=array of 100010 int
int main() { 
  int n; // n=int
  int i; // i=int
  bool flag = false; // flag=false
  cin >> n; // read n
  getchar(); // getchar()
  gets(s); // gets(s)
  for (i = 0; i < n; i++) { // for i=0 to n exclusive
    num[s[i] - 'a']++; // increment num[s[i]-'a']
    if (num[s[i] - 'a'] > 1 || n == 1) flag = true; // if num[s[i]-'a'] > 1 or n is 1 flag=true
  } 
  if (flag == true) // if flag
    cout << "Yes" << endl; // print "Yes"
  else // else
    cout << "No" << endl; // print "No"
  return 0; 
} 