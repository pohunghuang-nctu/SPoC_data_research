
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int ada[10005]; // ada is a new array of integers with size 10005
int main() { 
  int n; // create integer variable n
  cin >> n; // read from the input to n
  string s; // declare string variable with name s
  cin >> s; // read s from the user input
  if (n == 1) { // if n = 1
    cout << "Yes" << endl; // print "Yes"
    return 0; 
  } 
  for (int i = 0; i < n; i++) { // in a for loop, change i from 0 to n exclusive incrementing i
    char x = s[i]; // x is a new character variable = s[i]
    int xx = (int)x; // create integer variable xx
    ada[xx] += 1; // add 1 to ada[xx]
  } 
  int satu = 0; // satu is a new integer variable = 0
  for (int i = 97; i <= 122; i++) { // start for loop from i = 97 to 122 inclusive incrementing i
    if (ada[i] > 1) { // if ada[i] is greater than 1
      cout << "Yes" << endl; // print "Yes"
      return 0; 
    } 
  } 
  cout << "No" << endl; // print "No" to the standard output
} 