
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int has(char c) { // in function has taking char c returning int
  return (c - 'a'); // return c - 'a'
} 
int main() { 
  int n; // n = int
  cin >> n; // read n
  int freq[26]; // freq = int array of size 26
  for (int i = 0; i < 26; i++) freq[i] = 0; // set all values of freq to 0
  string str; // str = string
  cin >> str; // read str
  int flag = 0; // flag = int with flag = 0
  for (int i = 0; i < n; i++) { // for i = 0 to n
    int index = has(str[i]); // index = int with index = has of str[i]
    freq[index]++; // increment freq[index]
    if ((freq[index] >= 2) || (n == 1)) { // if freq[index] >= 2 or n is 1
      flag = 1; // set flag to 1
      break; // break
    } else // else
      flag = 0; // set flag to 0
  } 
  if (flag == 0) // if flag is 0
    cout << "No" // print "No"
      << "\n"; // print newline
  else // else
    cout << "Yes" // print "Yes"
      << "\n"; // print newline
  return 0; 
} 