
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int len, a[26]; // let len , a be integers with a = array of of integers of length 26
string str; // let str be a string
int main() { 
  cin >> len >> str; // read len , str
  for (int i = 0; i < len; i++) a[str[i] - 'a']++; // for i = 0 to len exclusive , increment a[str[i] - a ] by 1
  if (len == 1 || a[max_element(a, a + 26) - a] >= 2) // if len is equal to 1 or a[max_element(a, a + 26) - a] >= 2
    cout << "Yes" << endl; // print Yes and newline
  else // else do the following
    cout << "No" << endl; // print No and newline
  return 0; 
} 