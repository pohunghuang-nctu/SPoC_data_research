
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bool same(long long a, long long b) { // bool function same with long long arguments a and b
  if (a > 0 && b > 0) return true; // if a and b are both > 0, return true
  if (a < 0 && b < 0) return true; // if both a and b are less than 0, return true
  return false; // return false
} 
int main() { 
  long long x1, y1, x2, y2; // declare long long variables x1, y1, x2 and y2
  cin >> x1 >> y1 >> x2 >> y2; // read user input to x1, y1, x2 and y2
  int n; // define new integer n
  cin >> n; // read n from the input
  int res = 0; // define new integer called res = 0
  for (int i = 0; i < n; i++) { // in a for loop, change i from 0 to n exclusive
    long long a, b, c; // define long longs a, b and c
    cin >> a >> b >> c; // read a, b and c
    long long s1 = a * x1 + b * y1 + c; // define long long s1 = a * x1 + b * y1 + c
    long long s2 = a * x2 + b * y2 + c; // s2 is a new long long variable with value a * x2 + b * y2 + c
    if (!same(s1, s2)) res++; // if the result of same(s1, s2) is false, increment res by one
  } 
  cout << res << endl; // print res
  return 0; 
} 