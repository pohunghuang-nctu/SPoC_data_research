
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long int mod = 1000000007; // declare long long integer mod = 1000000007
int main() { 
  long long int x1, y1, x2, y2, a, b, c; // declare long long integers x1, y1, x2, y2, a, b, c
  int n, ans = 0; // declare integers n, ans = 0
  cin >> x1 >> y1 >> x2 >> y2 >> n; // read x1, y1, x2, y2, n
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> a >> b >> c; // read a, b, c
    long long int val1 = a * x1 + b * y1 + c; // declare long long integer val1 = a * x1 + b * y1 + c
    long long int val2 = a * x2 + b * y2 + c; // declare long long integer val2 = a * x2 + b * y2 + c
    if ((val1 < 0 && val2 > 0) || (val1 > 0 && val2 < 0)) { ans++; } // if ( val1 is less than 0 and val2 is greater than 0 ) or ( val1 is greater than 0 and val2 is less than 0 ), increment ans
  } 
  cout << ans << endl; // print ans and newline
  return 0; 
} 