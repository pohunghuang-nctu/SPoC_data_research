
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long x1, y1, x2, y2; // x1,y1,x2,y2=long long
  int n, a, b, c; // n,a,b,c=int
  while (cin >> x1 >> y1 >> x2 >> y2 >> n) { // while read x1,y1,x2,y2,n
    int num = 0; // num=0
    while (n--) { // while n is not 0, decrement n
      cin >> a >> b >> c; // read a,b,c
      long long i, j; // i,j=long long
      i = a * x1 + b * y1 + c; // i = a * x1 + b * y1 + c
      j = a * x2 + b * y2 + c; // j = a * x2 + b * y2 + c
      if (i > 0 && j < 0 || i < 0 && j > 0) num++; // if i>0 and j>0 or i<0 and j>0 increment num
    } 
    cout << num << endl; // print num
  } 
  return 0; 
} 