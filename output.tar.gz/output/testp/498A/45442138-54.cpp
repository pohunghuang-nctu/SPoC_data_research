
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long int x1, y1, x2, y2; // define long long ints x1, y1, x2 and y2
  int n, ans = 0; // create ints n and ans where ans = 0
  cin >> x1 >> y1 >> x2 >> y2 >> n; // read user input to x1, y1, x2, y2 and n
  for (int i = 0; i < n; i++) { // start for loop from i = 0 to n exclusive
    long long int a, b, c; // declare new long long int variables a, b and c
    cin >> a >> b >> c; // read a, b and c from the input
    if (a * x1 + b * y1 + c < 0 && a * x2 + b * y2 + c > 0) ans++; // if a * x1 + b * y1 + c < 0 and a * x2 + b * y2 + c > 0, increment ans
    if (a * x1 + b * y1 + c > 0 && a * x2 + b * y2 + c < 0) ans++; // increment ans if a * x1 + b * y1 + c > 0 and a * x2 + b * y2 + c < 0
  } 
  cout << ans << endl; // print ans to the standard output
} 