
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long int h1, h2, u1, u2; // declare long long int variables h1, h2, u1 and u2
  cin >> h1 >> h2 >> u1 >> u2; // read h1, h2, u1 and u2 from the input
  int n; // declare new integer called n
  cin >> n; // read user input to n
  int a[n + 5], b[n + 5], c[n + 5]; // declare int arrays a, b and c with n + 5 elements
  for (int i = 0; i < n; i++) { cin >> a[i] >> b[i] >> c[i]; } // read n new elements into a, b and c in a loop
  int ans = 0; // declare integer variable ans with value 0
  for (int i = 0; i < n; i++) { // start for loop from i = 0 to n exclusive
    long long int v1 = a[i] * h1 + b[i] * h2 + c[i]; // create new long long integers v1 = a[i] * h1 + b[i] * h2 + c[i]
    long long int v2 = a[i] * u1 + b[i] * u2 + c[i]; // new long long integer v2 = a[i] * u1 + b[i] * u2 + c[i]
    if ((v1 > 0 and v2 < 0) or (v1 < 0 and v2 > 0)) { ans++; } // if (v1 > 0 and v2 < 0) or (v1 < 0 and v2 > 0), increment ans
  } 
  cout << ans << endl; // print ans to the standard output
  return 0; 
} 