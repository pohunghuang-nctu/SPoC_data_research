
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int P = 1e9 + 7; // declare constant integer P = 1e9 + 7
long long gcd(long long a, long long b) { // declare gcd with long longs a, b as arguments, returning long long
  return b ? gcd(b, a % b) : a; // return b if result of run gcd(b,a%b) is true else a
} 
long long qpow(long long a, long long n) { // declare qpow with long longs a, n as arguments, returning long long
  long long r = 1 % P; // declare long long r = 1 % P
  for (a %= P; n; a = a * a % P, n >>= 1) // for let a be a % P, n, let a be a * a % P, setting n to n bitshift right 1
    if (n & 1) r = r * a % P; // if n bitwise and 1, let r be r * a % P
  return r; // return r from function
} 
long long inv(long long x) { // declare inv with long long x as argument, returning long long
  return x <= 1 ? 1 : inv(P % x) * (P - P / x) % P; // returnn 1 if x is less than or equal to 1 else result of run inv(P % x) * (P - P / x) % P
} 
const int N = 2e5 + 10; // declare constant integer N = 2e5 + 10
int a[N], b[N], f[N], n, m, k; // declare integer arrays a size N, b size N, f size N, integers n, m, k
int main() { 
  long long x1, y1, x2, y2; // declare long longs x1, y1, x2, y2
  cin >> x1 >> y1 >> x2 >> y2; // read x1, y1, x2 y2
  int ans = 0; // declare integer ans = 0
  cin >> n; // read n
  for (int i = 1; i <= n; ++i) { // for i = 1 to n inclusive
    long long a, b, c; // declare long longs a, b, c
    cin >> a >> b >> c; // read a, b, c
    long long x = (a * x1 + b * y1 + c); // declare long long x = (a * x1 + b * y1 + c)
    long long y = (a * x2 + b * y2 + c); // declare long long y = (a * x2 + b * y2 + c)
    if (x > 0 && y < 0 || x < 0 && y > 0) ++ans; // if x is greater than 0 and y is less than 0 or x is less than 0 and y is greater than 0, increment ans
  } 
  cout << ans << endl; // print ans and newline
} 