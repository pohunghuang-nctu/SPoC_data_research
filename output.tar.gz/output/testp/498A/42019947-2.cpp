
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long x1, y1, x2, y2; // let x1, y1, x2, y2 be long integers
  while (cin >> x1 >> y1 >> x2 >> y2) { // while read x1, y1, x2, y2
    long long a, b, c; // let a, b, c be long integers
    int n, ans = 0; // let n, ans be integers with ans = 0
    cin >> n; // read n
    for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
      cin >> a >> b >> c; // read a , b , c
      if (a * x1 + b * y1 + c < 0 && a * x2 + b * y2 + c > 0) ans++; // if a * x1 + b * y1 + c is less than 0 and a * x2 + b * y2 + c is greater than 0 , increment ans by 1
      if (a * x1 + b * y1 + c > 0 && a * x2 + b * y2 + c < 0) ans++; // if a * x1 + b * y1 + c is greater than 0 and a * x2 + b * y2 + c is less than 0 , increment ans by 1
    } 
    cout << ans << endl; // print ans and new line
  } 
  return 0; 
} 