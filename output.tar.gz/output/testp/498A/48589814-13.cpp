
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long xa, ya, xb, yb; // create long long ints xa, ya, xb, and yb
  cin >> xa >> ya >> xb >> yb; // read xa, ya, xb, and yb
  int n; // make integer n
  cin >> n; // read n
  long long a, b, c; // make long long ints a, b, and c
  int ans = 0; // create integer ans = 0
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> a >> b >> c; // read a, b, and c
    if (b == 0) { // if b is equal to 0
      if (-c > min(xa * a, xb * a) && -c < max(xa * a, xb * a)) { ans++; } // if -c is greater than min(xa * a, xb * a) and -c is less than max(xa * a, xb * a), set ans to ans + 1
    } else { // otherwise
      long long y1, y2; // create long long integers y1 and y2
      y1 = -a * xa - c; // set y1 to -a * xa - c
      y2 = -a * xb - c; // set y2 to -a * xb - c
      if ((y1 > ya * b && y2 < yb * b) || (y1 < ya * b && y2 > yb * b)) { ans++; } // if y1 is greater than ya * b and y2 is less than yb * b or if y1 is less than ya * b and y2 is greater than yb * b, increment ans
    } 
  } 
  cout << ans << endl; // show ans
  return 0; 
} 