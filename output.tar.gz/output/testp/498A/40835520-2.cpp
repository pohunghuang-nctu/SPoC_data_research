
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, a, b, c, d; // let n, a, b, c, d be long integers
  cin >> a >> b; // read a, b
  cin >> c >> d; // read c, d
  cin >> n; // read n
  long long cross = 0; // cross is a long integer equal to 0
  long long x, y, z; // let x, y, z be long integers
  for (long long i = 0; i < n; i++) { // for long integer i = 0 to n exclusive
    cin >> x >> y >> z; // read x, y, z
    if ((a * x + b * y + z) > 0 && (c * x + d * y + z) < 0) { cross++; } // if (a * x + b * y + z) is greater than 0 and value of (c * x + d * y + z) is less than 0, increment cross by 1
    if ((a * x + b * y + z) < 0 && (c * x + d * y + z) > 0) { cross++; } // if (a * x + b * y + z) is greater than 0 and value of (c * x + d * y + z) is less than 0, increment cross by 1
  } 
  cout << cross << endl; // print cross value and new line
  return 0; 
} 