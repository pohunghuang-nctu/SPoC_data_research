
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, cnt; // let n, cnt be integers
  long long x1, y1, x2, y2, a, b, c, l1, l2; // let x1, y1, x2, y2, a, b, c, l1, l2 be long integers
  while (cin >> x1 >> y1 >> x2 >> y2 >> n) { // while read x1, y1, x2, y2, n
    cnt = 0; // cnt is equal to 0
    while (n--) { // while n is decremented by 1
      cin >> a >> b >> c; // read a , b, c
      l1 = a * x1 + b * y1 + c; // l1 = a * x1 + b * y1 + c
      l2 = a * x2 + b * y2 + c; // l2 = a * x2 + b * y2 + c
      if (l1 > 0 && l2 < 0 || l1 < 0 && l2 > 0) cnt++; // if l1 is greater than 0 and l2 is less than 0 or l1 is less than 0 and l2 is greater than 0 , increment cnt by 1
    } 
    cout << cnt << endl; // print cnt and newline
  } 
  return 0; 
} 