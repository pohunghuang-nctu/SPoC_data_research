
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long x1, y1, x2, y2; // create long longs x1, y1, x2 and y2
  while (cin >> x1 >> y1 >> x2 >> y2) { // read x1, y1, x2 and y2 and keep looping
    long long a, b, c; // create new long longs a, b and c
    int n, ans = 0; // n and ans are integers with ans = 0
    cin >> n; // read n
    for (int i = 0; i < n; i++) { // for i from 0 to n exclusive
      cin >> a >> b >> c; // read variables a, b and c from the input
      if (a * x1 + b * y1 + c < 0 && a * x2 + b * y2 + c > 0) ans++; // increment ans if a * x1 + b * y1 + c < 0 and a * x2 + b * y2 + c > 0
      if (a * x1 + b * y1 + c > 0 && a * x2 + b * y2 + c < 0) ans++; // increment ans if a * x1 + b * y1 + c > 0 and a * x2 + b * y2 + c < 0
    } 
    cout << ans << endl; // print ans
  } 
  return 0; 
} 