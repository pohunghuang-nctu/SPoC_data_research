
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long mod = 1000000007; // mod = long long with mod = 1000000007
int main() { 
  long long a, b, x, y; // a, b, x, y = long long
  cin >> a >> b >> x >> y; // read a, b, x, y
  long long ans = 0; // ans = long long with ans = 0
  long long n, n1; // n, n1 = long long
  cin >> n; // read n
  n1 = n; // n1 = n
  while (n1--) { // while decrement n1
    long long a1, b1, c1; // a1, b1, c1 = long long
    cin >> a1 >> b1 >> c1; // read a1, b1, c1
    long long d1 = (a1 * a) + (b1 * b) + c1; // d1 = long long with d1 = (a1 * a) + (b1 * b) + c1
    long long d2 = (a1 * x) + (b1 * y) + c1; // d2 = long long with d2 = (a1 * x) + (b1 * y) + c1
    if ((d1 >= 0 && d2 >= 0) || (d1 < 0 && d2 < 0)) ans++; // if ((d1 >= 0 and d2 >= 0) or (d1 < 0 and d2 < 0)), increment ans
  } 
  cout << n - ans << endl; // print n - ans
  return 0; 
} 