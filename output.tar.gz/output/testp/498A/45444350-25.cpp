
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long x1, x2, y1, y2, n; // create long longs x1, x2, y1, y2, n
  cin >> x1 >> y1 >> x2 >> y2; // read x1, x2, y1, y2
  cin >> n; // read n
  int t = 0; // create int t = 0
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    long long a, b, c; // create long longs a, b, c
    cin >> a >> b >> c; // read a, b, c
    if ((a * x1 + b * y1 + c) > 0 && (a * x2 + b * y2 + c) < 0) t++; // if (a * x1 + b * y1 + c) GREATER THAN 0 AND (a * x2 + b * y2 + c) LESS THAN 0, increment t
    if ((a * x1 + b * y1 + c) < 0 && (a * x2 + b * y2 + c) > 0) t++; // if (a * x1 + b * y1 + c) LESS THAN 0 AND (a * x2 + b * y2 + c) GREATER THAN 0, increment t
  } 
  cout << t << endl; // print t
} 