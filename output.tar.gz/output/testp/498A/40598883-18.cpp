
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long x1, y1, x2, y2; // x1, y1, x2, y2 = long long
  int n; // n = integer
  int cont = 0; // cont = integer = 0
  cin >> x1 >> y1 >> x2 >> y2; // read x1, y1, x2, y2
  cin >> n; // read n
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    long long a, b, c; // a, b, c = long long
    cin >> a >> b >> c; // read a, b, c
    if (((x1 * a + y1 * b + c) > 0) && ((x2 * a + y2 * b + c) < 0)) { cont++; } // if (x1 * a + y1 * b + c) > 0) and (x2 * a + y2 * b + c) < 0), then increase cont by 1
    if (((x1 * a + y1 * b + c) < 0) && ((x2 * a + y2 * b + c) > 0)) { cont++; } // if (x1 * a + y1 * b + c) < 0) and (x2 * a + y2 * b + c) > 0), then increase cont by 1
  } 
  cout << cont << endl; // print cont
  return 0; 
} 