
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const double EPS = 1e-8; // declare double EPS = 1e-8
void fast() {} // declare fast with no arguments, returning void
bool sortby(const pair<int, int> &a, const pair<int, int> &b) { // declare sortby with constant pairs from integer to integer addresses a, b, returning boolean
  if (a.first >= b.first && a.second >= b.second) return true; // if first element of a is greater than or equal to first element of b and second element of a is greater than or equal to second element of b, return true from function
  return false; // return false from function
} 
double area(int x1, int y1, int x2, int y2, int x3, int y3) { // declare area with integers x1, y1, x2, y2, x3, y3 as arguments, returning double
  return abs((x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2.0); // return absolute value of ( (x1 * (y2 - y3) + x2 * (y3 - y1) + x3 * (y1 - y2)) / 2.0 ) from function
} 
int gcd(int a, int b) { // declare gcd with integers a, b as arguments, returning integer
  return b == 0 ? a : gcd(b, a % b); // return a if b is 0, else result of run gcd(b,a%b)
} 
int main() { 
  fast(); // run fast
  int n, m, x, ans = 0, z = 0; // declare integers n, m, x, ans = 0, z = 0
  cin >> n >> m; // read n and m
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    cin >> x; // read x
    int y; // declare integer y
    x % m == 0 ? y = x / m : y = x / m + 1; // let y be x / m if x % m is 0, else let y be x / m + 1
    if (y >= z) { // if y is greater than or equal to z
      z = y; // let z be y
      ans = i; // let ans be i
    } 
  } 
  cout << ans << endl; // print ans and newline
  return 0; 
} 