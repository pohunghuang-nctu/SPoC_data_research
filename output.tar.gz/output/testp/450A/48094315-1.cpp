
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int max_n = 2e2; // declare constant integer max_n = 2e2
int a[max_n]; // declare integer array a size max_n
int n, m, cnt, mx, ans; // declare integers n, m, cnt, mx, ans
int main() { 
  cin >> n >> m; // read n, m
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> a[i]; // read a[i]
    mx = max(mx, a[i]); // let mx be maximum of mx and a[i]
  } 
  mx = (mx + m - 1) / m; // let mx be ( mx + m - 1 ) / m
  for (int j = 0; j < mx; j++) // for j = 0 to mx exclusive
    for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
      if (a[i] > 0) { // if a[i] is greater than 0
        a[i] -= m; // decrement a[i] by m
        if (a[i] <= 0) ans = i; // if a[i] is less than or equal to 0, let ans be i
      } 
    } 
  cout << ans + 1 << '\n'; // print ans + 1 and '\n'
  return 0; 
} 