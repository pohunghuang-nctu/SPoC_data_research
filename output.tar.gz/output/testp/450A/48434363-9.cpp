
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, m; // integers = n,m
  cin >> n >> m; // read n,m
  vector<int> arr; // create integer vector of arr
  int max = -1; // integers = max = -1
  int index = -1; // integers = index = -1
  for (int i = 0; i < n; i++) { // for i = 0 to less than n do the following
    int x; // integers = x
    cin >> x; // read x
    if (x > max) { // if x is greater than max then do the following
      max = x; // set max to x
      index = i + 1; // set index to i + 1
    } 
    arr.push_back(x); // add new element x to end of vector arr
  } 
  if (m >= max) { // if m is greater than or equal to max then do the following
    cout << n << endl; // output n
  } else { // else
    int index = -1; // integers = index = -1
    int count = 0; // integers = count = 0
    int i = 0; // integer i = 0
    for (i = 0; count < n; i++) { // for = 0 to less than n do the following
      if (arr[i % n] > 0) { // if arr[i modulo n] is greater than 0 then do the following
        arr[i % n] -= m; // subtract m from arr[i modulo n]
        if (arr[i % n] <= 0) { count++; } // if arr[i modulo n] is less than or equal to 0 then do the following count++
      } 
      if (count == n) { break; } // if count is n then break
    } 
    cout << i % n + 1 << endl; // output i modulo n + 1
  } 
  return 0; 
} 