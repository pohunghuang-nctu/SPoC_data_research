
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, m; // n, m = long long
  cin >> n >> m; // read n, m
  int a[n], index; // a, index = integers with a = array of size n
  int max = INT_MIN; // max = integer with max = INT_MIN
  for (int i = 0; i < n; i++) { cin >> a[i]; } // for i = 0 to n exclusive, read a[i]
  double val = ceil(a[0] / m); // val = double with val = ceil(a[0] / m)
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    val = ceil(double(a[i]) / double(m)); // val = ceil of double(a[i]) / double(m)
    if (max <= val) { // if (max <= val)
      index = i + 1; // index = i + 1
      max = val; // max = val
    } 
  } 
  cout << index << "\n"; // print index
} 