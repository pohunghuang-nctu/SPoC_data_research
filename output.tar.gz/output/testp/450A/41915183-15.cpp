
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long int a, b, c = 0, d, i, j, k, n, l; // a, b, c, d, i, j, k, n, l = long integers with c = 0
  cin >> n >> a; // read n, a
  int ar[n + 2]; // ar = integer array of size [n+2]
  for (i = 0; i < n; i++) { cin >> ar[i]; } // for i = 0 to n (exclusive), read ar[i]
  for (i = n - 1; i >= 0; i--) { // for i = n - 1 to 0 (inclusive)
    b = ar[i]; // let b = ar[i]
    if (b % a == 0) { // if b modulo a is 0
      d = b / a; // let d = b/a
      if (c < d) { // if c is less than d
        c = d; // let c = d
        j = i + 1; // let j = i + l
      } 
    } else { // otherwise
      d = (b / a) + 1; // let d = (b/a) + l
      if (c < d) { // if c is less than d
        c = d; // let c = d
        j = i + 1; // let j = i + l
      } 
    } 
  } 
  cout << j << endl; // print j
} 