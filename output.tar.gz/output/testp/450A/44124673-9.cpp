
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int n, m; // integers = n,m
int main() { 
  cin >> n >> m; // read n,m
  int a, ans, maxa = -1; // integers = a,ans,maxa = -1
  for (int i = 1; i <= n; i++) { // for i = 1 to less than or equal to n do the following
    cin >> a; // read a
    if ((a % m) == 0) // if is 0 then do the following
      a /= m; // divide a by m
    else { // else
      a /= m; // divide a by m
      a++; // add one to a
    } 
    if (a >= maxa) { // if a is greater than or equal to maxa then do the following
      maxa = a; // set maxa to a
      ans = i; // set ans to i
    } 
  } 
  cout << ans << "\n"; // output ans
  return 0; 
} 