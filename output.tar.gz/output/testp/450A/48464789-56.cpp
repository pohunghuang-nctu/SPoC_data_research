
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int a, b, c, t, l, i, k = 0; // let a,b,c,t,l,i,k be integers with k = 0
  double sum = 0, d = 0; // let sum and d be double with sum = d = 0
  cin >> a >> b; // read a and b
  for (i = 1; i <= a; i++) { // for i = 1 to a inclusive
    cin >> c; // read c
    if (sum <= ceil((double)c / b)) { // is sum is less than or equal to ceil of c/b
      sum = ceil((double)c / b); // set sum to ceil of c/b
      k = i; // set k to i
    } 
  } 
  cout << k << endl; // print k with newline
} 