
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long int i, j, count = 0, n, m, save = 0, sav, last; // i,j,count = 0,n,m,save = 0,sav,last = long long integers
  cin >> n >> m; // read n,m
  long long int a[n]; // a[n] = long long integers
  for (i = 0; i < n; i++) cin >> a[i]; // read a[i]
  for (i = 0; i < n; i++) { // for = 0 to less than n input array a
    count = 0; // set count to 0
    while (a[i] > 0) { // if array a[i] is greater than 0 then do the following
      a[i] -= m; // subtract m from a[i]
      count++; // add one to count
    } 
    if (save <= count) { // if save is less than or equal to count then do the following
      sav = i; // set sav to i
      save = count; // set save to count
    } 
  } 
  cout << ++sav << endl; // output save + 1
  return 0; 
} 