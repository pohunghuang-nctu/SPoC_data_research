
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, m, i; // let n, m, i be integers
  while (cin >> n >> m) { // while read n , m
    int a[n]; // a = array of integers of length n
    int c = 0, b = 0; // let c , b be integers with c = 0, b = 0
    for (i = 0; i < n; i++) { // for i = 0 to n exclusive
      cin >> a[i]; // read a[i]
      if ((a[i] - 1) / m >= c) { // if (a[i] - 1) / m >= c
        c = (a[i] - 1) / m; // c is equal to (a[i] - 1) / m
        b = i; // b is equal to i
      } 
    } 
    cout << b + 1 << endl; // print b + 1 and newline
  } 
  return 0; 
} 