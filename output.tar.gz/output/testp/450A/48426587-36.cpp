
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, m, g; // n, m, g = integers
  cin >> n >> m; // read n and m
  int arr[105]; // arr = array of integers with length 105
  for (int i = 0; i < n; i++) { cin >> arr[i]; } // for i = 0 to n exclusive, print arr[i]
  for (int i = n; i;) { // for i = n
    for (int j = 0; j < n; j++) { // for j = 0 to n exclusive
      if (arr[j] > 0) { // if arr[j] > 0
        arr[j] -= m; // decrement arr[j] by m
        if (arr[j] <= 0) { // if arr[j] <= 0
          g = j; // set g to j
          i--; // decrement i by 1
        } 
      } 
    } 
  } 
  cout << g + 1 << endl; // print g + 1
  return 0; 
} 