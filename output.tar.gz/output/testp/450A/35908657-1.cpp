
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, m, a, k = 0, id = 0, t; // declare integers n, m, a, k = 0, id = 0, t
  cin >> n >> m; // read n and m
  for (int i = 1; i <= n; i++) { // for i = 1 to n inclusive
    cin >> a; // read a
    t = (a - 1) / m + 1; // let t be ( a - 1 ) / m + 1
    if (t >= k) { // if t is greater than or equal to k
      k = t; // let k be t
      id = i; // let id be i
    } 
  } 
  cout << id << endl; // print id and newline
  return 0; 
} 