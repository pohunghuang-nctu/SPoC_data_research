
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, m, max = -1, idx; // let n, m, max, idx = integers with max = -1
  float x; // let x = float
  cin >> n >> m; // read n, m
  for (int i = 0; i < n; i++) { // for integer i=0 to n exclusive do the following
    cin >> x; // read x
    x = ceil(x / m); // set x = round up of x / m
    if (x >= max) { // if x is greater than or equal to max do the following
      max = x; // set max = x
      idx = i; // set idx = i
    } 
  } 
  cout << (idx + 1) << endl; // print idx + 1
  return 0; 
} 