
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, m, i, j, num[105], cnt = 0; // n,m,i,j=int, num=array of 105 int, cnt=0
  cin >> n >> m; // read n,m
  for (i = 0; i < n; i++) { // for i=0 to n exclusive
    cin >> num[i]; // read num[i]
    if (num[i] <= m) { // if num[i] <= m
      num[i] = 0; // num[i]=0
      j = i; // j=i
    } else { // else
      num[i] = num[i] - m; // subtract m from num[i]
      cnt = 1; // cnt=1
    } 
  } 
  while (cnt) { // while cnt
    cnt = 0; // cnt=0
    for (i = 0; i < n; i++) { // for i=0 to n exclusive
      if (num[i] <= m && num[i] != 0) { // if num[i] <= m and is not 0
        num[i] = 0; // num[i]=0
        j = i; // j=i
      } else if (num[i] > m) { // else if num[i]>m
        num[i] = num[i] - m; // subtract m from num[i]
        cnt = 1; // cnt=1
      } 
    } 
  } 
  cout << j + 1 << endl; // print j+1
  return 0; 
} 