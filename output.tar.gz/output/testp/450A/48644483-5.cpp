
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long int kids, candies, input, answer; // kids, candies, input, answer = long long integers
  cin >> kids >> candies; // read kids, candies
  queue<long long int> qkids; // qkids = queue of long long integer
  queue<long long int> index; // index = queue of long long integer
  for (int i = 0; i < kids; i++) { // for i = 0 to kids exclusive
    cin >> input; // read input
    qkids.push(input); // push input in qkids
    index.push(i); // push i in index
  } 
  while (!qkids.empty()) { // while (not qkids.empty())
    if (qkids.front() <= candies) { // if (qkids.front() <= candies)
      qkids.pop(); // pop qkids
      index.pop(); // pop index
    } else { // else
      qkids.push(qkids.front() - candies); // push qkids.front() - candies in qkids
      index.push(index.front()); // push index.front() in index
      qkids.pop(); // pop qkids
      index.pop(); // pop index
    } 
    answer = index.back(); // answer = back of index
  } 
  cout << (answer + 1) << endl; // print (answer + 1)
  return 0; 
} 