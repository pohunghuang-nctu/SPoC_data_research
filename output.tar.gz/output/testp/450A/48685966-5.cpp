
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, m, i, l, c = 0; // n, m, i, l, c = integers with c = 0
  cin >> n >> m; // read n, m
  int a[n]; // a = integer array of size n
  for (i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> a[i]; // read a[i]
    if (a[i] <= m) { // if (a[i] <= m)
      l = i; // l = i
      a[i] = 0; // a[i] = 0
    } else { // else
      a[i] -= m; // a[i] = a[i] - m
      if (a[i] < 0) a[i] = 0; // if (a[i] < 0), a[i] = 0
    } 
  } 
  i = 0; // i = 0
  while (c < n) { // while (c < n)
    for (i = 0; i < n; i++) { // for i = 0 to n exclusive
      if (a[i] == 0) // if (a[i] is 0)
        c++; // increment c
      else if (a[i] <= m) { // else if (a[i] <= m)
        l = i; // l = i
        a[i] = 0; // a[i] = 0
        c = 0; // c = 0
      } else { // else
        a[i] -= m; // a[i] = a[i] - m
        if (a[i] < 0) a[i] = 0; // if (a[i] < 0), a[i] = 0
        c = 0; // c = 0
        l = i; // l = i
      } 
    } 
  } 
  l++; // increment l
  cout << l << endl; // print l
} 