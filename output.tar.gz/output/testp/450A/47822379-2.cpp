
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // let n be a integer
  float m; // let m be a float value
  cin >> n >> m; // read n , m
  vector<int> v; // create a vector of integers v
  for (int i = 0; i < n; i += 1) { // for i = 0 to n exclusive
    int x; // let x be a integer
    cin >> x; // read x
    v.push_back(x); // push_back x into vector v
  } 
  for (int i = 0; i < n; i += 1) { v[i] = ceil(v[i] / m); } // for i = 0 to n exclusive , v[i] is equal to ceiling of v[i] / m
  int p = 0, max = -1; // let p , max be integers with p = 0, max = -1
  for (int i = 0; i < n; i += 1) { // for i = 0 to n exclusive
    if (max <= v[i]) { // if max <= v[i]
      p = i + 1; // p is equal to i + 1
      max = v[i]; // max is equal to v[i]
    } 
  } 
  cout << p << endl; // print p and newline
  return 0; 
} 