
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, m, t, sum, esum, id; // n, m, t, sum, esum, id = integers
  while (cin >> n >> m) { // while read n, m
    esum = 0; // esum = 0
    for (int i = 1; i <= n; i++) { // for i = 1 to n
      cin >> t; // read t
      sum = (t - 1) / m + 1; // sum = (t - 1) / m + 1
      if (sum >= esum) { // if (sum >= esum)
        esum = sum; // esum = sum
        id = i; // id = i
      } 
    } 
    cout << id << endl; // print id
  } 
} 