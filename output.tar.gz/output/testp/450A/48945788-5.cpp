
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  map<int, int> m; // m = map from integer to integer
  map<int, int>::iterator it, bit; // it, bit = iterator map from integer to integer
  int a, b, c; // a, b, c = integers
  cin >> a >> b; // read a, b
  for (int i = 1; i <= a; i++) { // for i = 1 to a
    cin >> c; // read c
    m.insert(make_pair(i, c)); // insert make_pair(i, c) in m
  } 
  int i = 1; // i = integer with i = 1
  it = m.begin(); // it = m.begin()
  while (m.size() != 1) { // while (m.size() is not 1)
    bit = it; // bit = it
    it++; // increment it
    if (bit->second <= b) { // if (bit of second <= b)
      m.erase(bit); // erase bit from m
    } else // else
      bit->second -= b; // bit of second = bit of second - b
    if (it == m.end()) it = m.begin(); // if (it is m.end()), it = m.begin()
  } 
  it = m.begin(); // it = m.begin()
  cout << it->first << endl; // print it of first
} 