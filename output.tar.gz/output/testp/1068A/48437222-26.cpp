
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, amigos, coins, min; // create long long n, amigos, coins, min
  cin >> n >> amigos >> coins >> min; // read n, amigos, coins, min
  if (amigos > n || coins > n - min || min > n) // i amigos > n or coins > n-min or min >n
    cout << -1 << endl; // print -1
  else { // else
    long long x = (min + coins) / amigos; // x = (min + coins) / amigos
    if ((min + coins) % amigos == 0) { // if (min + coins) % amigos = 0
      if (amigos * x <= n) // if amigos * x <= n
        cout << x << endl; // print x
      else // else
        cout << -1 << endl; // print -1
    } else { // else
      if (amigos * (x + 1) <= n) // if amigos * (x + 1) <= n
        cout << x + 1 << endl; // print x+1
      else // else
        cout << -1 << endl; // print -1
    } 
  } 
  return 0; 
} 