
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long int n, m, k, l; // n, m, k, l = long long int
  cin >> n >> m >> k >> l; // read n, m, k, l
  if (m > n || l > n - k) { // if m > n or l > n - k
    cout << -1 << "\n"; // print -1
    return 0; 
  } 
  long long int x; // x = long long int
  if ((k + l) % m == 0) // if (k + l) % m = 0
    x = (k + l) / m; // let x = (k + 1) / m
  else // else
    x = (k + l) / m + 1; // let x = (k + 1) / m + 1
  if (m * x > n) { // if m * x > n
    cout << -1 << "\n"; // print -1
  } else { // else
    cout << x << "\n"; // print x
  } 
  return 0; 
} 