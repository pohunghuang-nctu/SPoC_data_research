
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long n, m, k, l; // let n, m, k, l be integers
int main() { 
  cin >> n >> m >> k >> l; // read n, m, k, l
  if (m > n) { // if m > n
    cout << -1 << endl; // print -1
    return 0; 
  } 
  if (k + l <= m) { // if k+l <= m
    cout << 1 << endl; // print 1
    return 0; 
  } 
  long long a; // let a be long lon
  if ((k + l) % m == 0) // if (k+l) mod m == 0
    a = (k + l) / m; // set a to (k+l) / m
  else // else
    a = (k + l) / m + 1; // set a to (k+l) / m + 1
  if (a * m > n) // if a * m > n
    cout << -1 << endl; // print -1
  else // else
    cout << a << endl; // print a
} 