
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, m, k, l; // n, m, k, l = long long
  cin >> n >> m >> k >> l; // read n, m, k, l
  long long sum = k + l; // sum = long long, sum = k + l
  long long out = sum / m; // out = long long, out = sum / m
  while (1) { // while true
    if (out * m <= n) { // if out * m <= n
      if (out * m >= sum) { // if out * m >= sum
        cout << out << endl; // print out
        break; // exit while loop
      } else // else
        out++; // add one to out
    } else { // else
      cout << -1 << endl; // print -1
      break; // exit while loo[
    } 
  } 
  return 0; 
} 