
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long int power(long long int x, long long int y) { // define function power which takes in long integers x and y as parameters
  long long int temp; // let temp be a long long integer
  if (y == 0) return 1; // if y is equal to 0, return 1
  temp = power(x, y / 2); // set temp to power(x, y / 2)
  if (y % 2 == 0) // if y is even
    return temp * temp; // return the value of temp * temp
  else { // or else
    if (y > 0) // if y is greater than 0
      return x * temp * temp; // return the value of x * temp * temp
    else // or else
      return (temp * temp) / x; // return the value of (temp * temp) / x
  } 
} 
bool prime[10000000]; // let prime be an array of booleans of size 10000000
void sieve() { // define function sieve
  memset(prime, true, sizeof(prime)); // set every value in prime to true
  prime[0] = prime[1] = false; // set prime[0] and prime[1] to false
  for (long long int p = 2; p * p <= 10000000; p++) { // for p = 2 to p * p <= 10000000
    if (prime[p] == true) { // if prime[p] is true
      for (long long int i = p * 2; i <= 10000000; i += p) prime[i] = false; // for i = p * 2 to i <= 10000000
    } 
  } 
} 
long long int gcd(long long int a, long long int b) { // define function gcd which takes in long long integers a and b as arguments
  if (a == 0) return b; // if a is equal to 0, return the value of b
  return gcd(b % a, a); // return the greatest common denominator of b % a and a
} 
int main() { 
  long long int n, m, k, l; // let n, m, k, and l be integers
  cin >> n >> m >> k >> l; // read in n, m, k and l
  if (m > n || l > n - k) { // if m is greater than n or l is greater than n - k
    cout << -1 << "\n"; // print -1 and a newline
    return 0; 
  } 
  long long int x; // let x be a long long integer
  x = (k + l) / m; // set x to (k + l) / m
  if ((k + l) % m != 0) x++; // if (k + l) % m is not equal to 0, increment x
  if (m * x > n) { // if m * x is greater than n
    cout << -1 << "\n"; // print -1 and a newline
  } else { // or else
    cout << x << "\n"; // print x and a newline
  } 
  return 0; 
} 