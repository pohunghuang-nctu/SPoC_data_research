
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long N, M, K, L, res; // N, M, K, L, res are long longs
  cin >> N >> M >> K >> L; // read N, M, K, L
  if (M > N || L + K > N) { // if M is greater than N or L + K is greater than N
    res = -1; // set res to -1
  } else { // else
    if (!((L + K) % M)) // if not ((L + K) mod M)
      res = (L + K) / M; // set res to (L + K) / M
    else // else
      res = (L + K) / M + 1; // set res to (L + K) / M + 1
    if (res * M > N) res = -1; // if res * M is greater than N, set res to -1
  } 
  cout << res << endl; // print res
  return 0; 
} 