
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, m, k, l, tmp, tmp2; // n, m, k, l, tmp, tmp2 = long long
  cin >> n >> m >> k >> l; // read n, m, k, l
  if (k + l > n) return cout << "-1\n", 0; // if k + l > n then return print -1
  tmp2 = ((l + k) / m) + ((l + k) % m != 0); // set tmp to (l + k) / m) + ((l + k) % m isn't 0
  if (m * tmp2 > n) // if m*tmp2 > n
    cout << "-1\n"; // print -1
  else // else
    cout << tmp2 << "\n"; // print tmp2
  return 0; 
} 