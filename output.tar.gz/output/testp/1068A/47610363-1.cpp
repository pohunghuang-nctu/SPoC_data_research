
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long N, M, K, L; // declare long longs N, M, K, L
  cin >> N >> M >> K >> L; // read N and M and K and L
  long long left = (K + L) / M; // declare long long left = ( K + L ) / M
  if ((left * M) < (K + L)) left++; // if ( left * M ) is less than ( K + L ), increment left
  long long right = N / M; // declare long long right = N / M
  long long ans = -1; // declare long long ans = -1
  if (left <= right) { ans = left; } // if leeft is less than or equal to right, let ans be left
  cout << ans << endl; // print ans and newline
  return 0; 
} 