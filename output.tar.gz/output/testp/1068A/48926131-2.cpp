
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const double PI = acos(-1); // the constant double value of PI = acos(-1)
const int MAX = 2e9 + 7; // the constant integer value of MAX = 2e9 + 7
const long long MOD = 1e9 + 7; // the constant long integer value of MOD = 1e9 + 7
void solve() { // let solve be a void function
  long long n, m, k, l; // let n, m, k, l be long integers
  cin >> n >> m >> k >> l; // read n, m, k, l
  long long dif = n - k; // the long integer value of dif = n - k
  if (dif < l) { // if dif is less than l
    cout << -1 << endl; // print -1 and newline
    return; // return nothing
  } 
  long long h = (k % m == 0 ? k / m : k / m + 1); // let h be a long integer , if k modulo m equals 0 , h = k / m else h = k / m + 1
  long long r = h * m - k; // the long integer value of r = h * m - k
  if (r >= l) { // if r >= l
    if (h * m <= n) // if h * m <= n
      cout << h << endl; // print h and newline
    else // else do the following
      cout << -1 << endl; // print -1 and newline
    return; // return nothing
  } else { // else do the following
    long long t = (l % m == 0 ? l / m : l / m + 1); // let t be a long integer , if l modulo m equals 0 the value of t is equal to l / m else t is equal to l / m + 1
    if ((t + h - 1) * m <= n and (t + h - 1) * m - k >= l) // if (t + h - 1) * m <= n and (t + h - 1) * m - k >= l
      cout << t + h - 1 << endl; // print t + h - 1 and newline
    else if ((t + h) * m <= n) // else if (t + h) * m <= n
      cout << t + h << endl; // print t + h and newline
    else // else do the following
      cout << -1 << endl; // print -1 and newline
  } 
} 
int main() { 
  solve(); // call the solve function
  return 0; 
} 