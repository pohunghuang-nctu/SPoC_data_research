
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int MAXN = 200005; // MAXN = constant int, MAXN = 200005
int main() { 
  long long N, M, K, L, ans; // N, M, K, L, ans = long long
  cin >> N >> M >> K >> L; // read N, M, K, L
  ans = (K + L + M - 1) / M; // let ans = (K + L + M - 1) / M
  if (K + L <= M * ans && M * ans <= N) // if K + L <= M * ans AND M * ans <= N)
    cout << ans << endl; // print ans
  else // else
    cout << -1 << endl; // print -1
  return 0; 
} 