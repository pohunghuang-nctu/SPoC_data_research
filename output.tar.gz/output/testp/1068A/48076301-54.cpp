
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long int ceil(long long int n, long long int m) { // long long int function ceil with long long int arguments n and m
  return n % m ? n / m + 1 : n / m; // return n / m + 1 if n modulo m is not 0, or n / m otherwise
} 
int main() { 
  long long int n, m, k, l; // declare long long int variables n, m, k and l
  cin >> n >> m >> k >> l; // read variables n, m, k and l from the input
  if (m > n || n - k < l) return cout << -1 << endl, 0; // if m > n or n - k < l, return cout << -1 << endl, 0
  long long int sum = ceil((l + k), m) * m; // create new long long integer called sum = (ceil of (l+k) and m) * m
  if (sum > n) return cout << "-1" << endl, 0; // if sum is greater than n, return cout << "-1" << endl, 0
  cout << sum / m << endl; // print sum / m
} 