
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long N, M, K, L, res; // declare long longs N, M, K, L and res
  cin >> N >> M >> K >> L; // read N, M, K and L
  if (K + L > N) // if K + L is greater than N
    res = -1; // set the value of res to - 1
  else { // else
    if ((K + L) % M) // if (K + L) % M is not zero
      res = (K + L) / M + 1; // change the value of res to (K + L) / M + 1
    else // else
      res = (K + L) / M; // set the value of res to (K + L) / M
    if (res * M > N) res = -1; // if res * M is greater than N, assign the new value = -1 to res
  } 
  cout << res << endl; // print res
  return 0; 
} 