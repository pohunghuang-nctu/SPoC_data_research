
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long gcd(long long a, long long b) { // define gcd which takes long long a, b as arguments and return long long
  return b == 0 ? a : gcd(b, a % b); // return a if b == 0 else gcd of b, a mod b
} 
long long lcm(long long a, long long b) { // define lcm which takes long long a, b as arguments and return long long
  return a * (b / gcd(a, b)); // return a * (b / gcd of a, b)
} 
const int q = 1e9 + 7; // let q be const integer with q = 1e9 + 7
long long ans = 0; // let ans be long long with ans = 0
vector<int> v; // let v be vector of integers
int main() { 
  long long n, f, iv, l; // let n, f, iv, l be long lon
  cin >> n >> f >> iv >> l; // read n, f, iv, l
  l += iv; // increment l by iv
  ans = l / f; // update ans to l / f
  if (l % f) ans++; // if l % f, increment ans
  if (ans * f > n) // if ans * f > n
    cout << -1 << '\n'; // print -1 with newline
  else // else
    cout << ans << '\n'; // print out ans with newline
  return 0; 
} 