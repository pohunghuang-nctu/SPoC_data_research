
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, m, k, l; // long long integer as n,m,k,l
  cin >> n >> m >> k >> l; // read n,m,k,l
  if (k + l > n) { // if k + l is greater than n then do the following
    cout << -1 << endl; // output -1
    return 0; 
  } 
  if (n / m * m < l + k) { // if n / m * m is less than l + k then do the following
    cout << -1 << endl; // output -1
    return 0; 
  } 
  long long ans = (l + k) / m; // long long integer as ans = (l + k) / m
  if ((l + k) % m != 0) ans++; // if l+k modulo m is not equal to 0 then add one to ans
  if (ans * m > n) // if ans * m is greater than n then do the following
    cout << -1 << endl; // output -1
  else // else
    cout << ans << endl; // output ans
} 