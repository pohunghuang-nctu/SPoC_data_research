
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long double x; // double integer = x
  cin >> x; // read x
  if (x <= 127) { // if x is less than or equal to 127 then do the following
    cout << "byte" << endl; // output byte
  } else if (x <= 32767) { // else if x is less than or equal to 32767 then do the following
    cout << "short" << endl; // output short
  } else if (x <= 2147483647) { // else if x is less than or equal to 2147483647 then do the following
    cout << "int" << endl; // output int
  } else if (x <= 9223372036854775807) { // else if x is less than or equal to 9223372036854775807 then do the following
    cout << "long" << endl; // output long
  } else { // else
    cout << "BigInteger" << endl; // output BigInteger
  } 
  return 0; 
} 