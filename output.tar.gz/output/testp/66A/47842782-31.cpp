
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long double n; // n=long double
  cin >> n; // read n
  if (n <= 127) { // if n<=127
    cout << "byte\n"; // print byte
  } else if (n <= 32767) { // else if n<=32767
    cout << "short" << endl; // print short
  } else if (n <= 2147483647) { // else if n<=2147483647
    cout << "int" << endl; // print int
  } else if (n <= 9223372036854775807) { // else if n<=9223372036854775807
    cout << "long" << endl; // print long
  } else { // else
    cout << "BigInteger" << endl; // print BigInteger
  } 
  return 0; 
} 