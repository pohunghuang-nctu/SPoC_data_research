
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int M = 1000 + 5; // M=1005
string type[5] = {"byte", "short", "int", "long", "BigInteger"}; // type=array of 5 string filled with "byte", "short", "int", "long", "BigInteger"
string border[4] = {"127", "32767", "2147483647", "9223372036854775807"}; // border=array of 4 string filled with "127", "32767", "2147483647", "9223372036854775807"
int digit[4] = {3, 5, 10, 19}; // digit=array of 4 int (3, 5, 10, 19)
int main() { 
  string s; // s=string
  cin >> s; // read s
  int ans = 4; // ans=4
  for (int i = 0; i < 4; i++) { // for i=0 to 4 exclusive
    if (s.length() < digit[i]) { // if length of s < digit[i]
      ans = i; // ans=i
      break; // break
    } 
    if (s.length() == digit[i]) { // if length of s is digit[i]
      if (s <= border[i]) { // if s <= border[i]
        ans = i; // ans=i
        break; // break
      } 
    } 
  } 
  cout << type[ans] << endl; // print type[ans]
  return 0; 
} 