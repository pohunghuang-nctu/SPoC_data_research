
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long double a; // a = double double
  cin >> a; // read a
  if (a <= 127) // if a <= 127
    cout << "byte" << endl; // print byte
  else if (a <= 32767) // else if a <= 32767
    cout << "short" << endl; // print short
  else if (a <= 2147483647) // else if a <= 2147483647
    cout << "int" << endl; // print int
  else if (a <= 9223372036854775807) // else if a <= 9223372036854775807
    cout << "long" << endl; // print long
  else // else
    cout << "BigInteger" << endl; // print BigInteger
  return 0; 
} 