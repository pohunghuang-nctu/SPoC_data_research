
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  unsigned long long int l; // create unsigned long long integer variable l
  cin >> l; // read variable l from the input
  if (l <= 127) { // if l <= 127
    cout << "byte" << endl; // print "byte"
  } else if (l <= 32767) { // else if l <= 32767
    cout << "short" << endl; // print "short"
  } else if (l <= 2147483647) { // else if l <= 2147483647
    cout << "int" << endl; // print "int" to the standard output
  } else if (l <= 9223372036854775807) { // else if l <= 9223372036854775807
    cout << "long" << endl; // print "long"
  } else // else
    cout << "BigInteger" << endl; // print "BigInteger"
  return 0; 
} 