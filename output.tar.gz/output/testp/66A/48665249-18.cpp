
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int dx[] = {0, 1, 0, -1, 1, 1, -1, -1}; // dx = integer array with element in the following order: 0, 1, 0, -1, 1, 1, -1, -1
int dy[] = {1, 0, -1, 0, 1, -1, 1, -1}; // dy = integer array with element in the following order: 1, 0, -1, 0, 1, -1, 1, -1
void fast() {} // in function fast the returns nothing
pair<string, string> arr[4]; // arr = 4 pairs of strings
int main() { 
  fast(); // call fast
  string s; // s = string
  string out[] = {"byte", "short", "int", "long", "BigInteger"}; // out = string array with the following elements = byte, short, int, long, BigInteger
  cin >> s; // read s
  arr[0] = {"-128", "127"}; // arr[0] = -128, 127
  arr[1] = {"-32768", "32767"}; // arr[1] = -32768, 32767
  arr[2] = {"-2147483648", "2147483647"}; // arr[2] = -2147483648, 2147483647
  arr[3] = {"-9223372036854775808", "9223372036854775807"}; // arr[3] = -9223372036854775808, 9223372036854775807
  if (s[0] == '-') { // if s[0] is -
    for (int i = 0; i < 4; i++) { // for i = 0 to 4 exclusive
      if (s.size() < arr[i].first.size()) return cout << out[i] << "\n", 0; // if size of s < size of first letter of arr[i], then return print out i
      ; // ;
      if (s.size() == arr[i].first.size()) { // if size of s = size of first letter of arr[i]
        for (int j = 1; j < s.size(); j++) { // for j = 1 to size of s exclusive
          if (s[j] > arr[i].first[j]) return cout << out[i + 1] << "\n", 0; // if s[j] > first j of arr[i], then return print out[i + 1] 0
          ; // ;
          if (s[j] < arr[i].second[j]) return cout << out[i] << "\n", 0; // if s[j] > second j of arr[i], then return print out[i] 0
          ; // return print out[i] 0
        } 
        return cout << out[i] << "\n", 0; // return print out[i] 0
        ; // ;
      } 
    } 
    return cout << out[4] << "\n", 0; // return print out[4] 0
    ; // ;
  } else { // else
    for (int i = 0; i < 4; i++) { // for i = 0 to 4 exclusive
      if (s.size() < arr[i].second.size()) return cout << out[i] << "\n", 0; // if size of s < second letter of arr[i], then return print out[i] 0
      ; // ;
      if (s.size() == arr[i].second.size()) { // if size of s is second letter of arr[i], then return print out[i] 0
        for (int j = 0; j < s.size(); j++) { // for j = 0 to size of s exclusive
          if (s[j] > arr[i].second[j]) return cout << out[i + 1] << "\n", 0; // if s[j] > second j of arr[i], then return print out[i + 1] 0
          ; // ;
          if (s[j] < arr[i].second[j]) return cout << out[i] << "\n", 0; // if s[j] < second j of arr[i], then return print out[i] 0
          ; // ;
        } 
        return cout << out[i] << "\n", 0; // return print out[i] 0
        ; // ;
      } 
    } 
    return cout << out[4] << "\n", 0; // print out[4] 0
    ; // ;
  } 
} 