
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long double n; // create long double n
  cin >> n; // read n
  if (n <= 127) { // if n is less than or equal to 127
    cout << "byte" << endl; // print "byte"
  } else if (n <= 32767) { // else if n is less than or equal to 32767
    cout << "short" << endl; // display "short"
  } else if (n <= 2147483647) { // else if n is less than or equal to 2147483647
    cout << "int" << endl; // display "int"
  } else if (n <= 9223372036854775807) { // else if n is less than or equal to 9223372036854775807
    cout << "long" << endl; // print "long"
  } else { // otherwise
    cout << "BigInteger" << endl; // show "BigInteger"
  } 
} 