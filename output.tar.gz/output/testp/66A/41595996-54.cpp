
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  unsigned long long int n; // define unsigned long long integer n
  cin >> n; // read standard input to n
  if (n <= 127) // if n <= 127
    cout << "byte\n"; // print "byte\n"
  else if (n <= 32767) // else if n <= 32767
    cout << "short\n"; // print "short\n"
  else if (n <= 2147483647) // else if n <= 2147483647
    cout << "int\n"; // print "int\n" to the standard output
  else if (n <= 9223372036854775807) // else if n <= 9223372036854775807
    cout << "long\n"; // print "long\n"
  else // else
    cout << "BigInteger\n"; // print "BigInteger\n"
  return 0; 
} 