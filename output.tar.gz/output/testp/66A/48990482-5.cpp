
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

string str; // str = string
unsigned long long n, negative; // n, negative = unsigned long long
int main() { 
  cin >> str; // read str
  if (str[0] == '-') { // if str[0] is -
    str.erase(str.begin()); // erase str.begin() from str
    negative = 1; // negative = 1
  } 
  if (str.size() > 19) { // if (str.size() > 19)
    cout << "BigInteger\n"; // print BigInteger
    return 0; 
  } 
  for (int i = 0; i < str.size(); i++) { // for i = 0 to str.size() exclusive
    n *= 10; // n = n * 10
    n += int(str[i] - '0'); // n = n + cast to integer(str[i] - 0)
  } 
  n += negative; // n = n + negative
  if (n <= 127) // if (n <= 127)
    cout << "byte\n"; // print byte
  else if (n <= 32767) // else if (n <= 32767)
    cout << "short\n"; // print short
  else if (n <= 2147483647) // else if (n <= 2147483647)
    cout << "int\n"; // print int
  else if (n <= 9223372036854775807) // else if (n <= 9223372036854775807)
    cout << "long\n"; // print long
  else // else
    cout << "BigInteger\n"; // print BigInteger
  return 0; 
} 