
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  char s[1000]; // s= array of characters of size 1000
  cin >> s; // read s
  int n = strlen(s); // create integer n = length of s
  if (n < 3 or (n == 3 and strcmp(s, "127") <= 0)) // if n<3 or (n=3 and strcmp(s, "127") <= 0)
    cout << "byte" << endl; // print byte and newline
  else if (n < 5 or (n == 5 and strcmp(s, "32767") <= 0)) // else if n<5 or (n = 5 and strcmp(s, "32767") <= 0)
    cout << "short" << endl; // print short
  else if (n < 10 or (n == 10 and strcmp(s, "2147483647") <= 0)) // else if n<10 or (n = 10 and strcmp(s, "2147483647") <= 0)
    cout << "int" << endl; // print int
  else if (n < 19 or (n == 19 and strcmp(s, "9223372036854775807") <= 0)) // else if n<19 or (n = 19 and strcmp(s, "9223372036854775807") <= 0)
    cout << "long" << endl; // print long and a new line
  else // else do the following
    cout << "BigInteger" << endl; // print BigInteger
  return 0; 
} 