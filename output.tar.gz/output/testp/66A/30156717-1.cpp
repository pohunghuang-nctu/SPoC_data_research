
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long x; // declare long long x
  cin >> x; // read x
  if (!cin.fail()) { // if fail bit on cin is false
    if (x <= 127) // if x is less than or equal to 127
      cout << "byte" << endl; // print "byte" and newline
    else if (x <= 32767) // else if x is less than or equal to 32767
      cout << "short" << endl; // print "short" and newline
    else if (x <= 2147483647) // else if x is less than or equal to 2147483647
      cout << "int" << endl; // print "int" and newline
    else // else
      cout << "long" << endl; // print "long" and newline
  } else { // else
    cout << "BigInteger" << endl; // print "BigInteger" and newline
  } 
  return 0; 
} 