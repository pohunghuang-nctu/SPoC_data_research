
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, k; // n, k = integers
  cin >> n >> k; // read n, k
  int num[100005]; // num = integer array of size 100005
  for (int i = 1; i <= n - k; i++) { num[i] = i; } // for i = 1 to n - k, num[i] = i
  int flag = (n - k) % 2; // flag = integer with flag = (n - k) modulo 2
  for (int i = n - k + 1; i <= n; i++) { // for i = n - k + 1 to n
    if (i % 2 == flag) { // if i modulo 2 is flag
      num[i] = num[i - 1] - k; // num[i] = num[i - 1] - k
    } else { // else
      num[i] = num[i - 1] + k; // num[i] = num[i - 1] + k
    } 
    k--; // decrement k
  } 
  for (int i = 1; i <= n; i++) { // for i = 1 to n
    if (i == 1) // if i is 1
      cout << num[i]; // print num[i]
    else // else
      cout << ' ' << num[i]; // print ' ',num[i]
  } 
  cout << endl; // print new line
  return 0; 
} 