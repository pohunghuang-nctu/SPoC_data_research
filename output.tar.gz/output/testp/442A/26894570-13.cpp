
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int b[20], ans, n; // create ints ans and n and int array b of size 20
bool a[10][10]; // make bool array a of size 10 with array of size 10
bool check() { // declare check returning bool
  int i, j, r, l, tot; // make ints i, j, r, l, and tot
  for (i = 1; i <= 5; i++) { // for i = 1 to 5
    l = r = 0; // set l and r to 0
    for (j = 1; j <= 5; j++) { // for j = 1 to 5
      if (a[i][j]) { // if a[i][j] is truthy
        l++; // increment l
        if (b[j]) { r++; } // if b[j] is truthy, add 1 to r
      } 
    } 
    if (l - 1 > r) return false; // if l - 1 is greater than r, return false
  } 
  for (i = 1; i <= 5; i++) { // for i = 1 to 5
    l = r = 0; // set l and r to 0
    for (j = 1; j <= 5; j++) { // for j = 1 to 5
      if (a[j][i]) { // if a[j][i] is truthy
        l++; // increment l
        if (b[5 + j]) r++; // if b[5 + j] is truthy, increment r
      } 
    } 
    if (l - 1 > r) return false; // if l - 1 is greater than r, return false
  } 
  tot = 0; // set tot to 0
  for (i = 1; i <= 5; i++) { // for i = 1 to 5
    for (j = 1; j <= 5; j++) { // for j = 1 to 5
      if (a[i][j] && !b[i + 5] && !b[j]) tot++; // if a[i][j] is truthy, !b[i + 5] is truthy, and b[j] is falsy, increment tot
    } 
  } 
  if (tot > 1) return false; // if tot is greater than 1, return false
  return true; // return true
} 
void dfs(int x) { // declare dfs taking in integer x
  int i, sum; // make ints i and sum
  if (x == 11) { // if x is equal to 11
    if (check()) { // if check() returns true
      sum = 0; // set sum to 0
      for (i = 1; i <= 11; i++) { // for i = 1 to 11
        if (b[i] == 1) sum++; // if b[i] is equal to 1, add 1 to sum
      } 
      ans = min(sum, ans); // set ans to min of sum and ans
    } 
    return; // return
  } 
  b[x] = 1; // set b[x] to 1
  dfs(x + 1); // call dfs(x + 1)
  b[x] = 0; // set b[x] to 0
  dfs(x + 1); // call dfs(x + 1)
} 
int main() { 
  int i, y; // create ints i and y
  char ch; // make char ch
  int k; // let integer k
  cin >> n; // read n
  memset(a, false, sizeof(a)); // set all contents of a to false
  for (i = 1; i <= n; i++) { // for i = 1 to n
    cin >> ch >> k; // read ch and k
    if (ch == 'R') // if ch is equal to 'R'
      y = 1; // set y to 1
    else if (ch == 'G') // else if ch is equal to 'G'
      y = 2; // set y to 2
    else if (ch == 'B') // else if ch is equal to 'B'
      y = 3; // set y to 3
    else if (ch == 'Y') // else if ch is equal to 'Y'
      y = 4; // set y to 4
    else if (ch == 'W') // else if ch is equal to 'W'
      y = 5; // set y to 5
    a[y][k] = true; // set a[y][k] to true
  } 
  memset(b, 0, sizeof(b)); // set all contents of b to 0
  ans = 9999999; // set ans to 9999999
  ; // end statement
  dfs(1); // call dfs(1)
  cout << ans << endl; // show ans
} 