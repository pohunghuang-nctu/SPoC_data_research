
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 150; // create constant integer variable with name N = 150
int x[N], y[N], info[N], n; // declare integer arrays x, y and info with size N, and a variable n
int color_to_id(char ch) { // integer function color_to_id with char argument ch
  if (ch == 'R') return 1; // if ch = 'R', return 1
  if (ch == 'G') return 2; // if ch is equal to 'G', return 2
  if (ch == 'B') return 3; // if ch = 'B', return 3
  if (ch == 'Y') return 4; // if ch = 'Y', return 4
  if (ch == 'W') return 5; // if ch is equal to 'W', return 5
} 
int count_one(int x) { // function count_one with int argument x that returns int
  int cnt = 0; // create integer variable called cnt with value 0
  while (x) { // while x
    cnt += (x & 1); // change cnt to the sum of cnt and x & 1
    x >>= 1; // change x to x >> 1
  } 
  return cnt; // return cnt
} 
bool check(int sta) { // bool function check with int argument sta
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive incrementing i
    info[i] = 0; // change info[i] to 0
    info[i] |= (1 << (x[i] - 1)) & sta; // set info[i] to info[i] | (1 << (x[i] - 1)) & sta
    info[i] |= (1 << (y[i] - 1 + 5)) & sta; // change the value of info[i] to info[i] | (1 << (y[i] - 1 + 5)) & sta
    for (int j = 0; j < i; j++) // in a for loop, change j from 0 to i exclusive
      if (info[i] == info[j] && (x[i] != x[j] || y[i] != y[j])) return false; // return false if info[i] = info[j] and (x[i] != x[j] or y[i] != y[j])
  } 
  return true; // return true
} 
int main() { 
  string str; // declare string variable with name str
  while (cin >> n) { // read n and loop further
    for (int i = 0; i < n; i++) { // for i = 0 to n exclusive incrementing i
      cin >> str; // read input to str
      x[i] = color_to_id(str[0]); // change the value of x[i] to color_to_id(str[0])
      y[i] = str[1] - '0'; // set y[i] to str[1] - '0'
    } 
    int ans = 10; // define integer ans with value 10
    for (int i = 0; i < (1 << 10); i++) { // for integer i = 0 to 1 << 10 exclusive
      int n_one = count_one(i); // declare new integer variable n_one with value = result of count_one(i)
      if (n_one >= ans) continue; // if n_one >= ans, go to the start of the loop
      if (check(i)) ans = n_one; // if check(i) returned true, set the value of ans to n_one
    } 
    cout << ans << endl; // print ans
  } 
  return 0; 
} 