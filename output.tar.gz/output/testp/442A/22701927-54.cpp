
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // new integer variable n
  cin >> n; // read variable n from the input
  vector<string> s(n); // create new vector of strings s with size n
  for (int i = 0; i < n; ++i) { cin >> s[i]; } // in a for loop, read n elements into s
  string candidates = "RGBYW12345"; // define new string candidates with value "RGBYW12345"
  map<char, int> pos; // create a map from characters to integers called pos
  for (int i = 0; i < candidates.size(); ++i) { pos[candidates[i]] = i; } // for i = 0 to length of candidates exclusive, change pos[candidates[i]] to i
  int m = 10; // declare new integer variable m = 10
  int res = 8; // create integer variable with name res with value 8
  for (int mask = 0; mask < (1 << m); ++mask) { // for mask from 0 to 1 << m exclusive
    int bits = 0; // declare integer variable with name bits = 0
    for (int i = 0; i < m; ++i) { // for i from 0 to m exclusive incrementing i
      if (mask & (1 << i)) { ++bits; } // increment bits if mask & (1 << i) != 0
    } 
    if (bits >= res) { continue; } // if bits >= res, go to the start of the loop
    vector<bool> used(n, false); // create vector of booleans used with n elements filled with false
    for (int i = 0; i < n; ++i) { // for i from 0 to n exclusive
      int u = pos[s[i][0]]; // create new integer u with value pos[s[i][0]]
      int v = pos[s[i][1]]; // declare integer variable with name v and value pos[s[i][1]]
      if ((mask & (1 << u)) && (mask & (1 << v))) { used[i] = true; } // if mask & (1 << u) and mask & (1 << v) are both != 0, change the value of used[i] to true
    } 
    while (true) { // start infinite loop
      bool updates = false; // new boolean updates with value false
      for (int i = 0; i < m; ++i) { // for i from 0 to m exclusive
        if (mask & (1 << i)) { // if mask & ( 1<< i) != 0
          set<string> t; // t is a new set of strings
          for (int j = 0; j < n; ++j) { // for integer j = 0 to n exclusive incrementing j
            if (candidates[i] == s[j][i / 5] && !used[j]) { t.insert(s[j]); } // if candidates[i] = s[j][i / 5] and used[j] is false, add s[j] into t
          } 
          if (t.size() <= 1) { // if length of t <= 1
            for (set<string>::iterator it = t.begin(); it != t.end(); ++it) { // move new set iterator it through the set t
              for (int j = 0; j < n; ++j) { // for j from 0 to n exclusive incrementing j
                if (s[j] == *it && !used[j]) { // if s[j] = value at it and used[j] is false
                  used[j] = true; // assign true to used[j]
                  updates = true; // set updates to true
                } 
              } 
            } 
          } 
        } 
      } 
      if (!updates) { break; } // if updates is false, break the loop
    } 
    set<string> t; // create new set of unique strings called t
    for (int i = 0; i < n; ++i) { // start for loop from i = 0 to n exclusive incrementing i
      if (!used[i]) { t.insert(s[i]); } // if used[i] is false, insert s[i] into t
    } 
    if (t.size() <= 1) { res = min(res, bits); } // if length of t <= 1, assign the new value = min of res and bits to res
  } 
  cout << res << endl; // print res
  return 0; 
} 