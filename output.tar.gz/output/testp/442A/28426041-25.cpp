
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int n, a[105]; // create integer n, array a with size 105
map<char, int> mp; // create map mp of char to int
int main() { 
  cin >> n; // read n
  mp['R'] = 5; // set mp['R'] to 5
  mp['G'] = 6; // set mp['G'] to 6
  mp['B'] = 7; // set mp['B'] to 7
  mp['Y'] = 8; // set mp['Y'] to 8
  mp['W'] = 9; // set mp['W'] to 9
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    string s; // create stirng s
    cin >> s; // read s
    int c, v; // create ints c, v
    c = mp[s[0]]; // set c to mp[s[0]]
    v = s[1] - '0' - 1; // set v to s[1] - '0' - 1
    a[i] = (1 << c) | (1 << v); // set a[i] to (1 bitwise shift left c) bitwise or (1 bitwise shift left v)
  } 
  sort(a, a + n); // sort a [0:n)
  n = unique(a, a + n) - a; // set n to unique(a, a + n) - a
  int ans = 11; // create integer ans = 11
  for (int msk = 0; msk < (1 << 10); msk++) { // for int mask = 0; msk less than (1 bitwise shift left 10); increment msk
    bool f = true; // create bool f = true
    for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
      for (int j = i + 1; j < n; j++) { // for j = i + 1 to n exclusive
        int t = a[i] ^ a[j]; // create int t = a[i] bitwise XOR a[j]
        if ((msk & t) == 0) { // if (msk bitwise and t) equals 0
          f = false; // set f to false
          break; // break
        } 
      } 
      if (!f) break; // if not f, break
    } 
    if (f) { ans = min(ans, __builtin_popcount(msk)); } // if f, set ans to min(ans, __builtin_popcount(msk))
  } 
  cout << ans << endl; // print ans
  return 0; 
} 