
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 5e5, inf = 1e9 + 7; // make constant ints N = 5e5 and inf = 1e9
map<char, int> M; // create map m of chars to ints
int tmp[N], x[N], y[N], n; // create int n and int arrays tmp of size N, x of size N, and y of size N
bool Ok(int cur) { // declare Ok taking in int cur and returning bool
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    tmp[i] = 0; // set tmp[i] to 0
    tmp[i] |= (1 << (x[i] - 1)) & cur; // set tmp[i] to tmp[i] | (1 << (x[i] - 1)) & cur
    tmp[i] |= (1 << (y[i] - 1 + 5)) & cur; // set tmp[i] to tmp[i] | (1 << (y[i] - 1 + 5)) & cur
    for (int j = 0; j < i; j++) { // for j = 0 to i exclusive
      if (tmp[i] == tmp[j] && (x[i] != x[j] || y[i] != y[j])) return false; // if tmp[i] is equal to tmp[j] and if x[i] is not equal to x[j] or y[i] is not equal to y[j], return false
    } 
  } 
  return true; // return true
} 
int main() { 
  M['R'] = 1, M['G'] = 2, M['B'] = 3, M['Y'] = 4, M['W'] = 5; // set M['R'] to 1, M['G'] to 2, M['B'] to 3, M['Y'] to 4, and M['W'] to 5
  cin >> n; // read n
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    string s; // make string s
    cin >> s; // read s
    x[i] = M[s[0]]; // set x[i] to M[s[0]]
    y[i] = s[1] - '0'; // set y[i] to s[1] - '0'
  } 
  int res = 10; // create integer res = 10
  for (int i = 0; i < (1 << 10); i++) { // for i = 0 to (1 << 10) exclusive
    int cur = __builtin_popcount(i); // make integer cur = _builtin_popcount(i)
    if (cur >= res) continue; // if cur is greater than or equal to res, continue loop
    if (Ok(i)) res = cur; // if Ok(i) is truthy, set res to cur
  } 
  cout << res << "\n"; // print res
  return 0; 
} 