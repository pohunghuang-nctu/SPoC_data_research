
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 150; // N = const int = 150
int x[N], y[N], info[N], n; // let x[N], y[N], info[N], n be ints
int color_to_id(char ch) { // in int function color_to_id taking char ch
  if (ch == 'R') return 1; // if ch = 'R' then return 1
  if (ch == 'G') return 2; // if ch = 'G' then return 2
  if (ch == 'B') return 3; // if ch = 'B' then return 3
  if (ch == 'Y') return 4; // if ch = 'Y' then return 4
  if (ch == 'W') return 5; // if ch = 'W' then return 5
} 
int count_one(int x) { // in int function count_one taking x
  int cnt = 0; // cnt = 0 = int
  while (x) { // while x isn't 0
    cnt += (x & 1); // increment cnt by x&1
    x >>= 1; // x = x bit right shift 1
  } 
  return cnt; // return cnt
} 
bool check(int sta) { // in bool function check taking sta = int
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    info[i] = 0; // set info[i] = 0
    info[i] |= (1 << (x[i] - 1)) & sta; // info[i] bitwise or (1 bitwise left shift (x[i] - 1)) bitwise and sta
    info[i] |= (1 << (y[i] - 1 + 5)) & sta; // info[i] bitwise or (1 bitwise left shift (y[i] - 1 + 5)) bitwise and sta
    for (int j = 0; j < i; j++) // for j = 0 to i exclusive
      if (info[i] == info[j] && (x[i] != x[j] || y[i] != y[j])) return false; // if info[i] = info[j] and (x[i] is not x[j] or y[i] is not y[j])
  } 
  return true; // return true
} 
int main() { 
  string str; // str = string
  while (cin >> n) { // while reading n
    for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
      cin >> str; // read str
      x[i] = color_to_id(str[0]); // set x[i] = color_to_id of str[0]
      y[i] = str[1] - '0'; // y[i] = str[1] - '0'
    } 
    int ans = 10; // ans = 10 = int
    for (int i = 0; i < (1 << 10); i++) { // for i = 0 to 1 bitwise left shit 10
      int n_one = count_one(i); // n_one = count_one(i) = int
      if (n_one >= ans) continue; // if n_one >= ans then go to next iteration
      if (check(i)) ans = n_one; // if check(i) then set ans to n_one
    } 
    cout << ans << endl; // print ans
  } 
  return 0; 
} 