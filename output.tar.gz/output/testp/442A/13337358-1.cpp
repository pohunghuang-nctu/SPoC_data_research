
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

string s[100]; // declare string array s size 100
string t[100]; // declare string array t size 100
string suit = "RGBYW"; // declare string suit = "RGBYW"
int bitcount(int n) { // declare bitcount with integer n as argument, returning integer
  int ans = 0; // declare integer ans = 0
  while (n > 0) { // while n is greater than 0
    n = n & (n - 1); // let n be n bitwise and ( n - 1 )
    ans++; // increment ans
  } 
  return ans; // return ans from function
} 
int main() { 
  int n; // declare integer n
  cin >> n; // read n
  set<string> cnt; // declare string set cnt
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> s[i]; // read s[i]
    cnt.insert(s[i]); // insert s[i] into cnt
  } 
  int distinct = cnt.size(); // declare integer distinct = size of cnt
  int ans = 8; // declare integer ans = 8
  for (int i = 0; i < (1 << 10); i++) { // for i = 0 to ( 1 bitshift left 10 ) exclusive
    int tmin = bitcount(i); // declare integer tmin = result of run bitcount(i)
    if (tmin >= ans) continue; // if tmin is greater than or equal to ans, end loop iteration
    cnt.clear(); // remove all elements from cnt
    for (int j = 0; j < 10; j++) { // for j = 0 to 10 exclusive
      if (i & (1 << j)) // if i bitwise and ( 1 bitshift left j )
        for (int k = 0; k < n; k++) { // for k = 0 to n exclusive
          if (j < 5) { // if j is less than 5
            if (s[k][1] == '1' + j) { // if s[k][1] is '1' + j
              t[k].push_back('1'); // add '1' to end of t[k]
            } else // else
              t[k].push_back('0'); // add '0' to end of t[k]
          } else { // else
            if (s[k][0] == suit[j - 5]) { // if s[k][0] is suit[j-5]
              t[k].push_back('1'); // add '1' to end of t[k]
            } else // else
              t[k].push_back('0'); // add '0' to end of t[k]
          } 
        } 
    } 
    for (int j = 0; j < n; j++) { // for j = 0 to n exclusive
      cnt.insert(t[j]); // insert t[j] into cnt
      t[j] = ""; // let t[j] be ""
    } 
    if (cnt.size() == distinct) ans = tmin; // if size of cnt is distinct, let ans be tmin
  } 
  cout << ans << endl; // print ans and newline
  return 0; 
} 