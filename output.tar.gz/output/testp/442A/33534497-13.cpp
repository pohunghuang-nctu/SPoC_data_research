
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int a[1000], b[1000]; // make int arrays a of size 1000 and b of size 1000
char C[1000]; // create char C of size 1000
int B(int x) { // declare B taking in integer x and returning integer
  int ans = 0; // create int ans = 0
  for (int i = 0; i < 10; i++) // for i = 0 to 10 exclusive
    if ((1 << i) & x) ans++; // if (1 << i) & x is truthy, increment ans
  return ans; // return ans
} 
int main() { 
  int n; // create integer n
  cin >> n; // read n
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> C[i] >> a[i]; // read C[i] and a[i]
    a[i]--; // decrease a[i] by 1
    if (C[i] == 'R') b[i] = 0; // if C[i] is equal to 'R', set b[i] to 0
    if (C[i] == 'Y') b[i] = 1; // if C[i] is equal to 'Y', set b[i] to 1
    if (C[i] == 'W') b[i] = 2; // if C[i] is equal to 'W', set b[i] to 2
    if (C[i] == 'G') b[i] = 3; // if C[i] is equal to 'G', set b[i] to 3
    if (C[i] == 'B') b[i] = 4; // if C[i] is equal to 'B', set b[i] to 4
  } 
  int ans = n + 1; // make integer ans = n + 1
  for (int i = 0; i < 32; i++) { // for i = 0 to 32 exclusive
    for (int j = 0; j < 32; j++) { // for j = 0 to 32 exclusive
      int f[5], g[5]; // make int arrays f of size 5 and g of size 5
      for (int k = 0; k < 5; k++) // for k = 0 to 5 exclusive
        if ((1 << k) & i) // if (1 << k) & 1 is truthy
          f[k] = 1; // set f[k] to 1
        else // else do
          f[k] = 0; // set f[k] to 0
      for (int k = 0; k < 5; k++) // for k = 0 to 5 exclusive
        if ((1 << k) & j) // if (1 << k) & j is truthy
          g[k] = 1; // set g[k] to 1
        else // otherwise
          g[k] = 0; // set g[k] to 0
      int fl = 1; // create integer f1 = 1
      for (int i = 0; i < n; i++) // for i = 0 to n exclusive
        for (int j = i + 1; j < n; j++) { // for j = i + 1 to n exclusive
          if (a[i] == a[j] && b[i] == b[j]) continue; // if a[i] is equal to a[j] and b[i] is equal to b[i], continue loop
          if (a[i] == a[j] && g[b[i]] | g[b[j]]) continue; // if a[i] is equal to a[j] and g[b[i]] | g[b[j]] is truthy, continue to next loop iteration
          if (b[i] == b[j] && f[a[i]] | f[a[j]]) continue; // if b[i] is equal to b[j] and f[a[i]] | f[a[j]] is truthy, continue loop
          if (a[i] != a[j] && b[i] != b[j] && f[a[i]] | f[a[j]] | g[b[i]] | g[b[j]]) continue; // if a[i] is not equal to a[j] and b[i] is not equal to b[j] and f[a[i]] | f[a[j]] | g[b[i]] | g[b[j]] is truthy, continue loop
          fl = 0; // set f1 to 0
        } 
      if (fl) ans = min(ans, B(i) + B(j)); // if f1 is truthy, set ans to min of ans and B(i) + B(j)
    } 
  } 
  cout << ans << endl; // show ans
} 