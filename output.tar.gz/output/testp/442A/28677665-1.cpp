
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int INF = (int)1e9; // declare constant integer INF = integer casted 1e9
const double PI = 2 * acos(0.0); // declare constant double PI = 2 * acosign of 0.0
const double eps = 1e-9; // declare constant double eps = 1e-9
const int NPOS = -1; // declare constant integer NPOS = -1
const int MAX = 105; // declare constant integer MAX = 105
string arr[MAX]; // declare string array arr size MAX
int have[MAX]; // declare integer array have size MAX
map<char, int> m; // declare map from character to integer m
int n, diff, flag, flg; // declare integers n, diff, flag, flg
int main() { 
  cin >> n; // read n
  m['R'] = 0; // let m['R'] be 0
  m['G'] = 1; // let m['G'] be 1
  m['B'] = 2; // let m['B'] be 2
  m['Y'] = 3; // let m['Y'] be 3
  m['W'] = 4; // let m['W'] be 4
  for (int i = int(0); i < int(n); ++i) cin >> arr[i]; // for i = 0 to n exclusive, read arr[i]
  int ans = INT_MAX; // declare integer ans = INT_MAX
  for (int col = 0; col < (1 << 5); col++) { // for col = 0 to 1 bitshift left 5 exclusive
    for (int num = int(0); num < int((1 << 5)); ++num) { // for num = 0 to integer casted ( 1 bitshift left 5 ) exclusive
      flag = 0; // let flag be 0
      for (int i = int(0); i < int(n); ++i) { // for i = 0 to integer casted n exclusive
        for (int j = i + 1; j < n; j++) { // for j = i + 1 to n exclusive
          flg = 0; // let flg be 0
          if (arr[i][0] != arr[j][0]) { // if arr[i][0] is not arr[j][0]
            if ((1 << m[arr[i][0]]) & col) flg = 1; // if (1 bitshift left m[arr[i][0]]) bitwise and col, let flg be 1
            if ((1 << m[arr[j][0]]) & col) flg = 1; // if (1 bitshift left m[arr[j][0]]) bitwise and col, let flg be 1
          } 
          if (arr[i][1] != arr[j][1]) { // if arr[i][1] is not arr[j][1]
            if ((1 << (arr[i][1] - '1')) & num) flg = 1; // if ( 1 bitshift left ( arr[i][1] - '1' ) ) bitwise and num, let flg be 1
            if ((1 << (arr[j][1] - '1')) & num) flg = 1; // if ( 1 bitshift left ( arr[j][1] - '1' ) ) bitwise and num, let flg be 1
          } 
          if ((arr[i][0] == arr[j][0]) && (arr[i][1] == arr[j][1])) flg = 1; // if (arr[i][0] is arr[j][0]) and (arr[i][1] is arr[j][1]), let flg be 1
          if (!flg) flag = 1; // if not flg, let flag be 1
        } 
      } 
      if (!flag) { // if not flag
        int t = __builtin_popcount(col) + __builtin_popcount(num); // declare integer t = result of run __builtin_popcount(col) + result of run __builtin_popcount(num)
        ans = min(t, ans); // let ans be minimum of t ans ans
      } 
    } 
  } 
  cout << ans << '\n'; // print ans and '\n'
  return 0; 
} 