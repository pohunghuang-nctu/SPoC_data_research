
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 2e5 + 10; // create constant integer N = 2e5 + 10
string z = "GRBYW"; // make string z = "GRBYW"
int t1[N], t2[N]; // make int arrays t1 of size N and t2 of size N
long ans = 1e9, temp, same; // make long ints ans = 1e9, temp, and same
int resolve(char c) { // declare resolve taking in char c and returning integer
  for (int i = 0; i < z.size(); i++) // for i = 0 to z.size() exclusive
    if (z[i] == c) return i; // if z[i] is equal to c, return i
} 
long long cbits(long long x) { // declare cbits taking in long long x and returning long long
  int r = 0; // make integer r = 0
  for (int i = 0; i < 10; i++) { // for i = 0 to 10 exclusive
    if (x & (1 << i)) r++; // if x & (1 << i) is truthy, increment r
  } 
  return r; // return r
} 
int main() { 
  long long n; // make long long integer n
  cin >> n; // read n
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    string s; // create string s
    cin >> s; // read s
    t1[i] = resolve(s[0]); // set t1[i] to resolve(s[0])
    t2[i] = s[1] - '1' + 5; // set t2[i] to s[1] - '1' + 5
  } 
  for (int mask = 0; mask < 1024; mask++) { // for mask = 0 to 1024 exclusive
    temp = cbits(mask); // set temp to cbits(mask)
    if (temp > ans) continue; // if temp is more than ans, continue loop
    int err = 0; // make integer err = 0
    for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
      for (int j = i + 1; j < n; j++) { // for j = i + 1 to n exclusive
        if (t1[i] == t1[j] && t2[i] == t2[j]) continue; // if t1[i] is equal to t1[j] and t2[i] is equal to t2[j], continue loop
        same = 1; // set same to 1
        if (t1[i] != t1[j]) { // if t1[i] is not equal to t1[j]
          if (mask & (1 << t1[i])) same = 0; // if mask & (1 << t1[i]) is truthy, set same to 0
          if (mask & (1 << t1[j])) same = 0; // if mask & (1 << t1[j]) is truthy, set same to 0
        } 
        if (t2[i] != t2[j]) { // if t2[i] is not equal to t2[j]
          if (mask & (1 << t2[i])) same = 0; // if mask & (1 << t2[j]), set same to 0
          if (mask & (1 << t2[j])) same = 0; // if mask & (1 << t2[j]), set same to 0
        } 
        if (same) err = 1; // if same is truthy, set err to 1
      } 
    } 
    if (!err) ans = min(ans, temp); // if err is falsy, set ans to min of ans and temp
  } 
  cout << ans << "\n"; // display ans
  return 0; 
} 