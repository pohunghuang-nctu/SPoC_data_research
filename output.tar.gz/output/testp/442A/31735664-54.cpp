
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

static const double EPS = 1e-5; // new static double constant EPS = 1e-5
char colortable[] = {'R', 'G', 'B', 'Y', 'W'}; // new chat array colortable with elements 'R', 'G', 'B', 'Y' and 'W'
int getX(string s) { // int function getX with string argument s
  for (int i = 0; i < 5; i++) { // for i from 0 to 5 exclusive incrementing i
    if (colortable[i] == s[0]) return i; // if colortable[i] is equal to s[0], return i
  } 
  return -1; // return -1
} 
int getY(string s) { // getY is a integer function with string argument s
  return s[1] - '1'; // return s[1] - '1'
} 
int bitcount(int b) { // bitcount is a int function with int argument b
  int ans = 0; // declare new integer variable ans = 0
  while (b != 0) { // while b != 0
    ans++; // increment ans
    b &= b - 1; // change b to b & (b - 1)
  } 
  return ans; // return ans
} 
bool check(int maskX, int maskY, string C1, string C2) { // bool function check with int arguments maskX and maskY and string arguments C1 and C2
  int x1 = getX(C1); // x1 is a new integer = result of getX(C1)
  int x2 = getX(C2); // create new integer variable x2 with value from getX(C2)
  int y1 = getY(C1); // declare integer variable y1 = value, returned by getY(C1)
  int y2 = getY(C2); // declare integer y2 = result of getY(C2)
  if (x1 == x2 && y1 == y2) return true; // return true if x1 is equal to x2 and y1 = y2
  if (x1 != x2) { // if x1 != x2
    if ((maskX & (1 << x1)) != 0 || (maskX & (1 << x2)) != 0) return true; // if (maskX & (1 << x1)) != 0 || (maskX & (1 << x2)) != 0, return true
  } 
  if (y1 != y2) { // if y1 != y2
    if ((maskY & (1 << y1)) != 0 || (maskY & (1 << y2)) != 0) return true; // if (maskY & (1 << y1)) != 0 || (maskY & (1 << y2)) != 0, return true
  } 
  return false; // return false
} 
int main() { 
  int n; // declare new integer variable n
  cin >> n; // read n
  vector<string> cards(n); // cards is a new vector of strings with n elements
  for (int i = 0; i < n; i++) cin >> cards[i]; // read n elements from the input into cards in a loop
  int ans = 100000; // declare new integer ans = 100000
  sort(cards.begin(), cards.end()); // sort cards
  cards.erase(unique(cards.begin(), cards.end()), cards.end()); // remove duplicates from cards
  for (int maskX = 0; maskX < (1 << 5); maskX++) { // start for loop from maskX = 0 to 1 << 5 exclusive
    for (int maskY = 0; maskY < (1 << 5); maskY++) { // start for loop from maskY = 0 to 1 << 5 exclusive incrementing maskY
      bool ok = true; // create boolean variable with name ok = true
      for (int i = 0; ok && (i < (int)cards.size()); i++) { // incremen i in a loop from 0, while ok is true and i < size of cards
        for (int j = i + 1; ok && (j < (int)cards.size()); j++) { ok = check(maskX, maskY, cards[i], cards[j]); } // for j from i + 1 to exclusive, assign the result of check(maskX, maskY, cards[i], cards[j]) to ok
      } 
      if (ok) { ans = min(ans, bitcount(maskX) + bitcount(maskY)); } // if ok is true, set the value of ans to min of ans and bitcount(maskX) + bitcount(maskY)
    } 
  } 
  cout << ans << endl; // print ans to the standard output
  return 0; 
} 