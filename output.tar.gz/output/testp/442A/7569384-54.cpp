
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

short X[105], Y[105]; // define arrays of shorts X and Y with size 105
short bin[15]; // bin is a new array of shorts with size 15
const int C = 5; // create constant integer variable C with value 5
map<char, int> M; // create a map from characters to integers called M
void trans(int x) { // void function trans with int argument x
  int ind = 0; // create new integer variable ind with value 0
  for (int j = 0; j < 12; j++) bin[j] = 0; // set first 12 elements of bin to 0
  while (x > 0) { // while x > 0
    bin[ind++] = x % 2; // change the value of bin[ind] to x modulo 2 and increment ind
    x /= 2; // change the value of s quared divided by 2
  } 
} 
int main() { 
  char ch; // create new character called ch
  int n; // define new integer n
  cin >> n; // read n from the user input
  M['R'] = 0; // assign 0 to M['R']
  M['G'] = 1; // assign 1 to M['G']
  M['B'] = 2; // change the value of M['B'] to 2
  M['Y'] = 3; // assign 3 to M['Y']
  M['W'] = 4; // assign the new value = 4 to M['W']
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> ch; // read standard input to ch
    X[i] = M[ch]; // change the value of X[i] to M[ch]
    cin >> ch; // read ch
    Y[i] = ch - '1'; // assign the new value = ch - '1' to Y[i]
  } 
  int ans = 20, anst; // define integers ans and anst with ans = 20
  bool all; // declare boolean variable all
  bool ones = true; // new boolean ones = true
  for (int i = 0; i < n - 1; i++) ones = (X[i] == X[i + 1] && Y[i] == Y[i + 1]) && ones; // start for loop from i = 0 to n - 1 exclusive, change ones to (X[i] == X[i + 1] && Y[i] == Y[i + 1]) && ones
  if (!ones) { // if ones is false
    for (int i = 1; i <= 1023; i++) { // for integer i = 1 to 1023 inclusive incrementing i
      trans(i); // call trans of i
      anst = 0; // change the value of anst to 0
      all = true; // assign the new value = true to all
      for (int k = 0; k < n - 1; k++) { // increment k in a loop from 0 to n - 1 exclusive
        for (int l = k + 1; l < n; l++) { // for integer l = k + 1 to n exclusive
          if (X[k] != X[l] && ((bin[X[k]] == 1) || (bin[X[l]] == 1))) // if X[k] != X[l] and (bin[X[k]] or bin[X[l]] = 1)
            all = true; // change the value of all to true
          else if (Y[k] != Y[l] && ((bin[Y[k] + C] == 1) || bin[Y[l] + C] == 1)) // else if Y[k] != Y[l] and (bin[Y[k] + C] or bin[Y[l] + C] = 1)
            all = true; // change the value of all to true
          else if (X[l] == X[k] && Y[l] == Y[k]) // else if X[l] = X[k] and Y[l] = Y[k]
            all = true; // assign true to all
          else // else
            all = false; // assign false to all
          if (!all) break; // if all is false, break
        } 
        if (!all) break; // if all is false, break the loop
      } 
      if (all) { // if all is true
        for (int i = 0; i < 12; i++) // for i = 0 to 12 exclusive
          if (bin[i] == 1) anst++; // if bin[i] is equal to 1, increment anst by one
        ans = ans > anst ? anst : ans; // change the value of ans to anst of ans > anst
      } 
    } 
  } else // else
    cout << 0 << endl; // print 0
  if (!ones) cout << ans << endl; // if ones is false, print ans
  return 0; 
} 