
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int INF = 2147483647; // create new integer constant INF = 2147483647
const int mod = 1000000007; // define integer constant mod =1000000007
const int tmod = 1000000009; // new constant integer tmod = 1000000009
map<char, int> ma; // let ma be a map from characters to integers
int vis[25]; // create new array of integers vis with size 25
vector<int> v; // declare vector of integers v
int sum[25]; // declare new array of integers sum with size 25
int a1[5]; // a1 is an array of integers with 5 elements
int a2[5]; // create new array of integers a2 with size 5
int main() { 
  int n; // declare new integer called n
  cin >> n; // read variable n from the input
  ma['R'] = 0; // assign 0 to ma['R']
  ma['G'] = 1; // change ma['G'] to 1
  ma['B'] = 2; // assign the new value = 2 to ma['B']
  ma['Y'] = 3; // set ma['Y'] to 3
  ma['W'] = 4; // assign the new value = 4 to ma['W']
  for (int i = 0; i < (n); i++) { // start for loop from i = 0 to n exclusive
    string str; // define string str
    cin >> str; // read input to str
    int tmp = ma[str[0]] * 5 + str[1] - '1'; // declare new integer tmp = ma[str[0]] * 5 + str[1] - '1'
    vis[tmp] = 1; // change vis[tmp] to 1
  } 
  for (int i = 0; i < (25); i++) // start for loop from i = 0 to 25 exclusive incrementing i
    if (vis[i]) v.push_back(i); // if vis[i] is true, add i to v
  int ans = 10; // define integer ans = 10
  for (int s = 0; s < (1 << 10); s++) { // in a for loop, change s from 0 to 1 << 10 exclusive
    memset(a1, 0, sizeof(a1)); // set the values of first sizeof(a1) bytes at the pointer a1 to 0
    memset(a2, 0, sizeof(a2)); // set first sizeof(a2) bytes at the pointer a2 to 0
    memset(sum, 0, sizeof(sum)); // change the values of first sizeof(sum) bytes at the pointer sum to 0
    int pos = 1; // create integer pos with value 1
    for (int i = 0; i < 5; i++) // for integer i = 0 to 5 exclusive
      if ((s >> i) & 1) a1[i] = pos++; // if (s >> i) & 1 != 0, change the value of a1[i] to pos and increment pos
    int pos2 = 1; // declare integer variable with name pos2 = 1
    for (int i = 5; i < 10; i++) // for i from 5 to 10 exclusive
      if ((s >> i) & 1) a2[i % 5] = pos2++; // if (s >> i) & 1 != 0, set a2[i % 5] to pos2 and increase pos2 by 1
    for (int i = 0; i < (v.size()); i++) { // for integer i = 0 to (ength of v exclusive
      int tmp = v[i]; // define integer tmp with value v[i]
      int l = a1[tmp / 5]; // define new integer called l with value = value of a1[tmp / 5]
      int r = a2[tmp % 5]; // new integer r = value of a2[tmp % 5]
      sum[l * 5 + r]++; // increment sum[l * 5 + r] by one
    } 
    bool flag = true; // create new boolean flag = true
    for (int i = 0; i < (25); i++) // in a for loop, change i from 0 to 25 exclusive incrementing i
      if (sum[i] > 1) { // if sum[i] is greater than 1
        flag = false; // assign the new value = false to flag
        break; // stop the loop
      } 
    if (!flag) continue; // if flag is false, skip the rest of the loop
    ans = min(ans, pos - 1 + pos2 - 1); // change ans to min of ans and pos - 1 + pos2 - 1
  } 
  cout << ans << '\n'; // print ans and '\n'
  return 0; 
} 