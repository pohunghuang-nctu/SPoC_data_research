
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bool v[12][12]; // declare boolean array v size 12 by 12
bool isOK(int a) { // declare isOK with integer a as argument, returning boolean
  int add[12]; // declare integer array add size 12
  int count = 0; // declare integer count = 0
  memset(add, 0, sizeof(add)); // set bytes from add to size of add to value 0
  for (int i = 0; i < 5; i++) { // for i = 0 to 5 exclusive
    for (int j = 5; j < 10; j++) { // for j = 5 to 10 exclusive
      if (v[i][j]) { // if v[i][j] is true
        if (((a & (1 << i)) == 0) && ((a & (1 << j)) == 0)) count++; // if (((a bitwise and (1 bitshift left i)) is 0) and ((a bitwise and (1 bitshift left j)) is 0)), increment count
        if (((a & (1 << i)) == 0) && ((a & (1 << j)) != 0)) add[j]++; // if (((a bitwise and (1 bitshift left i)) is 0) and ((a bitwise and (1 bitshift left j)) is not 0)), increment add[j]
        if (((a & (1 << i)) != 0) && ((a & (1 << j)) == 0)) add[i]++; // (((a bitwise and (1 bitshift left i)) is not 0) and ((a bitwise and (1 bitshift left j)) is 0)), increment add[i]
      } 
    } 
  } 
  if (count > 1) { return false; } // if count is greater than 1, return false from function
  for (int i = 0; i < 10; i++) { // for i = 0 to 10 exclusive
    if (add[i] > 1) return false; // if add[i] is greater than 1, return false from function
  } 
  return true; // return true from function
} 
int main() { 
  int N; // declare integer N
  while (cin >> N) { // while read N is true
    memset(v, 0, sizeof(v)); // set bytes from v to size of v to value 0
    string s; // declare string s
    for (int i = 0; i < N; i++) { // for i = 0 to N exclusive
      cin >> s; // read s
      int t; // declare integer t
      if (s[0] == 'R') // if s[0] is 'R'
        t = 0; // let t be 0
      else if (s[0] == 'G') // else if s[0] is 'G'
        t = 1; // let t be 1
      else if (s[0] == 'B') // else if s[0] is 'B'
        t = 2; // let t be 2
      else if (s[0] == 'Y') // else if s[0] is 'Y'
        t = 3; // let t be 3
      else if (s[0] == 'W') // else if s[0] is 'W'
        t = 4; // let t be 4
      int y = s[1] - '0' + 4; // declare integer y = s[1] - '0' + 4
      v[t][y] = true; // let v[t][y] be true
    } 
    int ans = 0x3f3f3f3f; // declare integer ans = 0x3f3f3f3f
    for (int i = 0; i < (1 << 10); i++) { // for i = 0 to i is less than ( 1 bitshift left 10 ), incrementing i
      if (isOK(i)) { // if result of run isOK(i) is true
        int t = i; // declare integer t = i
        int count = 0; // declare integer count = 0
        while (t) { // while t is true
          if (t & 1) { count++; } // if t bitwise and 1, increment count
          t /= 2; // let t be t / 2
        } 
        ans = min(ans, count); // let ans be minimumm of ans and count
      } 
    } 
    cout << ans << endl; // print ans and newline
  } 
} 