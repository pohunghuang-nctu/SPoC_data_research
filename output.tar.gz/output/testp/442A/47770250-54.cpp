
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int MAXN = 101; // create constant integer variable MAXN with value 101
int colo[MAXN], num[MAXN]; // define integer arrays colo and num with size MAXN
int mark[MAXN]; // mark is a new array of integers with size MAXN
int main() { 
  map<char, int> m; // create a map from characters to integers called m
  m['R'] = 0, m['G'] = 1, m['B'] = 2, m['Y'] = 3, m['W'] = 4; // change m['R'] to 0, m['G'] to 1, m['B'] to 2, m['Y'] to 3 and m['W'] to 4
  int n; // declare new integer variable n
  cin >> n; // read n
  for (int i = (0); i <= (n - 1); ++i) { // for integer i = 0 to n - 1 inclusive
    string second; // declare new string variable second
    cin >> second; // read user input to second
    colo[i] = m[second[0]]; // assign m[second[0]] to colo[i]
    num[i] = second[1] - '1'; // assign second[1] - '1' to num[i]
  } 
  int ans = 100; // create new integer called ans with value 100
  for (int i = 0; i < (1 << 10); i++) { // for integer i = 0 to (1<<10) exclusive incrementing i
    int req = __builtin_popcount(i); // define integer req = __builtin_popcount of i
    for (int j = (0); j <= (n - 1); ++j) mark[j] = 0; // set the values of n first elements of mark to 0
    for (int j = 0; j < 5; j++) { // for j from 0 to 5 exclusive
      if (i & (1 << j)) { // if i & (1 << j) != 0
        for (int k = (0); k <= (n - 1); ++k) // in a for loop, change k from 0 to n - 1 inclusive
          if (colo[k] == j) mark[k] |= (1 << j); // if colo[k] = j set mark[k] to mark[k] |= (1 << j)
      } 
    } 
    for (int j = 5; j < 10; j++) { // in a for loop, change j from 5 to 10 exclusive incrementing j
      if (i & (1 << j)) { // if i & (1 << j) != 0
        for (int k = (0); k <= (n - 1); ++k) // change k from 0 to n - 1 inclusive in a for loop
          if (num[k] == j - 5) mark[k] |= (1 << j); // if num[k] = j - 5, set mark[k] to mark[k] |= (1 << j)
      } 
    } 
    bool able = true; // create boolean able = true
    for (int j = (0); j <= (n - 1); ++j) { // for j from 0 to n - 1 inclusive incrementing j
      for (int k = (0); k <= (n - 1); ++k) { // in a for loop, change k from o to n - 1 inclusive
        if (colo[j] != colo[k] || num[j] != num[k]) { // if colo[j] != colo[k] or num[j] != num[k]
          if (mark[j] == mark[k]) able = false; // if mark[j] is equal to mark[k], change able to false
        } 
      } 
    } 
    if (able) ans = min(ans, req); // if able is true, assign min of ans and req to ans
  } 
  cout << ans << endl; // print ans
} 