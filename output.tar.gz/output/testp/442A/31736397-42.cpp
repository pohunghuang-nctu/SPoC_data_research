
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // n = integer
  cin >> n; // read n
  bool C[5][5] = {}; // C = boolean array of sizes 5, 5 with C = {}
  string color = "RGBYW"; // color = string = "RGBYW"
  string value = "12345"; // value = string = "12345"
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    string c; // declare a string c
    cin >> c; // read c
    for (int i = 0; i < 5; i++) // for i = 0 to 5 exclusive
      for (int j = 0; j < 5; j++) // for j = 0 to 5 exclusive
        if (c[0] == color[i] && c[1] == value[j]) C[i][j] = true; // if c[0] equals color[i] and c[1] equals value[j], set C[i][j] to true
  } 
  int ans = 25; // ans = integer set to 25
  for (int bc = 0; bc < 1 << 5; bc++) // for bc = 0 as long as bc is less than 1 shifted left 5 bits with increment bc + 1
    for (int bv = 0; bv < 1 << 5; bv++) { // for bv = 0 as long as bv is less than 1 shifted left 5 bits with increment bv + 1
      bool ok = true; // ok = boolean = true
      for (int c = 0; c < 5; c++) // for c = 0 to 5 exclusive
        if (bc >> c & 1) { // if bc shifted left c bitwise and 1 bits
          int t = 0; // t = integer = 0
          for (int v = 0; v < 5; v++) // for v = 0 to 5 exclusive
            if (!(bv >> v & 1)) t += (int)C[c][v]; // if bv shifted right v bitwise and 1 bits is false, add integer value of C[c][v] to t
          if (t > 1) ok = false; // if t is greater than 1, set ok to false
        } 
      for (int v = 0; v < 5; v++) // for v = 0 to 5 exclusive
        if (bv >> v & 1) { // if bv shifted right v bitwise and 1 bits
          int t = 0; // t = integer = 0
          for (int c = 0; c < 5; c++) // for c = 0 to 5 exclusive
            if (!(bc >> c & 1)) t += (int)C[c][v]; // if bc shifted right c bitwise and 1 bits is false, add integer value of C[c][v] to t
          if (t > 1) ok = false; // if t is greater than 1, set ok to false
        } 
      int t = 0; // t = integer = 0
      for (int c = 0; c < 5; c++) // for c = 0 to 5 exclusive
        for (int v = 0; v < 5; v++) // for v = 0 to 5 exclusive
          if (!(bc >> c & 1) && !(bv >> v & 1)) t += (int)C[c][v]; // if not (bc shifted right c bitwise and 1 bits) and not (bv shifted right v bitwise and 1 bits), add integer value of C[c][v] to t
      if (t > 1) ok = false; // if t is greater than 1, set ok to false
      if (ok) { // if ok
        int a = 0; // a = integer set to 0
        for (int i = 0; i < 5; i++) a += (bc >> i & 1) + (bv >> i & 1); // for i = 0 to 5 exclusive, add (bc shifted right i bitwise and 1 bits) + (bv shifted right i bitwise and 1 bits) to a
        ans = min(ans, a); // set ans to call min with ans, a
      } 
    } 
  cout << ans << endl; // display ans
} 