
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int b[20], ans, n; // declare integer array b size 20, integers ans, n
bool a[10][10]; // declare boolean array a size 10 by 10
bool check() { // declare check with no arguments, returning boolean
  int i, j, r, l, tot; // declare integers i, j, r, l, tot
  for (i = 1; i <= 5; i++) { // for i = 1 to 5 inclusive
    l = r = 0; // let l be r be 0
    for (j = 1; j <= 5; j++) { // for j = 1 to 5 inclusive
      if (a[i][j]) { // if a[i][j]
        l++; // increment l
        if (b[j]) { r++; } // if b[j], increment r
      } 
    } 
    if (l - 1 > r) return false; // if l - 1 is greater than r, return false from function
  } 
  for (i = 1; i <= 5; i++) { // for i = 1 to 5 inclusive
    l = r = 0; // let l be r be 0
    for (j = 1; j <= 5; j++) { // for j = 1 to 5 inclusive
      if (a[j][i]) { // if a[j][i] is true
        l++; // increment l
        if (b[5 + j]) r++; // if b[5+j], increment r
      } 
    } 
    if (l - 1 > r) return false; // if l - 1 is greater than r, return false from function
  } 
  tot = 0; // let tot be 0
  for (i = 1; i <= 5; i++) { // for i = 1 to 5 inclusive
    for (j = 1; j <= 5; j++) { // for j = 1 to 5 inclusive
      if (a[i][j] && !b[i + 5] && !b[j]) tot++; // if a[i][j] and not b[i+5] and not b[j], increment tot
    } 
  } 
  if (tot > 1) return false; // if tot is greater than 1, return false
  return true; // return true
} 
void dfs(int x) { // declare dfs with integer x as argument, returning void
  int i, sum; // declare integers i, sum
  if (x == 11) { // if x is 11
    if (check()) { // if result of run check is true
      sum = 0; // let sum be 0
      for (i = 1; i <= 11; i++) { // for i = 1 to 11 inclusive
        if (b[i] == 1) sum++; // if b[i] is 1, increment sum
      } 
      ans = min(sum, ans); // let ans be minimum of ( sum and ans )
    } 
    return; // return from function
  } 
  b[x] = 1; // let b[x] be 1
  dfs(x + 1); // run dfs(x+1)
  b[x] = 0; // let b[x] be 0
  dfs(x + 1); // run dfs with x + 1 as argument
} 
int main() { 
  int i, y; // declare integers i, y
  char ch; // declare character ch
  int k; // declare integer k
  cin >> n; // read n
  memset(a, false, sizeof(a)); // set bytes form a to size of a to value of false
  for (i = 1; i <= n; i++) { // for i = 1 to n inclusive
    cin >> ch >> k; // read ch and k
    if (ch == 'R') // if ch is 'R'
      y = 1; // let y be 1
    else if (ch == 'G') // else if ch is 'G'
      y = 2; // let y be 2
    else if (ch == 'B') // else if ch is 'B'
      y = 3; // let y be 3
    else if (ch == 'Y') // else if ch is 'Y'
      y = 4; // let y be 4
    else if (ch == 'W') // else if ch is 'W'
      y = 5; // let y be 5
    a[y][k] = true; // let a[y][k] be true
  } 
  memset(b, 0, sizeof(b)); // set bytes from b to size of b to value 0
  ans = 9999999; // let ans be 9999999
  ; // end statement
  dfs(1); // run dfs with 1 as argument
  cout << ans << endl; // print ans and newline
} 