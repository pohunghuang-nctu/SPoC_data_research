
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int a, n, m, i, j, t[200010] = {0}, p, num; // declare int variables a, n, m, i, j, p and num, and an array of ints t with size 200010 filled with 0
  while (cin >> n >> m) { // read n and m and loop further
    for (i = 1; i <= n; i++) cin >> t[i]; // read n elements from the user input to array t, starting from the index 1
    for (i = 1; i <= n; i++) { // start for loop from i = 1 to n inclusive
      t[i] += t[i - 1]; // change t[i] to t[i] + t[i - 1]
      num = t[i] / m; // set the value of num to t[i] / m
      t[i] -= num * m; // decrease t[i] by num * m
      cout << num; // print num
      if (i != n) cout << ' '; // if i != n, print ' ' to the stdout
    } 
    cout << endl; // print new line
  } 
  return 0; 
} 