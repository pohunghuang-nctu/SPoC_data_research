
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int a, n, m, i, j, t[200010] = {0}, p, num; // let a, n, m, i, j , p , num be integers , the 200010th element of integer array t is equal to 0
  while (cin >> n >> m) { // while read n , m
    for (i = 1; i <= n; i++) cin >> t[i]; // for i = 1 to n inclusive , read t[i]
    for (i = 1; i <= n; i++) { // for i = 1 to n inclusive
      t[i] += t[i - 1]; // increment t[i] by t[i - 1]
      num = t[i] / m; // num is equal to t[i] / m
      t[i] -= num * m; // decrement t[i] by num * m
      cout << num; // print num
      if (i != n) cout << ' '; // if i is not equal to n , print ' '
    } 
    cout << endl; // print newline
  } 
  return 0; 
} 