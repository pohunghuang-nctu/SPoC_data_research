
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int remain = 0, i, n, x, a[200001] = {0}, b[200001] = {0}; // remain, i, n, x = int with remain = 0 and a, b = int array of size 200001 and all values set to 0 each
  while (cin >> n >> x) { // loop while reading n then x
    for (i = 1; i <= n; i++) cin >> a[i]; // for i = 1 to n inclusive read a[i]
    for (i = 1; i <= n; i++) { // for i = 1 to n inclusive
      b[i] = (a[i] + remain) / x; // set b[i] to (a[i] + remain) / x
      remain = (a[i] + remain) % x; // set remain to (a[i] + remain) mod x
    } 
    for (i = 1; i <= n; i++) { // for i = 1 to n inclusive
      if (i < n) // if i < n
        cout << b[i] << " "; // print b[i] and " "
      else // else
        cout << b[i] << endl; // print b[i]
    } 
  } 
  return 0; 
} 