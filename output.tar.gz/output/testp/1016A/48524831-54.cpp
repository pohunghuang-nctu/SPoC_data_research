
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int a, n, m, i, j, t[200010] = {0}, p, num; // declare int variables a, n, m, i, j, p and num; declare int array t with 200010 elements
  while (cin >> n >> m) { // read n and m and keep looping
    for (i = 1; i <= n; i++) cin >> t[i]; // read user input to n consecutive elements of t, starting from the index 1
    for (i = 1; i <= n; i++) { // for i from 1 to n inclusive incrementing i
      t[i] += t[i - 1]; // add t[i - 1] to t[i]
      num = t[i] / m; // assign the new value = t[i] / m to num
      t[i] -= num * m; // decrease t[i] by num * m
      cout << num; // print num
      if (i != n) cout << ' '; // if i != n, print ' '
    } 
    cout << endl; // print new line to the standard output
  } 
  return 0; 
} 