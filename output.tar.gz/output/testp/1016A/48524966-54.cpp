
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int remain = 0, i, n, x, a[200001] = {0}, b[200001] = {0}; // declare integers remain, i, n and x with remain = 0, and arrays of integers a and b with size 200001
  while (cin >> n >> x) { // loop, reading n and x from the input
    for (i = 1; i <= n; i++) cin >> a[i]; // read n new elements to a from the input, starting from the index 1
    for (i = 1; i <= n; i++) { // in a for loop, change i from 1 to n inclusive
      b[i] = (a[i] + remain) / x; // set the value of b[i] to (a[i] + remain) / x
      remain = (a[i] + remain) % x; // assign (a[i] + remain) modulo x to remain
    } 
    for (i = 1; i <= n; i++) { // for i from 1 to n inclusive incrementing i
      if (i < n) // if i is less than n
        cout << b[i] << " "; // print b[i] and " "
      else // else
        cout << b[i] << endl; // print b[i] to the standard output
    } 
  } 
  return 0; 
} 