
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int MAX = 2e5; // MAX=200000
pair<pair<long long, long long>, long long> a[MAX + 9]; // a=array of MAX+9 pair of pair of long long, long long, long long
long long n, k, a0, x, y, m, ans, cnt, t, tmp; // n,k,a0,x,y,m,ans,cnt,t,tmp=long long
int main() { 
  cin >> n; // read n
  for (int i = 0; i < n; i++) { // for i=0 to n exclusive
    cin >> k >> a0 >> x >> y >> m, t = 0; // read k,a0,x,y,m, t=0
    for (int j = 0; j < k; j++) { // for j=0 to k exclusive
      if (cnt <= MAX) a[cnt++] = {{t, a0}, i}; // if cnt<=MAX a[cnt]=t, a0, i, increment cnt
      tmp = (a0 * x + y) % m; // tmp=(a0*x+y) modulo m
      if (tmp < a0 && j != k - 1) t++; // if tmp<a0 and j is not k-1 increment t
      a0 = tmp; // a0=tmp
    } 
    ans = max(ans, t); // ans=max(ans, t)
  } 
  cout << ans << '\n'; // print ans
  if (cnt <= MAX) { // if cnt<=MAX
    sort(a, a + cnt); // sort first cnt items of a
    for (int i = 0; i < cnt; i++) cout << a[i].first.second << " " << a[i].second + 1 << '\n'; // for i=0 to cnt exclusive print second item of first item of a[i], space, second item of a[i]+1
  } 
} 