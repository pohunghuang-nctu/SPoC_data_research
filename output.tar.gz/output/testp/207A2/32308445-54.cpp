
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, count = 0; // let n and count be long longs with count = 0
  cin >> n; // read standard input to n
  const int max_i = 2e5; // declare constant integer max_i = 2e5
  int counter = 0; // declare new integer counter with value 0
  tuple<int, int, int> data[max_i + 9]; // create an array of tuples of int, int, int> called data with max_i + 9 elements
  for (int i = 0; i < n; i++) { // in a for loop, change i from 0 to n exclusive incrementing i
    long long k, a0, x, y, m, t = 0, a = 0; // declare long long variables k, a0, x, y, m, t and a where t and a = 0
    cin >> k >> a0 >> x >> y >> m; // read from the input to k, a0, x, y and m
    for (int j = 0; j < k; j++) { // in a for loop, change j from 0 to k exclusive
      if (counter <= max_i) { data[counter++] = make_tuple(t, a0, i); } // if counter <= max_i, change the value of data[counter] to the new tuple from make_tuple(t, a0, i) and increment counter
      a = (a0 * x + y) % m; // change the value of a to (a0 * x + y) % m
      if (a < a0 && j != k - 1) { t++; } // if a < a0 and j != k - 1, increment t by one
      a0 = a; // change a0 to a
    } 
    count = max(count, t); // change the value of count to max of count and t
  } 
  cout << count << endl; // print count
  if (counter <= max_i) { // if counter <= max_i
    sort(data, data + counter); // sort data from the start to the index = counter
    for (int i = 0; i < counter; i++) { cout << get<1>(data[i]) << " " << get<2>(data[i]) + 1 << endl; } // for i from 0 to counter exclusive, print get<1>(data[i]), " " and get<2>(data[i]) + 1
  } 
} 