
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long a1, a2, n, k, second = 0, ans = 0, ans1; // let a1, a2, n, k, second, ans, and ans1 be long long ints with second = 0 and ans = 0
vector<pair<long long, pair<long long, long long>>> h; // let h be a vector of pairs of long longs and pairs of long longs and long longs
void read(void) { // in function read
  cin >> n; // read n
  for (int i = 0, x, y, m; i < n; ++i) { // for i=0 to n exclusive with x, y, m ints
    cin >> k; // read k
    second += k; // set second to second + k
    cin >> a1; // read a1
    long long t = a1; // let t be a long long int with value a1
    cin >> x >> y >> m; // read x and y and m
    h.push_back(make_pair(0, make_pair(a1, i + 1))); // append the pair 0 and the pair a1 and i+1 to h
    ans1 = 0; // set ans1 to 0
    for (int j = 1; j < k; ++j) { // for j=1 to k exclusive with j preincremented
      a2 = (a1 * x + y) % m; // set a2 to (a1* x+y) mod m
      if (a2 < a1) ans1++; // if a2 is less than a1 increment ans1
      a1 = a2; // set a1 to a2
      t = max(t, a1); // set t to max of t and a1
      if (h.size() <= 200000) h.push_back(make_pair(ans1, make_pair(a1, i + 1))); // if size of h is less than or equal to 200000 append the pair ans1 and pair a1 and i+1 to h
    } 
    ans = max(ans, ans1); // set ans to max of ans and ans1
  } 
  sort(h.begin(), h.end()); // sort h
  cout << ans << "\n"; // print ans and newline
  if (second <= 200000) // if second is less than or equal to 200000
    for (int i = 0; i < second; ++i) cout << h[i].second.first << " " << h[i].second.second << "\n"; // for i=0 to second inclusive with i preincremented, print the first item of the second item in h[i] followed by space and the second item of the second item in h[i] and then newline
} 
int main() { 
  read(); // call read
  return 0; 
} 