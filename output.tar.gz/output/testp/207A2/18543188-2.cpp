
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int MAX = 2e5; // let MAX be a constant integer MAX = 2e5
pair<pair<long long, long long>, long long> a[MAX + 9]; // pair<pair<long long, long long>, long long> a[MAX + 9]
long long n, k, a0, x, y, m, ans, cnt, t, tmp; // let n, k, a0, x, y, m, ans, cnt, t, tmp be long integers
int main() { 
  cin >> n; // read n
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> k >> a0 >> x >> y >> m, t = 0; // read k, a0, x, y, m, the value of t is equal to 0
    for (int j = 0; j < k; j++) { // for j = 0 to k exclusive
      if (cnt <= MAX) a[cnt++] = {{t, a0}, i}; // if cnt <= MAX , a[cnt++] is equal to {{t, a0}, i}
      tmp = (a0 * x + y) % m; // tmp is equal to (a0 * x + y) modulo m
      if (tmp < a0 && j != k - 1) t++; // if tmp is less than a0 and j is not equal to k - 1 , increment t by 1
      a0 = tmp; // a0 is equal to tmp
    } 
    ans = max(ans, t); // ans is equal to maximum of ans and t
  } 
  cout << ans << '\n'; // print ans and newline
  if (cnt <= MAX) { // if cnt <= MAX
    sort(a, a + cnt); // sort the values a, a + cnt
    for (int i = 0; i < cnt; i++) cout << a[i].first.second << " " << a[i].second + 1 << '\n'; // for i = 0 to cnt exclusive, print a[i].first.second and space and a[i].second + 1 and newline
  } 
} 