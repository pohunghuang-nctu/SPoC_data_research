
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  string s; // declare string variable s
  cin >> s; // read s
  int n = ((int)(s).size()); // declare integer variable n
  int ab = 1000000, ba = 1000000; // create integers ab and ba = 1000000
  for (int i = 0; i < int(n - 1); i++) // for integer i = 0 to n - 1 exclusive
    if (s[i] == 'A' && s[i + 1] == 'B') { // if s[i] = 'A' and s[i + 1] is equal to 'B'
      ab = i + 2; // change ab to i + 2
      break; // break the loop
    } 
  for (int i = 0; i < int(n - 1); i++) // for integer i = 0 to n - 1 exclusive
    if (s[i] == 'B' && s[i + 1] == 'A') { // if s[i] is equal to 'B' and s[i + 1] is equal to 'A'
      ba = i + 2; // assign i + 2 to ba
      break; // break the loop
    } 
  bool flag = false; // create bool flag = false
  for (int i = int(ab); i < int(n - 1); i++) // for integer i = ab to n - 1 exclusive
    if (s[i] == 'B' && s[i + 1] == 'A') { // if s[i] = 'B' and s[i + 1] is equal to 'A'
      flag = true; // set flag to true
      break; // stop the loop
    } 
  for (int i = int(ba); i < int(n - 1); i++) // for i = ba to n - 1 exclusive
    if (s[i] == 'A' && s[i + 1] == 'B') { // if s[i] = 'A' and s[i + 1] = 'B'
      flag = true; // change flag to true
      break; // stop the loop
    } 
  cout << (flag ? "YES" : "NO") << endl; // print "YES" if flag is true or "NO" if it is false
  return 0; 
} 