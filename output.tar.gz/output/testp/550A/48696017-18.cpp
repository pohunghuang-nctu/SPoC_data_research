
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

string s; // s = string
bool check[2]; // check = boolean array of size 2
int d[100001][2][2]; // d = integer array of size 100001, width of 2, and depth of 2
int go(int x, int y, int z) { // in function go with argument integer x, integer y, and integer z and returns an integer
  if (x >= s.size()) { // if x >= size of s
    if (y && z) { return 1; } // if y and z are nonzero, then return 1
    return 0; 
  } 
  if (d[x][y][z] != -1) return d[x][y][z]; // if d[x][y][z] is not -1, then return d[x][y][z]
  d[x][y][z] = go(x + 1, y, z); // d[x][y][z] = the result of calling go with arguments x + 1, y, z
  if (x < s.size() - 1 && s[x] == 'A' && s[x + 1] == 'B' && y == 0) { d[x][y][z] = max(d[x][y][z], go(x + 2, 1, z)); } // if x < size of s - 1 and s[x] is A and s[x + 1] is B and y is 0, then d[x][y][z] is the bigger value between d[x][y][z] and the result of calling go with arguments x + 2, 1, z
  if (x < s.size() - 1 && s[x] == 'B' && s[x + 1] == 'A' && z == 0) { d[x][y][z] = max(d[x][y][z], go(x + 2, y, 1)); } // if x < size of s - 1 and s[x] is B and s[x + 1] is A and y is 0, then d[x][y][z] is the bigger value between d[x][y][z] and the result of calling go with arguments x + 2, y, 1
  return d[x][y][z]; // return d[x][y][z]
} 
int main() { 
  cin >> s; // read s
  memset(d, -1, sizeof(d)); // set all values of d to -1
  if (go(0, 0, 0) == 1) // if the result of calling go with arguments 0, 0, 0 is 1
    cout << "YES" << '\n'; // print YES
  else // else
    cout << "NO" << '\n'; // print NO
} 