
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

void fastIo() {} // void function fastIo, blank
string s; // s = string
int indx; // indx = integer
int check(string temp) { // in int function check that takes string temp
  int i; // let i be an int
  for (int i = 0; i < s.length() - 1; i++) { // for i = 0 to length of s inclusive
    if (i != indx && i + 1 != (indx) && i != (indx + 1)) { // if i different indx and i + 1 diffenrent indx and i different indx + 1
      if (s.substr(i, 2) == temp) { // if substring of s between i and 2 is same as temp
        indx = i; // set indx to i
        return 1; // return 1
      } 
    } 
  } 
  return 0; 
} 
int main() { 
  fastIo(); // call fastIo()
  cin >> s; // read s
  indx = -2; // indx = -2
  int ans = check("AB"); // ans = integer = check of "AB"
  ans += check("BA"); // increment ans by check of "BA"
  if (ans == 2) { // if ans is 2
    cout << "YES" << endl; // print YES
  } else { // else
    ans = 0; // set ans to 0
    indx = -2; // set indx to -2
    ans = check("BA"); // set ans to check of "BA"
    ans += check("AB"); // increment asn by check of "AB"
    if (ans == 2) { // if ans is 2
      cout << "YES" << endl; // print YES
    } else { // else
      cout << "NO" << endl; // print NO
    } 
  } 
  return 0; 
} 