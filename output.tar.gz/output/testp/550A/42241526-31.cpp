
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  string s1; // s1=string
  while (cin >> s1) { // while read s1
    if (s1.length() < 3) // if length of s1 < 3
      cout << "NO" << endl; // print "NO"
    else { // else
      int a = s1.find("AB"); // a=position of "AB" in s1
      int b = s1.find("BA", a + 2); // b=position of "BA" in s1 starting from a+2
      int c = s1.find("BA"); // c=position of "BA" in s1
      int d = s1.find("AB", c + 2); // d=position of "AB" in s1 starting from c+2
      if (a != -1 && b != -1 || c != -1 && d != -1) // if a is not -1 and b is not -1 or c is not -1 and d is not -1
        cout << "YES" << endl; // print "YES"
      else // else
        cout << "NO" << endl; // print "NO"
    } 
  } 
  return 0; 
} 