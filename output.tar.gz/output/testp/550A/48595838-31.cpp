
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bool ab1 = false, ba1 = false, ab2 = false, ba2 = false; // ab1,ba1,ab2,ba2=false
int main() { 
  string s; // s=string
  cin >> s; // read s
  int n = s.size(); // n=size of s
  for (int i = 0; i < n - 1; ++i) { // for i=0 to n-1 exclusive
    if (s[i] == 'A' && s[i + 1] == 'B' && !ab1) { // if s[i] is 'A' and s[i+1] is 'B' and not ab1
      ab1 = true; // ab1=true
      i++; // increment i
    } else if (s[i] == 'B' && s[i + 1] == 'A' && ab1) { // else if s[i] is 'B' and s[i+1] is 'A' and ab1
      ba1 = true; // ba1=true
      i++; // increment i
    } 
  } 
  for (int i = 0; i < n - 1; ++i) { // for i=0 to n-1 exclusive
    if (s[i] == 'B' && s[i + 1] == 'A' && !ba2) { // if s[i] is 'B' and s[i+1] is 'A' and not ba2
      ba2 = true; // ba2=true
      i++; // increment i
    } else if (s[i] == 'A' && s[i + 1] == 'B' && ba2) { // else if s[i] is 'A' and s[i+1] is 'B' and ba2
      ab2 = true; // ab=true
      i++; // increment i
    } 
  } 
  if (ab1 && ba1) // if ab1 and ba1
    cout << "YES\n"; // print "YES"
  else if (ab2 && ba2) // else if ab2 and ba2
    cout << "YES\n"; // print "YES"
  else // else
    cout << "NO\n"; // print "NO"
} 