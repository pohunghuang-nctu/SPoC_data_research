
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const long long maxn = 1e5 + 8; // maxn = const long long with maxn = 1e5 + 8
string t; // t = string
int vis[maxn]; // vis = int array of size maxn
int main() { 
  cin >> t; // read t
  int len = t.size(); // len = int with len = size of t
  if (len <= 3) // if len is less than 4
    puts("NO"); // print "NO"
  else { // else
    int a, b, c, d; // a, b, c, d = int
    a = t.find("AB"); // set a to find of "AB" on t
    b = t.find("BA", a + 2); // set b to find of "BA" and a + 2 of t
    c = t.find("BA"); // set c to find of "BA" on t
    d = t.find("AB", c + 2); // set d to find of "AB" and c + 2 of t
    if ((a != -1 && b != -1) || (c != -1 && d != -1)) // if a and b are not -1 or c and d are not -1
      puts("YES"); // print "YES"
    else // else
      puts("NO"); // print "NO"
  } 
  return 0; 
} 