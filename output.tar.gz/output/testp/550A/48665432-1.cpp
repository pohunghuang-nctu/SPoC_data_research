
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  char s[100003]; // create character array s with size 100003
  char *c; // create character pointer c
  cin >> s; // read s
  if ((c = strstr(s, "AB")) != NULL && strstr(c + 2, "BA") != NULL) { // if ( set c to first occurrence of "AB" in s ) is not NULL and first occurrence of "BA" in c + 2 is not null
    cout << "YES" << endl; // print "YES" print newline
    return 0; 
  } 
  if ((c = strstr(s, "BA")) != NULL && strstr(c + 2, "AB") != NULL) { // if ( set c to first occurrence of "BA" in s ) is not NULL and first occurrence of "AB" in c + 2 is not null
    cout << "YES" << endl; // print "YES" print newline
    return 0; 
  } 
  cout << "NO" << endl; // print "NO" print newline
} 