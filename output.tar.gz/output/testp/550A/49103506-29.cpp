
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

void solve() { // define void argumentless function solve
  string s; // define string s
  cin >> s; // read s
  int n = s.length(); // define integer n to be lenth of s
  bool flag = false; // define bool flag to be F
  for (int i = 0; i < n - 1; i++) { // for int i from 0 to n - 1 (exclusive) by 1
    if (s[i] == 'A' && s[i + 1] == 'B') { // if s[i] is 'A' and s[i + 1] is 'B'
      for (int j = i + 2; j < n - 1; j++) { // for int j from i + 2 to n - 1 (exclusive) by 1
        if (s[j] == 'B' && s[j + 1] == 'A') { flag = true; } // if s[j] is character B and s[j + 1] is character A, then set flag to true
      } 
      break; // break out of loop
    } 
  } 
  for (int i = 0; i < n - 1; i++) { // for int i from 0 to n - 1 (exclusive) by +1
    if (s[i] == 'B' && s[i + 1] == 'A') { // if s[i] = character B and s[i + 1] = character A
      for (int j = i + 2; j < n - 1; j++) { // for int j by +1 from i + 2 to n - 1 (exclusive)
        if (s[j] == 'A' && s[j + 1] == 'B') { flag = true; } // if s[j] = 'A' and s[j + 1] = 'B', then assign true to flag
      } 
      break; // break out
    } 
  } 
  if (flag) { // if flag is T
    cout << "YES" << endl; // print "YES" and newline
  } else // else
    cout << "NO" << endl; // print "NO" and newline
} 
int main() { 
  int t = 1; // define integer t, set to 1
  while (t--) { solve(); } // while t, decrement it and solve()
  return 0; 
} 