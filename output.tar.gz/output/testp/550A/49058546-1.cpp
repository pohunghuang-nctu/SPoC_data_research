
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

inline size_t key(int i, int j) { // declare inline key with integers i, j as arguments, returning size_t
  return (size_t)i << 32 | (unsigned int)j; // return size_t casted i bitshift left 32 bitwise or unsigned integer casted j
} 
long long max(long long a, long long b) { // declare max with long longs a, b as arguments, returning long long
  return a > b ? a : b; // return a if a is greater than b, else b from function
} 
long long min(long long a, long long b) { // declare min with long longs a, b as arguments, returning long long
  return a < b ? a : b; // return a if a is less than b, else b from function
} 
int main() { 
  string s; // create string s
  cin >> s; // read s
  int a1 = -1; // create integer a1 with a1 = -1
  int a2 = INT_MAX; // create integer a2 with a2 = INT_MAX
  int b1 = -1; // create integer b1 with b1 = -1
  int b2 = INT_MAX; // create integer b2 with b2 = INT_MAX
  int a = 0, b = 0; // create integers a, b, with a = 0, b = 0
  for (int i = 0; i < s.length() - 1; i++) { // for i = 0 to length of s - 1 exclusive
    if (s[i] == 'A' && s[i + 1] == 'B') { // if s[i] is 'A' and s[i+1] is 'B'
      a1 = max(a1, i); // set a1 to maximum of a1 and i
      a2 = min(a2, i); // set a2 to maximum of a2 and i
      a = 1; // set a to 1
    } else if (s[i] == 'B' && s[i + 1] == 'A') { // else if s[i] is 'B' and s[i+1] is 'A'
      b1 = max(b1, i); // set b1 to maximum of b1 and i
      b2 = min(b2, i); // set b2 to minimum of b2 and i
      b = 1; // set b to 1
    } 
  } 
  if (a && b && (a1 > b2 + 1 || b1 > a2 + 1)) { // if a and b and ( a1 is greater than b2 + 1 or b1 is greater than a2 + 1 )
    cout << "YES\n"; // print "YES\n"
  } else { // else
    cout << "NO\n"; // print "NO\n"
  } 
  return 0; 
} 