
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  string str; // create string str
  cin >> str; // read input to str
  if (str.find("AB") == string::npos || str.find("BA") == string::npos) { // if there is no "AB" or "BA" in the str
    cout << "NO" << endl; // print "NO"
    return 0; 
  } 
  size_t pos = str.find("AB"); // declare size_t pos = index of "AB" in str
  if (str.find("BA", pos + 2) != string::npos) { // if there is substring "BA" after pos + 2 in str
    cout << "YES" << endl; // print "YES"
    return 0; 
  } 
  size_t posn = str.find("BA"); // declare size_t posn = index of "BA" in str
  if (str.find("AB", posn + 2) != string::npos) { // if there is substring "AB" after posn + 2 in str
    cout << "YES" << endl; // print "YES"
    return 0; 
  } 
  cout << "NO" << endl; // print "NO"
  return 0; 
} 