
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  string a, b; // create strings a, b
  int judge = 0, judge2 = 0, ab = 0, ba = 0; // create integers judge, judge2, ab, ba with judge = 0, judge2 = 0, ab = 0, ba = 0
  cin >> a; // read a
  b = a; // set b to a
  for (int i = 0; i < a.size(); i++) { // for i = 0 to size of a exclusive
    if ((a[i] == 'A' && a[i + 1] == 'B') && ab < 1) { // if (a[i] is 'A' and a[i + 1] is 'B') and ab is less than 1
      judge++; // increment judge
      a[i] = a[i + 1] = 'c'; // set a[i] to a[i+1] to 'c'
      ab++; // increment ab
    } 
    if ((a[i] == 'B' && a[i + 1] == 'A') && ba < 1) { // if (a[i] is 'B' and a[i + 1] is 'A') and ba is less than 1
      judge++; // increment judge
      a[i] = a[i + 1] = 'c'; // set a[i] to a[i+1] to 'c'
      ba++; // increment ba
    } 
  } 
  ab = 0; // set ab to 0
  ba = 0; // set ba to 0
  a = b; // set a to b
  for (int i = a.size() - 1; i >= 0; i--) { // for i = size of a - 1 to 0 inclusive, decrementing i
    if ((a[i] == 'A' && a[i + 1] == 'B') && ab < 1) { // if (a[i] is 'A' and a[i + 1] is 'B') and ab is less than 1
      judge2++; // increment judge2
      a[i] = a[i + 1] = 'c'; // set a[i] to a[i+1] to 'c'
      ab++; // increment ab
    } 
    if ((a[i] == 'B' && a[i + 1] == 'A') && ba < 1) { // if (a[i] is 'B' and a[i + 1] is 'A') and ba is less than 1
      judge2++; // increment judge2
      a[i] = a[i + 1] = 'c'; // set a[i] to a[i+1] to 'c'
      ba++; // increment ba
    } 
  } 
  if (judge == 2 || judge2 == 2) // if judge2 is 2 or judge2 is 2
    cout << "YES" << endl; // print "YES" print newline
  else // else
    cout << "NO" << endl; // print "NO" print newline
} 