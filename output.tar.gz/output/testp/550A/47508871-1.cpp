
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  char s[100005], *p; // create character array s with size 100005 create character pointer p
  int x; // create integer x
  cin >> s; // read s
  if ((p = strstr(s, "AB")) && (strstr(p + 2, "BA"))) { // if ( p is first occurrence of "AB" in s ) and ( first occurrence of "BA" in p + 2 )
    cout << "YES" << endl; // print "YES" print newline
  } else if ((p = strstr(s, "BA")) && (strstr(p + 2, "AB"))) { // else if (p is first occurrence of "BA" in s ) and ( first occurrence of "AB" in p + 2 )
    cout << "YES" << endl; // print "YES" print newline
  } else { // else
    cout << "NO" << endl; // print "NO" print newline
  } 
  return 0; 
} 