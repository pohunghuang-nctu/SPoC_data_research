
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  string ak; // create string ak
  cin >> ak; // read ak
  int sz = ak.size(); // create integer sz = ak.size()
  int f1 = 0, f2 = 0, f3 = 0, f4 = 0, i; // create integers f1 = 0, f2 = 0, f3 = 0, f4 = 0, and i
  for (i = 0; i < sz; i++) { // for i = 0 to sz exclusive
    if (ak[i] == 'A' && ak[i + 1] == 'B' && f1 == 0) { // if ak[i] is equal to 'A' and ak[i + 1] is equal to 'B' and f1 is equal to 0
      f1 = 1; // set f1 to 1
      i++; // increment i
      continue; // continue to the next loop iteration
    } 
    if (ak[i] == 'B' && ak[i + 1] == 'A' && f1 == 1) { f2 = 1; } // if ak[i] is equal to 'B' and ak[i + 1] is equal to 'A' and f1 is equal to 1, set f2 to 1
  } 
  for (i = 0; i < sz; i++) { // for i = 0 to sz exclusive
    if (ak[i] == 'B' && ak[i + 1] == 'A' && f3 == 0) { // if ak[i] is equal to 'B' and ak[i + 1] is equal to 'A' and f3 is equal to 0
      f3 = 1; // set f3 to 1
      i++; // increment i
      continue; // continue to the next loop iteration
    } 
    if (ak[i] == 'A' && ak[i + 1] == 'B' && f3 == 1) { f4 = 1; } // if ak[i] is equal to 'A' and ak[i + 1] is equal to 'B' and f3 is equal to 1, set f4 to 1
  } 
  if (f1 == 1 && f2 == 1) { // if f1 is equal to 1 and f2 is equal to 1
    cout << "YES" << endl; // print "YES"
    return 0; 
  } 
  if (f3 == 1 && f4 == 1) { // if f3 is equal to 1 and f4 is equal to 1
    cout << "YES" << endl; // print "YES"
    return 0; 
  } 
  cout << "NO" << endl; // print "NO"
  return 0; 
} 