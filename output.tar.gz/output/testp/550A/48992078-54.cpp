
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 1e5 + 5; // declare const int N = 1e5 + 5
char str[N]; // create character array str with N elements
bool flg[N], f1, f2; // declare bool variables f1 and f2 and bool array flg with size N
int len; // create integer len
inline void ac() { // inline void function ac
  cout << "YES" << endl; // print "YES"
} 
inline void wa() { // inline void function wa
  cout << "NO" << endl; // print "NO"
} 
inline bool judge1(int x) { // inline bool function judge1 with int argument x
  return (str[x] == 'A' && str[x + 1] == 'B') ? true : false; // return true if str[x] = 'A' && str[x + 1] = 'B', or else false
} 
inline bool judge2(int x) { // inline bool function judge2 with int argument x
  return (str[x] == 'B' && str[x + 1] == 'A') ? true : false; // return true if str[x] = 'B' && str[x + 1] = 'A' or else false
} 
inline bool check1(int x) { // function check1 with int argument x that returns inline bool
  flg[x] = flg[x + 1] = true; // set flg[x] to set flg[x + 1] to true
  for (int i = 0; i < len - 1; i++) // loop i from 0 to len-1 exclusive
    if (!flg[i] && !flg[i + 1] && judge2(i)) return true; // return true if flg[i] is false and flg[i + 1] is false and judge2(i) is true
  flg[x] = flg[x + 1] = false; // set flg[x] and flg[x + 1] to false
  return false; // return false
} 
inline bool check2(int x) { // check2 is a an inlined bool function with int argument x
  flg[x] = flg[x + 1] = true; // change flg[x + 1] and flg[x] to true
  for (int i = 0; i < len - 1; i++) // for integer i = 0 to len - 1 exclusive
    if (!flg[i] && !flg[i + 1] && judge1(i)) return true; // return true if flg[i] is false and flg[i + 1] is false and judge1(i) is true
  flg[x] = flg[x + 1] = false; // assign false to flg[x + 1] and flg[x]
  return false; // return false
} 
int main() { 
  cin >> str; // read input to str
  len = strlen(str); // set len to length of str
  memset(flg, false, sizeof(flg)); // set first sizeof(flg) bytes at the pointer flg to false
  f1 = f2 = false; // change value of f1 and f2 to false
  for (int i = 0; i < len - 1; i++) { // loop i from 0 to len - 1 exclusive
    if (!f1 && judge1(i)) { // if f1 is false and judge1(i) is true
      f1 = !f1; // invert f1
      if (check1(i)) { // if check1(i) is true
        ac(); // call ac()
        return 0; 
      } 
    } 
    if (!f2 && judge2(i)) { // if f2 is false and judge2(i) is true
      f2 = !f2; // invert f2
      if (check2(i)) { // if check2(i) is true
        ac(); // call ac()
        return 0; 
      } 
    } 
  } 
  wa(); // call wa()
} 