
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bool kontol = true; // declare boolean variable kontol = true
string S; // create string S
int Q, W, E, R; // declare ints Q, W, E and R
int H, U; // declare integer variables H and U
int main() { 
  cin >> S; // read S
  Q = S.find("BA"); // assign index of "BA" in S to Q
  W = S.rfind("AB"); // assign last index of "AB" in S to W
  E = S.rfind("BA"); // assign last index of "BA" in S to E
  R = S.find("AB"); // assign index of "AB" in S to R
  if (Q == -1 || W == -1) { kontol = false; } // if Q = -1 or W = -1, set kontol to false
  if (abs(Q - W) == 1) { H = 1; } // if abs(Q - W) = 1, set H to 1
  if (abs(E - R) == 1) { U = 1; } // if abs(E - R) = 1, set U to 1
  if (H == 1 && U == 1) kontol = false; // if H = 1 and U = 1, assign false to kontol
  if (kontol) // if kontol is true
    cout << "YES" << endl; // print "YES"
  else // else
    cout << "NO" << endl; // print "NO"
} 