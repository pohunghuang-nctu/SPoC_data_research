
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  string s; // create string s
  cin >> s; // read s
  for (int i = 0; i < s.length() - 1; i++) { // for i=0 to (length of s) - 1 exclusive
    int i2 = i + 1; // create integer i2=i+1
    if (s[i] == 'A' && s[i2] == 'B') { // if s[i]= A and s[i2]=B
      for (int j = 0; j < s.length() - 1; j++) { // for j=0 to length of s-1 exclusive
        int j2 = j + 1; // let j2 be a int with j2=j+1
        if (s[j] == 'B' && s[j2] == 'A') { // if s[j]= B and s[j2]= A
          if (i != j && i != j2 && i2 != j && i2 != j2) { // if i is not equal to j and i is not equal to j2 and i2!=j and i2 is not equal to j2
            cout << "YES" << endl; // print YES
            return 0; 
          } 
        } 
      } 
    } 
  } 
  cout << "NO" << endl; // print NO
  return 0; 
} 