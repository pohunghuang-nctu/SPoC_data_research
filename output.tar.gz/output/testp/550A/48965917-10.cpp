
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  char s[500005]; // s = char array of size 500005
  cin >> s; // read s
  int dp1[500005], dp2[500005], idx1 = 0, idx2 = 0; // dp1, dp2 = int array of size 500005 each and idx1, idx2 = int with idx1 = 0 and idx2 = 00
  for (int i = 0; i < strlen(s); i++) { // for i = 0 to strlen of s
    if (s[i] == 'A' && s[i + 1] == 'B') { // if s[i] is 'A' and s[i + 1] is 'B'
      dp1[idx1++] = i; // set dp1[idx1] to i then increment idx1
    } else if (s[i] == 'B' && s[i + 1] == 'A') { // else if s[i] is 'B' and s[i + 1] is 'A'
      dp2[idx2++] = i; // set dp2[idx2] to i then increment idx2
    } 
  } 
  bool flag = false; // flag = bool with flag = false
  for (int i = 0; i < idx1; i++) { // for i = 0 to idx1
    for (int j = 0; j < idx2; j++) { // for j = 0 to idx2
      if (abs(dp2[j] - dp1[i]) > 1) { // if absolute of dp2[j] - dp1[i] is greater than 1
        flag = true; // set flag to true
        break; // break
      } 
    } 
  } 
  if (flag) { // if flag is true
    cout << "YES" << endl; // print "YES"
  } else { // else
    cout << "NO" << endl; // print "NO"
  } 
  return 0; 
} 