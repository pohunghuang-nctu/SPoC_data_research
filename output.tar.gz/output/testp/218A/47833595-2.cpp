
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, k; // let n, k be integers
  cin >> n >> k; // read n, k
  int r[2 * n + 1]; // r = array of integers of length 2 * n + 1
  for (int i = 0; i < 2 * n + 1; i++) cin >> r[i]; // for i = 0 to 2 * n + 1 exclusive, read r[i]
  for (int i = 0; i < 2 * n + 1; i++) { // for i = 0 to 2 * n + 1 exclusive
    if ((i + 1) % 2 == 0 && k > 0 && r[i] - 1 > r[i + 1] && r[i - 1] < r[i] - 1) { // if (i + 1) modulo 2 is equal to 0 and k is greater than 0 and r[i] - 1 is greater than r[i + 1] and r[i - 1] is less than r[i] - 1
      cout << r[i] - 1; // print r[i] - 1
      --k; // decrement k by 1
    } else { // else do the following
      cout << r[i]; // print r[i]
    } 
    if (i == 2 * n) // if i is equal to 2 * n
      cout << "\n"; // print newline
    else // else do the following
      cout << " "; // print space
  } 
  return 0; 
} 