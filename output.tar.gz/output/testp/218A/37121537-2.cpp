
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int maxn = 100010; // let maxn be a constant integer with maxn = 100010
const int mo = 1e9 + 7; // let mo be a constant integer with mo = 1e9 + 7
long long ans; // let ans be a long integer
int f, n, m, h; // let f, n, m, h be integers
int a[maxn], c[maxn], k, sum[maxn]; // let a, c, k , sum be integers with a = array of integers of length maxn, c = array of integers of length maxn, sum = array of integers of length maxn
int b[maxn], flag, tmp; // let b, flag, tmp be integers with b = array of integers of length maxn
int dp[maxn]; // dp = array of integers of length maxn
string s; // let s be a string
int main() { 
  int T; // let T be a integer
  int cas = 1; // let cas be a integer with cas = 1
  while (cin >> n >> m) { // while read n, m
    n = 2 * n + 1; // n is equal to 2 * n + 1
    int ma = -1; // let ma be a integer with ma = -1
    for (int i = 0; i < n; i++) { cin >> a[i]; } // for i = 0 to n exclusive, read a[i]
    for (int i = 1; i < n - 1; i++) { // for i = 1 to n - 1 exclusive
      if ((a[i] > (a[i - 1] + 1)) && (a[i] > (a[i + 1] + 1)) && (m > 0)) { // if a[i] is greater than (a[i - 1] + 1) and a[i] is greater than (a[i + 1] + 1) and m is greater than 0
        m--; // decrement m by 1
        a[i]--; // decrement a[i] by 1
      } 
    } 
    for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
      cout << a[i]; // print a[i]
      if (i < n - 1) cout << " "; // if i is less than n - 1 , print space
    } 
    cout << endl; // print newline
  } 
  return 0; 
} 