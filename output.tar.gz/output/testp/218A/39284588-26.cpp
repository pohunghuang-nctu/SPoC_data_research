
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, k, a[1010]; // create int n, k, a[1010]
  cin >> n >> k; // read n and k
  for (int i = 1; i <= 2 * n + 1; i++) { cin >> a[i]; } // for i=1 to 2*n+1 inclusive, read a[i]
  cout << a[1]; // read a[1]
  for (int i = 2; i <= 2 * n; i++) { // for i=2 to 2*n inclusive
    if (i % 2 == 0) { // if i is even
      int b = a[i] - 1; // set b to a[i] - 1
      if (a[i - 1] < b && a[i + 1] < b && k) { // if a[i - 1] < b and a[i + 1] < b and k different from 0
        a[i] = b; // set a[i] to b
        k--; // decrement k
      } 
    } 
    cout << " " << a[i]; // print " ", a[i]
  } 
  cout << " " << a[2 * n + 1] << endl; // print " ", a[2 * n + 1]
  return 0; 
} 