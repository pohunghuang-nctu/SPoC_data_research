
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int a[1010]; // let a be an int array of length 1010
int main() { 
  int N, K; // let N, K be ints
  cin >> N >> K; // read N, K
  for (int i = 1; i <= N * 2 + 1; i++) { cin >> a[i]; } // for i = 1 to N*2+1 inclusive the read a[i]
  int k = 0; // let int k = 0
  for (int i = 2; i <= N * 2; i++) { // for i = 2 to N*2 inclusive
    if (a[i] > a[i - 1] + 1 && a[i] > a[i + 1] + 1) { // if a[i] > a[i - 1] + 1 and a[i] > a[i + 1] + 1
      a[i]--; // decrement a at i
      k++; // increment k
      if (k == K) break; // if k is same as K, exit loop
    } 
  } 
  for (int i = 1; i <= N * 2; i++) { cout << a[i] << " "; } // for i = 1 to N * 2, print a at i and space
  cout << a[N * 2 + 1] << endl; // print a[N * 2 + 1]
  return 0; 
} 