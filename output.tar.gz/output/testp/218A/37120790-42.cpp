
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int maxn = 101000; // maxn is a constant integer set to 101000
const int mo = 1e9 + 7; // mo is a constant integer set to 1e9 + 7
long long ans; // ans is a long long
int f, n, m, h; // f, n, m, h are integers
int a[maxn], c[maxn], k, sum[maxn]; // a, c, sum are all integer arrays all of size maxn, k is an integer
int b[maxn], flag, tmp; // b = integer array of size maxn, flag = integer, temp = integer
char s[maxn]; // s is a character array of size maxn
int main() { 
  int T; // T is an integer
  int cas = 1; // cas is an integer set to 1
  while (cin >> n >> m) { // while read n, m
    n = n * 2 + 1; // assign n * 2 + 1 to n
    ans = 0; // assign 0 to ans
    for (int i = 0; i < n; i++) { cin >> a[i]; } // read n values into array a
    cout << a[0] << " "; // display a[0], " "
    for (int i = 1; i < n - 1; i++) { // for i = 1 to n - 1 exclusive
      if (m && a[i] > a[i - 1] + 1 && a[i] > a[i + 1] + 1) { // if m and a[i] are greater than a[i - 1] + 1 and a[i] is greater than a[i + 1] + 1
        cout << a[i] - 1 << " "; // display a[i] - 1, " "
        m--; // decrement m
      } else // else
        cout << a[i] << " "; // display a[i], " "
    } 
    cout << a[n - 1] << endl; // display a[n - 1]
  } 
  return 0; 
} 