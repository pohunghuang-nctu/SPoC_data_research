
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 110 * 2; // N = const int with N = 110 * 2
int main() { 
  int n, k, i; // n, k, i = int
  int a[N]; // a = int array of size N
  cin >> n >> k; // read n then k
  int len = 2 * n + 1; // len = int with len = 2 * n + 1
  int cnt = 0; // cnt = int with cnt = 0
  for (i = 1; i <= len; i++) { cin >> a[i]; } // for i = 1 to len inclusive read a[i]
  for (i = 1; i <= len; i++) { // for i = 1 to len inclusive
    if (i % 2 == 0) { // if i is even
      if (a[i] - 1 > a[i - 1] && a[i] - 1 > a[i + 1]) { // if a[i] - 1 is greater than a[i - 1] and a[i + 1]
        a[i]--; // decrement a[i]
        cnt++; // increment cnt
      } 
    } 
    if (cnt == k) break; // if cnt is k break
  } 
  for (i = 1; i < len; i++) cout << a[i] << " "; // for i = 1 to len print a[i] then " "
  cout << a[len] << endl; // print a[len]
  return 0; 
} 