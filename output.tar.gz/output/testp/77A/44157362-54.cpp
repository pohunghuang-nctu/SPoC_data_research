
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long md = 10e10, ml = 0; // declare long longs ml = 0 and md = 10e10
vector<int> team(7, 0); // create vector of ints team with 7 elements filled with 0
map<string, int> hashi; // create map of string to int called hashi
map<pair<int, int>, bool> likes; // create map of int/int pairs to bool called likes
vector<long long> xp(3); // create vector of long long called xp with 3 elements
void tri(int i) { // tri is a void function with int argument i
  if (i == 7) { // if i is equal to 7
    long long mie = 10e10, mae = 0, lik = 0; // create long longs mie = 10e10 and mae and lik = 0
    bool can = true; // create bool can = true
    for (int j = 0; j < 3; j++) { // for integer j = 0 to 3 exclusive
      long long co = 0; // create long long co = 0
      for (int k = 0; k < 7; k++) { // loop k from 0 to 7 exclusive
        if (team[k] == j) { // if team[k] is equal to j
          co++; // increment co
          for (int l = 0; l < 7; l++) { // for l = 0 to 7 exclusive
            if (team[l] == j && likes[pair<int, int>(k, l)]) { lik++; } // if team[l] = j and likes[pair<int, int>(k, l)] is true, increment lik by one
          } 
        } 
      } 
      if (co == 0) { // if co is equal to 0
        can = false; // assign false to can
        break; // break
      } 
      mie = min(mie, xp[j] / co); // change mie to min of mie and xp[j] / co
      mae = max(mae, xp[j] / co); // change mae to max of mae and xp[j] / co
    } 
    if (can) { // if can is true
      long long dif = mae - mie; // create long long dif = mae - mie
      if (dif == md) // if dif = md
        ml = max(lik, ml); // set ml to max of lik and ml
      else if (dif < md) { // else if dif < md
        md = dif; // assign dif to md
        ml = lik; // assign lik to ml
      } 
    } 
  } else { // else
    for (int j = 0; j < 3; j++) { // for integer j = 0 to 3 exclusive
      team[i] = j; // set team[i] to j
      tri(i + 1); // call tri(i + 1)
    } 
  } 
  return; // return
} 
int main() { 
  int n; // declare int variable n
  cin >> n; // read input to n
  hashi["Trolong long"] = 0; // assign 0 to hashi["Trolong long"]
  hashi["Dracul"] = 1; // assign 1 to hashi["Dracul"]
  hashi["Anka"] = 2; // assign 2 to hashi["Anka"]
  hashi["Snowy"] = 3; // assign 3 to hashi["Snowy"]
  hashi["Hexadecimal"] = 4; // assign 4 to hashi["Hexadecimal"]
  hashi["Chapay"] = 5; // assign 5 to hashi["Chapay"]
  hashi["Cleo"] = 6; // assign 6 to hashi["Cleo"]
  while (n--) { // loop, decrementing n, while it is not 0
    string p, q; // create strings p and q
    cin >> p >> q >> q; // read input to p, q and q
    likes[pair<int, int>(hashi[p], hashi[q])] = true; // set likes[pair<int, int>(hashi[p], hashi[q])] to true
  } 
  for (int i = 0; i < 3; i++) cin >> xp[i]; // loop i from 0 to 3 exclusive, read xp[i]
  tri(0); // call tri(0)
  cout << md << " " << ml << "\n"; // print md, " ", ml and "\n"
  return 0; 
} 