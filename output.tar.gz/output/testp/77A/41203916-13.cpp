
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int b1, b2, b3, emm1, emm2, lk[10][10]; // create integers b1, b2, b3, emm1, emm2 and integer array lk of size 10 within an array of size 10
int a[8]; // create integer array a of size 8
map<string, int> m; // create string key-type integer map m
int js(int x, int y, int z) { // declare js taking in integers x, y, and z and returning integer
  x = b1 / x; // set x to b1 / x
  y = b2 / y; // set y to b2 / y
  z = b3 / z; // set z to b3 / z
  return emm1 = max(abs(x - y), max(abs(y - z), abs(x - z))); // set emm1 = the max of abs(x - y), max(abs(y - z), abs(x - z)) and return emm1
} 
int haogan(int x, int y, int z) { // declare haogan taking in integers x, y, and z and returning integer
  int ss = 0; // create integer ss = 0
  for (int i = 1; i <= x; i++) // for i = 1 to x inclusive
    for (int j = 1; j <= x; j++) // for j = 1 to x inclusive
      if (lk[a[i]][a[j]]) ss++; // if lk[a[i][a[j]] is truthy, increment ss
  for (int i = x + 1; i <= x + y; i++) // for i = x + 1 to x + y inclusive
    for (int j = x + 1; j <= x + y; j++) // for j = x + 1 to x + y inclusive
      if (lk[a[i]][a[j]]) ss++; // if lk[a[i]][a[j]] is truthy, increment ss
  for (int i = x + y + 1; i <= 7; i++) // for i = x + y + 1 to 7 inclusive
    for (int j = x + y + 1; j <= 7; j++) // for j = x + y + 1 to 7 inclusive
      if (lk[a[i]][a[j]]) ss++; // if lk[a[i]][a[j]] is truthy, increment ss
  return emm2 = ss; // set emm2 to ss and return emm2
} 
int main() { 
  m["Anka"] = 1; // set m["Anka"] to 1
  m["Chapay"] = 2; // set m["Chapay"] to 2
  m["Cleo"] = 3; // set m["Cleo"] to 3
  m["Troll"] = 4; // set m["Troll"] to 4
  m["Dracul"] = 5; // set m["Dracul"] to 5
  m["Snowy"] = 6; // set m["Snowy"] to 6
  m["Hexadecimal"] = 7; // set m["Hexadecimal"] to 7
  int n; // create integer n
  cin >> n; // read n
  while (n--) { // while n-- is truthy
    string s1, s, s2; // create strings s1, s, and s2
    cin >> s1 >> s >> s2; // read s1, s, and s2
    lk[m[s1]][m[s2]] = 1; // set lk[m[s1]][m[s2]] to 1
  } 
  int ans1 = 1e9, ans2 = -1e9; // create integers ans1 = 1e9 and ans2 = -1e9
  cin >> b1 >> b2 >> b3; // read b1, b2, and b3
  if (b1 < b2) swap(b1, b2); // if b1 is less than b2, swap the values of b1 and b2
  if (b2 < b3) swap(b2, b3); // if b2 is less than b3, swap the values of b2 and b3
  if (b1 < b2) swap(b1, b2); // if b1 is less than b2, swap the values of b1 and b2
  for (int i = 1; i <= 7; i++) a[i] = i; // for i = 1 to 7 inclusive, set a[i] to i
  do { // do
    if ((js(4, 2, 1) == ans1) && (haogan(4, 2, 1) > ans2)) { ans2 = emm2; } // if the return value of js(4, 2, 1) is equal to ans1 and the return value of haogan(4, 2, 1) is greater than ans2, set ans2 to emm2
    if (emm1 < ans1) { // if emm1 is less than ans1
      ans1 = emm1; // set ans1 to emm1
      ans2 = haogan(4, 2, 1); // set ans2 to the return value of haogan(4, 2, 1)
    } 
    if ((js(3, 3, 1) == ans1) && (haogan(3, 3, 1) > ans2)) { ans2 = emm2; } // if the return value of js(3, 3, 1) is equal to ans1 and the return value of haogan(3, 3, 1) is greater than ans2, set ans2 to emm2
    if (emm1 < ans1) { // if emm1 is less than ans1
      ans1 = emm1; // set ans1 to emm1
      ans2 = haogan(3, 3, 1); // set ans2 to the return value of haogan(3, 3, 1)
    } 
    if ((js(3, 2, 2) == ans1) && (haogan(3, 2, 2) > ans2)) { ans2 = emm2; } // if the return value of js(3, 2, 2) is equal to ans1 and the return value of haogan(3, 2, 2) is greater than ans2, set ans2 to emm2
    if (emm1 < ans1) { // if emm1 is less than ans1
      ans1 = emm1; // set ans1 to emm1
      ans2 = haogan(3, 2, 2); // set ans2 to the return value of haogan(3, 2, 2)
    } 
    if ((js(5, 1, 1) == ans1) && (haogan(5, 1, 1) > ans2)) { ans2 = emm2; } // if the return value of js(5, 1, 1) is equal to ans1 and the return value of haogan(5, 1, 1) is greater than ans2, set ans2 to emm2
    if (emm1 < ans1) { // if emm1 is less than ans1
      ans1 = emm1; // set ans1 to emm1
      ans2 = haogan(5, 1, 1); // set ans2 to haogan(5, 1, 1)
    } 
  } while (next_permutation(a + 1, a + 7 + 1)); // while the return value of next_permutation(a + 1, a + 7 + 1) is truthy
  cout << ans1 << ' ' << ans2 << endl; // print ans1, ' ', and ans2
} 