
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

vector<int> vec[3]; // create integer vector array vec with size 3
map<string, int> like; // create map like from string to integer
int diff, mat[10][10], ans, a, b, c; // create integers diff, ans, a, b, c, create 2d integer array mat with size 10 by 10
int cal() { // declare cal
  int sum = 0, i, j, k; // create integers sum, i, j, k, with sum = 0
  for (i = 0; i < 3; i++) { // for i = 0 to 3 exclusive
    for (j = 0; j < (int)vec[i].size(); j++) // for j = 0 to integer casted size of vec[i]
      for (k = 0; k < (int)vec[i].size(); k++) sum += mat[vec[i][j]][vec[i][k]]; // for k = 0 to integer casted size of vec[i] exclusive, increment sum by mat[vec[i][j]][vec[i][k]]
  } 
  return sum; // return sum from function
} 
void count(int now) { // declare count with integer now as argument, returning void
  if (now == 7) { // if now is 7
    if (vec[0].size() && vec[1].size() && vec[2].size()) { // if size of vec[0] and size of vec[1] and size of vec[2]
      int x[] = {a / vec[0].size(), b / vec[1].size(), c / vec[2].size()}; // create integer array x with x = { a / size of vec[0], b / size of vec[1], c / size of vec[2] }
      sort(x, x + 3); // sort elements from x to x + 3
      if (x[2] - x[0] < diff) { // if x[2] - x[0] is less than diff
        diff = x[2] - x[0]; // set diff to x[2] - x[0]
        ans = cal(); // set ans to result of run cal
      } else if (x[2] - x[0] == diff) // else if x[2] - x[0] is diff
        ans = max(ans, cal()); // set ans to maximum of ans and result of run cal
    } 
    return; // return from function
  } 
  for (int i = 0; i < 3; i++) { // for i = 0 to 3 exclusive
    vec[i].push_back(now); // add element now to end of vec[i]
    count(now + 1); // run count with now + 1 as argument
    vec[i].pop_back(); // remove last element from vec[i]
  } 
} 
int main() { 
  like["Anka"] = 0; // set like[ "Anka" ] to 0
  like["Chapay"] = 1; // set like[ "Chapay" ] to 1
  like["Cleo"] = 2; // set like[ "Cleo" ] to 2
  like["Troll"] = 3; // set like[ "Troll" ] to 3
  like["Dracul"] = 4; // set like[ "Dracul" ] to 4
  like["Snowy"] = 5; // set like[ "Snowy" ] to 5
  like["Hexadecimal"] = 6; // set like[ "Hexadecimal" ] to 6
  int n, i; // create integers n, i
  string name1, str, name2; // create strings name1, str, name2
  while (cin >> n) { // while read n is true
    diff = (1 << 31) - 1; // set diff to ( 1 bitshift left 31 ) - 1
    for (i = 0; i < 3; i++) vec[i].clear(); // for i = 0 to 3 exclusive, remove all elements from vec[i]
    memset(mat, 0, sizeof(mat)); // set bytes from mat to size of mat to value 0
    for (i = 0; i < n; i++) { // for i = 0 to n exclusive
      cin >> name1 >> str >> name2; // read name1 read str read name2
      mat[like[name1]][like[name2]]++; // increment mat[like[name1]][like[name2]]
    } 
    cin >> a >> b >> c; // read a read b read c
    count(0); // run count with 0 as argument
    cout << diff << " " << ans << endl; // print diff print " " print ans print newline
  } 
} 