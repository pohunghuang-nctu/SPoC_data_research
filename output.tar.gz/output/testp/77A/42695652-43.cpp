
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bool mat[7][7]; // let mat be a logical matrix of size 7x7
int calc(string s) { // in int function calc which takes string s
  int r = 0; // let r = 0 = integer
  for (int i = 0; i < 7; i++) { // for i = 0 to 7 exlusive
    for (int j = 0; j < 7; j++) { // for j = 0 to 7 exclusive
      if (s[i] == s[j] && mat[i][j]) r++; // if s at i is same as s at j and mat at i and j is not 0 then increment r
    } 
  } 
  return r; // return r
} 
int main() { 
  int n, ans = INT_MAX, temp = INT_MAX, lans = 0, ltemp = 0; // let n, ans, temp, lans, ltemp be int with ans = temp = lans = ltemp = INT_MAX
  cin >> n; // read n
  long long arr[3], t[3] = {0, 0, 0}; // let arr, t be long long arrays of size 3 both with all 0
  for (int i = 0; i < 7; i++) // for i = 0 to 7 exclusive
    for (int j = 0; j < 7; j++) mat[i][j] = false; // for j = 0 to 7 exclusive, set mat[i][j] to false
  map<string, int> hero; // let hero be a map form string to int
  hero["Anka"] = 0; // set hero at "Anka" to 0
  hero["Chapay"] = 1; // set hero at "Chapay" to 1
  hero["Cleo"] = 2; // set hero["Cleo"] = 2
  hero["Troll"] = 3; // set hero["Dracul"] to 3
  hero["Dracul"] = 4; // set hero["Dracul"] tp 4
  hero["Snowy"] = 5; // hero["Snowy"] = 5
  hero["Hexadecimal"] = 6; // set hero at Hexadecimal = 6
  string x, y, z, q; // let x, y, z, q be strings
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> x >> y >> z; // read x, y, z
    mat[hero[x]][hero[z]] = true; // set mat[hero[x]][hero[z]] to true
  } 
  cin >> arr[0] >> arr[1] >> arr[2]; // read arr at 0, arra at 1, arr at 2
  sort(arr, arr + 3); // sort the first 3 elements of arr
  set<string> h; // let h be a set of strings
  set<string>::iterator it; // let it be a set string iterator
  t[2] = arr[2] / 5; // set t at 2 = arr[2] / 5
  t[1] = arr[1]; // t[1] = arr[1]
  t[0] = arr[0]; // set t at 0 to arr[0]
  sort(t, t + 3); // sort the first 3 elements of t
  temp = t[2] - t[0]; // set temp to t[2] - t[0]
  if (temp < ans) { // if temp is less than ans
    ans = temp; // set ans to temp
    h.insert("aaaaabc"); // call insert on h with arg "aaaaabc"
  } 
  t[2] = arr[2] / 4; // set t at 2 = arr[2]/4
  t[1] = arr[1] / 2; // set t at 1 = arr[1]/2
  t[0] = arr[0]; // set t at 0 to arr at 0
  sort(t, t + 3); // sort the first three elements of arr
  temp = t[2] - t[0]; // set temp = t[2] - t[0]
  if (temp < ans) { // if temp is less than ans
    ans = temp; // set ans to temp
    h.clear(); // clear h
    h.insert("aaaabbc"); // insert "aaaabbc" in h
  } else if (temp == ans) { // else if temp is same as ans
    h.insert("aaaabbc"); // insert "aaaabbc" in h
  } 
  t[2] = arr[2] / 3; // set t[2] = arr[2] / 3
  t[1] = arr[1] / 3; // set t[1] = arr[1] / 3
  t[0] = arr[0]; // set t at 0 to arr at 0
  sort(t, t + 3); // sort the first 3 elements of t
  temp = t[2] - t[0]; // set tempo to t[2] - t[0]
  if (temp < ans) { // if temp < ans
    ans = temp; // set ans to temp
    h.clear(); // clear h
    h.insert("aaabbbc"); // insert "aaaabbc" in h
  } else if (temp == ans) { // else if temp is same as ans
    h.insert("aaabbbc"); // insert "aaaabbc" in h
  } 
  t[2] = arr[2] / 3; // set t[2] to arr[2] / 3
  t[1] = arr[1] / 2; // set t[1] to arr[1] / 2
  t[0] = arr[0] / 2; // set t[0] to arr[0] / 2
  sort(t, t + 3); // sort the first 3 elements of t
  temp = t[2] - t[0]; // set temp to t[2] - t[0]
  if (temp < ans) { // if temp is less than ans
    ans = temp; // set ans to temp
    h.clear(); // clear h
    h.insert("aaabbcc"); // insert "aaabbcc" in h
  } else if (temp == ans) { // if temp = ans
    h.insert("aaabbcc"); // insert "aaabbcc" in h
  } 
  while (!h.empty()) { // while h is not empty
    q = *(h.begin()); // set q to be q * the first element of h
    do { // do loop
      ltemp = calc(q); // set ltemp to calc of q
      if (ltemp > lans) lans = ltemp; // if ltemp is greater than lans then set lans to ltemp
    } while (next_permutation(q.begin(), q.end())); // while the result of calling next_permutation with args start of q and end of q is not 0
    h.erase(q); // erase q from h
  } 
  cout << ans << " " << lans << endl; // print ans and space and lans
  return 0; 
} 