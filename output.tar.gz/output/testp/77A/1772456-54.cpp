
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

map<string, int> M; // create map of strings to integers M
bool like[7][7]; // create 2d array of booleans like with size 7 by 7
string s1, s2, temp; // declare strings s1, s2 and temp
int n, g[3]; // create integer n and integer array g with size 3
int team[3]; // create an array of integers team with size 3
int heros[7]; // create an array of integers heros with size 7
int b1 = INT_MAX, b2 = -1; // create integer b1 = INT_MAX and b2= -1
void back_track(int a) { // void function back_track with int argument a
  int i, j; // declare integers i and j
  if (a == 7) { // if a is equal to 7
    int count[3] = {0, 0, 0}; // declare an array of integers count with elements 0, 0, 0
    int mx = -1, mn = INT_MAX; // create ints mx = - and mn = INT_MAX
    for (i = 0; i < 7; i++) count[heros[i]]++; // for i = 0 to 7 exclusive increment count[heros[i]]
    if (count[0] == 0 || count[1] == 0 || count[2] == 0) return; // if count[0], count[1] or count[2] = 0, return
    for (i = 0; i < 7; i++) { // for i from 0 to 7 exclusive
      int temp = g[heros[i]] / count[heros[i]]; // declare integer temp = g[heros[i]] / count[heros[i]]
      mx = max(mx, temp); // change mx to max of mx and temp
      mn = min(mn, temp); // change mn to min of mn and temp
    } 
    if (mx - mn > b1) return; // if mx - mn is greater than b1, return
    int likeNum = 0; // create int likeNum = 0
    for (i = 0; i < 7; i++) // loop i from 0 to 7 exclusive
      for (j = 0; j < 7; j++) // loop j from 0 to 7 exclusive
        if (heros[i] == heros[j] && like[i][j]) likeNum++; // if heros[i] = heros[j] and like[i][j] != 0, increment likeNum by one
    if ((mx - mn) < b1 || (mx - mn) == b1 && likeNum > b2) { // if mx - mn < b1 or mx - mn = b1and likeNum > b2
      b1 = mx - mn; // set b1 to mx - mn
      b2 = likeNum; // set b2 to likeNum
    } 
    return; // return
  } 
  for (i = 0; i < 3; i++) { // loop i from 0 to 3 exclusive
    heros[a] = i; // change heros[a] to i
    back_track(a + 1); // call back_track(a + 1)
  } 
} 
int main() { 
  M["Anka"] = 0; // assign 0 to M["Anka"]
  M["Chapay"] = 1; // assign 1 to M["Chapay"]
  M["Cleo"] = 2; // assign 2 to M["Cleo"]
  M["Troll"] = 3; // assign 3 to M["Troll"]
  M["Dracul"] = 4; // assign 4 to M["Dracul"]
  M["Snowy"] = 5; // assign 5 to M["Snowy"]
  M["Hexadecimal"] = 6; // assign 6 to M["Hexadecimal"]
  for (int i = 0; i < 7; i++) // loop i from 0 to 7 exclusive
    for (int j = 0; j < 7; j++) like[i][j] = false; // loop j from 0 to 7 exclusive, change like[i][j] to false
  cin >> n; // read n
  while (n--) { // while n != 0, decrement it and continue the loop
    cin >> s1 >> temp >> s2; // read input to s1, temp and s2
    like[M[s1]][M[s2]] = true; // set value of like[M[s1]][M[s2]] to true
  } 
  cin >> g[0] >> g[1] >> g[2]; // read g[0], g[1] and g[2]
  back_track(0); // call back_track(0)
  cout << b1 << ' ' << b2 << endl; // print b1, ' ' and b2
  return 0; 
} 