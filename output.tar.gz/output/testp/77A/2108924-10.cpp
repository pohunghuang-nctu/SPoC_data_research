
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

vector<int> vec[3]; // vec = int vector array of size 3
map<string, int> like; // like = string and int map
int diff, mat[10][10], ans, a, b, c; // diff, ans, a, b, c = int and mat = two dimensional int array of sizes 10 and 10
int cal() { // in function cal returning an int
  int sum = 0, i, j, k; // sum, i, j, k = int with sum = 0
  for (i = 0; i < 3; i++) { // for i = 0 to 3
    for (j = 0; j < vec[i].size(); j++) // for j = 0 to size of vec[i]
      for (k = 0; k < vec[i].size(); k++) sum += mat[vec[i][j]][vec[i][k]]; // for k = 0 to size of vec[i] increment sum by mat[vec[i][j]][vec[i][k]]
  } 
  return sum; // return sum
} 
void count(int now) { // in function count taking an int now
  if (now == 7) { // if now is 7
    if (vec[0].size() && vec[1].size() && vec[2].size()) { // if size of vec[0] and size of vec[1] and size of vec[2] are all not 0
      int x[] = {a / vec[0].size(), b / vec[1].size(), c / vec[2].size()}; // x = int array with the values a / size of vec[0], b / size of vec[1] and c / size of vec[2]
      sort(x, x + 3); // sort x
      if (x[2] - x[0] < diff) { // if x[2] - x[0] is less than diff
        diff = x[2] - x[0]; // set diff to x[2] - x[0]
        ans = cal(); // set ans to cal
      } else if (x[2] - x[0] == diff) // else if x[2] - x[0] is diff
        ans = max(ans, cal()); // set ans to max of ans and cal
    } 
    return; // return
  } 
  for (int i = 0; i < 3; i++) { // for i = 0 to 3
    vec[i].push_back(now); // append now to vec[i]
    count(now + 1); // call count of now + 1
    vec[i].pop_back(); // remove last value of vec[i]
  } 
} 
int main() { 
  like["Anka"] = 0; // set like["Anka"] to 0
  like["Chapay"] = 1; // set like["Chapay"] to 1
  like["Cleo"] = 2; // set like["Cleo"] to 2
  like["Troll"] = 3; // set like["Troll"] to 3
  like["Dracul"] = 4; // set like["Dracul"] to 4
  like["Snowy"] = 5; // set like["Snowy"] to 5
  like["Hexadecimal"] = 6; // set like["Hexadecimal"] to 6
  int n, i; // n, i = int
  string name1, str, name2; // name1, str, name2 = string
  while (cin >> n) { // loop while reading n
    diff = (1 << 31) - 1; // set diff to (1 bitshift right by 31) - 1
    for (i = 0; i < 3; i++) vec[i].clear(); // for i = 0 to 3 clear vec[i]
    memset(mat, 0, sizeof(mat)); // set all values of mat to 0
    for (i = 0; i < n; i++) { // for i = 0 to n
      cin >> name1 >> str >> name2; // read name1 then str then name2
      mat[like[name1]][like[name2]]++; // increment mat[like[name1]][like[name2]]
    } 
    cin >> a >> b >> c; // read a then b then c
    count(0); // call count of 0
    cout << diff << " " << ans << endl; // print diff and ans
  } 
} 