
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const long long N = 2002; // N=2002
map<string, long long> mp; // mp=map from string to long long
map<pair<long long, long long>, long long> likes; // likes=map from pair of long long, long long to long long
int main() { 
  long long n = 7, m, sz = 0, a, b, c; // n=7, sz=0, m, a, b, c = long long
  cin >> m; // read m
  while (m--) { // while decremented value of m not equal 0
    string l, r; // l,r=string
    cin >> l >> r >> r; // read l,r,r
    if (mp[l] == 0) mp[l] = ++sz; // if mp[l] is 0 increment sz, mp[l] = sz
    if (mp[r] == 0) mp[r] = ++sz; // if mp[r] is 0 increment sz, mp[r] = sz
    likes[make_pair(mp[l], mp[r])] = 1; // likes[make_pair(mp[l], mp[r])] = l
  } 
  cin >> a >> b >> c; // read a,b,c
  long long pt = 2187, minimal = a + b + c, ml; // pt=2187, minimal=a+b+c, ml=long long
  for (long long i = 0; i < pt; i++) { // for i=0 to pt excluisve
    vector<long long> t[3]; // t=array of 3 vector of long long
    long long k = i, m1, m2, m3, lks = 0; // k=i, m1,m2,m3=long long, lks=0
    for (long long i = 1; i <= n; i++) { // for i=1 to n inclusive
      t[k % 3].push_back(i); // add i at end of t[k modulo 3]
      k /= 3; // divide k by 3
    } 
    if (t[0].size() && t[1].size() && t[2].size()) { // it size of t[0] and size of t[1] and size of t[2]
      m1 = a / t[0].size(); // m1=a/size of t[0]
      m2 = b / t[1].size(); // m2=b/size of t[1]
      m3 = c / t[2].size(); // m3=c/size of t[2]
      m1 = max(m1, max(m2, m3)) - min(m1, min(m2, m3)); // m1=max(m1, max(m2,m3))-min(m1, min(m2,m3))
      for (long long i = 0; i < 3; i++) // for i=0 to 3 exclusive
        for (long long j = 0; j < t[i].size(); j++) // for j=0 to size of t[i] exclusive
          for (long long k = 0; k < t[i].size(); k++) lks += likes[make_pair(t[i][j], t[i][k])]; // for k=0 to size of t[i] exclusive add likes[make_pair(t[i][j], t[i][k])] to lks
      if (minimal > m1) { // if minimal>m1
        minimal = m1; // minimal=m1
        ml = lks; // ml=lks
      } else if (minimal == m1) // else if minimal is m1
        ml = max(ml, lks); // ml=max(ml,lks)
    } 
  } 
  cout << minimal << " " << ml << endl; // print minimal, space, ml
} 