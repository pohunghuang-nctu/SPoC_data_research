
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // let n be a integer
  while (cin >> n) { // while read n
    if (n & 1) // if n & 1 is true
      cout << n / 2 << endl; // print n / 2 and newline
    else { // else do the following
      int m = 2; // the integer value of m = 2
      while (m <= n) { m <<= 1; } // while m <= n , m <<= 1
      m >>= 1; // m >>= 1
      cout << (n - m) / 2 << endl; // print (n - m) / 2 and newline
    } 
  } 
} 