
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int n, i; // n, i are integers
int main() { 
  cin >> n; // read n
  if (n & 1) // if n & 1
    n = n >> 1; // n equals n shifted bitwise by 1 to right
  else { // else
    for (i = 1; i <= n; i <<= 1) // for i = 1 to n inclusive
      ; // end statement
    n = (n - (i >> 1)) >> 1; // n equals n - (i >> 1) shifted bitwise by 1 to right
  } 
  cout << n << endl; // print n and endline
  return 0; 
} 