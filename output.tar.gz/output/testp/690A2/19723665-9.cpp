
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // integer as n
  cin >> n; // read n
  int k = (n & 1) ? (n / 2) : (n - (int)pow(2, (int)log2(n))) / 2; // integer as k = (n / 2) if (n & 1) is true else (n - (int)pow(2,(int)log2(n))) / 2
  cout << k << endl; // output k
} 