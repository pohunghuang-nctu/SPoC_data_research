
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // create integer n
  cin >> n; // read n
  if (n % 2) // if n modulo 2 is truthy
    cout << n / 2 << endl; // print n / 2
  else { // else
    n /= 2; // divide n by 2
    int d = 0; // create int d = 0
    while ((1 << d) <= n) ++d; // while (1 << d) is less than or equal to n, increment d
    --d; // subtract d by 1
    n -= (1 << d); // set n to n - (1 << d)
    cout << n << endl; // show n
  } 
} 