
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // make int n
  cin >> n; // read n
  if (n % 2) { // if n mod 2
    cout << (n + 1) / 2 - 1 << endl; // print (n + 1) / 2 - 1
  } else { // else
    cout << (n ^ (1 << (31 - __builtin_clz(n)))) / 2 << endl; // print (n ^ (1 << (31 - __builtin_clz(n)))) / 2
  } 
} 