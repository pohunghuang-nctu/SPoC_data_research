
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int A[1000]; // A = int array size 1000
int main() { 
  int n; // n = int
  cin >> n; // read n
  int two = 1; // two = int, two = 1
  while (two <= n) two *= 2; // while two <= n, multiply two by 2
  two /= 2; // divide two by 2
  cout << (n % 2 ? (n - 1) / 2 : (n - two) / 2) << endl; // print n % 2 ? (n - 1) / 2 : (n - two) / 2
} 