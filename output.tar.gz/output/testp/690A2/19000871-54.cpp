
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // declare new integer n
  cin >> n; // read user input to n
  if (n % 2 == 0) { n -= (1 << (int)log2(n)) - 1; } // if n is even, change n to n - (1 << (int)log2(n)) - 1
  cout << n / 2 << endl; // print n / 2 to the standard output
} 