
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // declare integer n
  cin >> n; // read n
  if (n % 2) // if n mod 2
    cout << (n - 1) / 2 << endl; // print (n - 1) / 2
  else // else
    cout << (n - (1 << (31 - __builtin_clz(n)))) / 2 << endl; // print (n - (1 << (31 - __builtin_clz(n)))) / 2
  return 0; 
} 