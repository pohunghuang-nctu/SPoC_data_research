
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, m, k, a; // n, m, k, a = long long
  cin >> n >> m >> k; // read n, m, k, a
  long long minn = 20000000000; // minn = long long with minn = 20000000000
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> a; // read a
    if (i % 2 == 0) minn = min(a, minn); // if i modulo 2 is 0, minn = min of a and minn
  } 
  if (n % 2) { // if n modulo 2
    if (n / 2 + 1 <= m) { // if n / 2 + 1 <= m
      long long x = n / 2 + 1; // x = long long with x = n / 2 + 1
      x = m / x * k; // x = m / x * k
      cout << (x < minn ? x : minn) << endl; // if x < minn, print x else minn
    } else { // else
      cout << 0 << endl; // print 0
    } 
  } else // else
    cout << 0 << endl; // print 0
} 