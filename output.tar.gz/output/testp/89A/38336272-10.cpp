
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long a[100010]; // a = long long array of size 100010
int main() { 
  long long N, M, K; // N, M, K = long long
  long long mm = 1e9; // mm = long long with mm = 1e9
  cin >> N >> M >> K; // read N then M then K
  for (int i = 1; i <= N; i++) { // for i = 1 to N inclusive
    cin >> a[i]; // read a[i]
    if (i % 2 == 1) { mm = min(mm, a[i]); } // if i is uneven set mm to min of mm, a[i]
  } 
  if (N % 2 == 0) { // if N is even
    cout << "0" << endl; // print "0"
    return 0; 
  } 
  int temp = (N + 1) / 2; // temp = int with temp = (N + 1) / 2
  cout << min(mm, M / temp * K) << endl; // print min of mm, M / temp * K
  return 0; 
} 