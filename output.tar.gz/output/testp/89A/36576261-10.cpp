
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long n, m, k, a[10004]; // n, m, k = long long and a = long long array of size 10004
int main() { 
  cin >> n >> m >> k; // read n then m then k
  for (long long i = 0; i < n; i++) cin >> a[i]; // read n values into a
  if (n % 2 == 0) { // if n is even
    cout << "0\n"; // print "0"
    return 0; 
  } 
  long long x = min(a[0], a[n - 1]); // x = long long with x = min of a[0], a[n - 1]
  if (n == 1) { // if n is 1
    cout << min(x, m * k) << endl; // print min of x, m * k
    return 0; 
  } 
  for (long long i = 0; i < n; i += 2) { x = min(x, a[i]); } // for i = 0 to n incrementing i by 2 set x to min of x, a[i]
  long long onerun = (n + 1) / 2; // onerun = long long with onerun = (n + 1) / 2
  onerun = m / onerun; // set onerun to m / onerun
  long long ans = min(x, onerun * k); // ans = long long with ans = min of x, onerun * k
  cout << ans << endl; // print ans
  return 0; 
} 