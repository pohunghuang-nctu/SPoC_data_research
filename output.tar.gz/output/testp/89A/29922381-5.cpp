
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int M = 10000 + 10; // M = const integer with M = 10010
int a[M]; // a = integer array of size M
int main() { 
  long long int n, m, k; // n, m, k = long long integers
  cin >> n >> m >> k; // read n, m, k
  long long int min_v = 1E+9; // min_v = long long integer with min_v = 1E+9
  for (int i = 1; i <= n; i++) { // for i = 1 to n
    cin >> a[i]; // read a[i]
    if (i % 2 == 1 && a[i] < min_v) { min_v = a[i]; } // if i modulo 2 is 1 and a[i] < min_v, min_v = a[i]
  } 
  if (n % 2 == 0) { // if n modulo 2 is 0
    cout << "0" << endl; // print 0
  } else { // else
    long long int x = 2 * m / (n + 1); // x = long long integer with x = 2 * m / (n + 1)
    long long int y = x * k; // y = long long integer with y = x * k
    long long int ans = (y > min_v ? min_v : y); // ans = long long integer with ans = if y > min_v, min_v else y
    cout << ans << endl; // print ans
  } 
  return 0; 
} 