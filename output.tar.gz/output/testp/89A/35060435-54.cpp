
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, m, k; // declare integer variables n, m and k
  cin >> n >> m >> k; // read standard input to n, m and k
  long long mi = INT_MAX; // declare new long long variable mi with value INT_MAX
  for (int i = 1; i <= n; i++) { // start for loop from i = 1 to n inclusive incrementing i
    long long a; // declare long long variable a
    cin >> a; // read from the input to a
    if (i % 2 != 0) mi = min(mi, a); // if i is odd, assign min of mi and a to mi
  } 
  if (n % 2 == 0) { // if n is even
    cout << 0 << "\n"; // print 0 and "\n"
    return 0; 
  } else { // else
    long long ans = n / 2; // ans is a new long long = n / 2
    ans++; // increment ans
    ans = m / ans; // assign the new value = m / ans to ans
    ans *= k; // set ans to ans multiplied by k
    ans = min(mi, ans); // set ans to min of mi and ans
    cout << ans << "\n"; // print ans and "\n" to the standard output
  } 
  return 0; 
} 