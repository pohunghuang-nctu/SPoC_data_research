
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 1e4 + 5; // N = const integer with N = 1e4 + 5
int a[N]; // a = integer array of size N
int main() { 
  long long n, m, k; // n, m, k = long long
  cin >> n >> m >> k; // read n, m, k
  int mi = 1e8; // mi = integer with mi = 1e8
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> a[i]; // read a[i]
    if (i % 2 == 0) mi = min(mi, a[i]); // if i modulo 2 is 0, mi = min of mi and a[i]
  } 
  if (n % 2 == 0) return cout << 0 << endl, 0; // if n modulo 2 is 0, return print 0, new line, 0
  long long x = m / ((n + 1) / 2); // x = long long with x = m / ((n + 1) / 2
  x *= k; // x = x * k
  cout << min(x, 1ll * mi) << endl; // print min(x, 1ll * mi)
  return 0; 
} 