
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long a[100005], n, k, m, minn, s, x; // declare long long array a size 100005, long longs n, k, m, minn, s, x
  cin >> n >> m >> k; // read n and m and k
  for (int i = 0; i < n; i++) cin >> a[i]; // for i = 0 to n exclusive, read a[i]
  if (!n % 2) // if not n % 2
    cout << 0 << endl; // print 0 and newline
  else { // else
    minn = 0; // let minn be 0
    s = n / 2 + 1; // let s be n / 2 + 1
    if (s > m) // if s is greater than m
      minn = 0; // let minn be 0
    else { // else
      minn = a[0]; // let minn be a[0]
      for (int i = 0; i <= n; i += 2) minn = min(minn, a[i]); // for i = 0 to n inclusive, incrementing i by 2, let minn be minimum of minn and a[i]
      x = m / s * k; // let x be m / s * k
      minn = min(minn, x); // let minn be minn and x
    } 
    cout << minn << endl; // print minn and newline
  } 
} 