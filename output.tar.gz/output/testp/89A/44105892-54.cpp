
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int mod = 1e9 + 7; // declare constant integer mod = 1e9 + 7
const int maxn = 1e6 + 5; // create constant integer maxn = 1e6 + 5
long long int power(long long int base, long long int exp, long long int mod) { // power is a long long int function with long long int arguments base, exp and mod
  long long int res = 1; // create new long long integer res with value 1
  while (exp) { // while exp is not 0
    if (exp % 2) res *= base; // if exp is odd, change the value of multiply res by base
    base *= base; // multiply base by base
    res %= mod; // change res to the remainder of res divided by mod
    base %= mod; // change base to base modulo mod
    exp /= 2; // change the value of exp to exp divided by 2
  } 
  return res; // return res
} 
long long int n, m, k; // declare long long int variables n, m and k
int main() { 
  cin >> n >> m >> k; // read user input to n, m and k
  long long int ans = mod; // create new long long integer called ans with value mod
  for (int i = 1; i <= n; i++) { // for i from 1 to n inclusive
    long long int x; // declare long long integer variable x
    cin >> x; // read variable x from the input
    if (i % 2) { ans = min(ans, x); } // if i is odd, set ans to min of ans and x
  } 
  if (n % 2 == 0) ans = 0; // if n is even, change the value of ans to 0
  m = m * 2; // set m to m * 2
  m /= (n + 1); // divide m by (n + 1)
  cout << min(ans, m * k) << "\n"; // print min of ans and m * k and "\n" to the standard output
  return 0; 
} 