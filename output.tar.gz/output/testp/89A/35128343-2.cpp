
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long int i, n, m, k, arr[100000]; // let i, n, m, k be long integers , arr = array of long integers of length 100000
  long long int ans = INFINITY; // let ans be a long integer with ans = INFINITY
  cin >> n >> m >> k; // read n, m, k
  for (i = 0; i < n; i++) { cin >> arr[i]; } // for i = 0 to n exclusive , read arr[i]
  if (n % 2 == 0 || (n / 2) + 1 > m) { // if n modulo 2 is equal to 0 or (n / 2) + 1 is greater than m
    cout << "0" << endl; // print 0 and newline
  } else { // else do the following
    for (i = 0; i < n; i += 2) { ans = min(ans, arr[i]); } // for i = 0 to n exclusive, i is incremented by 2 , ans is equal to minimum of ans, arr[i]
    long long s = m / ((n / 2) + 1); // let s be a long integer with s = m / ((n / 2) + 1)
    ans = min(ans, s * k); // ans is equal to minimum of ans, s * k
    cout << ans << endl; // print ans and new line
  } 
  return 0; 
} 