
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long int i, n, m, k, arr[100000]; // i,n,m,k=long long int, arr=array of 100000 long long int
  long long int temp = INFINITY; // temp=long long int with value INFINITY
  cin >> n >> m >> k; // read n,m,k
  for (i = 0; i < n; i++) { cin >> arr[i]; } // for i=0 to n exclusive read arr[i]
  if (n % 2 == 0 || (n / 2) + 1 > m) { // if n is even or n/2+1 > m
    cout << "0" << endl; // print "0"
  } else { // else
    for (i = 0; i < n; i += 2) { temp = min(temp, arr[i]); } // for i=0 to n by 2 temp=min(temp, arr[i])
    long long s = (m / ((n / 2) + 1)) * k; // s=(m/(n/2)+1))*k
    temp = min(temp, s); // temp=min(temp, s)
    cout << temp << endl; // print temp
  } 
  return 0; 
} 