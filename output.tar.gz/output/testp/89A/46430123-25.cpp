
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long n, dia[10010], m, ans = 0, mis = 100000, k, need = 0; // create long long n, array dia of size 10010, m, ans = 0, mis = 100000, k, need = 0
int main() { 
  cin >> n >> m >> k; // read n, m, k
  for (int i = 1; i <= n; ++i) { // for i = 1 to n inclusive
    cin >> dia[i]; // read dia[n]
    if (mis > dia[i] && i % 2 == 1) mis = dia[i]; // if mis greater than dia[i] and i is odd: set mis to dia[i]
  } 
  need = n / 2 + 1; // set need to n / 2 + 1
  if (n % 2 == 0 || need > m) // if n is even or need is greater than m
    ; // pass
  else { // else
    ans = m / need * k; // set ans to m / need * k
    ans = min(mis, ans); // set ans to min(mis, ans)
  } 
  cout << ans << endl; // print ans
  return 0; 
} 