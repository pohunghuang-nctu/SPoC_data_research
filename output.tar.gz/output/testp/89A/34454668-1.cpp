
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const long long mod = 1e9 + 7, maxn = 1e4 + 100; // declare constant long longs mod = 1e9 + 7, maxn = 1e4 + 100
long long a[maxn]; // declare long long array a size maxn
int main() { 
  long long n, m, k; // declare long longs n, m, k
  cin >> n >> m >> k; // read n, m, k
  for (int i = 1; i <= n; i++) cin >> a[i]; // for i = 1 to n inclusive, read a[i]
  if (n % 2 == 0) return cout << 0 << endl, 0; // for n % 2 is 0, return print 0 and newline, 0
  long long op = m / ((n + 1) / 2); // declare long long op = m / ((n + 1) / 2)
  op *= k; // let op = op * k
  long long minn = 1000 * 1000 * 1000; // declare long long minn = 1000 * 1000 * 1000
  for (int i = 1; i <= n; i += 2) minn = min(minn, a[i]); // for i = 1 to n inclusive, incrementing i by 2, let minn be minimum of minn and a[i]
  cout << min(minn, op) << endl; // print minimum of minn and op, newline
} 