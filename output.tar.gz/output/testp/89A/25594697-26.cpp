
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long dia[10005]; // create long long dia[10005]
int main() { 
  long long n; // create long long n
  long long m, k; // create long long m and k
  cin >> n >> m >> k; // read n, m and k
  for (int i = 0; i < n; i++) { cin >> dia[i]; } // for i=0 to n exclusive, read dia[i]
  if (n % 2 == 0) { // if n is even
    cout << 0 << endl; // print 0
  } else { // else
    long long h = m / (1 + (n - 1) / 2); // set h to m / (1 + (n - 1) / 2)
    long long MI = dia[0]; // MI = dia[0]
    for (int j = 0; j < n; j += 2) { // for j=0 to n exclusive, with increment j=j+2
      if (MI > dia[j]) MI = dia[j]; // if MI > dia[j], set Mi to dia[j]
    } 
    if (MI < k * h) // if MI < k*h
      cout << MI << endl; // print MI
    else // else
      cout << k * h << endl; // print k*h
  } 
  return 0; 
} 