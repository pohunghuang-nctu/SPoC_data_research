
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, m, k, a; // declare long longs n, m, k, a
  cin >> n >> m >> k; // read n and m and k
  long long minn = 20000000000; // declare minn = 20000000000 as long long
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> a; // read a
    if (i % 2 == 0) minn = min(a, minn); // if i % 2 is 0, let minn = minimum of a and minn
  } 
  if (n % 2) { // if n % 2
    if (n / 2 + 1 <= m) { // if n / 2 + 1 is less than or equal to m
      long long x = n / 2 + 1; // declare long long x = n / 2 + 1
      x = m / x * k; // let x be m / x * k
      cout << (x < minn ? x : minn) << endl; // print ( x if x is less than minn, else minn ) and newline
    } else { // else
      cout << 0 << endl; // print 0 print newline
    } 
  } else // else
    cout << 0 << endl; // print 0 print newline
} 