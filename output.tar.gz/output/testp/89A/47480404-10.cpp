
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int maxn = 10005; // maxn = const int with maxn = 10005
long long n, m, k, arr[maxn], minn = 1e8; // n, m, k, minn = long long with minn = 1e8 and arr = long long array of size maxn
int main() { 
  cin >> n >> m >> k; // read n then m then k
  for (int i = 0; i < n; i++) { // for i = 0 to n
    cin >> arr[i]; // read arr[i]
    if (!(i & 1)) minn = min(minn, arr[i]); // if not (i bitwise-and 1) set minn to min of minn, arr[i]
  } 
  if (!(n & 1) || m < (n / 2 + 1)) { // if not (n bitwise-and 1) or m < (n / 2 + 1)
    cout << "0\n"; // print "0"
    return 0; 
  } 
  cout << min(minn, m / (n / 2 + 1) * k) << "\n"; // print min of minn, m / (n / 2 + 1) * k
  return 0; 
} 