
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, m, k; // n, m, k = long long integers
  cin >> n >> m >> k; // read n, m, k
  vector<long long> a(n); // a with n = long long vector
  long long mn = 1e9; // mn = long long integer set to 1e9
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> a[i]; // read a[i]
    if (i % 2 == 0) mn = min(mn, a[i]); // if i modulo 2 is 0, set mn to minimum of mn and a[i]
  } 
  if (n % 2 == 0) { // if n modulo 2 is 0
    cout << 0 << endl; // print 0
    return 0; 
  } 
  cout << min(m / (n / 2 + 1) * k, mn) << endl; // print minimum of m / n / 2 + 1 * k and mn
  return 0; 
} 