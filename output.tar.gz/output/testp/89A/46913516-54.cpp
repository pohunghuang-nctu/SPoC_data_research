
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, m, k, cnt, mn = 1e9; // create long longs n, m, k, cnt and mn with value of mn = 1e9
  cin >> n >> m >> k; // read variables n, m and k from the input
  for (int i = 0; i < n; i++) { // start for loop from i = 0 to n exclusive incrementing i
    int x; // create new integer variable x
    cin >> x; // read the data from the input to x
    if (i % 2 == 0) mn = min(mn, 1ll * x); // if i is even, change mn to min of mn and 1ll * x
  } 
  cnt = m / ((n + 1) / 2); // change cnt to m / ((n + 1) / 2)
  cnt *= k; // change the value of cnt to cnt multiplied by k
  long long ans = min(cnt, mn); // create long long variable ans with value min of cnt and mn
  if (n % 2 == 0) ans = 0; // if n is even, set ans to 0
  cout << ans << endl; // print ans to the standard output
  return 0; 
} 