
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int maxn = 100000 + 5; // declare constant integer maxn = 100000 + 5
int a[maxn]; // a is an array of integers with maxn elements
int main() { 
  int n, m, k; // declare new integer variables n, m and k
  cin >> n; // read n from the user input
  cin >> m; // read m from the user
  cin >> k; // read from the input to k
  int i; // declare new integer i
  for (i = 0; i < n; i++) cin >> a[i]; // read n elements into a
  if (n % 2 == 0) { // if n is even
    cout << 0 << endl; // print 0
    return 0; 
  } 
  long long ans = 0; // declare new long long called ans with value 0
  int nn = n / 2 + 1; // nn is a new integer variable with value n / 2 + 1
  if (nn > m) // if nn is greater than m
    ans = 0; // assign 0 to ans
  else { // else
    ans = a[0]; // set ans to a[0]
    for (int i = 0; i < n; i++) // in a for loop, change i from 0 to n exclusive
      if ((i & 1) == 0) ans = (ans < a[i] ? ans : a[i]); // if i & 1 is equal to 0, change the value of ans to ans if ans < a[i] and a[i] otherwise
    long long int aa; // declare new long long integer aa
    aa = (long long int)m / nn * k; // change aa to n/ nn * k
    ans = min(ans, aa); // set ans to min of ans and aa
  } 
  cout << ans << endl; // print ans
  return 0; 
} 