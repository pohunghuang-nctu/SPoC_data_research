
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int M = 100005; // M = const int with M = 100005
long long n, m, k; // n, m, k = long long
long long a[M]; // a = long long array of size M
long long num[M]; // num = long long array of size M
int main() { 
  cin >> n >> m >> k; // read n then m then k
  for (int i = 1; i <= n; i++) cin >> a[i]; // for i = 1 to n inclusive read a[i]
  if (n % 2 == 0) { // if n is even
    cout << "0" << endl; // print "0"
    return 0; 
  } 
  long long ans = 0; // ans = long long
  long long movs = n / 2 + 1; // movs = long long with movs = n / 2 + 1
  if (movs > m) { // if movs > m
    ans = 0; // set ans to 0
  } else { // else
    long long minn = a[1]; // minn = long long with minn = a[1]
    for (int i = 2; i <= n; i++) { // for i = 2 to n inclusive
      if (i % 2 == 1) { minn = min(a[i], minn); } // if i is uneven set minn to min of a[i], minn
    } 
    ans = min(minn, (long long)m / movs * k); // set ans to min of minn, m as long long / movs * k
  } 
  cout << ans << endl; // print ans
  return 0; 
} 