
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int N = 2e6; // N = const integer with N = 2e6
bool prime[N]; // prime = bool array of size N
void Prime() { // in the function Prime
  memset(prime, 0, sizeof(prime)); // set all contents of prime to 0
  prime[1] = 1; // prime[1] = 1
  for (int i = 2; i < N; i++) { // for i = 2 to N exclusive
    if (!prime[i]) { // if (not prime[i])
      for (int j = i * 2; j < N; j += i) { prime[j] = 1; } // for j = i * 2 to N with j = j + i, prime[j] = 1
    } 
  } 
} 
bool is_palindromic(int n) { // in the function is_palindromic that takes integer n and returns bool
  int t = n; // t = integer with t = n
  int fn = 0; // fn = integer with fn = 0
  while (t) { // while (t)
    fn *= 10; // fn = fn * 10
    fn += t % 10; // fn = fn + t modulo 10
    t /= 10; // t = t / 10
  } 
  return n == fn; // return n is fn
} 
int main() { 
  double p, q; // p, q = double
  double A; // A = double
  Prime(); // call Prime
  while (cin >> p >> q) { // while read p, q
    int ans = -1; // ans = integer with ans = -1
    A = p / q; // A = p / q
    int pi = 0; // pi = integer with pi = 0
    int pa = 0; // pa = integer with pa = 0
    for (int i = 1; i < N; i++) { // for i = 1 to N exclusive
      if (!prime[i]) pi++; // if (not prime[i]), increment pi
      pa += is_palindromic(i); // pa = pa + is_palindromic(i)
      if (pi <= pa * A) ans = i; // if (pi <= pa * A), ans = i
    } 
    if (ans == -1) // if (ans is -1)
      cout << "Palindromic tree is better than splay tree" << endl; // print Palindromic tree is better than splay tree
    else // else
      cout << ans << endl; // print ans
  } 
} 