
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bitset<10000007> prims, palins; // prims, palins = bitset with prims = 10000007
long long somaPrim[10000007], somaPoli[10000007]; // function somaPrim, somaPoli = long long with somaPrim, somaPoli = 10000007
void sieve() { // in the function sieve
  prims.set(); // set of prims
  prims[0] = prims[1] = false; // prims[0] = prims[1] = false
  for (int i = 2; i < 10000007; i++) { // for i = 2 to 10000006
    if (prims[i]) { // if (prims[i])
      for (int j = i + i; j < 10000007; j += i) prims[j] = false; // for j = i + i to 10000006, j = j + i, prims[j] = false
    } 
  } 
  for (int i = 2; i < 10000007; i++) somaPrim[i] = somaPrim[i - 1] + prims[i]; // for i = 2 to 10000006, somaPrim[i] = somaPrim[i - 1] + prims[i]
} 
int aux[10]; // aux = integer array of size 10
bool is_palin(int val) { // in the function is_palin that takes val and returns bool
  int len = 0; // len = integer with len = 0
  while (val > 0) { // while (val > 0)
    aux[len++] = val % 10; // aux[increment len] = val modulo 10
    val /= 10; // val = val / 10
  } 
  for (int i = 0; i <= len / 2; i++) // for i = 0 to len / 2
    if (aux[i] != aux[len - i - 1]) return false; // if (aux[i] is not aux[len - i - 1]), return false
  return true; // return true
} 
void build() { // in the function build
  for (int i = 1; i < 10000007; i++) { palins[i] = is_palin(i); } // for i = 1 to 10000006, palins[i] = is_palin(i)
  somaPoli[0] = palins[0]; // somaPoli[0] = palins[0]
  for (int i = 1; i < 10000007; i++) somaPoli[i] = somaPoli[i - 1] + palins[i]; // for i = 1 to 10000006, somaPoli[i] = somaPoli[i - 1] + palins[i]
} 
int main() { 
  sieve(); // call sieve
  build(); // call build
  long long A, B; // A, B = long long
  cin >> A >> B; // read A, B
  int ans; // ans = integer
  for (ans = 10000007 - 1; ans >= 0; ans--) { // for ans = 10000007 - 1 down to 0
    if (A * somaPoli[ans] >= B * somaPrim[ans]) { // if A * somaPoli[ans] >= B * somaPrim[ans]
      cout << ans << endl; // print ans
      return 0; 
    } 
  } 
  cout << "Palindromic tree is better than splay tree" << endl; // print Palindromic tree is better than splay tree
  return 0; 
} 