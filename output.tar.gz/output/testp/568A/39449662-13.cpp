
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int p, q, A, B, R, C[2000000] = {1, 1}, i = 1; // create ints p, q, A, B, R, and i = 1 and int array C of size 2000000 containing {1, 1}
int main() { 
  cin >> p >> q; // read p and q
  for (; i < 2e6; i++) { // for loop i to 2e6 exclusive
    if (!C[i]) { // if C[i] is falsy
      A += q; // set A to A + q
      for (int j = i; j < 2e6; j += i) C[j] = 1; // for j = i to 2e6 exclusive by incrementing by i, set C[j] to 1
    } 
    int r = 0, t = i; // make ints r = 0 and t = i
    for (; t; r = 10 * r + t % 10, t /= 10) // for loop while t is truthy and increment by r = 10 * r + t % 10 and t /= 10
      ; // end statement
    B += p * (r == i); // set B to B + p * (r == i )
    R = A <= B ? i : R; // set R to A <= B ? i : R
  } 
  cout << R << endl; // display R
} 