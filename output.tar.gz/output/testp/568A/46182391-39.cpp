
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bool palindrom(int k) { // declare boolean function palindrom taking in integer k
  int n = log10(k) + 1; // let n = integer with value log10(k) +1
  int dig[n], i = 0; // let dig = array of integers size n and i = integer with value 0
  while (k > 0) { // while (K is greater than 0) is true do the following
    dig[i++] = k % 10; // set dig [increment i] = k modulo 10
    k /= 10; // set k = k / 10
  } 
  bool ans = true; // let ans = boolean with value true
  for (int i = 0; i <= n / 2; ++i) { ans &= dig[i] == dig[n - i - 1]; } // for integer i=0 to n / 2 inclusive set ans = ans & dig[i] is dig[n - i - 1]
  return ans; // return ans
} 
int main() { 
  int p, q; // let p, q = integers
  cin >> p >> q; // read p, q
  bool prime[2000000]; // let prime = array of boolean size 2000000
  memset(prime, true, sizeof prime); // set sizeof(prime) bytes starting at prime to 0
  int sqLIM = sqrt(2000000); // let sqLIM = integer with value sqrt(2000000)
  for (int i = 2; i <= sqLIM; ++i) { // for integer i=2 to sqLIM inclusive dothe following
    if (!prime[i]) continue; // if not prime[i] go to start of loop
    for (int j = i * i; j < 2000000; j += i) { prime[j] = false; } // for integer j=i*i to 2000000 exclusive increment step i set prime[j] = false
  } 
  prime[1] = false; // set prime[1] = false
  int pr = 0, pal = 0, ans = 0; // let pr, pal, ans = integers with value 0
  for (int i = 1; i < 2000000; ++i) { // for integer i=1 to 2000000 do the following
    if (palindrom(i)) ++pal; // if palindrom[i] is true increment pal
    if (prime[i]) ++pr; // if prime[i] is true increment pr
    if (p * pal >= q * pr) ans = i; // if p * pal is greater than or equal to q * pr set ans = i
  } 
  cout << ans << "\n"; // print ans
  cin >> p; // read p
} 