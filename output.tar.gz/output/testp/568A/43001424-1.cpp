
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int MAX = 1e7; // declare constant integer MAX = 1e7
long long a[MAX], sushu[MAX], huiwen[MAX]; // declare long long arrays a size MAX, sushu size MAX, huiwen size MAX
void init() { // declare init with no arguments, returning void
  a[1] = 1; // let a[1] be 1
  a[0] = 1; // let a[0] be 1
  for (int i = 2; i <= 10000; i++) { // for i = 2 to 10000 inclusive
    if (!a[i]) { // if not a[i]
      for (int j = i; i * j < MAX; j++) { a[i * j] = 1; } // for j = i to i * j is less than MAX, incrementing j, let a[i*j] be 1
    } 
  } 
} 
int panduan(long long x) { // declare panduan with long long x as argument, returning integer
  long long w = x; // declare long long w = x
  long long y = 0; // declare long long y = 0
  while (w != 0) { // while w is not 0
    y = y * 10 + w % 10; // let y be y * 10 + w % 10
    w /= 10; // let w be w / 10
  } 
  if (y == x) // if y is x
    return 1; // return 1 from function
  else // else
    return 0; 
} 
int main() { 
  init(); // run init
  for (int i = 1; i < MAX; i++) { // for i = 1 to MAX exclusive
    if (a[i]) // if a[i] is true
      sushu[i] = sushu[i - 1]; // let sushu[i] be sushu[i - 1]
    else // else
      sushu[i] = sushu[i - 1] + 1; // let sushu[i] be sushu[i - 1] + 1
    if (panduan(i)) // if result of run panduan(i) is true
      huiwen[i] = huiwen[i - 1] + 1; // let huiwen[i] be huiwen[i - 1] + 1
    else // else
      huiwen[i] = huiwen[i - 1]; // let huiwen[i] be huiwen[i - 1]
  } 
  long long p, q; // declare long longs p, q
  cin >> p >> q; // read p and q
  for (int i = MAX - 1; i >= 0; i--) { // for i = MAX - 1 to 0 inclusive, decrementing i
    if (sushu[i] * q <= huiwen[i] * p) { // if sushu[i] * q is less than or equal to huiwen[i] * p
      if (i == 0) // if i is 0
        cout << "Palindromic tree is better than splay tree" << endl; // print "Palindromic tree is better than splay tree" and newline
      else // else
        cout << i << endl; // print i and newline
      return 0; 
    } 
  } 
  return 0; 
} 