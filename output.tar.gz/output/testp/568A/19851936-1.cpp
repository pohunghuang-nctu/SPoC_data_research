
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long int p, q; // declare long long integers p, q
long long int primes[2100000]; // declare long long integer array primes size 2100000
long long int pi[2100000]; // declare long long integer pi size 2100000
long long int rub[2100000]; // declare long long integer rub size 2100000
int ans; // declare integer ans
int inv(int x) { // declare inv with integer x as argument, returning integer
  int ret = 0; // declare integer ret = 0
  while (x != 0) { // while x is not 0
    ret = ret * 10 + x % 10; // let ret be ret * 10 + x % 10
    x = x / 10; // let x be x / 10
  } 
  return ret; // return ret from function
} 
int chk(int x) { // declare chk with integer x as argument, returning integer
  if (inv(x) == x) { return 1; } // if result of run inv(x) is x, return 1
  return 0; 
} 
int main() { 
  cin >> p >> q; // read p and q
  int i, j; // declare integers i, j
  for (i = 2; i <= 2050000; i++) { primes[i] = 1; } // for i = 2 to 2050000 inclusive, let primes[i] be 1
  for (i = 2; i <= 2050000; i++) { // for i = 2 to 2050000 inclusive
    if (primes[i] == 1) { // if primes[i] is 1
      for (j = 2; i * j <= 2060000; j++) { primes[i * j] = 0; } // for j = 2 to i * j is less than or equal to 2060000, incrementing j, let primes[i*j] be 0
    } 
  } 
  for (i = 2; i <= 2050000; i++) { pi[i] = pi[i - 1] + primes[i]; } // for i = 2 to 2050000 inclusive, let pi[i] be pi[i-1] + primes[i]
  for (i = 1; i <= 2050000; i++) { rub[i] = rub[i - 1] + chk(i); } // for i = 1 to 2050000 inclusive, let rub[i] be rub[i-1] + result of run chk with i as argument
  for (i = 2050000; i >= 1; i--) { // for i = 2050000 to 1 inclusive, decrementing i
    if (q * pi[i] <= p * rub[i]) { // if q * pi[i] is less than or equal to p * rub[i]
      cout << i << endl; // print i and newline
      return 0; 
    } 
  } 
} 