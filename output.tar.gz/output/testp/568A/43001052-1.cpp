
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int MAX = 12e5 + 100; // declare constant integers MAX = 12e5 + 100
int a[MAX], sushu[MAX], huiwen[MAX]; // declare integer arrays a size MAX, sushu size MAX, huiwen size MAX
void init() { // declare init with no arguments, returning void
  a[1] = 1; // let a[1] be 1
  a[0] = 1; // let a[0] be 1
  for (int i = 2; i <= 10000; i++) { // for i = 2 to 10000 inclusive
    if (!a[i]) { // if not a[i]
      for (int j = i; i * j < MAX; j++) { a[i * j] = 1; } // for j = i to i * j is less than MAX, incrementing j, let a[i*j] be 1
    } 
  } 
} 
int panduan(int x) { // declare panduan with integer x as argument, returning integer
  int w = x; // declare integer w = x
  int y = 0; // declare integer y = 0
  while (w != 0) { // while w is not 0
    y = y * 10 + w % 10; // let y be y * 10 + w % 10
    w /= 10; // let w be w / 10
  } 
  if (y == x) // if y is x
    return 1; // return 1
  else // else
    return 0; 
} 
int main() { 
  init(); // run init
  for (int i = 1; i < MAX; i++) { // for i = 1 to MAX exclusive
    if (a[i]) // if a[i] is true
      sushu[i] = sushu[i - 1]; // let sushu[i] be sushu[i - 1]
    else // else
      sushu[i] = sushu[i - 1] + 1; // let sushu[i] be sushu[i - 1] + 1
    if (panduan(i)) // if result of run panduan with i as argument is true
      huiwen[i] = huiwen[i - 1] + 1; // let huiwen[i] be huiwen[i - 1] + 1
    else // else
      huiwen[i] = huiwen[i - 1]; // let huiwen[i] be huiwen[i - 1]
  } 
  int p, q; // declre integers p, q
  cin >> p >> q; // read p and q
  for (int i = MAX - 1; i >= 0; i--) { // for i = MAX - 1 to 0 inclusive, decrementing i
    if (sushu[i] * q <= huiwen[i] * p) { // if sushu[i] * q is less than or equal to huiwen[i] * p
      if (i == 0) // if i is 0
        cout << "Palindromic tree is better than splay tree" << endl; // print "Palindromic tree is better than splay tree" and newline
      else // else
        cout << i << endl; // print i and newline
      return 0; 
    } 
  } 
  return 0; 
} 