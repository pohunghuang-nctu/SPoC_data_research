
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bool isprime[1500000]; // declare boolean array isprime size 1500000
void sieve() { // declare sieve with no arguments, returning void
  fill(isprime, isprime + 1500000, (bool)1); // assign value boolean casted 1 from isprime to isprime + 1500000
  for (int i = 2; i < 1500000; i++) { // for i = 2 to 1500000 exclusive
    if (isprime[i]) { // if isprime[i] is true
      for (int j = 2 * i; j < 1500000; j += i) { isprime[j] = 0; } // for j = 2 * i to 1500000 exclusive, incrementing j by i, let isprime[j] be 0
    } 
  } 
  isprime[1] = 0; // let isprime[1] be 0
  return; // return from function
} 
bool ispalin(int num) { // declare ispalin with integer num as argument, returning boolean
  int divisor = 1; // declare integer divisor = 1
  while (num / divisor >= 10) divisor *= 10; // while num / divisor is greater than or equal to 10, let divisor be divisor * 10
  while (num != 0) { // while num is not 0
    int leading = num / divisor; // declare leading = num / divisor
    int trailing = num % 10; // declare trailing = num % 10
    if (leading != trailing) return false; // if leading is not trailing, return false from function
    num = (num % divisor) / 10; // let num be ( num % divisor ) / 10
    divisor = divisor / 100; // let divisor be divisor / 100
  } 
  return true; // return true from function
} 
int main() { 
  sieve(); // run sieve
  int lprime = 0, lpalin = 0; // declare lprime = 0, lpalin = 0 as integer
  int p, q; // declare integers p, q
  cin >> p >> q; // read p and q
  int ans; // declare integer ans
  for (int i = 1; i < 1500000; i++) { // for i = 1 to 1500000 exclusive
    if (isprime[i]) { lprime++; } // if isprime[i], increment lprime
    if (ispalin(i)) { lpalin++; } // if result of run ispalin(i) is true, increment lpalin
    if ((long long)q * lprime <= (long long)p * lpalin) { ans = i; } // if long long casted q * lprime is less than or equal to long long casted p * lpalin, let ans be i
  } 
  cout << ans << endl; // print ans and newline
  return 0; 
} 