
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

bool prime[1200000 + 4]; // prime is an array of booleans with 1200000 + 4 elements
int pali[1200000 + 4]; // pali is an array of integers with size 1200000 + 4
int pri[1200000 + 4]; // declare new array of integers pri with size 1200000 + 4
void sieve() { // function sieve
  for (int i = 4; i <= 1200000; i += 2) prime[i] = 1; // in a for loop, change i from 4 to 1200000 inclusive adding 2 to i and changing prime[i] to 1 on each loop
  for (int i = 3; i <= sqrt(1200000); i += 2) { // start for loop from i = 3 to square root of 1200000 inclusive increasing i by 2
    if (prime[i] == 0) { // if prime[i] is equal to 0
      for (int j = i * i; j <= 1200000; j += 2 * i) prime[j] = 1; // in a for loop, change j from i * i to 1200000 inclusive adding 2 * i to j, and setting prime[j] to 1 on each iteration
    } 
  } 
  prime[0] = prime[1] = 1; // change the value of prime[0] and prime[1] to 1
} 
bool is_Palindrome(int n) { // function is_Palindrome with int argument n that returns bool
  int arr[10]; // arr is a new array of integers with 10 elements
  int l = 0; // create new integer variable l = 0
  while (n != 0) { // while n is not 0
    arr[l++] = n % 10; // set arr[l] to n modulo 10 and increment l
    n = n / 10; // change n to n / 10
  } 
  bool flag = 1; // flag is a new boolean variable = 1
  for (int i = 0; i <= l / 2; i++) { // for i = 0 to l / 2 inclusive incrementing i
    if (arr[i] != arr[l - i - 1]) { // if arr[i] != arr[l - i - 1]
      flag = 0; // assign the new value = 0 to flag
      break; // stop the loop
    } 
  } 
  if (flag) // if flag is true
    return 1; // return 1
  else // else
    return 0; 
} 
int main() { 
  sieve(); // call sieve()
  pri[0] = 0; // set pri[0] to 0
  for (int i = 0; i <= 1200000; i++) { // for i from 0 to 1200000 inclusive
    if (prime[i] == 0) { // if prime[i] is equal to 0
      pri[i] = pri[i - 1] + 1; // set pri[i] to pri[i - 1] + 1
    } else { // else
      pri[i] = pri[i - 1]; // change the value of pri[i] to pri[i - 1]
    } 
  } 
  for (int i = 1; i <= 1200000; i++) { // in a for loop, change i from 1 to 1200000 inclusive
    if (is_Palindrome(i)) { // if is_Palindrome(i) returned true
      pali[i] = pali[i - 1] + 1; // assign the new value = pali[i - 1] + 1 to pali[i]
    } else { // else
      pali[i] = pali[i - 1]; // assign pali[i - 1] to pali[i]
    } 
  } 
  long long int p, q; // declare long long int variables p and q
  cin >> p >> q; // read standard input to p and q
  bool flag = 1; // create boolean flag with value 1
  int i; // declare integer i
  for (i = 1200000; i >= 0; i--) { // start for loop from i = 1200000 to 0 inclusive decrementing i
    if ((((long long int)pri[i]) * q) <= (p * (long long int)pali[i])) { // if pri[i] * q <= p * pali[i]
      cout << i << "\n"; // print i and "\n"
      return 0; 
    } 
  } 
  cout << "Palindromic tree is better than splay tree\n"; // print "Palindromic tree is better than splay tree\n" to the output
  return 0; 
} 