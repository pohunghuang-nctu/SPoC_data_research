
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int MAX = 1e7 - 8.8e6; // create new constant integer MAX with value 1e7 - 8.8e6
int a[MAX], sushu[MAX], huiwen[MAX]; // declare integer arrays a, sushu and huiwen with size MAX
void init() { // function init
  a[1] = 1; // change the value of a[1] to 1
  a[0] = 1; // assign the new value = 1 to a[0]
  for (int i = 2; i <= 10000; i++) { // for integer i = 2 to 10000 inclusive incrementing i
    if (!a[i]) { // if a[i] is false
      for (int j = i; i * j < MAX; j++) { a[i * j] = 1; } // in a for loop, change j starting from i while i * j < MAX, setting the value of a[i * j] to 1 on each iteration
    } 
  } 
} 
int panduan(int x) { // function panduan with int argument x that returns integer
  int w = x; // create new integer variable w with value x
  int y = 0; // declare new integer y = 0
  while (w != 0) { // while w is not 0
    y = y * 10 + w % 10; // assign the new value = y * 10 + w % 10 to y
    w /= 10; // divide w by 10
  } 
  if (y == x) // if y = x
    return 1; // return 1
  else // else
    return 0; 
} 
int main() { 
  init(); // call init()
  for (int i = 1; i < MAX; i++) { // in a for loop, change i from 1 to MAX exclusive
    if (a[i]) // if a[i] is true
      sushu[i] = sushu[i - 1]; // set sushu[i] to sushu[i - 1]
    else // else
      sushu[i] = sushu[i - 1] + 1; // assign sushu[i - 1] + 1 to sushu[i]
    if (panduan(i)) // if panduan(i) is true
      huiwen[i] = huiwen[i - 1] + 1; // set huiwen[i] to huiwen[i - 1] + 1
    else // else
      huiwen[i] = huiwen[i - 1]; // assign huiwen[i - 1] to huiwen[i]
  } 
  int p, q; // create new integers p and q
  cin >> p >> q; // read input to p and q
  for (int i = MAX - 1; i >= 0; i--) { // in a for loop, change i from MAX - 1 to 0 inclusive decrementing i
    if (sushu[i] * q <= huiwen[i] * p) { // if sushu[i] * q <= huiwen[i] * p
      if (i == 0) // if i is equal to 0
        cout << "Palindromic tree is better than splay tree" << endl; // print "Palindromic tree is better than splay tree"
      else // else
        cout << i << endl; // print i to the standard output
      return 0; 
    } 
  } 
  return 0; 
} 