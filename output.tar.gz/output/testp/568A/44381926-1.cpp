
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int dx[] = {-1, 0, 0}; // declare integer array dx = {-1, 0, 0}
int dy[] = {0, 1, -1}; // declare integer array dy = {0, 1, -1}
int prime[10000002]; // declare integer array prime size 10000002
bool ispal(int n) { // declare ispal with integer n as argument, returning boolean
  int rem(0), orginal(0); // declare integers rem initialized with 0, orginal initialized with 0
  orginal = n; // let orginal be n
  while (n > 0) { // while n is greater than 0
    rem = rem * 10 + n % 10; // let rem be rem * 10 + n % 10
    n /= 10; // let n be n / 10
  } 
  return (orginal == rem); // return ( original is rem ) from function
} 
void seive() { // declare seive with no arguments, returning void
  prime[1] = 1; // let prime[1] be 1
  for (long long i = 1; i <= 1e7; i++) { // for i = 1 to 1e7 inclusive
    if (!prime[i]) { // if not prime[i]
      for (long long j = i * 2; j <= 1e7; j += i) { prime[j] = 1; } // for j = i * 2 to 1e7 inclusive, incrementing j by i, let prime[j] be 1
    } 
  } 
} 
int main() { 
  seive(); // run seive
  bool done = 0; // declare boolean done = 0
  long long n, pal(0), pr(0), p, q, ans(0); // declare long longs n, pal initialized with 0, pr initialized with 0, p, q, ans initialized with 0
  cin >> p >> q; // read p and q
  for (int i = 1; i <= 1e7; i++) { // for i = 1 to 1e7 inclusive
    if (!prime[i]) { pr++; } // if not prime[i], increment pr
    if (ispal(i)) { pal++; } // if run ispal with i as argument is true, increment pal
    if (pr * q <= pal * p) { // if pr * q is less than or equal to pal * p
      ans = i; // let ans be i
      done = 1; // let done be 1
    } 
  } 
  if (done) { // if done is true
    cout << ans << "\n"; // print ans and "\n"
  } else // else
    cout << "Palindromic tree is better than splay tree\n"; // print "Palindromic tree is better than splay tree\n"
  return 0; 
} 