
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int arr[1300006] = {}; // declare arr size 1300006 as integer array = {}
  arr[1] = 1; // let arr[1] be 1
  for (int i = 2; i <= sqrt(1300006); i++) // for i = 2 to square root of 1300006 inclusive
    for (int j = i * i; j < 1300006; j += i) { // for j = i * i to 1300006 exclusive, incrementing j by i
      if (i % 2 == 0 && i != 2) break; // if i % 2 is 0 and i is not 2, end loop
      arr[j] = 1; // let arr[j] be 1
    } 
  long double c = 0, c2 = 0; // declare long doubles c = 0, c2 = 0
  long long a, b; // declare a, b as long longs
  cin >> a >> b; // read a, b
  unsigned long long maxi = 1; // declare unsigned long long maxi = 1
  for (unsigned long long i = 1; i < 1300006; i++) { // for i = 1 to 1300006 exclusive
    if (!arr[i]) c += b; // if not arr[i], increment c by b
    stringstream x; // declare stringstream x
    string s; // declare string s
    x << i; // let x be x bitshift left i
    s = x.str(); // let s be string version of x
    string news = s; // declare string news = s
    reverse(s.begin(), s.end()); // reverse sort from beginning of s to end of s
    if (news == s) c2 += a; // if news is s, increment c2 by a
    if (c2 >= c) maxi = max(maxi, i); // if c2 is greater than or equal to c, let maxi be maximum of maxi and i
  } 
  cout << fixed << setprecision(0) << maxi << endl; // set cout flag fixed, set cout precision to 0, print maxi and newline
} 