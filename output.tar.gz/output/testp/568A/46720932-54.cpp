
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int maxn = 2e6 + 7; // create constant integer with name maxn = 2e6 + 7
bool prime[maxn]; // prime is a new array of booleans with maxn elements
bool palindrome(string s) { // in the function palindrome with string argument s that returns boolean
  int lo = 0, hi = s.size() - 1; // declare ints lo = 0 and hi = length of s - 1
  while (lo <= hi) { // while lo <= hi
    if (s[lo++] != s[hi--]) return false; // if s[lo] != s[hi], return false; increment lo and decrement hi in any case
  } 
  return true; // return true
} 
int main() { 
  prime[1] = true; // assign the new value = true to prime[1]
  for (int i = 2; i < maxn; i++) { // in a for loop, change i from 2 to maxn exclusive incrementing i
    if (!prime[i]) { // if prime[i] is false
      for (int j = i + i; j < maxn; j += i) prime[j] = true; // start for loop from j = i + i to maxn exclusive adding i to j, and changing prime[j] to true on each iteration
    } 
  } 
  int p, q; // declare new integer variables p and q
  cin >> p >> q; // read variables p and q from the input
  int pi = 0, rub = 0; // declare new int variables pi and rub = 0
  int ans = 0; // ans is a new integer variable = 0
  for (int i = 1; i < maxn; i++) { // for integer i = 1 to maxn exclusive
    string num = ""; // declare string variable num with value ""
    int x = i; // create integer x with value i
    while (x) { // while x is not 0
      num += (char)(x % 10 + '0'); // append x % 10 + '0' to num
      x /= 10; // change the value of x to x divided by 10
    } 
    if (palindrome(num)) rub++; // if palindrome(num) is true, increment rub
    if (!prime[i]) pi++; // if prime[i] is false, increment pi by one
    if (pi * q <= rub * p) ans = i; // if pi * q <= rub * p, change the value of ans to i
  } 
  if (ans == 0) // if ans is equal to 0
    cout << "Palindromic tree is better than splay tree" << '\n'; // print "Palindromic tree is better than splay tree" and '\n' to the standard output
  else // else
    cout << ans << '\n'; // print ans and '\n' to the standard output
  return 0; 
} 