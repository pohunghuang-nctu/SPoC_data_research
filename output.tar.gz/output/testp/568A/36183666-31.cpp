
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int maxn = 2e6 + 10; // maxn=2000010
const int eps = 1e-14; // eps=1e-14
const int mod = 1e9 + 7; // mod=1000000007
const long long inf = 1e18; // inf=10^18
int pri[maxn]; // pri=array of maxn int
int a[500]; // a=array of 500 int
int npri[maxn], npal[maxn]; // npri and npal = array of maxn int
void getprime() { // function getprime (no args, no return value)
  memset(pri, 0, sizeof pri); // fill pri with 0
  for (int i = 2; i < maxn; i++) { // for i=2 to maxn exclusive
    if (!pri[i]) { // if not pri[i]
      for (int j = 2 * i; j < maxn; j += i) pri[j] = 1; // for j=2*i to maxn by i exclusive pri[j]=1
    } 
  } 
} 
int getpal(int x) { // function getpal (get int x, return int)
  int cnt = 0; // cnt=0
  while (x) { // while x
    a[cnt++] = x % 10; // a[cnt]=x modulo 10, increment cnt
    x /= 10; // divide x by 10
  } 
  for (int i = 0; i < cnt / 2; i++) { // for i=0 to cnt/2 exclusive
    if (a[i] != a[cnt - i - 1]) return 0; // if a[i] is not a[cnt-i-1] return 0
  } 
  return 1; // return 1
} 
void solve() { // function solve (no args, no return value)
  for (int i = 2; i < maxn; i++) { npri[i] = npri[i - 1] + (pri[i] == 0); } // for i=2 to maxn exclusive npri[i]=npri[i-1]+(pri[i] is 0)
  for (int i = 1; i < maxn; i++) { npal[i] = npal[i - 1] + getpal(i); } // for i=1 to maxn exclusive npri[i]=npri[i-1]+getpal(i)
} 
int main() { 
  getprime(); // getprime()
  solve(); // solve()
  int p, q; // p,q=int
  cin >> p >> q; // read p,q
  for (int i = maxn - 1; i >= 0; i--) { // for i=maxn-1 down to 0 inclusive
    if (q * npri[i] <= npal[i] * p) { // if q*npri[i] <= npal[i]*p
      cout << i << endl; // print i
      return 0; 
    } 
  } 
  cout << "Palindromic tree is better than splay tree" << endl; // print "Palindromic tree is better than splay tree"
  return 0; 
} 