
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int maxn = 2e6 + 10; // declare constant integer maxn = 2e6 + 10
int pri[maxn], pal[maxn], c[10]; // declare integer arrays pri size maxn, pal size maxn, c size 10
bool vis[maxn]; // declare boolean array vis size maxn
bool check(int k) { // declare check with integer k as argument, returning boolean
  int cnt = 0; // declare integer cnt = 0
  while (k) { // while k is true
    c[cnt++] = k % 10; // let c[increment cnt] be k % 10
    k /= 10; // let k be k / 10
  } 
  for (int i = 0; i < cnt; i++) // for i = 0 to cnt exclusive
    if (c[i] != c[cnt - i - 1]) return false; // if c[i] is not c[cnt-i-1], return false from function
  return true; // return true
} 
void init() { // declare init with no arguments, returning void
  memset(vis, false, sizeof vis); // set bytes from vis to size of vis to value false
  memset(pri, 0, sizeof pri); // set bytes from pri to size of pri to value 0
  memset(pal, 0, sizeof pal); // set bytes from pal to size of pal to value 0
  pal[1] = 1; // let pal[1] be 1
  for (int i = 2; i < maxn; i++) { // for i = 2 to maxn exclusive
    pri[i] = pri[i - 1]; // let pri[i] be pri[i-1]
    pal[i] = pal[i - 1]; // let pal[i] be pal[i-1]
    if (!vis[i]) { // if vis[i] is false
      pri[i]++; // increment pri[i]
      for (int j = 2; j * i < maxn; j++) vis[i * j] = true; // for j = 2 to j * i is less than maxn,incrementing j, let vis[i*j] be true
    } 
    if (check(i)) pal[i]++; // if result of run check(i) is true, increment pal[i]
  } 
} 
int main() { 
  init(); // run init
  long long p, q, ans = 0; // declare long longs p, q, ans = 0
  cin >> p >> q; // read p, q
  for (int i = maxn - 1; i >= 1 && !ans; i--) // for i = maxn - 1 to i is greater than or equal to 1 ad not ans, decrementing i
    if (q * pri[i] <= p * pal[i]) ans = i; // if (q * pri[i] is less than or equal to p * pal[i], let ans be i
  cout << ans << endl; // print ans and newline
  return 0; 
} 