
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long MOD = 1000000007; // declare long long MOD = 1000000007
vector<long long> primes; // declare long long vector primes
void sieve_of_eratosthenes(long long n) { // declare sieve_of_eratosthenes with long long n as argument, returning void
  primes.resize(n); // resize primes to size n
  for (long long i = 2; i < n; ++i) primes[i] = i; // for i = 2 to n exclusive, let primes[i] be i
  for (long long i = 2; i * i < n; ++i) // for i = 2 to i * i is less than n, incrementing i
    if (primes[i]) // if primes[i] is true
      for (long long j = i * i; j < n; j += i) primes[j] = 0; // for j = i * i to n exclusive, incrementing j by i, let primes[j] be 0
  for (long long i = 1; i < n; i++) { // for i= 1 to n exclusive
    if (primes[i] == i) { // if primes[i] is i
      primes[i] = primes[i - 1] + 1; // let primes[i] be primes[i-1] + 1
    } else { // else
      primes[i] = primes[i - 1]; // let primes[i] be primes[i-1]
    } 
  } 
} 
vector<long long> pa; // declare long long vector pa
vector<long long> t; // declare long long vector t
bool p(long long a) { // declare p with long long a as argument, returning boolean
  t.clear(); // remove all elements from t
  while (a > 0) { // while a is greater than 0
    t.push_back(a % 10); // add ( a % 10 ) to end of t
    a /= 10; // let a be a / 10
  } 
  for (long long i = 0; i < t.size() / 2; i++) { // for i = 0 to size of t / 2 exclusive
    if (t[i] != t[(long long)t.size() - 1 - i]) return false; // if t[i] is not t[long long casted size of t - 1 - i ], return false from function
  } 
  return true; // return true
} 
int main() { 
  long long P, Q; // declare P, Q as long long
  cin >> P >> Q; // read P and Q
  long long MX = 1300000; // declare MX = 1300000 as long long
  sieve_of_eratosthenes(MX); // run sieve_of_eratosthenes(MX)
  pa.resize(MX, 0); // resize pa to size MX, filling new empty with 0
  for (long long i = 1; i < pa.size(); i++) { // for i = 1 to size of pa exclusive
    if (p(i)) // if result of run p with i as argument is true
      pa[i] = pa[i - 1] + 1; // let pa[i] be pa[i-1]+1
    else // else
      pa[i] = pa[i - 1]; // let pa[i] be pa[i-1]
  } 
  for (long long i = MX - 1; i > 0; i--) { // for i = MX - 1 to 0 exclusive, decrementing i
    if (Q * primes[i] <= P * pa[i]) { // if Q * primes[i] is less than or equal to P * pa[i]
      cout << i << endl; // print i and newline
      return 0; 
    } 
  } 
  cout << "Palindromic tree is better than splay tree" << endl; // print "Palindromic tree is better than splay tree" and newline
} 