
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // n = integer
  cin >> n; // read n
  int a[n], b[n]; // a = b = integer array of size n
  for (int i = 0; i < n; i++) { cin >> a[i] >> b[i]; } // for i = 0 to n exclusive, then read a[i], b[i]
  int c = n; // c = integer = n
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    for (int j = 0; j < n; j++) { // for j = 0 to n exclusive
      if (a[i] == b[j] && i != j) { // if a[i] is b[j] and i is not j
        c--; // decrease c by 1
        break; // exit the for loop
      } 
    } 
  } 
  cout << c << endl; // print c
} 