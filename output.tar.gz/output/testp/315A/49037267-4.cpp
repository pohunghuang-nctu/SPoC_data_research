
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n; // n =integer
  cin >> n; // Read n
  int a[n], b[n]; // a, b = array of n integers each
  for (int i = 0; i < n; i++) { cin >> a[i] >> b[i]; } // read n values into array a and array b
  int ans = 0; // ans = integer with 0
  for (int j = 0; j < n; j++) { // for j = 0 to n exclusive
    for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
      if (i != j && a[j] == b[i]) { // if i is not j and a[j] is b[i]
        ans++; // increment ans
        break; // Terminate the loop
      } 
    } 
  } 
  cout << n - ans << endl; // print n - ans and a new line
} 