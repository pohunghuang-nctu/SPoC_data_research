
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int arr1[110]; // arr1= array of integer of size 110
int arr2[110]; // arr2 =array of integer of size 110
int main() { 
  int i, j, ind = 0, count = 0, n; // create integr i,j,ind,count ,n with value ind=0 and count=0
  cin >> n; // read n
  for (i = 1; i <= n; ++i) cin >> arr1[i] >> arr2[i]; // read n values of array arr1 and arr2
  for (i = 1; i <= n; ++i) { // for i=1 to n inclusive
    ind = 0; // set ind=0
    for (j = 1; j <= n; ++j) { // for j=1 to n inclusive
      if (i != j) { // if i is not equal to j
        if (arr2[j] == arr1[i]) ind = 1; // if arr2[j] = arr1[i] then set ind=1
      } 
    } 
    if (!ind) count++; // if ind is false then increment count
  } 
  cout << count << endl; // print count
  return 0; 
} 