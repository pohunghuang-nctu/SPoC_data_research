
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long i, j = 0, a[1000], b[1001], n, l = 0; // declare long longs i, j = 0, n, l = 0, declare long long array a size 1000, b size 1001
  cin >> n; // read n
  for (i = 0; i < n; i++) { cin >> a[i] >> b[i]; } // for i = 0 to n exclusive, read a[i] and b[i]
  for (i = 0; i < n; i++) { // for i = 0 to n exclusive
    for (j = 0; j < n; j++) { // for j = 0 to n exclusive
      if (j != i && a[i] == b[j]) { // if j is not i and a[i] is b[j]
        l++; // increment l
        break; // end loop
      } 
    } 
  } 
  cout << n - l << endl; // print n - l and newline
  return 0; 
} 