
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int maxn = 110; // declare constant integer maxn = 110
int a[maxn], b[maxn]; // declare integer arrays a size maxn, b size maxn
int vis[1010]; // declare integer array vis size 1010
int main() { 
  int n; // declare integer n
  int cnt = 0; // declare integer cnt = 0
  cin >> n; // read n
  memset(vis, 0, sizeof(vis)); // set bytes from vis to size of vis to value 0
  for (int i = 0; i < n; i++) { cin >> a[i] >> b[i]; } // for i = 0 to n exclusive, read a[i] and b[i]
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    for (int j = 0; j < n; j++) { // for j = 0 to n exclusive
      if (i == j) continue; // if i is j, end current loop iteration
      if (a[i] == b[j]) vis[i] = 1; // if a[i] is b[j], let vis[i] be 1
    } 
  } 
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    if (vis[i] == 1) cnt++; // if vis[i] is 1, increment cnt
  } 
  cout << n - cnt << endl; // print n - cnt and newline
  return 0; 
} 