
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, k, a[1010], b[1010], mark[1010] = {0}; // declare ints n and k, and int arrays a, b and mark with 1010 elements; mark is filled with 0
  cin >> n; // read from the input to n
  for (int i = 1; i <= n; i++) cin >> a[i] >> b[i]; // read n values from the input to a[i] and b[i], starting from the index 1
  for (int i = 1; i <= n; i++) // in a for loop, change i from 1 to n inclusive
    for (int j = 1; j <= n; j++) // for j from 1 to n inclusive
      if (i != j) { // if i != j
        if (a[i] == b[j]) mark[i] = 1; // if a[i] is equal to b[j], assign 1 to mark[i]
      } 
  int ans = 0; // ans is a new integer variable = 0
  for (int i = 1; i <= n; i++) // in a for loop, change i from 1 to n inclusive
    if (!mark[i]) ans++; // if mark[i] is false, increment ans
  cout << ans << "\n"; // print ans and "\n" to the standard output
  return 0; 
} 