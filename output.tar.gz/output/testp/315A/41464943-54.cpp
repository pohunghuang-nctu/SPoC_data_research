
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int open[100005]; // declare new array of integers open with size 100005
int main() { 
  int n; // create integer variable n
  int cnt = 0; // define new integer called cnt with value 0
  cin >> n; // read from the input to n
  int a[100005], b[100005], c[100005]; // define integer arrays a, b and c with size 100005
  for (int i = 0; i < n; i++) { cin >> a[i] >> b[i]; } // read n elements into variables a and b
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    for (int j = 0; j < n; j++) { // in a for loop, increment j from 0 to n exclusive
      if (b[i] == a[j] && i != j) { c[j] = 1; } // if b[i] = a[j] and i != j, set c[j] to 1
    } 
  } 
  for (int i = 0; i < n; i++) { // for integer i = 0 to n exclusive incrementing i
    if (c[i] == 0) { cnt++; } // if c[i] is equal to 0, increment cnt
  } 
  cout << cnt << endl; // print cnt
} 