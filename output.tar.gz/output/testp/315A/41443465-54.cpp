
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int n; // declare new integer variable n
int main() { 
  cin >> n; // read variable n from the input
  int ar[n], br[n]; // declare an arrays of integers ar and br with n elements
  for (int j = 0; j < n; j++) { cin >> ar[j] >> br[j]; } // read n new elements to ar and br in a loop
  int c = 0; // create new integer c with value 0
  for (int j = 0; j < n; j++) { // start for loop from j = 0 to n exclusive
    for (int i = 0; i < n; i++) { // in a for loop, change i from 0 to n exclusive
      if (i != j && ar[j] == br[i]) { // if i != j and ar[j] = br[i]
        c++; // increment c
        break; // break the loop
      } 
    } 
  } 
  cout << n - c << endl; // print n - c
} 