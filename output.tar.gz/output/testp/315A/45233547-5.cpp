
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, a[1001], b[1001], num; // n, a, b, num = integers with a, b = integer array of size 1001
  cin >> n; // read n
  num = n; // num = n
  for (int i = 1; i <= n; i++) { cin >> a[i] >> b[i]; } // for i = 1 to n, read a[i], b[i]
  for (int j = 1; j <= n; j++) { // for j = 1 to n
    for (int i = 1; i <= n; i++) { // for i = 1 to n
      if (i == j) { continue; } // if (i is j), continue next iteration
      if (b[j] == a[i]) { // if (b[j] is a[i])
        num--; // decrement num
        a[i] = 0; // a[i] = 0
      } 
    } 
  } 
  cout << num << endl; // print num
  return 0; 
} 