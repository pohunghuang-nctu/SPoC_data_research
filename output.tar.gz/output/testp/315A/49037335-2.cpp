
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int arr1[110]; // arr1 = array of integers of length 110
int arr2[110]; // arr2 = array of integers of length 110
int main() { 
  int i, j, ind = 0, count = 0, n; // let i, j, ind , count , n be integers with ind = 0, count = 0
  cin >> n; // read n
  for (i = 1; i <= n; ++i) cin >> arr1[i] >> arr2[i]; // for i = 1 to n inclusive , read arr1[i] , arr2[i]
  for (i = 1; i <= n; ++i) { // for i = 1 to n inclusive
    ind = 0; // ind is equal to 0
    for (j = 1; j <= n; ++j) { // for j = 1 to n inclusive
      if (i != j) { // if i is not equal to j
        if (arr2[j] == arr1[i]) ind = 1; // if arr2[j] is equal to arr1[i] , ind is equal to 1
      } 
    } 
    if (!ind) count++; // if not ind , increment count by 1
  } 
  cout << count << endl; // print count and newline
  return 0; 
} 