
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int maxn = 105; // maxn = constant integer = 105
int a[maxn]; // a = integer array of size maxn
int b[maxn]; // b = integer array of size maxn
int vis[maxn]; // vis = integer array of size maxn
int main() { 
  int n; // n = integer
  int num = 0; // num = integer = 0
  cin >> n; // read n
  for (int i = 0; i < n; i++) { cin >> a[i] >> b[i]; } // for i = 0 to n exclusive, read a[i], b[i]
  memset(vis, 0, sizeof(vis)); // set all element of vis to 0
  for (int i = 0; i < n; i++) // for i = 0 to n exclusive
    for (int j = 0; j < n; j++) { // for j = 0 to n exclusive
      if (i != j && b[i] == a[j]) vis[j] = 1; // if i is not j and b[i] is a[j], then vis[j] = 1
    } 
  for (int i = 0; i < n; i++) num += vis[i]; // for i = 0 to n exclusive, then num = num + vis[i]
  cout << n - num << endl; // print n - num
  return 0; 
} 