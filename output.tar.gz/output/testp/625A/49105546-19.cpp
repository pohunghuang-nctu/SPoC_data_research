
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int len = 1e2 + 5; // let len a constant int with value 1e2 + 5
const long long mod = 1e9 + 7; // let mod a constant long long with value 1e9 + 7
const double pi = acos(-1.0); // let pi a constant double with value acos(-1.0)
int main() { 
  long long n, a, b, c; // let n, a, b, c long longs
  cin >> n >> a >> b >> c; // read n, a, b, and c
  if (a <= b - c) // if a at most b - c
    cout << n / a << endl; // print n / a
  else { // otherwise
    if (n < b) { // if n < b
      cout << n / min(a, b) << endl; // print n / min(a, b)
      return 0; 
    } 
    long long ans = 0; // let ans a long long with value 0
    n -= b; // subtract b from n
    ans += n / (b - c); // add n / (b - c) to ans
    n = n % (b - c); // set n to n mod (b - c)
    ans++; // increment ans
    n += c; // add c to n
    ans += n / min(a, b); // add n / min(a, b) to ans
    cout << ans << endl; // print ans
  } 
} 