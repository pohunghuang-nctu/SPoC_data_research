
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int INF_INT = 2147483647; // create constant integer INF_INT = 2147483647
const long long INF_LL = 9223372036854775807LL; // create new constant long long INF_LL with value 9223372036854775807LL
const unsigned long long INF_ULL = 18446744073709551615Ull; // declare new unsigned long long constant INF_ULL = 18446744073709551615Ull
const long long P = 92540646808111039LL; // define new constant long long P with value 92540646808111039LL
const long long maxn = 1e5 + 10, MOD = 1e9 + 7; // declare long long constants maxn = 1e5 + 10 and MOD = 1e9 + 7
const int Move[4][2] = {-1, 0, 1, 0, 0, 1, 0, -1}; // create new 2d array of integers Move, with size 4 by 2 and filled by values -1, 0, 1, 0, 0, 1, 0, -1
const int Move_[8][2] = {-1, -1, -1, 0, -1, 1, 0, -1, 0, 1, 1, -1, 1, 0, 1, 1}; // define 2d array of integers Move_ 8 by 2 elements, filled by values -1, -1, -1, 0, -1, 1, 0, -1, 0, 1, 1, -1, 1, 0, 1 and 1
inline int read() { // define inlined function read that returns integer
  int x = 0, f = 1; // create new integers x = 0 and f = 1
  char ch = getchar(); // create character variable with name ch and value read from the input
  while (ch < '0' || ch > '9') { // while ch is not a digit
    if (ch == '-') f = -1; // if ch is equal to '-', set f to - 1
    ch = getchar(); // change ch to character from the input
  } 
  while (ch >= '0' && ch <= '9') { // while ch is a digit character
    x = x * 10 + ch - '0'; // change the value of x to x * 10 + ch - '0'
    ch = getchar(); // change ch to char from the input
  } 
  return x * f; // return x multiplied by f
} 
void init() {} // void function init
int main() { 
  init(); // call function init()
  long long n, a, b, c; // declare long long variables n, a, b and c
  cin >> n >> a >> b >> c; // read n, a, b and c from the user input
  if (n < b) { // if n is less than b
    cout << n / a << endl; // print n / a
    return 0; 
  } 
  if (a <= b - c) { // if a <= b - c
    if (n % a >= b) { // if n % a >= b
      cout << (n / a) + 1 + ((n % a) - b) / (b - c) << endl; // print (n / a) + 1 + ((n % a) - b) / (b - c)
      return 0; 
    } else // else
      cout << (n / a) << endl; // print n / a
    return 0; 
  } else { // else
    long long t = 1 + (n - b) / (b - c); // create long long variable t with value 1 + (n - b) / (b - c)
    n -= t * (b - c); // decrease n by t * (b - c)
    cout << t + n / a << endl; // print t + n / a
  } 
  return 0; 
} 