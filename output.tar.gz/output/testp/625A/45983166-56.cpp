
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

unsigned long long n, a, b, c; // let n, a, b, c be unsigned long long
int main() { 
  cin >> n >> a >> b >> c; // read n, a, b, c
  if (a <= b - c) { // if a <= b - c
    cout << n / a << endl; // print out n/a with newline
  } else { // else
    unsigned long long ans = 0; // let ans be unsigned long long with ans = 0
    if (n > c) ans = (n - c) / (b - c); // if n > c, set ans to (n-c) / (b-c)
    ans += (n - ans * (b - c)) / a; // increment ans by (n - ans * (b-c)) / a
    cout << ans << endl; // print ans
  } 
  return 0; 
} 