
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, a, b, c; // declare long longs n, a, b, c
  while (cin >> n) { // while read n is true
    cin >> a >> b >> c; // read a, b, c
    long long cnt = 0; // declare long long cnt = 0
    if (b - c >= a || (b - c < a) && (n < b)) // if b - c is greater than or equal to a or b - c is less than a and n is less than b
      cnt += n / a; // increment cnt by n / a
    else { // else
      cnt += (n - b) / (b - c) + 1; // increment cnt by (n - b) / (b - c) + 1
      n -= cnt * (b - c); // decrement n by cnt * ( b - c )
      cnt += n / a; // increment cnt by n / a
    } 
    cout << cnt << endl; // print cnt and newline
  } 
  return 0; 
} 