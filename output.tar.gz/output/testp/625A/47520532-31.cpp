
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, a, b, c, ans; // n,a,b,c,ans=long long
  cin >> n >> a >> b >> c; // read n,a,b,c
  ans = n / a; // ans=n/a
  if (n >= c) ans = max(ans, (n - c) / (b - c) + (n - (n - c) / (b - c) * (b - c)) / a); // if n>=c ans=max(ans, (n-c)/(b-c)+(n-(n-c)/(b-c)*(b-c))/a)
  cout << ans << endl; // print ans
  return 0; 
} 