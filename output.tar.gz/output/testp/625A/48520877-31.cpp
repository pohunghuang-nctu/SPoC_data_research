
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, a, b, c, ans; // n,a,b,c,ans=long long
  while (cin >> n >> a >> b >> c) { // while read n,a,b,c
    ans = n / a; // ans=n/a
    if (n >= b && a > (b - c)) { // if n>=b and a>b-c
      long long t = 1; // t=1
      t += (n - b) / (b - c); // add (n-b)/(b-c) to t
      n -= t * (b - c); // subtract t*(b-c) from n
      t += max(n / a, n / b); // add max(n(a,n/b) to t
      ans = max(ans, t); // ans=max(ans,t)
    } 
    cout << ans << endl; // print ans
  } 
  return 0; 
} 