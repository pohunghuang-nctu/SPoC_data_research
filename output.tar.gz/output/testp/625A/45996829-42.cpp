
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const long long mod = 998244353; // mod = constant long long = 998244353
const int maxn = 2e5; // maxn = constant integer = 2e5
int main() { 
  int t; // t = integer
  long long n, a, b, c; // n, a, b, c are long longs
  cin >> n; // read n
  cin >> a >> b >> c; // read a, b, c
  long long one = a, two = b - c; // one, two are long longs with one = a, two = b - c
  long long sum1 = n / one, yu1 = n % one, ci; // sum1 = long long = n / one, yu1 = long long = n mod 1, ci = long long
  while (yu1 / b > 0) { // while yu1 / b is positive
    ci = (yu1 - c) / two; // set ci to (yu1 - c) / 2
    yu1 = yu1 - ci * two; // set yu1 to yu1 - ci * two
    sum1 += ci; // add ci to sum1
  } 
  long long yu2 = n, sum2 = 0, ans = 0; // yu2 = long long = n, sum2 and ans are long longs both set to 0
  while (yu2 / b > 0) { // while yu2 / b is positive
    ci = (yu2 - c) / two; // set ci to (yu2 - c) / two
    yu2 = yu2 - ci * two; // set yu2 to yu2 - ci * two
    sum2 += ci; // add ci to sum2
  } 
  sum2 += yu2 / one; // add yu2 / one to sum2
  yu2 = yu2 % one; // set yu2 to yu2 mod one
  ans = max(ans, sum2); // set ans to call max with ans, sum2
  ans = max(sum1, ans); // set ans to call max with sum1, ans
  cout << ans << endl; // print ans
  return 0; 
} 