
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const long long mod = 998244353; // declare new constant long long mod = 998244353
const int maxn = 2e5; // define constant integer maxn with value 2e5
int main() { 
  int t; // declare new integer t
  long long n, a, b, c; // create long longs n, a, b and c
  cin >> n; // read standard input to n
  cin >> a >> b >> c; // read user input to a, b and c
  long long one = a, two = b - c; // create long long variables one a and two = b - c
  long long sum1 = n / one, yu1 = n % one, ci; // new long long variables sum1 = n / one, yu1 = n % one, and ci
  while (yu1 / b > 0) { // while yu1 / b > 0
    ci = (yu1 - b) / two; // set the value of ci to (yu1 - b) / two
    if (ci == 0 && yu1 >= b) { // if ci = 0 and yu1 >= b
      if (yu1 / a > 0 && yu1 / a * a < yu1 / b * two) { // if yu1 / a > 0 and yu1 / a * a < yu1 / b * two
        yu1 = yu1 - yu1 / a * a; // set the value of yu1 to yu1 - yu1 / a * a
        sum1 = sum1 + yu1 / a; // change the value of sum1 to sum1 + yu1 / a
      } else { // else
        yu1 -= two; // subtract two from yu1
        sum1++; // increment sum1
      } 
    } else { // else
      yu1 = yu1 - ci * two; // change the value of yu1 to yu1 - ci * two
      sum1 += ci; // change sum1 to sum1 + ci
    } 
  } 
  long long yu2 = n, sum2 = 0, ans = 0; // create new long longs yu2 = n, sum2 = 0 and ans = 0
  while (yu2 / b > 0) { // while yu2 / b > 0
    ci = (yu2 - b) / two; // assign (yu2 - b) / two to ci
    if (ci == 0 && yu2 >= b) { // if ci = 0 and yu2 >= b
      if (yu2 / a > 0 && yu2 / a * a < yu2 / b * two) { // if yu2 / a > 0 and yu2 / a * a < yu2 / b * two
        yu2 = yu2 - yu2 / a * a; // assign yu2 - yu2 / a * a to yu2
        sum2 += yu2 / a; // change sum2 to sum2 + yu2 / a
      } else { // else
        yu2 -= two; // decrease yu2 by two
        sum2++; // increment sum2
      } 
    } else { // else
      yu2 = yu2 - ci * two; // assign the new value = yu2 - ci * two to yu2
      sum2 += ci; // change sum2 to sum2 + ci
    } 
  } 
  sum2 += yu2 / one; // change sum2 to sum2 + yu2 / one
  yu2 = yu2 % one; // set yu2 to yu2 modulo one
  ans = max(ans, sum2); // set ans to max of ans and sum2
  ans = max(sum1, ans); // change the value of ans to max of sum1 and ans
  cout << ans << endl; // print ans
  return 0; 
} 