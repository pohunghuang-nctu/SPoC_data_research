
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const long long mod = 998244353; // mod = 998244353
const int maxn = 2e5; // maxn = 2e5
int main() { 
  int t; // create int t
  long long n, a, b, c; // create long long n, a, b, c
  cin >> n; // read n
  cin >> a >> b >> c; // read a, b and c
  long long one = a, two = b - c; // one = a, two = b - c
  long long sum1 = n / one, yu1 = n % one, ci; // set sum1 = n / one, yu1 = n % one, create long long c1
  while (yu1 / b > 0) { // while yu1 / b > 0
    ci = (yu1 - b) / two; // set ci = (yu1 - b) / two
    if (ci == 0 && yu1 >= b) { // if ci = 0 and yu1 >= b
      if (yu1 / a > 0 && yu1 / a * a < yu1 / b * two) { // if yu1 / a > 0 and yu1 / a * a < yu1 / b * two
        yu1 = yu1 - yu1 / a * a; // set yu1 to yu1 - yu1 / a * a
        sum1 = sum1 + yu1 / a; // assign sum1 + yu1 / a to sum1
      } else { // else
        yu1 -= two; // yu1 = yu1 - two
        sum1++; // increment sum1
      } 
    } else { // else
      yu1 = yu1 - ci * two; // yu1 = yu1 - ci * two
      sum1 += ci; // set sum1 to sum1 + ci
    } 
  } 
  long long yu2 = n, sum2 = 0, ans = 0; // set yu2 = n, sum2 = 0, ans = 0
  while (yu2 / b > 0) { // while yu2 / b > 0
    ci = (yu2 - b) / two; // assign (yu2 - b) / two to ci
    if (ci == 0 && yu2 >= b) { // if ci = 0 and yu2 >= b
      if (yu2 / a > 0 && yu2 / a * a < yu2 / b * two) { // if yu2 / a > 0 and yu2 / a * a < yu2 / b * two
        yu2 = yu2 - yu2 / a * a; // set yu2 to yu2 - yu2 / a * a
        sum2 += yu2 / a; // sum2 = sum2 + yu2/a
      } else { // else
        yu2 -= two; // set yu2 to yu2 - two
        sum2++; // add 1 to sum2
      } 
    } else { // else
      yu2 = yu2 - ci * two; // yu2 = yu2 - ci * two
      sum2 += ci; // assign sum2 + ci to sum2
    } 
  } 
  sum2 += yu2 / one; // set sum2 to sum2 + yu2/one
  yu2 = yu2 % one; // yu2 = yu2 % one
  ans = max(ans, sum2); // ans = max(ans, sum2)
  ans = max(sum1, ans); // ans = max of sum1 and ans
  cout << ans << endl; // print ans
  return 0; 
} 