
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long long n, a, b, c, remaind, c1 = 0, c2 = 0, t1; // create long long n, a, b, c, remaind, t1, set c1 = 0, c2 = 0
  cin >> n >> a >> b >> c; // read n, a, b and c
  if (a > n && b > n) { // if n is less than a and b
    cout << "0" << endl; // print 0
    return 0; 
  } 
  if (n >= a) { // if n >= a
    c1 = n / a; // c1= n/a
    remaind = n % a; // set remaind to n mod a
    if (remaind >= b) { // if remaind >= b
      remaind -= c; // set remaind to remaind - c
      c1 += (remaind / (b - c)); // assign c1 + (remaind / (b - c)) to c1
      t1 = c1 * (b - c); // t1 = c1 * (b - c)
      t1 = remaind - t1; // set t1 = remaind - t1
      t1 += c; // set t1 to t1 + c
      if (t1 >= b) c1++; // if t1 >= b, increment c1
    } 
  } 
  if (n >= b) { // if n >= b
    n = n - c; // n = n-c
    c2 = n / (b - c); // set c2 = n / (b - c)
    t1 = c2 * (b - c); // set t1 = c2 * (b - c)
    t1 = n - t1; // set t1 to n-t1
    t1 += c; // assign t1 + c to t1
    if (t1 >= b) { // if t1 >= b
      c2++; // increment c2
      t1 -= (b - c); // set t1 to t1- b-c
    } 
    if (t1 >= a) { c2 += (t1 / a); } // if t1 >= a, set c2 to c2 + t1/a
  } 
  c1 = max(c1, c2); // c1 = max of c1 and c2
  cout << c1 << endl; // print c1
  return 0; 
} 