
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long n, a, b, c, ans; // n, a, b, c, ans are long integers
int main() { 
  cin >> n >> a >> b >> c; // read n, a, b, c, ans
  if (a < b - c) return cout << n / a << '\n', 0; // if a < b - c, print n / a and stop
  if (n >= b) ans += (n - c) / (b - c); // if n >= b, increase ans by (n - c) / (b - c)
  n -= ans * (b - c); // decrease n by ans * (b - c)
  ans += n / a; // increase ans by n / a
  cout << ans << '\n'; // print ans and newline
} 