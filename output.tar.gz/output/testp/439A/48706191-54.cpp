
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long int a, b = 0, c, d, i, j, k, l, n, m; // declare long integers a, b, c, d, i, j, k, l, n and m with b = 0
  cin >> n >> m; // read n and m
  d = m; // assign value of m to d
  for (i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> a; // read a
    b += a; // increase b by a
  } 
  m -= b; // decrease m by b
  c = m / 10; // c = m / 10
  if (c >= (n - 1) && (b <= d)) { // if c >= (n - 1) and (b <= d)
    cout << m / 5 << endl; // print m / 5
  } else // else
    cout << "-1" << endl; // print "-1"
} 