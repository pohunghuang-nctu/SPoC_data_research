
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int songs[100001]; // let songs be integer array with size 100001
int main() { 
  int n, d; // declare integers n and d
  cin >> n >> d; // read n and d
  for (int i = 0; i < n; i++) { cin >> songs[i]; } // for integer i = 0 to n exclusive
  int replica = d; // declare integer replica = d
  int availabletime = d; // declare integer availabletime = d
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    replica -= songs[i]; // decrease replica by songs[i]
    replica -= 10; // decrease replica by 10
    availabletime -= songs[i]; // decrease availabletime by songs[i]
  } 
  replica += 10; // increase replica by 10
  if (replica < 0) { // if replica is less than 0
    cout << -1 << endl; // print -1
    return 0; 
  } else { // else
    cout << availabletime / 5 << endl; // print availabletime / 5
  } 
} 