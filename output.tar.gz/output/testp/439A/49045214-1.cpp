
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int x, y, songs, sum = 0; // create integers x, y, songs, sum with sum = 0
  cin >> x >> y; // read x read y
  for (int i = 0; i < x; i++) { // for i = 0 to x exclusive
    cin >> songs; // read songs
    sum += songs; // increment sum by songs
  } 
  if (sum + (x - 1) * 10 > y) { // if sum + ( x - 1 ) * 10 is greater than y
    cout << -1 << endl; // print -1 print newline
    return 0; 
  } else { // else
    cout << (y - sum) / 5 << endl; // print ( y - sum ) / 5 print newline
  } 
} 