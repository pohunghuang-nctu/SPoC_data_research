
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

long long sum_mod(long long a, long long b) { // declare sum_mod with long longs a, b as arguments, returning long long
  return (a + b) % 1000000007; // return (a + b) % 1000000007 from function
} 
long long subtract_mod(long long a, long long b) { // declare subtract mod with long longs a, b as arguments, returning long long
  return (a % 1000000007 - b % 1000000007 + 1000000007) % 1000000007; // return (a % 1000000007 - b % 1000000007 + 1000000007) % 1000000007 from function
} 
long long multiply_mod(long long a, long long b) { // declare multiply_mod with long longs a, b as arguments returning long long
  return (a % 1000000007 * b % 1000000007) % 1000000007; // return (a % 1000000007 * b % 1000000007) % 1000000007 from function
} 
long long modInverse(long long x, long long y) { // declare modInverse with long longs x, y as arguments, returning long long
  long long res = 1; // declare long long res with res = 1
  x = x % 1000000007; // set x to x % 1000000007
  while (y > 0) { // while y is greater than 0
    if (y & 1) res = (res * x) % 1000000007; // if y bitwise and 1, set res to (res * x) % 1000000007
    y = y >> 1; // set y to y bitshift right 1
    x = (x * x) % 1000000007; // set x to (x * x) % 1000000007
  } 
  return res; // return res from function
} 
long long divide_mod(long long a, long long b) { // declare divide_mod with long longs a, b as arguments, returning long long
  return (a * modInverse(b, 1000000007 - 2)) % 1000000007; // return (a * modInverse(b, 1000000007 - 2)) % 1000000007 from function
} 
long long gcd(long long a, long long b) { // declare gcd with long longs a, b as arguments, returning long long
  while (b) swap(a %= b, b); // while b is true, swap values between (set a to a % b) and b
  return a; // return a from function
} 
int main() { 
  long long n, d; // create long longs n, d
  cin >> n >> d; // read n read d
  vector<long long> nums(n); // create long long vector nums initialized with n
  long long cnt = 0, t = 0; // create long longs cnt, t, with cnt = 0, t = 0
  ; // end statement
  for (long long i = 0; i < n; ++i) { // for i = 0 to n exclusive
    cin >> nums[i]; // read nums[i]
    t += nums[i]; // increment t by nums[i]
    if (i < n - 1) t += 10; // if i is less than n - 1, increment t by 10
    cnt += nums[i]; // increment cnt by nums[i]
  } 
  if (t > d) // if t is greater than d
    cout << -1 << endl; // print -1 print newline
  else // else
    cout << (d - cnt) / 5 << endl; // print (d-cnt) / 5 print newline
} 