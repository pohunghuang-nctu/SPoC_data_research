
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

void fastIo() {} // declare fastIo with no arguments, returning void
int main() { 
  fastIo(); // run fastIo
  long long n, m; // create long longs n, m
  cin >> n >> m; // read n read m
  long long sum = 0; // create long long sum with sum = 0
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    long long temp; // create long long temp
    cin >> temp; // read temp
    sum += temp; // increment sum by temp
  } 
  if (m - sum < 10 * (n - 1)) // if m - sum is less than 10 * ( n - 1 )
    cout << "-1" << endl; // print "-1" print newline
  else { // else
    sum = m - sum - 10 * (n - 1); // set sum to m - sum - 10 * ( n - 1 )
    long long cnt = (n - 1) * 2; // create long long cnt with cnt = ( n - 1 ) * 2
    cnt += sum / 5; // increment cnt by sum / 5
    cout << cnt << endl; // print cnt print newline
  } 
  return 0; 
} 