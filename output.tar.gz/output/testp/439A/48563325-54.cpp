
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, d; // declare integers n and d
  int total = 0; // create integer total = 0
  int ans = 0; // create integer ans = 0
  cin >> n >> d; // read n and d
  while (n--) { // while n > 0, decrement it and continue the loop
    int tmp; // create integer tmp
    cin >> tmp; // read tmp
    total += tmp; // increase total by tmp
    total += 10; // increase total by 10
    ans += 2; // increase ans by 2
  } 
  total -= 10; // decrease total by 10
  ans -= 2; // decrease ans by 2
  if (total > d) { // if total is greater than d
    ans = -1; // assign value of -1 to ans
  } else { // else
    ans += (d - total) / 5; // increase ans by (d - total) / 5
  } 
  cout << ans << endl; // print ans
  return 0; 
} 