
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, d, i, sum = 0, l = 0; // n, d, i, sum, l =integers with sum, l set to 0
  cin >> n >> d; // Read n and d
  int a[n]; // a=array of n integers
  for (i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> a[i]; // Read a[i]
    sum += a[i]; // set sum to sum + a[i]
  } 
  if (sum + 10 * (n - 1) > d) // if sum + 10 * (n - 1) is greater than d
    cout << -1 << endl; // print -1 and a new line
  else // else do the following
    cout << (d - sum) / 5 << endl; // print (d - sum) / 5 and a new line
} 