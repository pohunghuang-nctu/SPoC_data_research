
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, d, t, aux = 0; // let n, d, t, aux be integers with aux is equal to 0
  cin >> n >> d; // read n and d
  for (int i = 0; i < n; i++) { // for i=0 to n exclusive
    cin >> t; // read t
    aux += t; // aux is equal to (aux+t)
  } 
  if (aux + (n - 1) * 10 > d) { // if (aux + (n - 1) * 10 is greater than d)
    cout << -1 << endl; // print -1 and newline
    return 0; 
  } else { // else do the following
    cout << (d - aux) / 5 << endl; // print ( d - aux ) / 5 and newline
  } 
  return 0; 
} 