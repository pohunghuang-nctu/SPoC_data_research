
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  long int n, d, i; // declare long integer variables n, d and i
  cin >> n >> d; // read n and d
  long int arr[n]; // create long integer array arr with n elements
  for (i = 0; i < n; i++) { cin >> arr[i]; } // read input into arr n times
  long int o = sizeof(arr) / sizeof(arr[0]); // declare long integer o = sizeof(arr) / sizeof(arr[0])
  int initial_sum = 0, flag = 0; // declare integer variables initial_sum and flag = 0
  long int y = accumulate(arr, arr + o, initial_sum); // sum all elements of arr, add it to initial_sum and put it to y
  long int p = 0, count = 0; // create long integers p and count = 0
  for (i = 0; i < n; i++) { // for i = 0 to n exclusive
    if (p + arr[i] <= d) { // if p + arr[i] <= d
      if (i == n - 1) { // if i = n - 1
        flag = 1; // flag = 1
        p = p + arr[i]; // set value of p to p + arr[i]
      } else { // else
        p = p + arr[i]; // set value of p to p + arr[i]
      } 
    } 
    if (p <= d - 5) { // if p <= d - 5
      p = p + 5; // set value of p to p + 5
      count++; // increase count
    } else { // else
      break; // stop the loop
    } 
    if (p <= d - 5) { // if p <= d - 5
      p = p + 5; // set value of p to p + 5
      count++; // increase count by one
    } else { // else
      break; // break the loop
    } 
  } 
  if (flag == 1) { // if flag = 1
    if (p >= d - 5) { // if p >= d - 5
      cout << count << endl; // print count
    } else { // else
      while (p <= d - 5) { // while p <= d - 5
        count++; // increment count
        p = p + 5; // set value of p to p + 5
      } 
      cout << count << endl; // print count
    } 
  } else { // else
    cout << "-1" << endl; // print "-1"
  } 
  return 0; 
} 