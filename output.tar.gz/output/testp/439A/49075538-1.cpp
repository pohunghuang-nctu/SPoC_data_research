
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  clock_t t1, t2; // create clock_ts t1, t2
  t1 = clock(); // set t1 to processor time
  int d, time; // create integers d, time
  cin >> d >> time; // read d read time
  int sum = 0; // create integer sum with sum = 0
  for (int i = 0; i < d; i++) { // for i = 0 to d exclusive
    int x; // create integer x
    cin >> x; // read x
    sum += x; // increment sum by x
  } 
  int rem = time - sum; // create integer rem with rem = time - sum
  int rest = (d - 1) * 10; // create integer rest with rest = ( d - 1 ) * 10
  if (rest > rem) { // if rest is greater than rem
    cout << "-1" // print "-1"
      << "\n"; // print "\n"
  } else { // else
    cout << (rem - rest) / 5 + rest / 5 << "\n"; // print ( rem - rest ) / 5 + rest / 5 print "\n"
  } 
  t2 = clock(); // set t2 to processor time
  float diff = (float)t2 - (float)t1; // create float diff with diff = float casted t2 - float casted t1
  float execution_time = diff / CLOCKS_PER_SEC; // create float execution_time with execution_time = diff / CLOCKS_PER_SEC
} 