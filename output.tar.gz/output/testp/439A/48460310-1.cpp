
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int n, d, sum, ans; // create integers n, d, sum, ans
int main() { 
  cin >> n >> d; // read n read d
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    int x; // create integer x
    cin >> x; // read x
    sum += x; // increment sum by x
  } 
  sum += (n - 1) * 10; // increment sum by (n-1) * 10
  if (sum > d) { // if sum is greater than d
    cout << -1 << endl; // print -1 print newline
    return 0; 
  } else { // else
    ans += (n - 1) * 2; // increment ans by (n-1)*2
  } 
  if ((d - sum) / 5 >= 1) ans += (d - sum) / 5; // if (d-sum)/5 is greater than or equal to 1, increment ans by (d-sum)/5
  cout << ans << endl; // print ans print newline
  return 0; 
} 