
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, d, arr[105]; // declare integers n and d and an array of integers arr with size 105
  cin >> n >> d; // read n and d
  for (int i = 0; i < n; i++) { cin >> arr[i]; } // read n elements into arr
  int sum = 0; // create integer sum = 0
  for (int i = 0; i < n; i++) { sum += arr[i]; } // sum n elements from arr and put them into variable sum
  int x = sum + (n - 1) * 10; // create integer x = sum + (n - 1) * 10
  if (x <= d) // if x <= d
    cout << (d - sum) / 5 << endl; // print (d - sum) / 5
  else // else
    cout << -1 << endl; // print -1
  return 0; 
} 