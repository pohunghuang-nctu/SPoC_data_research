
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, m; // declare integer variables n and m
  cin >> n >> m; // read n and m
  vector<int> v; // declare integer vector v
  for (int i = 0; i < n; i++) { // for integer i = 0 to n exclusive
    int x; // declare integer x
    cin >> x; // read x
    v.push_back(x); // add x into v
  } 
  int sum = 0; // declare integer sum = 0
  for (int i = 0; i < v.size(); i++) { sum = sum + v[i]; } // sum = sum of elements of v
  int a = sum + ((n - 1) * 10); // declare integer variable a = sum + ((n - 1) * 10)
  if (a <= m) { // if a <= m
    int b = m - a; // declare integer variable b = m - a
    cout << ((n - 1) * 2) + (m - a) / 5 << endl; // print ((n - 1) * 2) + (m - a) / 5
  } else // else
    cout << "-1" << endl; // print "-1"
  return 0; 
} 