
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, d, t; // create integers n, d, t
  int a[1000]; // create integer array a with size 1000
  cin >> n >> d; // read n read d
  int jokes = 0; // create integer jokes with jokes = 0
  int mint = 0; // create integer mint with mint = 0
  int restBetween = (n - 1) * 10; // create integer restBetween with restBetween = ( n - 1 ) * 10
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    cin >> a[i]; // read a[i]
    mint += a[i]; // increment mint by a[i]
  } 
  if (mint + restBetween <= d) { // if mint + restBetween is less than or equal to d
    int rem = d - (mint + restBetween); // create integer rem with rem = d - ( mint + restBetween )
    cout << restBetween / 5 + rem / 5 << endl; // print restBetween / 5 + rem / 5 print newline
  } else { // else
    cout << -1 << endl; // print -1 print newline
  } 
  return 0; 
} 