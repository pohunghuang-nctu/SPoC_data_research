
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, d; // n, d = integer
  cin >> n >> d; // read n and d
  int arr[n]; // arr = array of n integers
  int sum = 0; // set sum to 0
  for (int i = 0; i < n; i++) { // for i =0 to n exclusive
    cin >> arr[i]; // read arr[i]
    sum += arr[i]; // sum = sum + arr[i]
  } 
  int T = sum + (n - 1) * 10; // set T to sum + (n - 1) * 10
  if (T > d) { // if T > d
    cout << -1 << endl; // print -1
    return 0; 
  } 
  d = d - sum; // d = d - sum
  d = d / 5; // d = d / 5
  cout << d << endl; // print d
  return 0; 
} 