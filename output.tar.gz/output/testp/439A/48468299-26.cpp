
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, d; // create int n and d
  cin >> n >> d; // read n, d
  int jokes = (n - 1) * 2; // jokes = (n - 1) * 2
  int time_ = jokes * 5, x; // create int x and time_, set time_ to jokes*5
  for (int i = 0; i < n; ++i) { // for i=0 to n exclusive
    cin >> x; // read x
    time_ += x; // assign time_ + x to time_
  } 
  if (time_ > d) { // if time_ greater than d
    cout << -1 << endl; // print -1
    return 0; 
  } else { // else
    cout << jokes + (d - time_) / 5 << endl; // print jokes + (d - time_) / 5 and a newline
  } 
  return 0; 
} 