
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, d, a; // declare integers n, d and a
  cin >> n >> d; // read n and d
  int s = 0; // create integer s = 0
  for (int i = 0; i < n; i++) { // for integer i = 0 to n exclusive
    cin >> a; // read a
    s += a; // increase s by a
  } 
  int x = d - s; // declare integer variable x = d - s
  if (s + (n - 1) * 10 > d) { // if s + (n - 1) * 10 is greater than d
    cout << "-1" << endl; // print "-1"
    return 0; 
  } else { // else
    cout << x / 5 << endl; // print x / 5
    return 0; 
  } 
  return 0; 
} 