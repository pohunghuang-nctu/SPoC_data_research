
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  char a[3], b[3]; // declare character arrays a and b with size 3
  string str1, str2; // declare strings str1 and str2
  while (cin >> str1 >> str2) { // read str1 and str2 and keep looping
    int count(0); // create integer count
    a[0] = '\0'; // change a[0] to '\0'
    b[0] = '\0'; // change b[0] to '\0'
    int index = 0; // declare integer index = 0
    if (1 == str1.length() || str1.length() != str2.length()) { // if length of str1 = 1 or length of str1 != length of str2
      cout << "NO" << endl; // print "NO"
      continue; // skip the rest of the loop
    } 
    for (int i = 0; i < str1.length(); i++) { // for i = 0 to length of str1 exclusive
      if (str1[i] == str2[i]) // if str1[i] = str2[i]
        continue; // go to the start of the loop
      else { // else
        count++; // increment count
        if (count > 2) { // if count is greater than 2
          cout << "NO" << endl; // print "NO"
          break; // stop the loop
        } 
        a[index] = str1[i]; // set a[index] to str1[i]
        b[index] = str2[i]; // set b[index] to str2[i]
        index++; // increment index by one
        a[index] = '\0'; // change a[index] to '\0'
        b[index] = '\0'; // change b[index] to '\0'
      } 
    } 
    if (count > 2) continue; // if count is greater than 2, go to the start of the loop
    if (a[0] == b[1] && b[0] == a[1]) // if a[0] is equal to b[1] and b[0] is equal to a[1]
      cout << "YES" << endl; // print "YES"
    else // else
      cout << "NO" << endl; // print "NO"
  } 
  return 0; 
} 