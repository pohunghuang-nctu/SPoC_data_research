
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

char s[100005], t[100005]; // let s, t be characters with s = array of characters of length 100005, t = array of characters of length 100005
int vis[2][150]; // vis = 2d array of integers with 2 rows and 150 columns
int main() { 
  while (cin >> s >> t) { // while read s and t
    memset(vis, 0, sizeof(vis)); // memset of vis, 0, length of vis
    int n = strlen(s), m = strlen(t), flag = 0, gc = 0; // let n , m , flag, gc be integers with flag = 0, gc = 0, n = string length of s, m = string length of t
    if (n != m) { // if n is not equal to m
      cout << "NO" << endl; // print NO and newline
    } else { // else do the following
      for (int i = 0; s[i]; i++) { // for i = 0, s[i] is true , increment i by 1
        vis[0][s[i]]++; // increment vis[0][s[i]] by 1
        vis[1][t[i]]++; // increment vis[1][t[i]] by 1
      } 
      for (int i = 0; i < 150; i++) { // for i = 0 to 150 exclusive
        if (vis[0][i] != vis[1][i]) { // if vis[0][i] is not equal to vis[1][i]
          flag++; // increment flag by 1
          break; // stop
        } 
      } 
      if (flag == 0) { // if flag is equal to 0
        if (n == 1) { // if n is equal to 1
          cout << "YES" << endl; // print YES and newline
        } else { // else do the following
          for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
            if (s[i] != t[i]) { gc++; } // if s[i] is not equal to t[i] , increment gc by 1
          } 
          if (gc == 2) { // if gc is equal to 2
            cout << "YES" << endl; // print YES and newline
          } else { // else do the following
            cout << "NO" << endl; // print NO and newline
          } 
        } 
      } else { // else do the following
        cout << "NO" << endl; // print NO and newline
      } 
    } 
  } 
} 