
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  string s1, s2; // create strings s1, s2
  cin >> s1 >> s2; // read s1 read s2
  int count = 0, len1 = s1.size(), len2 = s2.size(), len, b1, b2; // create integers count, len1, len2, len, b1, b2 with count = 0, len1 = size of s1, len2 = size of s2
  len = (len1 < len2) ? len1 : len2; // set len to len1 if len1 is less than len2, else len2
  char a1, a2; // create characters a1, a2
  for (int i = 0; i < len; i++) // for i = 0 to len exclusive
    if (s1.at(i) != s2.at(i)) { // if character at position i in s1 is not character at position i in s2
      count++; // increment count
      if (count == 1) { a1 = s1.at(i), b1 = i; } // if count is 1, set a1 to character at position i in s1, set b1 to i
      if (count == 2) { a2 = s1.at(i), b2 = i; } // if count is 2, set a2 to character at position i in s1, set b2 to i
      if (count == 2) { // if count is 2
        s1.at(b1) = a2; // set character at position b1 in s1 to a2
        s1.at(b2) = a1; // set character at position b2 in s1 to a1
      } 
    } 
  if (count != 2 || s1 != s2) // if count is not 2 or s1 is not s2
    cout << "NO" << endl; // print "NO" print newline
  else // else
    cout << "YES" << endl; // print "YES" print newline
} 