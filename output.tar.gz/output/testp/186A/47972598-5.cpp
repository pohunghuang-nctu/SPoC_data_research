
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  char s1[100005], s2[100005], a[2], b[2]; // s1, s2 = character array of size 100005 and a, b = character array of size 2
  int l1, l2, i, j = 0, cnt = 0; // l1, l2, i, j0, cnt = integers with j = 0, cnt = 0
  cin >> s1 >> s2; // read s1, s2
  l1 = strlen(s1); // l1 = length of string(s1)
  l2 = strlen(s2); // l2 = length of string(s2)
  if (l1 != l2) { // if l1 is not l2
    cout << "NO" << endl; // print NO
    return 0; 
  } else { // else
    for (i = 0; i < l1; i++) { // for i = 0 to l1 exclusive
      if (s1[i] != s2[i]) { // if s1[i] is not s2[i]
        cnt++; // increment cnt
        a[j] = s1[i]; // a[j] = s1[i]
        b[j] = s2[i]; // b[j] = s2[i]
        j++; // increment j
        if (cnt > 2) { // if cnt > 2
          cout << "NO" << endl; // print NO
          return 0; 
        } 
      } 
    } 
  } 
  if (a[1] == b[0] && a[0] == b[1]) { // if a[1] is b[0] and a[0] is b[1]
    cout << "YES" << endl; // print YES
  } else { // else
    cout << "NO" << endl; // print NO
  } 
  return 0; 
} 