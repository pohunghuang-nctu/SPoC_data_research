
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const double PI = acos(-1.0); // PI = const double with PI = acos of -1.0
const double eps = 1e-6; // eps = const double with eps = 1e-6
const int INF = 0x3f3f3f3f; // INF = const int with INF = 0x3f3f3f3f
const int N = 2e5 + 5; // N = const int with N = 2e5 + 5
int main() { 
  string a, b; // a, b = string
  while (cin >> a >> b) { // loop while reading a then b
    bool flag = true; // flag = bool with flag = true
    bool tag = true; // tag = bool with tag = true
    char ch1, ch2, ch3, ch4; // ch1, ch2, ch3, ch4 = char
    bool kk = true; // kk = bool with kk = true
    if (a.size() != b.size()) { // if size of a is not size of b
      kk = false; // set kk to false
    } else { // else
      for (int i(0); i < a.size(); i++) { // for i = 0 to size of a
        if (a[i] != b[i] && flag) { // if a[i] is not b[i] and flag is true
          flag = false; // set flag to false
          ch1 = a[i]; // set ch1 to a[i]
          ch2 = b[i]; // set ch2 to b[i]
        } else if (a[i] != b[i] && tag) { // else if a[i] is not b[i] and tag is true
          tag = false; // set tag to false
          ch3 = a[i]; // set ch3 to a[i]
          ch4 = b[i]; // set ch4 to b[i]
        } else if (a[i] != b[i]) { // else if a[i] is not b[i]
          kk = false; // set kk to false
          break; // break
        } 
      } 
    } 
    if (!kk) // if kk is false
      cout << "NO" << endl; // print "NO"
    else { // else
      if (tag || flag) // if tag or flag is true
        cout << "NO" << endl; // print "NO"
      else if (ch1 == ch4 && ch2 == ch3) // else if ch1 is ch4 and ch2 is ch3
        cout << "YES" << endl; // print "YES"
      else // else
        cout << "NO" << endl; // print "NO"
    } 
  } 
  return 0; 
} 