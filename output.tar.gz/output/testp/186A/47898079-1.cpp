
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, f = 0, cnt = 0, i1, i2; // create integers n, f, cnt, i1, i2 with f = 0, cnt = 0
  string s, s1; // create strings s, s1
  cin >> s >> s1; // read s read s1
  if (s.size() != s1.size()) // if size of s is not size of s1
    cout << "NO" << endl; // print "NO" print newline
  else { // else
    for (int i = 0; i < s.size(); i++) { // for i = 0 to size of s exclusive
      if (s[i] != s1[i]) { // if s[i] is not s1[i]
        if (!f) // if not f
          i1 = i, f = 1; // set i1 to i, set f to 1
        else // else
          i2 = i; // set i2 to i
        cnt++; // increment cnt
      } 
    } 
    if (cnt != 2) // if cnt is not 2
      cout << "NO" << endl; // print "NO" print newline
    else { // else
      if (s[i2] == s1[i1] && s[i1] == s1[i2]) // if s[i2] is s1[i1] and s[i1] is s1[i2]
        cout << "YES" << endl; // print "YES" print newline
      else // else
        cout << "NO" << endl; // print "NO" print newline
    } 
  } 
} 