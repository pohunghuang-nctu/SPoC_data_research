
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  string s, v; // s, v = string
  cin >> s >> v; // read s then v
  if (s.size() != v.size()) { // if size of s is not size of v
    puts("NO"); // print "NO"
  } else { // else
    int at = -1, at2 = -1; // at, at2 = int with at = -1 and at2 = -1
    for (int len = s.size(), i = 0; i < len; ++i) { // for len = size of s, i = 0 to len
      if (s[i] != v[i]) { // if s[i] is not v[i]
        if (at == -1) { // if at is -1
          at = i; // set at to i
        } else { // else
          if (at2 == -1) { // if at2 is -1
            at2 = i; // set at2 to i
            if (s[at] != v[at2] || s[at2] != v[at]) { // if s[at] is not v[at2] or s[at2] is not v[at]
              puts("NO"); // print "NO"
              return 0; 
            } 
          } else { // else
            puts("NO"); // print "NO"
            return 0; 
          } 
        } 
      } 
    } 
    puts(at == -1 ? "YES" : at2 == -1 ? "NO" : "YES"); // if at is -1 print "YES" else if at2 is -1 print "NO" else print "YES"
  } 
  return true & false; // return true bitwise-and false
} 