
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int ct = 0, foo = 1; // declare ints ct = 0 and foo = 1
  string str1, str2; // declare strings str1 and str2
  int arr1[27] = {}, arr2[27] = {}; // create integer arrays arr1 and arr2 with size 27
  cin >> str1 >> str2; // read str1 and str2
  int n1 = str1.size(); // declare int n1 = length of str1
  int n2 = str2.size(); // declare int n2 = length of str2
  if (n1 != n2) { // if n1 != n2
    cout << "NO\n"; // print "NO\n"
    return 0; 
  } else { // else
    for (int i = 0; i < n1; i++) { // for integer i = 0 to n1 exclusive
      if (str1[i] != str2[i]) { ct++; } // if str1[i] != str2[i], increment ct
    } 
    for (int i = 0; i < n1; i++) { // loop i from 0 to n1 exclusive
      int temp1 = str1[i] - 'a'; // declare int temp1 = str1[i] - 'a'
      int temp2 = str2[i] - 'a'; // declare int temp2 = str2[i] - 'a'
      arr1[temp1]++; // increment arr1[temp1]
      arr2[temp2]++; // increment arr2[temp2]
    } 
    for (int i = 1; i <= 26; i++) { // for i from 1 to 26 inclusive
      if (arr1[i] != arr2[i]) foo = 0; // if arr1[i] != arr2[i], set foo to 0
    } 
    if (ct <= 2 && foo == 1) // if ct <= 2 and foo = 1
      cout << "YES\n"; // print "YES\n"
    else // else
      cout << "NO\n"; // print "NO\n"
  } 
} 