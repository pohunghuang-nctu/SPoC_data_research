
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  string a, b; // create strings a, b
  cin >> a >> b; // read a read b
  if (a.size() != b.size()) { // if size of a is not size of b
    cout << "NO" << endl; // print "NO" print newline
    return 0; 
  } 
  vector<int> r; // create integer vector r
  for (int i = 0; i < a.size(); i++) { // for i = 0 to size of a exclusive
    if (a[i] != b[i]) r.push_back(i); // if a[i] is not b[i], add element i to end of r
  } 
  if (r.size() != 2) { // if size of r is not 2
    cout << "NO" << endl; // print "NO" print newline
    return 0; 
  } 
  if (a[r[0]] == b[r[1]] && a[r[1]] == b[r[0]]) // if a[r[0]] is b[r[1]] and a[r[1]] is b[r[0]]
    cout << "YES" << endl; // print "YES" print newline
  else // else
    cout << "NO" << endl; // print "NO" print newline
} 