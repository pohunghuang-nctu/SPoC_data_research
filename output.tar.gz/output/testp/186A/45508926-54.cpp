
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  string str1, str2; // create strings str1 and str2
  int num1[300], num2[300]; // declare an arrays of integers num1 and num2 with size 300
  while (cin >> str1 >> str2) { // read str1 and str2 and keep looping
    if (str1.length() != str2.length()) { // if length of str1 != length of str2
      cout << "NO" << endl; // print "NO"
      continue; // skip the rest of the loop
    } 
    for (int k = 0; k < 300; k++) { // for k from 0 to 300 exclusive
      num1[k] = 0; // assign 0 to num1[k]
      num2[k] = 0; // assign 0 to num2[k]
    } 
    for (int k = 0; k < str1.length(); k++) { // for k = 0 to length of str1 exclusive
      num1[str1[k]]++; // increment num1[str1[k]]
      num2[str2[k]]++; // increment num2[str2[k]]
    } 
    int pan = 0; // declare integer pan = 0
    for (int i = 0; i < 300; i++) { // for i from 0 to 300 exclusive
      if (num1[i] != num2[i]) { // if num1[i] != num2[i]
        cout << "NO" << endl; // print "NO"
        pan = 1; // set pan to 1
        break; // stop the loop
      } 
    } 
    if (pan) continue; // if pan is not 0, skip the rest of the loop
    int count = 0; // create integer count = 0
    for (int i = 0; i < str1.length(); i++) { // loop i from 0 to length of str1 exclusive
      if (str1[i] != str2[i]) count++; // if str1[i] != str2[i], increment count
    } 
    if (count != 2) // if count != 2
      cout << "NO" << endl; // print "NO"
    else // else
      cout << "YES" << endl; // print "YES"
  } 
} 