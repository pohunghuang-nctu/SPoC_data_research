
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

string a, b, c, d; // declare strings a, b, c and d
long long btong; // declare long long btong
int main() { 
  cin >> a >> b; // read input to a and b
  c = a, d = b; // set c to a and d to b
  sort(d.begin(), d.end()); // sort d
  sort(c.begin(), c.end()); // sort c
  if (c != d) { // if c != d
    cout << "NO" << endl; // print "NO"
    return 0; 
  } else { // else
    for (int s = 0; s < a.size(); s++) { // for s from 0 to length of a exclusive
      if (a[s] != b[s]) btong++; // if a[s] != b[s], increment btong
    } 
  } 
  if (btong == 2) // if btong is equal to 2
    cout << "YES" << endl; // print "YES"
  else // else
    cout << "NO" << endl; // print "NO"
} 