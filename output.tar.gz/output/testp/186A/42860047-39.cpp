
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  string a, b; // let a, b = strings
  int c, d, cnt; // let c, d, cnt = integers
  int flag; // let flag = integer
  while (cin >> a >> b) { // while ( read a, b) is true do the following
    if (a.size() != b.size()) { // if the size of a is less than the size of b do the following
      cout << "NO" << endl; // print NO
      continue; // continue at the beginning of the loop
    } else { // else do the following
      flag = 1; // set flag to 1
      cnt = 0; // sent cnt to 0
      for (int i = 0; i < a.size(); i++) { // for i=0 to the size of a exclusive, do the following
        if (a[i] != b[i] && cnt == 0) { // if a[i] is not equal to b[i] and cnt is 0 do the following
          cnt++; // increment cnt
          c = i; // set c to i
        } else if (a[i] != b[i] && cnt == 1) { // else if a[i] is not equal to b[i] and cnt is 1 do the following
          cnt++; // increment cnt
          d = i; // set d to i
        } else if (a[i] != b[i] && cnt == 2) { // else if a[i] is not equal to b[i] and cnt is 2 do the following
          cout << "NO" << endl; // print NO
          flag = 0; // set flag to 0
          break; // exit the loop
        } 
      } 
      if (flag == 0) { // if flag is 0
        continue; // continue at the beginning of the loop
      } else { // else do the following
        if (cnt == 1) { // if cnt is 1 do the following
          cout << "NO" << endl; // print NO
          continue; // continue at the beginning of the loop
        } 
        if (a[c] == b[d] && a[d] == b[c]) { // if a[c] is b[d] and a[d] is b[c]
          cout << "YES" << endl; // print YES
        } else { // else
          cout << "NO" << endl; // print NO
        } 
      } 
    } 
  } 
  return 0; 
} 