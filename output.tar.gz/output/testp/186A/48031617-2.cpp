
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int t = 1; // let t be a integer with t = 1
  while (t--) { // while t is decremented by 1
    string s1, s2; // let s1, s2 be strings
    int cnt = 0; // let cnt be a integer with cnt = 0
    vector<int> ind; // let ind be a vector of integers
    cin >> s1 >> s2; // read s1 , s2
    bool flag = 1; // let the boolean value flag is equal to 1
    if (s1.size() != s2.size()) // if size of s1 is not equal to size of s2
      flag = 0; // set flag to 0
    else { // else do the following
      for (int i = 0; i < s1.size(); i++) { // for i = 0 to size of s1 exclusive
        if (s1[i] != s2[i]) { // if s1[i] is not equal to s2[i]
          cnt++; // increment cnt by 1
          ind.push_back(i); // push back i in vector ind
        } 
        if (cnt > 2) { // if cnt is greater than 2
          flag = 0; // set flag to 0
          break; // stop
        } 
      } 
      if (flag) { // if flag is true
        if (ind.size() == 2) { // if size of ind is equal to 2
          if (!(s1[ind[0]] == s2[ind[1]] && s1[ind[1]] == s2[ind[0]])) flag = 0; // if not s1[ind[0]] is equal to s2[ind[1]] and s1[ind[1]] is equal to s2[ind[0]]), set flag to 0
        } else // else do the following
          flag = 0; // set flag to 0
      } 
    } 
    if (flag) // if flag is true
      cout << "YES" << endl; // print YES and newline
    else // else do the following
      cout << "NO" << endl; // print NO and newline
  } 
} 