
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int freq[130]; // create integer array freq with size 130
vector<int> v; // create integer vector v
int main() { 
  string s, t; // create strings s, t
  cin >> s >> t; // read s read t
  for (int i = 0; i < min(s.size(), t.size()); i++) { // for i = 0 to minimum of ( size of s and size of t ) exclusive
    if (s[i] != t[i]) v.push_back(i); // if s[i] is not t[i], add element i to end of v
    freq[s[i]]++; // increment freq[s[i]]
  } 
  if (v.size() > 2 || v.size() == 1 || s.size() != t.size()) // if size of v is greater than 2 or size of v is 1 or size of s is not size of t
    puts("NO"); // print "NO"
  else if (v.size() == 2) { // else if size of v is 2
    if (s[v[0]] == t[v[1]] && s[v[1]] == t[v[0]]) // if s[v[0]] is t[v[1]] and s[v[1]] is t[v[0]]
      puts("YES"); // print "YES"
    else // else
      puts("NO"); // print "NO"
  } else { // else
    for (int i = 'a'; i <= 'z'; i++) { // for i = 'a' to 'z' inclusive
      if (freq[i] > 1) { // if freq[i] is greater than 1
        puts("YES"); // print "YES"
        return 0; 
      } 
    } 
    puts("NO"); // print "NO"
  } 
  return 0; 
} 