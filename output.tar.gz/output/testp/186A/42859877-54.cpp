
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const double PI = acos(-1.0); // declare constant double PI = acos(-1.0)
const double eps = 1e-6; // declare constant double eps = 1e-6
const int INF = 0x3f3f3f3f; // create const int INF = 0x3f3f3f3f
int gcd(int a, int b) { // gcd is a int function with int arguments a and b
  return a % b == 0 ? b : gcd(b, a % b); // return b if a % b =0, or gcd of b and a % b
} 
int n; // create int n
const int maxn = 60; // declare const int maxn = 60
int main() { 
  string a, b; // declare string variables a and b
  cin >> a >> b; // read a and b
  int num = 0; // declare int num = 0
  char aa[10]; // declare an array of characters aa with size 10
  int j = 0; // create int j = 0
  int len1 = a.size(), len2 = b.size(); // declare integer variable len1 = length of a and len2=length of b
  if (len1 != len2) // if len1 != len2
    cout << "NO" << endl; // print "NO"
  else { // else{
    for (int i = 0; i < len1; i++) { // for integer i = 0 to len1 exclusive
      if (a[i] != b[i]) { // if a[i] != b[i]
        aa[j++] = a[i]; // increment j and set aa[j] to a[i]
        aa[j++] = b[i]; // increment j and set aa[j] to b[i]
        num++; // increment num
      } 
      if (num > 2) break; // if num is greater than 2, break the loop
    } 
    if (num == 2 && (aa[0] == aa[3] && aa[1] == aa[2])) // if num = 2 and aa[0] = aa[3] and aa[1] = aa[2]
      cout << "YES" << endl; // print "YES"
    else // else
      cout << "NO" << endl; // print "NO"
  } 
  return 0; 
} 