
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const double PI = acos(-1.0); // PI = constant double = acos(-1.0)
const double eps = 1e-6; // eps = constant double = 1e-6
const int INF = 0x3f3f3f3f; // inf = constant integer = 0x3f3f3f3f
int main() { 
  string str1, str2; // str1, str2 = strings
  char st1[5], st2[5]; // st1 = character array of size 5, st2 = character array of size 5
  int counter; // counter = integer
  cin >> str1 >> str2; // read str1, str2
  counter = 0; // counter = 0
  if (str1.size() != str2.size()) // if the size of str1 is not the size of str2
    cout << "NO" << endl; // print NO
  else { // else
    for (int i = 0; i < str1.size(); ++i) { // for i = 0 to the size of str1 exclusive
      if (str1[i] != str2[i]) { // if str1[i] is not str2[i]
        if (counter > 2) { // if counter > 2
          cout << "NO" << endl; // print NO
          return 0; 
        } 
        st1[counter] = str1[i]; // st1[counter] = str1[i]
        st2[counter] = str2[i]; // st2[counter] = str2[i]
        ++counter; // increase counter by 1
      } 
    } 
    if (counter > 2) { cout << "NO" << endl; } // if counter > 2, then print NO
    if (counter == 1) cout << "NO" << endl; // if counter is 1, then print NO
    if (counter == 2) { // if counter is 2
      if ((st1[0] == st2[1]) && (st1[1]) == st2[0]) { // if st1[0] is st2[1] and st1[1] is st2[0]
        cout << "YES" << endl; // print YES
      } else // else
        cout << "NO" << endl; // print NO
    } 
    if (counter == 0) cout << "YES" << endl; // if counter is 0, then print YES
  } 
} 