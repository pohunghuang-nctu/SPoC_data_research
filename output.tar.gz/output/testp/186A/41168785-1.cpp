
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

char a[100010], b[100010]; // create character arrays a, b with a size 100010 b size 100010
int i, j = 0, p = -1, q = -1; // create integers i, j, p, q with j = 0, p = -1, q = -1
int main() { 
  gets(a), gets(b); // read a, read b
  for (i = 0; a[i] || b[i]; ++i) // for i = 0 to a[i] or b[i], incrementing i
    if (a[i] != b[i]) // if a[i] is not b[i]
      if (++j, p < 0) // if increment j, p is less than 0
        p = i; // set p to i
      else // else
        q = i; // set q to i
  puts(j == 2 && a[p] == b[q] && a[q] == b[p] ? "YES" : "NO"); // print "YES" if j is 2 and a[p] is b[q] and a[q] is b[p], else "NO"
  return 0; 
} 