
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  string str1, str2; // create strings str1 and str2
  cin >> str1 >> str2; // read str1 and str2
  int len1 = str1.length(); // declare int variable len1 = length of str1
  int len2 = str2.length(); // declare int variable len2 = length of str2
  if (len1 != len2) { // if len1 != len2
    cout << "NO" << endl; // print "NO"
    return 0; 
  } 
  bool flag = false; // declare bool variable flag = false
  int f = 0; // declare integer variable f = 0
  for (int i = 0; i < len1; i++) { // for i = 0 to len1 exclusive
    if (str1[i] != str2[i]) { // if str1[i] != str2[i]
      if (flag == false) { // if flag = false
        f = i; // assign i to f
        flag = true; // set flag to true
      } else { // else
        swap(str2[f], str2[i]); // swap str2[f] and str2[i]
        break; // break the loop
      } 
    } 
  } 
  int temp = str1.compare(str2); // declare int variable temp = result of comparing str1 to str2
  if (temp != 0) { // if temp != 0
    cout << "NO" << endl; // print "NO"
  } else { // else
    cout << "YES" << endl; // print "YES"
  } 
  return 0; 
} 