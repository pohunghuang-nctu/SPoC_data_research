
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

void fastscan(int &x) { // declare fastscan taking in integer &x and returning nothing
  bool neg = false; // create bool neg = false
  register int c; // create register integer c
  x = 0; // set x to 0
  c = getchar(); // set c to getchar()
  if (c == '-') { // if c is equal to '-'
    neg = true; // set neg to true
    c = getchar(); // set c to getchar()
  } 
  for (; (c > 47 && c < 58); c = getchar()) x = (x << 1) + (x << 3) + c - 48; // for c to c > 47 and c < 58, set x to (x << 1) + (x << 3) + c - 48
  if (neg) x *= -1; // if neg is truthy, set x to the result of x * -1
} 
int main() { 
  char s1[100005], s2[100005], a[2], b[2]; // create char arrays s1 of size 100005, s2 of size 100005, a of size 2, b of size 2
  int l1, l2, i, j = 0, cnt = 0; // create integers l1, l2, i, j = 0, cnt = 0
  cin >> s1 >> s2; // read s1 and s2
  l1 = strlen(s1); // set l1 to the length of s1
  l2 = strlen(s2); // set l2 to the length of s2
  if (l1 != l2) { // if l1 is not equal to l2
    cout << "NO" << endl; // print "NO"
    return 0; 
  } else { // else
    for (i = 0; i < l1; i++) { // for i = 0 to 11 exclusive
      if (s1[i] != s2[i]) { // if s1[i] is not equal to s2[i]
        cnt++; // increment cnt
        a[j] = s1[i]; // set a[j] to s1[i]
        b[j] = s2[i]; // set b[j] to s2[i]
        j++; // increment j
        if (cnt > 2) { // if cnt is greater than 2
          cout << "NO" << endl; // print "NO"
          return 0; 
        } 
      } 
    } 
  } 
  if (a[1] == b[0] && a[0] == b[1]) { // if a[1] is equal to b[0] and a[0] is equal to b[1]
    cout << "YES" << endl; // print "YES"
  } else { // else
    cout << "NO" << endl; // print "NO"
  } 
  return 0; 
} 