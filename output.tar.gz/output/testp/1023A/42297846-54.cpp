
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int n, m; // create new integers n and m
string a, b; // declare new string variables a and b
int main() { 
  cin >> n >> m >> a >> b; // read n, m, a and b from the input
  if (n > m) { // if n is greater than m
    for (int i = 0; i < n; i++) // for integer i = 0 to n exclusive
      if (a[i] == '*') { // if a[i] = '*'
        a.erase(i, 1); // erase 1 element at the position i from a
        break; // stop the loop
      } 
    if (a == b) // if a is equal to b
      puts("YES"); // print "YES" to stdout
    else // else
      puts("NO"); // print "NO" to standard output
    return 0; 
  } 
  if (n == m) { // if n = m
    for (int i = 0; i < n; i++) // in a for loop, change i from 0 to n exclusive incrementing i
      if (a[i] != '*') // if a[i] != '*'
        if (a[i] != b[i]) return puts("NO"), 0; // if a[i] != b[i], return puts("NO"), 0
    puts("YES"); // print "YES"
    return 0; 
  } 
  int Now = 0; // create integer Now = 0
  while (a[Now] != '*') { // while a[Now] is not '*'
    if (a[Now] != b[Now]) return puts("NO"), 0; // if a[Now] != b[Now], return puts("NO"), 0
    Now++; // increment Now by one
  } 
  Now = m - 1; // assign the new value = m - 1 to Now
  int now = n - 1; // now is a new integer = n-1
  while (a[now] != '*') { // while a[now] != '*'
    if (a[now] != b[Now]) return puts("NO"), 0; // if a[now] != b[Now], return puts("NO"), 0
    now--; // decrement now by one
    Now--; // decrement Now
  } 
  puts("YES"); // print "YES" to stdout
} 