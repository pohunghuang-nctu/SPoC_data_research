
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

const int maxl = 2e5 + 10; // maxl is a constant integer set to 2e5 + 10
int la, lb; // la, lb are integers
char s[maxl], t[maxl]; // s and t are both character arrays both with size maxl
int main() { 
  cin >> la >> lb >> s >> t; // read la, lb, s, t
  int tar = -1; // tar is an integer set to -1
  for (int i = 0; i < la; ++i) // for i = 0 to la exclusive
    if (s[i] == '*') tar = i; // if s[i] equals the character *, assign i to tar
  if (tar == -1) { // if tar equals -1
    if (la != lb) { // if la isn't lb
      puts("NO"); // display NO
      return 0; 
    } 
    for (int i = 0; i < la; ++i) // for i = 0 to la exclusive
      if (s[i] != t[i]) { // if s[i] isn't t[i]
        puts("NO"); // display NO
        return 0; 
      } 
    puts("YES"); // display YES
    return 0; 
  } 
  if (la - 1 > lb) { // if la - 1 is greater than lb
    puts("NO"); // display NO
    return 0; 
  } 
  for (int i = 0; i < tar; ++i) // for i = 0 to tar exclusive
    if (s[i] != t[i]) { // if s[i] isn't t[i]
      puts("NO"); // display NO
      return 0; 
    } 
  for (int i = 0; la - i - 1 > tar; ++i) // for i = 0 as long as la - i - 1 is greater than tar with increment i
    if (s[la - i - 1] != t[lb - i - 1]) { // if s[la - i - 1] isn't t[lb - i - 1]
      puts("NO"); // display NO
      return 0; 
    } 
  puts("YES"); // display YES
  return 0; 
} 