
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, m, u = 0, e = 0, x = 1, p = 0; // n, m = integer, u = integer = 0, e = integer = 0, x = integer = 1, p = integer = 0
  cin >> n >> m; // read n, m
  string s, t; // s, t = string
  cin >> s >> t; // read s, t
  if (n - 1 > m) { // if n - 1 > m
    cout << "NO" << endl; // print NO
    return 0; 
  } 
  for (int i = 0; i < n; i++) { // for i = 0 to n exclusive
    if (s[i] != t[i] and s[i] != '*') u++; // if s[i] is not t[i] and s[i] is not *
    if (s[i] == '*') { // if s[i] is *
      e = i; // e = i
      p++; // increase p by 1
      break; // exit the for loop
    } 
  } 
  for (int i = n - 1; i > e; i--) { // for i = n - 1 to e exclusive, decrease i by 1
    if (s[i] != t[m - x]) { u++; } // if s[i] is not t[m - x], then increase u by 1
    x++; // increase x by 1
  } 
  if (u >= 1 or n - p > m) // if u >=1 or n - p > m
    cout << "NO" << endl; // print NO
  else if (n < m and p == 0) // else if n < m and p is 0
    cout << "NO" << endl; // print NO
  else // else
    cout << "YES" << endl; // print YES
  return 0; 
} 