
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, m; // n, m = int
  int check_1 = 0, check_2 = 0; // check_1, check_2 = int with check_1 = 0 and check_2 = 0
  char s[200001]; // s = char array of size 200001
  char t[200001]; // t = char array of size 200001
  char ch[2] = "*"; // ch = char array of size 2 with value "*"
  cin >> n >> m; // read n then m
  cin >> s >> t; // read s then t
  if (strstr(s, ch)) { // if s contains ch
    if (m >= (n - 1)) { // if m >= n - 1
      for (int i = 0; s[i] != '*'; i++) { // iterate i while s[i] is not '*'
        if (s[i] == t[i]) { // if s[i] is t[i]
          continue; // continue
        } else { // else
          cout << "NO" << endl; // print "NO"
          return 0; 
        } 
        check_1++; // increment check_1
      } 
      for (int i = n - 1, j = m - 1; s[i] != '*'; i--, j--) { // for i = n - 1, j = m - 1 while s[i] is not '*' decrementing both i and j
        if (s[i] == t[j]) { // if s[i] is t[i]
          continue; // continue
        } else { // else
          cout << "NO" << endl; // print "NO"
          return 0; 
        } 
        check_2++; // increment check_2
      } 
      if (check_1 == (m - check_2)) { // if check_1 is m - check_2
        cout << "YES" << endl; // print "YES"
        return 0; 
      } 
      for (int i = check_1; i < (m - check_2); i++) { // for i = check_1 to m - check_2
        if (isalpha(t[i])) { // if t[i] is a letter
          continue; // continue
        } else { // else
          cout << "NO" << endl; // print "NO"
          return 0; 
        } 
      } 
      cout << "YES" << endl; // print "YES"
    } else { // else
      cout << "NO" << endl; // print "NO"
      return 0; 
    } 
  } else if (strcmp(s, t) == 0) { // else if s is t
    cout << "YES" << endl; // print "YES"
  } else { // else
    cout << "NO" << endl; // print "NO"
    return 0; 
  } 
  return 0; 
} 