
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, m, i = 0; // n, m and i are integers where i = 0
  string s, s1; // declare string variables s and s1
  cin >> n >> m; // read standard input to n and m
  cin >> s >> s1; // read user input to s and s1
  if (s == s1) { // if s = s1
    cout << "YES" << endl; // print "YES"
    return 0; 
  } 
  while (s[i] == s1[i] && i < min(n, m)) i++; // while s[i] is s1[i] and i < min of n and m
  while (s[n - 1] == s1[m - 1] && i < min(n, m)) n--, m--; // while s[n - 1] is s1[m - 1] and i < min of n and m
  cout << (s[i] == '*' && (n - i) == 1 ? "YES" : "NO") << endl; // print "YES" if s[i]= '*' and (n - i) = 1 or "NO" otherwise
} 