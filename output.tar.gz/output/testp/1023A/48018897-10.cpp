
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, m; // n, m = int
  cin >> n >> m; // read n then m
  string s, t; // s, t = string
  cin >> s >> t; // read s then t
  int p = -1; // p = int with p = -1
  int ans = 0; // ans = int with ans = 0
  for (int i = 0; i < n; i++) { // for i = 0 to n
    if (s[i] == '*') { // if s[i] is '*'
      p = i; // set p to i
      break; // break
    } 
  } 
  if (p > -1) { // if p > -1
    if (n > m + 1) // if n > m + 1
      ans = 0; // set ans to 0
    else { // else
      string n1, n2, m1, m2; // n1, n2, m1, m2 = string
      n1 = s.substr(0, p); // set n1 to substr of 0, p on s
      n2 = s.substr(p + 1, n); // set n2 to substr of p + 1, n on s
      m1 = t.substr(0, p); // set m1 to substr of 0, p on t
      m2 = t.substr(m - n2.size(), m); // set m2 to substr of m - size of n2, m on t
      if (n1 == m1 && n2 == m2) // if n1 is m1 and n2 is m2
        ans = 1; // set ans to 1
      else // else
        ans = 0; // set ans to 0
    } 
  } else { // else
    if (s == t) // if s is t
      ans = 1; // set ans to 1
    else // else
      ans = 0; // set ans to 0
  } 
  if (ans == 1) // if ans is 1
    cout << "YES" << endl; // print "YES"
  else // else
    cout << "NO" << endl; // print "NO"
  return 0; 
} 