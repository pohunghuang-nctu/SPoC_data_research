
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int n, m, i, k = -1; // create ints n, m, i, and k = -1
string s, t, s2; // let strings s, t, and s2
int main() { 
  cin >> n >> m >> s >> t; // read n, m, s, and t
  for (i = 0; i < n; i++) // for i = 0 to n exclusive
    if (s[i] == '*') { // if s[i] is equal to '*'
      k = i; // set k to i
      break; // break loop
    } 
  if ((k == -1 && s != t) || n - 1 > m) return cout << "NO" << endl, 0; // if k is equal to -1 and s is not equal to t or if n - 1 is more than m, print "NO" and return 0
  s2 = s.substr(k + 1); // set s2 to s.substr(k + 1)
  n = s2.size(); // set n to s2.size()
  if (s.substr(0, k) != t.substr(0, k) || s2 != t.substr(m - n)) return cout << "NO" << endl, 0; // if s.substr(0, k) is not equal to t.substr(0, k) or s2 is not equal to t.substr(m - n), print "NO" and return 0
  cout << "YES" << endl; // print "YES"
  return 0; 
} 