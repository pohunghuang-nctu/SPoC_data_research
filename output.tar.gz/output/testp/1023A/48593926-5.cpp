
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, m, inds = -1; // n, m, inds = integers with inds = -1
  string s, t; // s, t = strings
  cin >> n >> m >> s >> t; // read n, m, s, t
  for (int i = 0; i < n; ++i) // for i = 0 to n exclusive
    if (s[i] == '*') inds = 1; // if (s[i] is *), inds = 1
  if (inds == -1 && s != t) { // if (inds is -1 and s is not t)
    cout << "NO" << endl; // print NO
    return 0; 
  } 
  if (m + 1 < n) { // if (m + 1 < n)
    cout << "NO" << endl; // print NO
    return 0; 
  } 
  for (int i = n - 1, j = m - 1; i >= 0 && j >= 0; --i, --j) { // for i = n - 1, j = m - 1 down to i >= 0 and j >= 0
    if (s[i] == t[j]) // if (s[i] is t[j])
      s[i] = '*'; // s[i] = *
    else if (s[i] == '*') // else if s[i] is *
      break; // break loop
    else { // else
      cout << "NO" << endl; // print NO
      return 0; 
    } 
  } 
  for (int i = 0; i < s.size(); ++i) { // for i = 0 to s.size() exclusive
    if (s[i] == t[i]) // if (s[i] is t[i])
      s[i] = '*'; // s[i] = *
    else if (s[i] == '*') // else if (s[i] is *
      break; // break loop
  } 
  for (int i = 0; i < n; ++i) { // for i = 0 to n exclusive
    if (s[i] == '*' || s[i] == ' ') // if (s[i] is * or s[i] is ' ')
      continue; // continue next iteration
    else { // else
      cout << "NO" << endl; // print NO
      return 0; 
    } 
  } 
  cout << "YES" << endl; // print YES
} 