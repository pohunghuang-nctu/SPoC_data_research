
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int n, m; // make ints n and m
string a, b; // create strings a and b
int main() { 
  cin >> n >> m >> a >> b; // read n, m, a, and b
  if (n > m) { // if n is greater than m
    for (int i = 0; i < n; i++) // for i = 0 to n exclusive
      if (a[i] == '*') { // if a[i] is equal to '*'
        a.erase(i, 1); // erase index i of a
        break; // break loop
      } 
    if (a == b) // if a is b
      puts("YES"); // print "YES"
    else // else do
      puts("NO"); // print "NO"
    return 0; 
  } 
  if (n == m) { // if n is equal to m
    for (int i = 0; i < n; i++) // for i = 0 to n exclusive
      if (a[i] != '*') // if a[i] is not equal to '*'
        if (a[i] != b[i]) return puts("NO"), 0; // if a[i] is not equal to b[i], print "NO" and return 0
    puts("YES"); // print "YES"
    return 0; 
  } 
  int Now = 0; // create int Now = 0
  while (a[Now] != '*') { // while a[Now] is not equal to '*'
    if (a[Now] != b[Now]) return puts("NO"), 0; // if a[Now] is not equal to b[Now], print "NO" and return 0
    Now++; // increment Now
  } 
  Now = m - 1; // set Now to m - 1
  int now = n - 1; // create int now = n - 1
  while (a[now] != '*') { // while a[now] is not equal to '*'
    if (a[now] != b[Now]) return puts("NO"), 0; // if a[now] is not equal to b[Now], print "NO" and return 0
    now--; // decrease now by 1
    Now--; // reduce Now by 1
  } 
  puts("YES"); // print "YES"
} 