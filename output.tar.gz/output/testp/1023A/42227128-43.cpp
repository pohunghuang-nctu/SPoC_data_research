
#include <string>
#include <iostream>
#include <bits/stdc++.h>
#include "stdio.h"
using namespace std;

int main() { 
  int n, m, i, len, flag = 0; // let n, m, i, len, flag be ints with flag = 0
  string s, x, s1, s2; // s, x, s1, s2 = string
  cin >> n >> m; // read na dn m
  cin >> s >> x; // read s and x
  for (i = 0; i < n; i++) // for i = 0 to n exclusive
    if (s[i] == '*') { // if s[i] = '*'
      flag = 1; // set flag to 1
      break; // exit loop
    } 
  if (n - 1 > m) { // if n-1 > m
    cout << "NO" << endl; // print NO
    return 0; 
  } 
  if (flag) { // if flag isn't 0
    s1 = s.substr(0, i); // set s1 to substring form 0 to i of s
    s2 = s.substr(i + 1, n - i - 1); // set s2 = substring from i+1 to n-i-1 of s
    len = s2.length(); // set len to the length of s2
    if (x.substr(0, i) == s1 && x.substr(m - len, m - i) == s2) // if substring of x form 0 to i = s1 and substring of x form m=len to m-i = s2
      cout << "YES" << endl; // printYES
    else // else
      cout << "NO" << endl; // print NO
  } else { // else
    if (s == x) // if s = x
      cout << "YES" << endl; // print YES
    else // else
      cout << "NO" << endl; // print No
  } 
  return 0; 
} 